import sys, urllib.parse, urllib.request, xml.etree.ElementTree as ET, time
ns={'a':'http://www.w3.org/2005/Atom'}
queries = sys.argv[1:]
for q in queries:
    url = "https://export.arxiv.org/api/query?search_query=" + urllib.parse.quote(q) + "&max_results=12&sortBy=relevance"
    try:
        data = urllib.request.urlopen(url, timeout=40).read()
    except Exception as e:
        print("FAIL", q, e); continue
    t = ET.fromstring(data)
    print("="*100); print("QUERY:", q)
    for e in t.findall('a:entry', ns):
        aid = e.find('a:id', ns).text.split('/abs/')[-1]
        ti = ' '.join(e.find('a:title', ns).text.split())
        pub = e.find('a:published', ns).text[:10]
        au = ', '.join(x.find('a:name', ns).text for x in e.findall('a:author', ns))[:70]
        print(f"  {aid:22s} {pub}  {ti[:88]}")
        print(f"      {au}")
    time.sleep(1.5)
