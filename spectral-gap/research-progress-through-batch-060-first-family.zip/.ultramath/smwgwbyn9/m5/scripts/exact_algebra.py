#!/usr/bin/env python3
"""Exact (sympy) verification of the scalar facts used in proof/reduction.md.

Everything here is exact rational/symbolic arithmetic: no floating point is used
in any identity that the proof relies on.  Floating point appears only in
section 8, where it is labelled NUMERICAL.

Run:  python3 scripts/exact_algebra.py
"""
import sympy as sp

d, D, lam, r = sp.symbols('d Delta lambda r', positive=True)

def hdr(t):
    print("\n===", t, "===")

# ---------------------------------------------------------------- 1. transform
hdr("1. Kesten-McKay transform: exact algebraic form and both branches")
r_of_lam = ((lam - sp.sqrt(lam**2 - 4*(d-1)))/(2*(d-1)))
Gp = sp.simplify(sp.radsimp(r_of_lam/(1 - r_of_lam**2)))
print("G_d from r-parametrisation:", Gp)
target = (-(d-2)*lam + d*sp.sqrt(lam**2 - 4*(d-1)))/(2*(lam**2 - d**2))
print("difference from +branch radical form:",
      sp.simplify(sp.radsimp(Gp - target)))
Q = sp.expand((lam**2 - d**2)*target**2 + (d-2)*lam*target - (d-1))
print("(Q) residual, + branch:", sp.simplify(sp.radsimp(Q)))
Gb = (-(d-2)*lam - d*sp.sqrt(lam**2 - 4*(d-1)))/(2*(lam**2-d**2))
Qm = sp.expand((lam**2 - d**2)*Gb**2 + (d-2)*lam*Gb - (d-1))
print("(Q) residual, - branch:", sp.simplify(sp.radsimp(Qm)))
lamr = (d-1)*r + 1/r
Gr = r/(1 - r**2)
print("(Q) residual with lambda=(d-1)r+1/r, G=r/(1-r^2):",
      sp.simplify((lamr**2 - d**2)*Gr**2 + (d-2)*lamr*Gr - (d-1)))

hdr("2. special values and monotonicity")
Gd_at_d = (d-1)/(d*(d-2))
print("G_d(d) = (d-1)/(d(d-2)) verified via (Q) at lam=d:",
      sp.simplify((d**2-d**2)*Gd_at_d**2 + (d-2)*d*Gd_at_d - (d-1)), "(0 => correct)")
print("G_d(2 sqrt(d-1)) :", sp.simplify(sp.radsimp(target.subs(lam, 2*sp.sqrt(d-1)))),
      " expected:", sp.simplify(sp.sqrt(d-1)/(d-2)))
print("dG/dr  =", sp.simplify(sp.diff(Gr, r)))
print("dlam/dr=", sp.simplify(sp.diff(lamr, r)))
print("exterior branch: r^2 < 1/(d-1) => dlam/dr < 0, dG/dr > 0 => dG/dlam < 0.")

# ---------------------------------------------------------------- 3. finite root
hdr("3. finite-root equation lambda = Delta G_d(lambda): exact closed form")
eq = sp.expand(sp.together(((lam**2 - d**2)*(lam/D)**2 + (d-2)*lam*(lam/D) - (d-1))*D**2))
print("after G = lambda/Delta:  ", eq)
X = sp.symbols('X')
print("as quadratic in lam^2   :", sp.Poly(eq.subs(lam**2, X), X).as_expr())
a = d**2 - (d-2)*D
lamf2 = sp.simplify((a + sp.sqrt(a**2 + 4*(d-1)*D**2))/2)
print("lambda_f^2 (closed form) :", lamf2)
print("check biquartic residual :", sp.simplify(sp.expand(eq.subs(lam**2, lamf2))))
for (dd, DD) in [(3, 6), (3, 3), (3, 4), (4, 7), (5, 8)]:
    val = sp.simplify(lamf2.subs({d: dd, D: DD}))
    print(f"  d={dd} Delta={DD}: lambda_f = {sp.N(sp.sqrt(val), 12)}")

hdr("4. thresholds: h(lambda)=lambda-Delta G_d(lambda) is strictly increasing")
h = lam - D*target
print("h(2 sqrt(d-1)) =", sp.simplify(sp.radsimp(h.subs(lam, 2*sp.sqrt(d-1)))))
print("  => h(edge) < 0 iff Delta > 2(d-2)")
print("h(d) = d - Delta*(d-1)/(d(d-2)) =",
      sp.simplify(d - D*(d-1)/(d*(d-2))))
print("  => h(d) < 0 iff Delta > d^2(d-2)/(d-1)")
print("h' = 1 - Delta G_d' > 1 > 0 since G_d' < 0. So h strictly increasing.")
print("threshold check: lambda_f > 2 sqrt(d-1) iff Delta > 2(d-2).")
for dd in [3, 4, 5]:
    t = sp.symbols('t', positive=True)
    expr = sp.simplify(sp.radsimp(lamf2.subs({d: dd, D: 2*(dd-2) + t}) - 4*(dd-1)))
    print(f"  d={dd}: lambda_f^2-4(d-1) at Delta=2(d-2)+t  ->", sp.factor(expr))

hdr("5. the one-sided tree branch r gives the WRONG threshold 2(d-1)")
print("r(lambda) radical form:", sp.simplify(sp.radsimp(r_of_lam)))
print("r(d) =", sp.simplify(r_of_lam.subs(lam, d)))
print("r(2 sqrt(d-1)) =", sp.simplify(sp.radsimp(r_of_lam.subs(lam, 2*sp.sqrt(d-1)))))
print("edge criterion for lambda = Delta*r : Delta > 2 sqrt(d-1)*sqrt(d-1) = 2(d-1)")
print("=> substituting r for G_d shifts the threshold from 2(d-2) to 2(d-1).")

hdr("6. host-pole multiplicity lemma: exhaustive NUMERICAL check (fast)")
# Lemma: mu eigenvalue of A_G with multiplicity m, P_mu the projector.  Then
#   mult_{G'}(mu) = m-1 if P_mu 1_T != 0;  m+1 if P_mu 1_T = 0 and
#   1_T^T(A-mu)^+ 1_T = -mu;  m otherwise.
# The three named cases are checked in EXACT integer arithmetic below; the
# exhaustive sweep over all graphs with <=5 vertices and all T uses floats.
import itertools, numpy as np
def A_np(nv, edges):
    M = np.zeros((nv, nv))
    for (i, j) in edges:
        M[i, j] = M[j, i] = 1.0
    return M
def spike_np(G, T):
    n = G.shape[0]
    M = np.zeros((n+1, n+1)); M[:n, :n] = G
    for v in T:
        M[n, v] = M[v, n] = 1.0
    return M
def spec_mults(M, tol=1e-8):
    ev = np.linalg.eigvalsh(M)
    out = []
    i = 0
    while i < len(ev):
        j = i
        while j+1 < len(ev) and abs(ev[j+1]-ev[i]) < tol:
            j += 1
        out.append((ev[i], j-i+1)); i = j+1
    return out
bad = checked = 0; cases = {'m-1':0, 'm+1':0, 'm':0}
for nv in (2, 3, 4, 5):
    E = list(itertools.combinations(range(nv), 2))
    for mask in range(1, 2**len(E)):
        edges = [E[i] for i in range(len(E)) if mask >> i & 1]
        G = A_np(nv, edges)
        for D in range(1, nv+1):
            for T in itertools.combinations(range(nv), D):
                Gp = spike_np(G, T)
                one = np.zeros(nv); one[list(T)] = 1.0
                sp_p = spec_mults(Gp)
                for (mu, m) in spec_mults(G):
                    # projector test and pseudo-inverse test, in floats
                    ev, U = np.linalg.eigh(G)
                    ker = U[:, np.abs(ev-mu) < 1e-8]
                    P1 = ker @ (ker.T @ one)
                    if np.linalg.norm(P1) > 1e-7:
                        pred = m-1
                    else:
                        y = np.linalg.lstsq(G-mu*np.eye(nv), one, rcond=None)[0]
                        y = y - ker @ (ker.T @ y)
                        pred = m+1 if abs(one @ y + mu) < 1e-7 else m
                    actual = 0
                    for (v, c) in sp_p:
                        if abs(v-mu) < 1e-7:
                            actual = c
                    checked += 1
                    if pred != actual:
                        bad += 1
                    else:
                        cases['m-1' if pred == m-1 else ('m+1' if pred == m+1 else 'm')] += 1
print("instances checked:", checked, " mismatches:", bad, " case counts:", cases)
print("(all three cases occur, so no case in the lemma is vacuous)")

print("\nnamed examples, EXACT integer arithmetic:")
def cp(M):
    return sp.factor((sp.eye(M.rows)*lam - M).det())
def A_of_edges(n, edges):
    M = sp.zeros(n)
    for (aa, bb) in edges:
        M[aa, bb] = 1; M[bb, aa] = 1
    return M
def spike(G, T):
    n = G.rows
    M = sp.zeros(n+1); M[:n, :n] = G
    for v in T:
        M[n, v] = 1; M[v, n] = 1
    return M
G33 = A_of_edges(6, [(i, j) for i in range(3) for j in range(3, 6)])
print("spec(K33) =", cp(G33), "  spec(K33+spike to one side) =", cp(spike(G33, [0, 1, 2])))
G2 = A_of_edges(2, [(0, 1)])
print("spec(K2) =", cp(G2), "  spec(K2+spike to both) =", cp(spike(G2, [0, 1])))
G4 = A_of_edges(4, [(0,1),(1,2),(2,3),(3,0)])
print("spec(C4) =", cp(G4), "  spec(C4+spike to 0,2) =", cp(spike(G4, [0, 2])))

hdr("7. certificate of the exact secular identity on three graphs")
def secular(G, T):
    n = G.rows
    one = sp.zeros(n, 1)
    for v in T:
        one[v, 0] = 1
    lhs = sp.expand((sp.eye(G.rows+1)*lam - spike(G, T)).det())
    rhs = sp.expand((sp.eye(G.rows)*lam - G).det() * (lam + (one.T * (G - lam*sp.eye(n)).inv() * one)[0, 0]))
    return sp.simplify(lhs - rhs)
print("K33+side:", secular(G33, [0, 1, 2]))
Q3 = A_of_edges(8, [(0,1),(1,2),(2,3),(3,0),(4,5),(5,6),(6,7),(7,4),
                    (0,4),(1,5),(2,6),(3,7)])
print("Q3+5-set:", secular(Q3, [0, 1, 2, 4, 5]))
print("K5+2-set:", secular(A_of_edges(5, list(itertools.combinations(range(5), 2))), [0, 1]))

hdr("8. NUMERICAL only: values of the two algebraic branches near lam=d")
import numpy as np
dd = 3
for L in (2.83, 2.9, 3.0, 3.5, 4.0):
    sq = np.sqrt(L*L - 4*(dd-1))
    if abs(L*L - dd*dd) < 1e-12:
        print(f"  d=3 lambda={L}: 0/0; the limit is G_d(d) = (d-1)/(d(d-2)) = 2/3")
        continue
    print(f"  d=3 lambda={L}: +branch={(-(dd-2)*L + dd*sq)/(2*(L*L-dd*dd)):+.6f}"
          f"  -branch={(-(dd-2)*L - dd*sq)/(2*(L*L-dd*dd)):+.6f}")
print("  the + branch is continuous at lam=d and is G_d; the - branch has a")
print("  simple pole there, so it cannot be the Kesten-McKay transform.")
