"""Exhaustive spectra of all symmetric connection sets of size d in small groups."""
import sys, json
sys.path.insert(0, 'dossier/src')
import numpy as np
import builtins
def pp(*a, **k):
    k.setdefault('flush', True)
    builtins.print(*a, **k)
from cayley import *

np.set_printoptions(precision=12, suppress=False)


def cyc_str(G, S):
    """Cycle-type description of a connection set of permutations."""
    out = []
    for s in S:
        ct = cycle_type(G.els[s])
        out.append(''.join(str(c) for c in ct))
    return sorted(out)


def analyse(G, d, verbose=True, max_print=6):
    sets = G.symmetric_sets(d)
    thr = 2.0 * np.sqrt(d - 1)
    rows = []
    for S in sets:
        if not G.connected(S):
            continue
        ev = G.spectrum(S)
        # Perron
        idx = int(np.argmin(np.abs(ev - d)))
        rest = np.delete(ev, idx)
        lam = float(np.max(np.abs(rest)))
        above = int(np.sum(np.abs(rest) > thr + 1e-12))
        rows.append(dict(S=S, lam=lam, above=above, ev=ev))
    rows.sort(key=lambda r: r['lam'])
    info = dict(group=G.name, n=G.n, d=d, n_total=len(sets), n_connected=len(rows),
                thr=thr,
                lam_min=rows[0]['lam'], lam_max=rows[-1]['lam'],
                n_ramanujan=sum(1 for r in rows if r['lam'] <= thr + 1e-12),
                n_distinct_spectra=len({tuple(np.round(r['ev'], 9)) for r in rows}))
    if verbose:
        pp("=== %s, d=%d : %d symmetric sets, %d connected" % (G.name, d, len(sets), len(rows)))
        pp("    threshold 2 sqrt(d-1) = %.9f" % thr)
        pp("    lambda_min = %.12f   lambda_max = %.12f" % (info['lam_min'], info['lam_max']))
        pp("    # with lambda <= threshold: %d / %d" % (info['n_ramanujan'], len(rows)))
        pp("    # distinct spectra: %d" % info['n_distinct_spectra'])
        for r in rows[:max_print] + rows[-max_print:]:
            r['girth'] = G.girth(r['S'], cap=20)
        pp("    -- smallest lambda:")
        for r in rows[:max_print]:
            pp("       lam=%.9f  above=%d girth=%d  S=%s  spec=%s"
                  % (r['lam'], r['above'], r['girth'], cyc_str(G, r['S']),
                     np.round(r['ev'], 6)))
        pp("    -- largest lambda:")
        for r in rows[-max_print:]:
            pp("       lam=%.9f  above=%d girth=%d  S=%s  spec=%s"
                  % (r['lam'], r['above'], r['girth'], cyc_str(G, r['S']),
                     np.round(r['ev'], 6)))
    return info, rows


if __name__ == '__main__':
    out = []
    for name, G, ds in [('S4', sym_group(4), [3, 4, 5, 6]),
                        ('A5', alt_group(5), [3, 4, 5, 6]),
                        ('S5', sym_group(5), [3, 4])]:
        for d in ds:
            info, rows = analyse(G, d)
            out.append(info)
            pp()
    pp(json.dumps(out, indent=1))
