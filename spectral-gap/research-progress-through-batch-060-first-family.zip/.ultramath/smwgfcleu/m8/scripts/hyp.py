"""Shared helpers: Feng-Li adjacency operator of a k-uniform hypergraph.

A hypergraph is a list of tuples (edges), each of length k, over vertex set range(n).
Repeated tuples are allowed and are counted with multiplicity (they are distinct
hyperedges that happen to share a vertex set).  This is exactly the Feng-Li /
Dumitriu-Zhu convention: A[i][j] = #{e : {i,j} subset e}, A[i][i] = 0.
"""
import numpy as np


def degrees(edges, n):
    d = np.zeros(n, dtype=np.int64)
    for e in edges:
        for v in e:
            d[v] += 1
    return d


def is_regular(edges, n):
    d = degrees(edges, n)
    return len(set(d.tolist())) == 1, d


def incidence(edges, n):
    """n x m 0/1 incidence matrix."""
    m = len(edges)
    X = np.zeros((n, m), dtype=np.int64)
    for j, e in enumerate(edges):
        for v in e:
            X[v, j] = 1
    return X


def fengli(edges, n):
    """Feng-Li adjacency matrix A_H, and incidence X with A_H + d I = X X^T."""
    X = incidence(edges, n)
    A = X @ X.T
    np.fill_diagonal(A, 0)
    return A, X


def spec(A):
    w = np.linalg.eigvalsh(np.asarray(A, dtype=float))
    return w[::-1]  # decreasing


def window(d, k):
    """Li-Sole window for the Feng-Li operator: centre k-2, half-width 2 sqrt((d-1)(k-1))."""
    t = np.sqrt((d - 1) * (k - 1))
    return k - 2 - 2 * t, k - 2 + 2 * t


def components(W):
    n = W.shape[0]
    parent = list(range(n))

    def find(a):
        while parent[a] != a:
            parent[a] = parent[parent[a]]
            a = parent[a]
        return a

    for i in range(n):
        for j in range(i + 1, n):
            if W[i, j] != 0:
                ra, rb = find(i), find(j)
                if ra != rb:
                    parent[ra] = rb
    return len({find(i) for i in range(n)})


def mult_close(vals, c, tol=1e-8):
    return int(np.sum(np.abs(np.asarray(vals) - c) <= tol * max(1.0, abs(c))))


def rank_modp(X, p=2147483647):
    """Exact Gaussian elimination over GF(p), p a large prime.  rank_Q(X) >= rank_modp(X)."""
    import numpy as np
    A = (np.asarray(X, dtype=np.int64) % p).copy()
    rows, cols = A.shape
    r = 0
    for c in range(cols):
        piv = None
        for i in range(r, rows):
            if A[i, c] % p:
                piv = i
                break
        if piv is None:
            continue
        if piv != r:
            A[[r, piv]] = A[[piv, r]]
        A[r] = (A[r] * pow(int(A[r, c]), p - 2, p)) % p
        col = A[:, c].copy()
        col[r] = 0
        if col.any():
            A = (A - np.outer(col, A[r])) % p
        r += 1
        if r == rows:
            break
    return r


def rank_int(X):
    """Rank of an integer matrix.  Exact over Q for small matrices (sympy), otherwise the
    maximum of GF(p) ranks for three large primes, which equals rank_Q unless a maximal
    minor vanishes at all three primes."""
    import numpy as np
    X = np.asarray(X, dtype=np.int64)
    rows, cols = X.shape
    if rows * cols <= 4000:
        import sympy
        return sympy.Matrix(X.tolist()).rank()
    primes = (2147483647, 2147483629, 2147483587)
    return max(rank_modp(X, p) for p in primes)


def config_model_hypergraph(n, d, k, rng, guard=200000):
    """Random d-regular k-uniform hypergraph with no repeated vertex inside an edge.

    Configuration model on the incidence structure (d stubs per vertex, k slots per
    edge, uniform random pairing) followed by 2-switch repair of the O(d(k-1)/2)
    expected duplicate (vertex, edge) pairs.  The repair keeps the degree sequence and
    never increases the number of duplicates, so it terminates.  Repeated vertex SETS
    (multi-hyperedges) are allowed and are counted with multiplicity by the Feng-Li
    operator, and for fixed d,k and n -> infinity their number is O(1) in expectation.
    The local structure is the configuration-model one, i.e. locally tree-like.
    """
    import numpy as np
    assert (n * d) % k == 0, (n, d, k)
    m = (n * d) // k
    slots = np.repeat(np.arange(m), k)
    verts = np.repeat(np.arange(n), d)
    rng.shuffle(verts)
    edges = [[] for _ in range(m)]
    for s, v in zip(slots.tolist(), verts.tolist()):
        edges[s].append(v)
    mult = [e for e in range(m) if len(set(edges[e])) < k]
    steps = 0
    while mult:
        steps += 1
        if steps > guard:
            raise RuntimeError("switch repair did not converge")
        e = mult[0]
        seen = set()
        dup = None
        for v in edges[e]:
            if v in seen:
                dup = v
                break
            seen.add(v)
        fixed = False
        for _ in range(400):
            f = int(rng.integers(m))
            if f == e:
                continue
            sf = set(edges[f])
            if dup in sf:
                continue
            cand = [w for w in edges[f] if w not in seen]
            if not cand:
                continue
            w = cand[int(rng.integers(len(cand)))]
            edges[e][edges[e].index(dup)] = w
            edges[f][edges[f].index(w)] = dup
            fixed = True
            break
        if not fixed:
            raise RuntimeError("no switch partner found")
        mult = [g for g in range(m) if len(set(edges[g])) < k]
    return [tuple(sorted(e)) for e in edges]


def cyclic_interval_hypergraph(q, k):
    """H(q,k): vertex set Z_q, edges {i,i+1,...,i+k-1} mod q, i in Z_q.  d = k, k-uniform."""
    return [(tuple((i + j) % q for j in range(k))) for i in range(q)], q
