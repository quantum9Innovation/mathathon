# Verified literature: what is known, with sources

Labels: **[checked]** means I read the passage in the source during this run.
**[checked, dossier]** means the statement is taken from one of the four local
dossiers, whose quotations I did not re-verify against the PDF in this run.
**[reported]** means secondary or aggregator information that I did not confirm
in a primary source.

## 1. The tree threshold and Alon-Boppana

**Alon-Boppana.** For every $d \ge 3$ and $\varepsilon>0$, every $d$-regular
graph on $n \ge n_0(d,\varepsilon)$ vertices has $\lambda_2 \ge 2\sqrt{d-1} -
\varepsilon$. Standard. Used in the form stated in Mohanty-O'Donnell, Section
2.1. **[checked]**

**Greenberg's theorem, with Serre's strengthening.**
Greenberg (1995), with proofs in Li (1996, Chapter 9, Theorem 13) and
Grigorchuk-Zuk (1999). Quoted verbatim from Mohanty-O'Donnell, Theorem 2.9:
"For any $X$ and any $\epsilon>0$, there is a constant $c>0$ such that for all
$n$-vertex $G \in \mathrm{FinQuo}(X)$ it holds that at least $cn$ eigenvalues
from $\mathrm{spec}(G_n)$ are at least $\rho(X)-\epsilon$." The paper adds:
"One strengthening (usually attributed to Serre [Ser97]) says that for any
$k\ge2$, there are only finitely many $\Delta$-regular $G$ with $\lambda_k(G)
\le \rho(T_\Delta)-\epsilon$." **[checked]** (Mohanty-O'Donnell
arXiv:1904.03500v2, Section 2.1, and the text file `lit/modonn.txt` lines
190-220.)

**Feng-Li for biregular trees.** Quoted verbatim: "It holds that
$\chi(T_{\Delta_1,\Delta_2}) = \sqrt{\Delta_1\Delta_2}$ and
$\rho(T_{\Delta_1,\Delta_2}) = \sqrt{\Delta_1-1}+\sqrt{\Delta_2-1}$.
Feng and Li showed the Alon-Boppana Theorem analogue ... they also showed the
Serre-style strengthening." **[checked]** This is the threshold of the biregular
dossier, confirmed here from a second source.

## 2. Existence of Ramanujan graphs

Verbatim from Mohanty-O'Donnell, Section 2.2: "The Lubotzky-Phillips-Sarnak-
Margulis constructions give infinitely many $\Delta$-regular two-sided
Ramanujan graphs whenever $\Delta-1$ is a prime congruent to $1 \bmod 4$, and
also infinitely many $\Delta$-regular bipartite Ramanujan graphs in the same
case. By 1994, Morgenstern [Mor94] had extended their methods to obtain the same
results only assuming that $\Delta-1$ is a prime power." And: "To summarize
these results: for all $\Delta$ with $\Delta-1$ a prime power, there are
infinitely many $G \in \mathrm{FinQuo}(T_\Delta)$ with $\lambda_2(G) \le
\rho(T_\Delta)$." **[checked]** (Same source, Section 2.2.)

Since $\mathrm{FinQuo}(T_\Delta)$ "is the set of all finite $\Delta$-regular
graphs" (verbatim, Section 2.1), this settles the existence question for the
class of all regular graphs. The specific claim that the LPS graphs are Cayley
graphs of $\mathrm{PGL}_2(q)$ and $\mathrm{PSL}_2(q)$ is standard but I did not
re-verify it against the 1988 paper in this run. **[reported]**

Marcus-Spielman-Srivastava give bipartite Ramanujan graphs of every degree by
interlacing polynomials, and the method is the engine of Mohanty-O'Donnell's
construction of $k$-quasi-$X$-Ramanujan graphs for additive products.
**[checked, dossier + Mohanty-O'Donnell Sections 2.3, 3]**

## 3. Random regular graphs: Friedman, Bordenave, Friedman-Kohler, biregular

These are the four local dossiers. The statements I use.

**Friedman (Alon's conjecture).** For fixed even $d\ge4$ and $\varepsilon>0$, in
the permutation model $\mathcal{G}_{n,d}$,
$\Pr[\max_{2\le i\le n}|\lambda_i| \le 2\sqrt{d-1}+\varepsilon] \ge
1 - cn^{-\tau_{\mathrm{fund}}}$ with $\tau_{\mathrm{fund}} =
\lceil(\sqrt{d-1}+1)/2\rceil - 1$. **[checked, dossier]** (arXiv
cs/0405020v1, Theorem 1.1, pages 2-3.)

**Bordenave.** A shorter proof of Friedman's theorem, plus the extension to
random lifts: for a finite connected base graph with $|E|>|V|$, the largest new
non-backtracking eigenvalue of a random lift satisfies $|\lambda_1| \le
\sqrt{\rho_1}+o(1)$ with high probability, where $\rho_1$ is the Perron
eigenvalue of the base non-backtracking matrix. **[checked, dossier]**
(arXiv:1502.04482v4, Theorem 1, Theorem 23, Corollary 24.)

**Friedman-Kohler, relativized second eigenvalue.** For a fixed $d$-regular
base $B$ with $d\ge3$: $\Pr[\rho_B^{\mathrm{new}}(A_G) \ge 2\sqrt{d-1}+
\varepsilon] = O(n^{-1})$. **[checked, dossier]** (arXiv:1403.3462v1, Theorem
0.1.1.) The core of the proof assumes a connected base of negative Euler
characteristic, and the fundamental exponent is defined through *strict
feasible tangles*, that is, connected $B$-graphs $L$ with
$\rho(H_L) > \rho(H_B)^{1/2}$ (Definition 2.4.8). **[checked, dossier]**

**Brito-Dumitriu-Decker Harris.** For a uniform simple bipartite
$(d_1,d_2)$-biregular graph, asymptotically almost surely $\lambda_2(A) \le
\sqrt{d_1-1}+\sqrt{d_2-1}+o(1)$, and $\eta^+_{\min} \ge \sqrt{d_1-1} -
\sqrt{d_2-1}-o(1)$. **[checked, dossier]** (arXiv:1804.07808v6, Theorem 4.)

## 4. The X-Ramanujan framework and the quasi-index

**Mohanty-O'Donnell, $X$-Ramanujan graphs** (arXiv:1904.03500v2, 36 pages,
submitted 6 April 2019, revised 10 April 2019). Verbatim from the abstract:
"Let $X$ be an infinite graph of bounded degree, e.g., the Cayley graph of a
free product of finite groups. If $G$ is a finite graph covered by $X$, it is
said to be $X$-Ramanujan if its second-largest eigenvalue $\lambda_2(G)$ is at
most the spectral radius $\rho(X)$ of $X$, and more generally $k$-quasi-$X$-
Ramanujan if $\lambda_k(G)$ is at most $\rho(X)$." **[checked]**

Definition 2.10, verbatim: "$G$ ... (one-sided) Ramanujan if $\lambda_2(G) \le
2\sqrt{\Delta-1}$, and two-sided Ramanujan if in addition $\lambda_n(G) \ge
-2\sqrt{\Delta-1}$. If $G$ is bipartite and (one-sided) Ramanujan, we will call
it bipartite Ramanujan. (A bipartite graph cannot be two-sided Ramanujan, as
$\lambda_n(G)$ will always be $-\Delta$.)" **[checked]** This is the source of
Proposition 4 in `03-theory.md`.

Definition 2.16, verbatim: "An infinite graph $X$ is said to be
$k$-quasi-Ramanujan ($k\ge1$) if there are infinitely many $G \in
\mathrm{FinQuo}(X)$ with $\lambda_{k+1}(G) \le \rho(X)$." **[checked]**

Question 2.17, verbatim: "If $X$ is weakly Ramanujan, must it be
$k$-quasi-Ramanujan for some $k \in \mathbb{N}^+$?" plus Clark's Conjecture 2.18
and Mohar's Conjecture 2.20 for degree matrices. **[checked]** The quasi-index
in this dossier is the finite graph analogue of the index $k$ in these
statements.

## 5. Random Cayley graphs: what is actually known

**Abelian case, sharp order of the gap.** Hermon and Olesker-Taylor, "Geometry
of random Cayley graphs of Abelian groups", Annals of Applied Probability 33
(2023) 3520-3562, doi:10.1214/22-aap1899. Abstract, verbatim from the Warwick
repository record: "We prove that the order of the spectral gap is $|G|^{-2/k}$
when $k - d(G) \asymp k$ and $|G|$ lies in a density-1 subset of
$\mathbb{N}$ or when $k - 2d(G) \asymp k$. This extends, for Abelian groups, a
celebrated result of Alon and Roichman." **[reported, from the repository
abstract text]** Note that a gap of order $|G|^{-2/k}$ means
$\lambda_2 = d - \Theta(|G|^{-2/k})$, so abelian random Cayley graphs of fixed
degree are far from Ramanujan. My Proposition 6 gives the same order of
magnitude as a lower bound by pigeonhole.

**Nilpotent case, gap determined by the abelianization.** Hermon and Huang,
"Cutoff for random Cayley graphs of nilpotent groups", arXiv:2403.12355v1
(19 March 2024). Abstract, verbatim: "we show that there is a constant $c>0$,
depending only on the rank and the nilpotency class of $G$, such that for all
symmetric sets of generators $S$ of size at most $c\log|G|/\log\log|G|$, the
spectral gap and the $\varepsilon$-mixing time of the simple random walk on
$\mathrm{Cay}(G,S)$ are asymptotically the same as those of the projection of
$X$ to the abelianization of $G$". **[checked, arXiv abstract page]** This is a
theorem-level confirmation that an abelian quotient mechanism controls the gap
in a class of groups, and it supports the obstruction analysis in
`05-targets.md`.

**Fixed degree, non-abelian case: open.** An aggregator of open problems
records, under "Random Cayley graphs of finite groups with optimal spectral
gaps": "It is a folklore question whether there are sequences of finite groups
so that, if generators are chosen independently and uniformly at random, the
associated Cayley graph has an optimal spectral gap. This question is open for
any sequence of finite groups." And, under "Expansion for random Cayley graphs
of the symmetric group": "Whether random Cayley graphs of $\mathbf{S}_N$ have an
optimal spectral gap is a long-standing question ... it has not even been shown
that the maximum nontrivial eigenvalue is bounded away from the trivial
eigenvalue in this setting." Source:
https://www.emergentmind.com/open-problems/expansion-random-cayley-graphs-symmetric-group
and https://www.emergentmind.com/open-problems/random-cayley-graphs-optimal-spectral-gaps
(accessed 2026-11-14). **[reported]** These are aggregator pages that quote an
underlying paper with a section on Cayley graphs, which I did not identify in
this run. Treat the attribution as unverified, and treat the *content* as the
honest state of the field: no theorem of the form "random fixed-degree Cayley
graphs of $G_m$ are almost Ramanujan" is available for any sequence of groups.

## 6. What this dossier does not claim

It does not claim that any of the questions above are new. The Cayley
Ramanujan question is explicitly part of the $X$-Ramanujan programme, and the
abelian and nilpotent cases have theorems. What this dossier adds is (i) the
exact block and quasi-index laws in the Cayley setting, (ii) exact exhaustive
landscapes for small groups with closed-form extremal eigenvalues, (iii) two
exact structural certificates (coset and abelian pigeonhole) with the
demonstration that they do not explain the observed failures, and (iv) a
precise statement of the missing estimate.
