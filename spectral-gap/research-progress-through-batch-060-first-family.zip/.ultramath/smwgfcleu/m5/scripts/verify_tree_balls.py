"""Independent check of Theorem A on genuine balls of the spiked tree
(sparse eigensolver, so radii stay modest)."""
import numpy as np, networkx as nx
from scipy.sparse.linalg import eigsh
from scipy.sparse import csr_array

def spiked_ball(d, Delta, R):
    G = nx.Graph(); G.add_node(0); frontier = [0]
    for _ in range(R):
        nxt = []
        for v in frontier:
            k = Delta if v == 0 else d - 1
            for _ in range(k):
                w = G.number_of_nodes(); G.add_node(w); G.add_edge(v, w); nxt.append(w)
        frontier = nxt
    return G

print("Balls of the spiked tree: extreme eigenvalues")
print(f"{'d':>2} {'Del':>4} {'R':>3} {'|V|':>7} {'lam_max':>10} {'lam_min':>10} {'pred lam*':>10} {'edge':>9}")
for d, Delta, Rs in [(3,3,[10,14]),(3,4,[10,14]),(3,5,[10,14]),(3,6,[10,14]),(3,10,[8,11]),
                     (4,5,[9,12]),(4,7,[8,11]),(4,12,[7,9])]:
    for R in Rs:
        G = spiked_ball(d, Delta, R)
        A = csr_array(nx.to_scipy_sparse_array(G, format='csr'), dtype=float)
        n = A.shape[0]
        lm = eigsh(A, k=1, which='LA', return_eigenvectors=False, tol=0)[0]
        lmn = eigsh(A, k=1, which='SA', return_eigenvectors=False, tol=0)[0]
        pred = Delta/np.sqrt(Delta+1-d) if Delta > 2*(d-1) else float('nan')
        print(f"{d:2d} {Delta:4d} {R:3d} {n:7d} {lm:10.5f} {lmn:10.5f} {pred:10.5f} {2*np.sqrt(d-1):9.5f}")

print("\ntop eigenvector shape, d=3 Delta=10 R=9: level means and ratios")
G = spiked_ball(3, 10, 9)
A = csr_array(nx.to_scipy_sparse_array(G, format='csr'), dtype=float)
w, U = eigsh(A, k=1, which='LA', tol=0)
v = U[:, 0]
lev = nx.single_source_shortest_path_length(G, 0)
by = {}
for i in range(len(v)): by.setdefault(lev[i], []).append(v[i])
seq = np.array([np.mean(by[k]) for k in sorted(by)])
print("level means:", np.round(seq, 6))
print("ratios     :", np.round(seq[1:]/seq[:-1], 6))
print("predicted level ratio z = 1/sqrt(Delta+1-d) =", 1/np.sqrt(10+1-3))
print("observed level ratio (first) =", round(seq[1]/seq[0], 6),
      "  lambda* =", 10/np.sqrt(8), "  computed lambda_max =", round(w[0], 6))
print("note: in the Jacobi normalisation g_n = sqrt(N_n) f_n the ratio is sqrt(d-1) z =",
      round(np.sqrt(2)/np.sqrt(10+1-3), 6))
