"""Seed-averaged verification: resolvent-limit values (reported as F_n, not Sigma_n) and
the lambda_2 trend for the adjacent pair.  Same exactly-uniform sampler as numerics.py."""
import numpy as np, json, time, collections
from scipy.sparse import identity
from scipy.sparse.linalg import spsolve
import numerics as NM

out = {}
print("= resolvent limit F_n = 1_T^T (lam I-A)^{-1} 1_T ; adjacent pair (T={c,u}) vs far pair =")
print("   prediction: adjacent K_adj(lam)+4/(n(lam-d));  far 2G_d(lam)+4/(n(lam-d))")
rows=[]
for d, n, lam in [(3,1000,3.2),(3,4000,3.2),(3,8000,3.2),(3,4000,2.95),(3,8000,2.95),
                  (3,8000,3.5),(4,4000,3.8),(4,4000,4.5)]:
    rng = np.random.default_rng(4242+n+int(100*lam)); pairs = NM.uniform_regular(n,d,rng)
    A = NM.to_csr(n,pairs)
    u = sorted(A[0].indices.tolist())[0]
    dist={0:0}; q=collections.deque([0])
    while q:
        v=q.popleft()
        for w in A[v].indices:
            if w not in dist: dist[w]=dist[v]+1; q.append(w)
    w_far = next(w for w in range(1,n) if dist.get(w,99)>=8)
    _,fa = NM.secular(A,[0,u],lam); _,fs = NM.secular(A,[0,w_far],lam)
    pa = NM.Kadj(lam,d)+4/(n*(lam-d)); ps = 2*NM.Gd(lam,d)+4/(n*(lam-d))
    print("  d=%d n=%-5d lam=%-4.2f : F_adj=%11.7f pred=%11.7f  err=%9.2e | F_far=%11.7f pred=%11.7f err=%9.2e"
          % (d,n,lam,fa,pa,fa-pa,fs,ps,fs-ps))
    rows.append(dict(d=d,n=n,lam=lam,F_adj=fa,pred_adj=pa,F_far=fs,pred_far=ps,
                     dist_far=dist[w_far]))
out["resolvent"]=rows
json.dump(out, open('out/numerics_resolvent2.json','w'), indent=1)

print(); print("= lambda_2(G') trend for the adjacent pair (secular zero == eigensolver value) =")
print("  d=3: predicted limit lam* = 2.87512979416 ; separated-pair prediction 2sqrt2 = 2.82842712475")
rows=[]
for d, n, seeds in [(3,4000,[11,12,13,14,15,16]), (3,8000,[21,22,23,24,25,26]),
                    (4,4000,[11,12,13,14])]:
    vals=[]
    for s in seeds:
        rng=np.random.default_rng(s*1000+n); pairs=NM.uniform_regular(n,d,rng); A=NM.to_csr(n,pairs)
        u=sorted(A[0].indices.tolist())[0]; T=[0,u]
        A2=NM.adj_added(A,T); ev2=NM.top_eigs(A2,3); evh=NM.top_eigs(A,2)
        z=NM.secular_zero(A,T,evh[1]+1e-7,d-1e-7)
        vals.append((float(ev2[0]),float(ev2[1]),float(z),s))
        print("  d=%d n=%-5d seed=%2d : lam1=%.8f lam2=%.8f seczero=%.8f |diff|=%.1e"
              % (d,n,s,ev2[0],ev2[1],z,abs(z-ev2[1])))
    a=np.array([v[:3] for v in vals])
    pred = 2.875129794162778 if d==3 else 2*np.sqrt(d-1)
    print("   ==> d=%d n=%d : mean lam2 = %.6f  sd = %.6f  (predicted %.6f) ; mean lam1 = %.6f ; mean n(lam1-d) = %.4f"
          % (d,n,a[:,1].mean(), a[:,1].std(), pred, a[:,0].mean(), (n*(a[:,0]-d)).mean()))
    rows.append(dict(d=d,n=n,seeds=seeds,lam1=list(a[:,0]),lam2=list(a[:,1]),seczero=list(a[:,2]),
                     mean_lam2=float(a[:,1].mean()), sd_lam2=float(a[:,1].std()), pred=float(pred),
                     mean_nlam1md=float((n*(a[:,0]-d)).mean())))
out["lam2_trend"]=rows
json.dump(out, open('out/numerics_trend.json','w'), indent=1)
print("\npredicted n(lam1-d): d=3 -> 4/Phi_adj(3)=4 ; d=4 -> 4/Phi_adj(4)=4/3=1.3333")
print("separated-pair (Delta=2) predictions would be 12/5=2.4 and 16/13=1.2308")
