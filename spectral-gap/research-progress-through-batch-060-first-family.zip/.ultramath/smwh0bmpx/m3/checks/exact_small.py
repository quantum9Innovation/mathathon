"""Exact (rational / symbolic) checks, fast version.

(1) Reduced infinite-tree matrix inverse for integer d, symbolic r.
(2) One-sided message identity.
(3) Truncated tree balls: exact rational linear algebra, T-block sum -> closed form.
(4) Added-vertex secular identity p_G' = p_G * Sigma, certified at rational points.
(5) d not in spec(G'), twin eigenvalue 0.
"""
import sympy as sp, json
from fractions import Fraction

lam, r = sp.symbols('lambda r')
allok = True
def rep(name, got, exp=0):
    global allok
    ok = sp.simplify(got - exp) == 0
    allok &= ok
    print(f"[{'OK ' if ok else 'FAIL'}] {name}" + ("" if ok else f"  got {sp.simplify(got)} exp {exp}"))
    return ok

# ---------- (1) reduced matrix inverse, integer d, symbolic r -------------
print("(1) reduced (d+1)x(d+1) infinite-tree matrix, symbolic r:")
for d in [3, 4, 5, 6, 7]:
    lam_of = (d - 1) * r + 1 / r
    M = sp.zeros(d + 1, d + 1)
    M[0, 0] = lam_of
    for i in range(1, d + 1):
        M[0, i] = -1; M[i, 0] = -1; M[i, i] = 1 / r
    G = sp.simplify(M.inv())
    diag, off = sp.simplify(G[1, 1]), sp.simplify(G[1, 2])
    tot = sp.simplify(sum(G[i, j] for i in range(1, d + 1) for j in range(1, d + 1)))
    rep(f"d={d} diag  = r + r^2/(lam-dr)", diag, r + r**2 / (lam_of - d * r))
    rep(f"d={d} off   = r^2/(lam-dr)", off, r**2 / (lam_of - d * r))
    rep(f"d={d} 1'G1   = d lam r/(lam-dr)", tot, d * lam_of * r / (lam_of - d * r))
    rep(f"d={d} 1'G1   = G_d(d + d(d-1)r^2)", tot, r / (1 - r**2) * (d + d * (d - 1) * r**2))
    rep(f"d={d} 1'G1   = dr + d^2r^2/(lam-dr)", tot, d * r + d**2 * r**2 / (lam_of - d * r))

print("\n(2) one-sided message identity (d-1)r^2 - lam r + 1 = 0:")
for d in [3, 4, 5, 6]:
    lam_of = (d - 1) * r + 1 / r
    rep(f"d={d}", (d - 1) * r**2 - lam_of * r + 1)

# ---------- (3) truncated balls, exact rational arithmetic ---------------
def tree_ball(d, R):
    import collections
    nodes = {(): 0}; adj = collections.defaultdict(set)
    frontier = [()]
    while frontier:
        nxt = []
        for p in frontier:
            if len(p) < R:
                for i in range(d if len(p) == 0 else d - 1):
                    q = p + (i,)
                    if q not in nodes:
                        nodes[q] = len(nodes); nxt.append(q)
                    adj[nodes[p]].add(nodes[q]); adj[nodes[q]].add(nodes[p])
        frontier = nxt
    n = len(nodes)
    A = [[Fraction(0)] * n for _ in range(n)]
    for u, vs in adj.items():
        for v in vs:
            A[u][v] = Fraction(1)
    T = [nodes[(i,)] for i in range(d)]
    return A, T, n

def solve_exact(A, b):
    """Gauss-Jordan on Fractions; returns x with A x = b."""
    n = len(A)
    M = [row[:] + [b[i]] for i, row in enumerate(A)]
    for col in range(n):
        piv = next(i for i in range(col, n) if M[i][col] != 0)
        M[col], M[piv] = M[piv], M[col]
        pv = M[col][col]
        M[col] = [x / pv for x in M[col]]
        for i in range(n):
            if i != col and M[i][col] != 0:
                f = M[i][col]
                M[i] = [a - f * c for a, c in zip(M[i], M[col])]
    return [M[i][n] for i in range(n)]

print("\n(3) truncated balls: 1_T^T (lam-A)^{-1} 1_T vs closed form K, exact rationals")
rows = []
CASES = [(3, Fraction(1, 2), Fraction(3)),        # d=3, r=1/2  -> lam = 3
         (3, Fraction(1, 3), Fraction(11, 3)),    # d=3, r=1/3  -> lam = 11/3
         (4, Fraction(1, 2), Fraction(7, 2))]     # d=4, r=1/2  -> lam = 7/2
for d, rv, lamv in CASES:
    # sanity: lam = (d-1) r + 1/r
    assert Fraction(d - 1) * rv + 1 / rv == lamv, (d, rv, lamv)
    Kcl = (rv / (1 - rv**2)) * (d + d * (d - 1) * rv**2)
    rmax = 5 if d == 3 else 4
    for R in range(1, rmax + 1):
        A, T, n = tree_ball(d, R)
        M = [[(lamv if i == j else Fraction(0)) - A[i][j] for j in range(n)] for i in range(n)]
        b = [Fraction(0)] * n
        for t in T:
            b[t] = Fraction(1)
        x = solve_exact(M, b)
        tot = sum(x[t] for t in T)
        rows.append(dict(d=d, r=str(rv), lam=str(lamv), R=R, n=n,
                         value=str(float(tot)), closed=str(float(Kcl)), diff=str(float(tot - Kcl))))
        print(f"   d={d} R={R} |ball|={n}: sum={float(tot):.10f}  closed={float(Kcl):.10f}  diff={float(tot-Kcl):+.3e}")

# ---------- (4)/(5) small d-regular graphs ------------------------------
def adj_from_edges(n, E):
    A = [[0] * n for _ in range(n)]
    for (i, j) in E:
        A[i][j] = A[j][i] = 1
    return A
def dense(n):
    return [[1 if i != j else 0 for j in range(n)] for i in range(n)]

GRAPHS = {}
GRAPHS['K4'] = dense(4)
GRAPHS['K33'] = adj_from_edges(6, [(i, j) for i in range(3) for j in range(3, 6)])
GRAPHS['Q3'] = adj_from_edges(8, [(0,1),(1,2),(2,3),(3,0),(4,5),(5,6),(6,7),(7,4),(0,4),(1,5),(2,6),(3,7)])
GRAPHS['Petersen'] = adj_from_edges(10, [(i,(i+1)%5) for i in range(5)] + [(i,i+5) for i in range(5)] +
                                    [(5,7),(7,9),(9,6),(6,8),(8,5)])
GRAPHS['K5'] = dense(5)
GRAPHS['K44'] = adj_from_edges(8, [(i, j) for i in range(4) for j in range(4, 8)])

def det_frac(M):
    n = len(M); M = [row[:] for row in M]; det = Fraction(1)
    for c in range(n):
        p = next((i for i in range(c, n) if M[i][c] != 0), None)
        if p is None: return Fraction(0)
        if p != c:
            M[c], M[p] = M[p], M[c]; det = -det
        det *= M[c][c]
        inv = Fraction(1) / M[c][c]
        for i in range(c + 1, n):
            f = M[i][c] * inv
            if f != 0:
                M[i] = [a - f * bb for a, bb in zip(M[i], M[c])]
    return det

print("\n(4)/(5) exact secular identity at rational points, and spectrum of G':")
for nm, A in GRAPHS.items():
    n = len(A); c = 0
    T = [j for j in range(n) if A[c][j] == 1 and j != c]
    d = len(T)
    assert all(sum(row) == d for row in A), (nm, d)
    Ap = [[A[i][j] for j in range(n)] + [1 if i in T else 0] for i in range(n)]
    Ap.append([1 if j in T else 0 for j in range(n)] + [0])
    okall = True
    pts = [Fraction(1, 3), Fraction(2, 5), Fraction(5, 7), Fraction(11, 13),
           Fraction(17, 4), Fraction(23, 5), Fraction(31, 6), Fraction(41, 7),
           Fraction(53, 8), Fraction(61, 9), Fraction(71, 10), Fraction(83, 11)]
    # need n+2 points to certify the degree n+1 polynomial identity
    used = 0
    for L in pts:
        if used >= n + 2: break
        Mi = [[(L if i == j else Fraction(0)) - A[i][j] for j in range(n)] for i in range(n)]
        pG = det_frac(Mi)
        if pG == 0:            # L happens to be a host eigenvalue: skip
            continue
        Mi2 = [[(L if i == j else Fraction(0)) - Ap[i][j] for j in range(n + 1)] for i in range(n + 1)]
        pGp = det_frac(Mi2)
        b = [Fraction(1) if i in T else Fraction(0) for i in range(n)]
        x = solve_exact(Mi, b)
        Sig = L - sum(x[t] for t in T)   # = L + 1_T^T (A - L I)^{-1} 1_T
        okall &= (pG * Sig == pGp)
        used += 1
    allok &= okall
    # exact spectrum of G'
    Ls = sp.symbols('L')
    ApS = sp.Matrix(Ap)
    spec = ApS.eigenvals()
    spect = []
    for val, mul in spec.items():
        spect += [sp.nsimplify(val)] * mul
    spect = sorted(spect, key=lambda z: -complex(sp.N(z)).real)
    has_d = any(sp.simplify(s - d) == 0 for s in spect)
    has_0 = any(sp.simplify(s) == 0 for s in spect)
    twinvec_ok = all(Ap[j][n] == A[c][j] for j in range(n)) and Ap[n][n] == A[c][c] == 0
    allok &= (not has_d) and has_0
    print(f"   [{'OK ' if okall else 'FAIL'}] {nm}: d={d}, |T|={d}, secular identity at {used} rational points; "
          f"spec(G')={[sp.N(z,8) for z in spect]}; d in spec? {has_d}; 0 in spec? {has_0}; x,c twins? {twinvec_ok}")

print("\nALL EXACT CHECKS PASS" if allok else "\nSOME CHECKS FAILED")
json.dump(rows, open('checks/out/exact_small.json', 'w'), indent=1)
