"""
(F) Exact Ihara-Bass transfer for line digraphs DL(G) of d-regular graphs G.

Formula (Hashimoto / Ihara-Bass, as stated in Parzanchevski arXiv:1804.08028v4 eq (3.1)):
   Spec(DL(G)) = { (lam +- sqrt(lam^2 - 4k))/2 : lam in Spec(G) } u {+-1 repeated |E|-|V| times},
with k = d-1.  For Ramanujan G (|lam| <= 2 sqrt(d-1) for every nontrivial lam) every
nontrivial eigenvalue of DL(G) has modulus exactly sqrt(k).

We verify the formula densely on small graphs, then use the transfer (which is exact)
to compute rho(DL(G)) for random d-regular graphs at large n, comparing with sqrt(d-1).
"""
import json
import numpy as np
import scipy.sparse as sp
import scipy.sparse.linalg as spla

rng = np.random.default_rng(11)
out = {}

def ihara_transfer(lam, k):
    disc = lam * lam - 4 * k
    return (lam + np.sqrt(disc + 0j)) / 2, (lam - np.sqrt(disc + 0j)) / 2

def hashimoto(G, n):
    nb = [[] for _ in range(n)]
    for (u, v) in G:
        nb[u].append(v); nb[v].append(u)
    arcs = []
    for u in range(n):
        for v in nb[u]:
            arcs.append((u, v))
    idx = {a: i for i, a in enumerate(arcs)}
    B = np.zeros((len(arcs), len(arcs)))
    for (u, v) in arcs:
        for w in nb[v]:
            if w != u:
                B[idx[(u, v)], idx[(v, w)]] += 1
    return B

def adj_from_edges(G, n):
    A = np.zeros((n, n))
    for (u, v) in G:
        A[u, v] = 1; A[v, u] = 1
    return A

def random_regular_edges(d, n, rng, simple=True):
    for _ in range(2000):
        stubs = np.repeat(np.arange(n), d)
        rng.shuffle(stubs)
        G = []
        ok = True
        seen = set()
        for i in range(0, len(stubs), 2):
            u, v = stubs[i], stubs[i + 1]
            if u == v or (min(u, v), max(u, v)) in seen:
                ok = False; break
            seen.add((min(u, v), max(u, v)))
            G.append((u, v))
        if ok:
            return G
    raise RuntimeError("failed to sample simple regular graph")

print("=== dense verification of the Ihara-Bass transfer on small graphs ===")
def cycle(n): return [(i, (i + 1) % n) for i in range(n)]
def complete(n): return [(i, j) for i in range(n) for j in range(i + 1, n)]
def petersen():
    return ([(i, (i + 1) % 5) for i in range(5)] + [(5 + i, 5 + (i + 2) % 5) for i in range(5)]
            + [(i, 5 + i) for i in range(5)])
def cube():
    # 3-cube Q3, 8 vertices
    E = []
    for i in range(8):
        for b in range(3):
            j = i ^ (1 << b)
            if i < j: E.append((i, j))
    return E
def k33(): return [(i, 3 + j) for i in range(3) for j in range(3)]
def heawood():
    E = []
    for i in range(7):
        E += [(i, 7 + i), (i, 7 + (i + 1) % 7), (i, 7 + (i + 3) % 7)]
    return E
def dodeca():
    # dodecahedral graph, 20 vertices, 3-regular
    E = []
    for i in range(5):
        E.append((i, (i + 1) % 5))
        E.append((5 + i, 5 + (i + 1) % 5))
        E.append((10 + i, 10 + (i + 1) % 5))
        E.append((15 + i, 15 + (i + 1) % 5))
        E.append((i, 5 + i))
        E.append((10 + i, 10 + i))
    E = [e for e in E if e[0] != e[1]]
    E += [(15 + i, 10 + 2 * i) for i in range(5)]
    E += [(15 + (i + 2) % 5, 10 + 2 * i + 1) for i in range(5)]
    return E

rows = []
for name, G, n, d in [("C_6", cycle(6), 6, 2), ("C_7", cycle(7), 7, 2), ("K_4", complete(4), 4, 3),
                      ("Q_3", cube(), 8, 3), ("K_{3,3}", k33(), 6, 3), ("Petersen", petersen(), 10, 3),
                      ("Heawood", heawood(), 14, 3)]:
    k = d - 1
    B = hashimoto(G, n)
    wG = np.linalg.eigvals(adj_from_edges(G, n))
    wB = np.linalg.eigvals(B)
    pred = []
    for lam in wG:
        a, b = ihara_transfer(lam, k)
        pred += [a, b]
    pred += [1.0] * (len(G) - n) + [-1.0] * (len(G) - n)
    ok = np.allclose(np.sort(np.round(pred, 6)), np.sort(np.round(wB, 6)), atol=1e-6)
    nontriv = np.array([abs(z) for z in wB if abs(abs(z) - k) > 1e-7])
    if len(nontriv) == 0:
        nontriv = np.array([np.nan])
    rows.append(dict(graph=name, d=d, k=k, n=n, formula_ok=bool(ok),
                     lam2G=float([x for x in np.sort(np.abs(wG))[::-1] if abs(x - d) > 1e-7][0]),
                     rho_DL=float(nontriv.max()),
                     min_nontriv=float(nontriv.min()),
                     sqrt_k=float(np.sqrt(k))))
    print(f"{name:9s} d={d} k={k}: formula={ok}; lambda_2(G)={rows[-1]['lam2G']:.6f} "
          f"Ramanujan={rows[-1]['lam2G'] <= 2*np.sqrt(k)+1e-9}; nontrivial |mu| in "
          f"[{rows[-1]['min_nontriv']:.6f},{rows[-1]['rho_DL']:.6f}] vs sqrt(k)={np.sqrt(k):.6f}")

out["dense"] = rows

print()
print("=== rho(DL(G)) for random d-regular G, via the exact transfer ===")
rows = []
for d in [3, 4, 5]:
    k = d - 1
    for n in [200, 800, 2000, 5000]:
        G = random_regular_edges(d, n, rng)
        A = sp.csr_matrix(adj_from_edges(G, n))
        w = spla.eigsh(A, k=4, which='LA', return_eigenvectors=False, maxiter=20000, tol=1e-12)
        lam2 = np.sort(w)[::-1][1]
        mu1, mu2 = ihara_transfer(lam2, k)
        rho = max(abs(mu1), abs(mu2))
        rows.append(dict(d=d, n=n, lam2=float(lam2), rho_DL=float(rho), sqrt_k=float(np.sqrt(k)),
                         two_sqrt_lam=float(2 * np.sqrt(k))))
        print(f"d={d} k={k} n={n}: lambda_2(G)={lam2:.5f} (2sqrt(k)={2*np.sqrt(k):.5f}) "
              f"rho(DL)={rho:.5f} sqrt(k)={np.sqrt(k):.5f} ratio={rho/np.sqrt(k):.5f}")
out["random_transfer"] = rows
json.dump(out, open("raw/line_digraph_transfer.json", "w"), indent=1)
print("written raw/line_digraph_transfer.json")
