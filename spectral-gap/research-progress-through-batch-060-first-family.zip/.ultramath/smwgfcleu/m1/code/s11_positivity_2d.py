r"""Positivity of the band-edge Hessian in two dimensions, with the correct
connectivity test.

For a Z^d-periodic graph presented on a finite quotient B, the infinite graph
Gamma is connected iff the cycle windings generate Z^d as a group.  We test this
by the gcd of all d x d minors of the matrix of fundamental-cycle windings:
the subgroup generated equals Z^d exactly when that gcd is 1.
"""
import sys, os, itertools, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
import lib

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "out")


def cycle_windings(p, edges, d):
    """Windings of a basis of cycles, obtained from a spanning tree of B."""
    # spanning tree of the multigraph on p vertices using the edge list
    par = list(range(p))
    def find(x):
        while par[x] != x:
            par[x] = par[par[x]]
            x = par[x]
        return x
    tree, extra = [], []
    for idx, (u, v, g) in enumerate(edges):
        ru, rv = find(u), find(v)
        if ru != rv:
            par[ru] = rv
            tree.append(idx)
        else:
            extra.append(idx)
    if len({find(x) for x in range(p)}) != 1:
        return None            # B itself is disconnected
    # adjacency in the tree, with the oriented shift from the parent
    adj = {i: [] for i in range(p)}
    for idx in tree:
        u, v, g = edges[idx]
        adj[u].append((v, np.array(g)))
        adj[v].append((u, -np.array(g)))
    # path winding from root 0 to every vertex
    pot = {}
    stack = [(0, np.zeros(d, dtype=int))]
    while stack:
        x, s = stack.pop()
        if x in pot:
            continue
        pot[x] = s
        for (y, g) in adj[x]:
            if y not in pot:
                stack.append((y, s+g))
    winds = []
    for idx in extra:
        u, v, g = edges[idx]
        winds.append(pot[v]+np.array(g)-pot[u])
    return winds


def generates_all(winds):
    if winds is None:
        return False
    M = np.array(winds, dtype=int)
    d = M.shape[1]
    from math import gcd
    g = 0
    for cols in itertools.combinations(range(M.shape[0]), d):
        sub = M[list(cols)]
        det = int(round(np.linalg.det(sub)))
        g = gcd(g, abs(det))
    return g == 1


def closed_form_M(G):
    p = G.p
    A0 = G.A(np.zeros(G.d)).real
    lam, vec = np.linalg.eigh(A0)
    lam1 = lam[-1]
    psi = vec[:, -1]
    if psi.sum() < 0:
        psi = -psi
    W = np.zeros((p, p, G.d, G.d))
    H = np.zeros((p, p, G.d))
    for (u, v, g) in G.edges:
        for i in range(G.d):
            for j in range(G.d):
                W[u, v, i, j] += g[i]*g[j]
                W[v, u, i, j] += g[i]*g[j]
            H[u, v, i] += g[i]
            H[v, u, i] -= g[i]
    dd = lam1-lam
    dd[np.abs(dd) < 1e-11] = np.inf
    M = np.zeros((G.d, G.d))
    for i in range(G.d):
        for j in range(G.d):
            t1 = psi @ (W[:, :, i, j] @ psi)
            Hi = H[:, :, i] @ psi
            Hj = H[:, :, j] @ psi
            t2 = 2*sum((vec[:, k] @ Hi)*(vec[:, k] @ Hj)/dd[k] for k in range(p))
            M[i, j] = (2*np.pi)**2*(t1-t2)
    return 0.5*(M+M.T)


def main():
    log = []
    rng = np.random.default_rng(12345)
    ratios = []
    tests = 0
    skipped_deg = 0
    skipped_disc = 0
    worst = None
    for trial in range(4000):
        p = int(rng.integers(2, 5))
        d = 2
        edges = []
        for (u, v) in itertools.combinations(range(p), 2):
            if rng.random() < 0.65:
                g = (int(rng.integers(-3, 4)), int(rng.integers(-3, 4)))
                edges.append((u, v, g))
        for u in range(p):
            if rng.random() < 0.35:
                g = (int(rng.integers(-2, 3)), int(rng.integers(-2, 3)))
                if g != (0, 0):
                    edges.append((u, u, g))
        if len(edges) < p:
            continue
        winds = cycle_windings(p, edges, d)
        if not generates_all(winds):
            skipped_disc += 1
            continue
        G = lib.PeriodicGraph(p, edges)
        if np.max(np.abs(G.A(np.zeros(2)).imag)) > 1e-12:
            continue
        ev = np.linalg.eigvalsh(G.A(np.zeros(2)).real)
        if ev[-1]-ev[-2] < 1e-8:
            skipped_deg += 1
            continue
        M = closed_form_M(G)
        e = np.linalg.eigvalsh(M)
        tests += 1
        ratios.append(float(e[0]/e[1]) if e[1] > 0 else 0.0)
        if worst is None or e[0] < worst[0]:
            worst = (float(e[0]), p, [[int(a), int(b), list(g)] for (a, b, g) in edges],
                     float(e[1]))
    log.append(f"two-dimensional scan: {tests} connected periodic graphs tested")
    log.append(f"  skipped: {skipped_disc} with disconnected Gamma, "
               f"{skipped_deg} with a degenerate top eigenvalue of A(0)")
    log.append(f"  smallest lambda_min(M) = {worst[0]:.9f} at p = {worst[1]}, "
               f"lambda_max(M) = {worst[3]:.9f}")
    log.append(f"  its edges (u, v, shift) = {worst[2]}")
    log.append(f"  smallest lambda_min(M)/lambda_max(M) = {min(ratios):.6f}")
    log.append(f"  cases with lambda_min(M) <= 0: "
               f"{sum(1 for r in ratios if r <= 0)}")
    txt = "\n".join(log)
    open(os.path.join(OUT, "s11_positivity_2d.log"), "w").write(txt)
    print(txt)


if __name__ == "__main__":
    main()
