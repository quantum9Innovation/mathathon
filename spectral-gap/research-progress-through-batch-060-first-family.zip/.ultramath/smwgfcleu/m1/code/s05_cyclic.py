r"""Cyclic covers of a fixed finite base: the exact second-order constant.

Base B (p vertices; every undirected edge carries an integer winding w, oriented
u -> v).  The infinite cyclic cover Gamma is Z-periodic with Bloch matrix

    A(kappa) = sum_w A_w exp(2 pi i kappa w),   Lambda_j(kappa) in spec A(kappa),

where (A_w)_{uv} counts edges from (cell 0, u) to (cell w, v).  The n-fold
cyclic cover is G_n = Gamma / nZ, and

    Spec(A_{G_n}) = { Lambda_j(k/n) : k = 0,...,n-1 }.

Therefore  lambda_1(G_n) - lambda_2(G_n) = (1/2) M_1 / n^2 + O(n^-4)  with

    M_1 = -Lambda_1''(0) = (2 pi)^2 [ <psi, W_2 psi> - 2 <H_1 psi,
                                      (lambda_1 - A_0)^+ H_1 psi> ],

psi the Perron vector of A_0 = A(0), W_2 = sum_w w^2 A_w (symmetric),
H_1 = sum_w w A_w (real antisymmetric).

Four independent determinations are compared:
  (a) the closed formula, with the two terms separately,
  (b) a finite difference of Lambda_1 at kappa = 0,
  (c) the explicit lifted graph, for small n,
  (d) the limit of n^2 (lambda_1(G_n) - lambda_2(G_n))/(2 pi^2), i.e. the constant C.
"""
import sys, os, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
import lib

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "out")


class CyclicBase:
    def __init__(self, name, p, edges):
        self.name, self.p, self.edges = name, p, edges

    def Aw(self):
        W = {}
        for (u, v, w) in self.edges:
            W.setdefault(w, np.zeros((self.p, self.p)))
            W[w][u, v] += 1
        return W

    def A(self, kappa):
        Ph = np.zeros((self.p, self.p), dtype=complex)
        for w, M in self.Aw().items():
            Ph += M*np.exp(2j*np.pi*kappa*w)
        return Ph + Ph.conj().T - np.diag(np.diag(Ph+Ph.conj().T)).real*0

    def Ah(self, kappa):
        """Hermitian Bloch matrix: A(kappa) = sum_w Aw exp(2 pi i kappa w)
        plus its conjugate transpose, correctly assembled from oriented shifts.
        """
        M = np.zeros((self.p, self.p), dtype=complex)
        for w, Aw in self.Aw().items():
            M += Aw*np.exp(2j*np.pi*kappa*w)
            M += Aw.T*np.exp(-2j*np.pi*kappa*w)
        return M

    def band(self, kappa):
        return np.linalg.eigvalsh(self.Ah(kappa))

    def constant(self):
        A0 = self.Ah(0.0).real
        lam, vec = np.linalg.eigh(A0)
        lam1 = lam[-1]
        psi = vec[:, -1]
        if psi.sum() < 0:
            psi = -psi
        W2 = np.zeros((self.p, self.p))
        H1 = np.zeros((self.p, self.p))
        for w, Aw in self.Aw().items():
            W2 += w*w*(Aw+Aw.T)
            H1 += w*(Aw-Aw.T)
        d = lam1 - lam
        d[np.abs(d) < 1e-11] = np.inf
        Hp = H1 @ psi
        inner = sum(abs(vec[:, i] @ Hp)**2/d[i] for i in range(self.p))
        t1 = psi @ (W2 @ psi)
        t2 = 2*inner
        C = t1 - t2
        return C, t1, t2, psi, lam1

    def M1_difference(self, h=1e-4):
        f = lambda k: np.linalg.eigvalsh(self.Ah(k))[-1]
        return -(f(-h)-2*f(0.0)+f(h))/h**2

    def spectrum_cyclic(self, n):
        vals = []
        for k in range(n):
            vals.extend(np.linalg.eigvalsh(self.Ah(k/n)))
        return np.sort(np.array(vals))[::-1]

    def lift_adjacency(self, n):
        N = n*self.p
        A = np.zeros((N, N))
        for i in range(n):
            for (u, v, w) in self.edges:
                j = (i+w) % n
                A[i*self.p+u, j*self.p+v] += 1
                A[j*self.p+v, i*self.p+u] += 1
        return A

    def girth(self, n, cap=10**9):
        A = (self.lift_adjacency(n) > 0).astype(int)
        N = A.shape[0]
        best = cap
        for s in range(N):
            dist = np.full(N, -1)
            par = np.full(N, -1)
            dist[s] = 0
            frontier = [s]
            while frontier:
                nxt = []
                for u in frontier:
                    for v in np.nonzero(A[u])[0]:
                        if dist[v] < 0:
                            dist[v] = dist[u]+1
                            par[v] = u
                            nxt.append(v)
                        elif par[u] != v and par[v] != u:
                            best = min(best, dist[u]+dist[v]+1)
                frontier = nxt
        return best


def complete_graph(p):
    return [(u, v) for u in range(p) for v in range(u+1, p)]


def main():
    log = []
    out = {}
    bases = []

    K4 = complete_graph(4)
    wK = {}
    for e, t in zip(K4, [1, 0, 2, 1, 0, 1]):
        wK[e] = t
    bases.append(CyclicBase("K4", 4, [(u, v, wK[(u, v)]) for (u, v) in K4]))

    pet = [(0, 1), (1, 2), (2, 3), (3, 4), (4, 0), (0, 5), (1, 6), (2, 7),
           (3, 8), (4, 9), (5, 7), (7, 9), (9, 6), (6, 8), (8, 5)]
    pat = [1, 0, 1, 2, 0, 0, 1, 0, 1, 1, 2, 0, 1, 0, 1]
    bases.append(CyclicBase("Petersen", 10, [(u, v, t) for (u, v), t in zip(pet, pat)]))

    q3 = [(v, v ^ (1 << b)) for v in range(8) for b in range(3) if v < (v ^ (1 << b))]
    patq = [1, 0, 1, 1, 0, 1, 2, 0, 1, 1, 0, 1]
    bases.append(CyclicBase("Q3", 8, [(u, v, t) for (u, v), t in zip(q3, patq)]))

    k33 = [(i, 3+j) for i in range(3) for j in range(3)]
    patk = [1, 0, 1, 1, 2, 0, 0, 1, 1]
    bases.append(CyclicBase("K33", 6, [(u, v, t) for (u, v), t in zip(k33, patk)]))

    for B in bases:
        C, t1, t2, psi, lam1 = B.constant()
        M1 = 4*np.pi**2*C
        M1d = B.M1_difference()
        log.append(f"\n=== base {B.name}, p={B.p}, windings "
                   f"{[e[2] for e in B.edges]}")
        log.append(f"  Lambda_1(0) = {lam1:.12f},  Perron vector = "
                   f"{np.round(np.real(psi), 6).tolist()}")
        log.append(f"  closed form: C = t1 - t2 = {t1:.12f} - {t2:.12f} = {C:.12f}")
        log.append(f"  M_1 = 4 pi^2 C = {M1:.12f}    finite difference M_1 = {M1d:.12f}")
        log.append(f"  relative discrepancy of the two: "
                   f"{abs(M1-M1d)/M1:.3e}")
        log.append("     n   nverts   lambda_2(G_n)     gap            "
                   "C_n = n^2 gap/(2 pi^2)    ratio to C")
        rows = []
        for n in [2, 3, 4, 5, 6, 8, 10, 15, 20, 30, 40, 60, 80, 120, 160]:
            if n*B.p > 1400:
                continue
            ev = B.spectrum_cyclic(n)
            gap = ev[0]-ev[1]
            Cn = n*n*gap/(2*np.pi**2)
            rows.append(dict(n=n, nverts=n*B.p, lam2=float(ev[1]),
                             gap=float(gap), Cn=float(Cn), ratio=float(Cn/C)))
            log.append(f"  {n:4d} {n*B.p:7d}  {ev[1]:.12f}  {gap:.9e}  "
                       f"{Cn:.9f}      {Cn/C:.9f}")
        for n in (3, 4):
            A = B.lift_adjacency(n)
            ex = np.sort(np.linalg.eigvalsh(A))[::-1]
            bl = B.spectrum_cyclic(n)
            log.append(f"  cross-check explicit lift n={n}: "
                       f"max|explicit - Bloch| = {np.max(np.abs(ex-bl)):.3e}")
        g = [int(B.girth(n)) for n in (3, 5, 8)]
        log.append(f"  girths of the cyclic covers n = 3,5,8 : {g}")
        out[B.name] = dict(p=B.p, edges=[[int(a), int(b), int(c)] for (a, b, c) in B.edges],
                           lam1=float(lam1), C=float(C), t1=float(t1), t2=float(t2),
                           M1=float(M1), M1_fd=float(M1d), rows=rows, girth=g)

    txt = "\n".join(log)
    open(os.path.join(OUT, "s05_cyclic.log"), "w").write(txt)
    json.dump(out, open(os.path.join(OUT, "s05_cyclic.json"), "w"), indent=1)
    print(txt)


if __name__ == "__main__":
    main()
