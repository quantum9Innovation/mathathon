"""
Hypergraph Berge non-backtracking operator on flags (v,e), v in e:
    B[(v,e),(w,f)] = 1   iff   w != v, w in e, f != e, w in f.
For a k-uniform, d-regular, linear hypergraph this is a 0/1 matrix with constant
row sum (k-1)(d-1), so the Perron eigenvalue is (k-1)(d-1).  Question addressed:
how many eigenvalues of maximal modulus (the "trivial" ones) does B have?
This decides which index is the first informative one: if there are t trivial
eigenvalues of modulus (k-1)(d-1), the first nontrivial one is lambda_{t+1}.
"""
import json
import numpy as np
from itertools import combinations

rng = np.random.default_rng(2026)
out = []

def random_regular_linear_hypergraph(k, d, n, rng, tries=200):
    """configuration model on vertex stubs; reject multi-edges/parallel vertices."""
    for _ in range(tries):
        stubs = np.repeat(np.arange(n), d)
        rng.shuffle(stubs)
        edges = [tuple(sorted(stubs[i:i + k])) for i in range(0, len(stubs), k)]
        if any(len(set(e)) < k for e in edges):
            continue
        if len(set(edges)) < len(edges):
            continue
        # linearity: no pair of vertices in two edges
        pairs = set()
        ok = True
        for e in edges:
            for p in combinations(e, 2):
                if p in pairs:
                    ok = False; break
                pairs.add(p)
            if not ok: break
        if ok:
            return edges
    return None

def berge_nb(edges, n, k, d):
    flags = [(v, i) for i, e in enumerate(edges) for v in e]
    idx = {f: j for j, f in enumerate(flags)}
    inc = [set(e) for e in edges]
    v2e = {}
    for i, e in enumerate(edges):
        for v in e:
            v2e.setdefault(v, []).append(i)
    B = np.zeros((len(flags), len(flags)))
    for (v, i) in flags:
        for w in inc[i]:
            if w == v: continue
            for f in v2e[w]:
                if f != i:
                    B[idx[(v, i)], idx[(w, f)]] += 1
    return B, len(flags)

print("k,d,n,#edges,#flags,perron,(k-1)(d-1),#(modulus=perron),next modulus, ratio next/perron")
for k in [3, 4, 5]:
    for d in [2, 3, 4]:
        n = 400
        edges = random_regular_linear_hypergraph(k, d, n, rng)
        if edges is None:
            print(f"k={k} d={d}: sampling failed"); continue
        B, nf = berge_nb(edges, n, k, d)
        w = np.linalg.eigvals(B)
        mods = np.sort(np.abs(w))[::-1]
        perron = (k - 1) * (d - 1)
        t = int(np.sum(np.abs(mods - perron) < 1e-6))
        nxt = mods[t] if t < len(mods) else np.nan
        out.append(dict(k=k, d=d, n=n, nflags=nf, perron=float(perron), trivial_count=t,
                        next_modulus=float(nxt), ratio=float(nxt / perron)))
        print(f"{k},{d},{n},{len(edges)},{nf},{mods[0]:.4f},{perron},{t},{nxt:.5f},{nxt/perron:.5f}",
              flush=True)
json.dump(out, open("raw/hypergraph_nb_trivial.json", "w"), indent=1)
print("written raw/hypergraph_nb_trivial.json")
