import sys, urllib.request, xml.etree.ElementTree as ET
ns={'a':'http://www.w3.org/2005/Atom'}
ids = ",".join(sys.argv[1:])
url = "https://export.arxiv.org/api/query?id_list=" + ids + "&max_results=20"
t = ET.fromstring(urllib.request.urlopen(url, timeout=60).read())
for e in t.findall('a:entry', ns):
    aid = e.find('a:id', ns).text.split('/abs/')[-1]
    ti = ' '.join(e.find('a:title', ns).text.split())
    au = ', '.join(x.find('a:name', ns).text for x in e.findall('a:author', ns))
    pub = e.find('a:published', ns).text[:10]
    upd = e.find('a:updated', ns).text[:10]
    su = ' '.join(e.find('a:summary', ns).text.split())
    print("="*100)
    print(f"{aid}  pub {pub}  upd {upd}")
    print(f"TITLE: {ti}")
    print(f"AUTHORS: {au}")
    print(f"ABSTRACT: {su}")
