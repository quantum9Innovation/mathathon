# Batch 060 / m2 / direction d3

## Rooted bounded-cluster embedding, exterior resolvent, and the complete secular law for
## the full-neighbourhood cluster `T = N(c)`

Swarm `smwh0bmpx`, member `m2`, direction `d3`. Everything labelled **(P)** is proved below
in full from the stated inputs, **(C)** is an exact computation (sympy, `check_symbolic.py`,
raw output `out/symbolic.txt`), **(L)** is a literature import with its hypotheses checked,
**(N)** is numerics (corroboration only, `num_check.py`, `out/numeric.json`).

Inputs held fixed: `results/050-finite-defect.md`, `.ultramath/smwgwbyn9/m2/proof.md`,
`.ultramath/smwgwbyn9/m6/THEOREM.md`, `results/spectral-research/batch-060/FROZEN-SEPARATED-CASE.md`.
None of them is rewritten here. One genuine (rate-only) defect of the batch-050 proof is
reported separately in `ERRATUM-050-theoremC-rate.md`; the limit statement affected by it is
not used here.

---

## 0. What is proved

Fix an integer `d ≥ 3`, `e := 2√(d-1)`, and the principal branch

```
r(λ) = (λ - √(λ²-4(d-1)))/(2(d-1)) ∈ (0, 1/√(d-1))     (λ > e),
G_d(λ) = r/(1-r²) = 1/(λ - d r) .
```

For a fixed bounded rooted pattern with marked set `T_∞` put

```
P_T(r) := Σ_{s,t∈T_∞} r^{dist_{T_d}(s,t)} ,      Φ_T(λ) := λ - G_d(λ) P_T(r(λ)) .
```

**Theorem 1 (pattern resolvent limit, general bounded rooted cluster). (P)**
Under the pattern hypothesis (H1) of §1, with `L_n = ⌊(1/4) log_{d-1} n⌋` and any compact
`K ⊂ (e,∞)`:

```
1_{T_n}^T (A_n - λ I)^{-1} 1_{T_n} = - G_d(λ) P_T(r(λ)) + Δ²/(n(d-λ)) + E_n(λ),
|E_n(λ)| ≤ C(d,R,Δ,K) [ ρ_1^{L_n+1} + ρ_*^{L_n+1} + n^{-1} B_K ]      (λ ∈ K, λ≠d),
```

with `ρ_1 = e/λ_min < 1`, `ρ_* < 1`, `B_K` an explicit constant, uniformly in `λ ∈ K`, with
probability `≥ 1 - C n^{-γ(d)}`, `γ(d) = 1 - (1/2)·log d/log(d-1) > 0` (`γ(3) ≈ 0.207`).
The pole-free version — replace `1_{T_n}` by `Q 1_{T_n}`, `Q = I - J/n` — holds on compacts
of `(e,∞)` *including* `λ = d`. The finite off-diagonal terms `s ≠ t` are **kept exactly**:
they are the terms `r^{dist(s,t)}` of `P_T`, not discarded.

**Theorem 2 (pattern secular law). (P)** `Φ_T` is real-analytic and strictly increasing on
`(e,∞)` with `Φ_T' > 1` and `Φ_T(λ) → +∞`. Hence it has **at most one** exterior root, always
simple. A root exists iff `P_T(1/√(d-1)) > 2(d-2)` (strict), and then it is unique.

**Theorem 3 (top-two eigenvalues, all cases). (P)** With `λ_P` the exterior root, and the
convention `λ_P := e` when none exists,

```
λ_1(G'_n) → max(d, λ_P),    λ_2(G'_n) → min(d, λ_P)      in probability,
```

including the degenerate case `λ_P = d`, where both limits are `d` and
`√n (λ_1(G'_n) - d) → +Δ/√(Φ_T'(d))`, `√n (d - λ_2(G'_n)) → +Δ/√(Φ_T'(d))`
(Theorem 4). Each of `λ_1(G'_n), λ_2(G'_n)` is a **simple** eigenvalue of `G'_n` for all large
`n` on the good event, and the host eigenvalue multiplicity is handled in §8.

**Theorem 5 (worked families). (P)+(C)**

* `T = N(c)`, all `d ≥ 3`. `P_T(r) = d + d(d-1)r²`, the exterior root always exists, and

  ```
  r_P² = 1/(d+1),      λ_P = 2d/√(d+1)      (exact, unique, simple),
  Φ_T'(λ_P) = 2(d+1).
  ```

  `2√(d-1) < λ_P < d` for `d ≥ 4`; `λ_P = d = 3` for `d = 3`.

* Adjacent pair `T = {c,u}`, all `d ≥ 3`. `P_T(r) = 2 + 2r`. An exterior root exists **iff
  `d = 3`**; for `d = 3` it is the unique root of `2r⁴ + 2r³ + r² - 1 = 0` in
  `(0,1/√2)`, `r_P = 0.58975451…`, `λ_P = 2.87512979…` `(C)`. For `d ≥ 4` there is no defect
  eigenvalue: `λ_1(G') → d`, `λ_2(G') → e`.

**Theorem 4 (near-Perron displacements). (P)** Write `τ := Φ_T(d) = d - G_d(d)P_T(r(d))`,
`r(d) = 1/(d-1)`, `G_d(d) = (d-1)/(d(d-2))`.

* `τ < 0` (equivalently `λ_P > d`, a root above `d`): `n(d - λ_2(G'_n)) → Δ²/|τ|`.
* `τ > 0`: `n(λ_1(G'_n) - d) → Δ²/τ` **always** — whether or not an exterior root exists.
  If `λ_P < d` then `λ_2(G'_n) → λ_P`; if no exterior root exists then `λ_2(G'_n) → e`.
* `τ = 0` (critical, `λ_P = d`): the `1/n` law degenerates to a **`√n` law**
  `√n|λ_i(G'_n) - d| → Δ/√(Φ_T'(d))`, `i = 1,2`, and `ν_1 - ν_2 ~ 2Δ/√(nΦ_T'(d))`.
* `T = N(c)`: `τ = d(d-3)/(d-2)`, so `τ>0 ⟺ d ≥ 4` and `τ = 0 ⟺ d = 3`; at `d=3`,
  `Δ/√(Φ_T'(d)) = 3/√8 = 1.06066…`, i.e. `λ_{1,2}(G'_n) = 3 ± 1.0607/√n (1+o(1))`.

**Proposition 6 (pole bookkeeping). (P)** On the whole exterior branch the algebraic
denominator `λ - d r(λ)` of the `dλr/(λ-dr)` form never vanishes: `λ - d r = (1-r²)/r > 0`.
The "pole" `λ = d r` combined with the branch equation forces `r² = 1`, `λ = ±d`, outside
`|r| < 1/√(d-1)`. So the alternative representation has **no pole in the domain** and its use
needs no domain restriction here. The only genuine spectral pole of `Σ_n` in the window is the
host Perron pole at `λ = d` (residue `Δ²/n`), which is *not* a zero of the pattern law except
in the critical case of Theorem 5; see §6–§7. The pattern function `Φ_T` itself is pole-free
on `(e,∞)`.

Not claimed: bulk energies `λ ∈ [-e,e]`, growing `|T|`, random attachment rules that are not
functions of a bounded rooted neighbourhood, complex `z` near the branch cut, rates, any
novelty claim, and any Lean formalisation. No universality statement is made.

---

## 1. Setting and the pattern hypothesis

`G_n` is uniform simple `d`-regular on `[n]`, `dn` even, `d ≥ 3` fixed; `A = A_{G_n}`;
`c` is a fixed vertex label (`c = 1`). `G'_n` is `G_n` plus one new vertex `x` adjacent to
exactly `T_n ⊆ [n]`. `J = 11^T`, `P = J/n`, `Q = I - P`, `A' := QAQ = A - dP`.

**Pattern hypothesis (H1).** Fix `R ≥ 0`, `Δ ≥ 1` and a fixed finite `T_∞ ⊆ V(B_R^{T_d}(o))`
with `|T_∞| = Δ`. For each `n` let `T_n ⊆ [n]`, `|T_n| = Δ`, and assume: on the event

```
𝒢_n := { B_{R+L_n}(c) is rooted-isomorphic to B_{R+L_n}^{T_d}(o) }
```

there is a rooted isomorphism `φ: B_{R+L_n}(c) → B_{R+L_n}^{T_d}(o)` with `φ(T_n) = T_∞`.

Two instances (both with `R = 1`), verified in §10:

* `T_n = N(c)`, `T_∞ = N_{T_d}(o)`;
* `T_n = {c, u}` where `u` is any neighbour of `c` specified by a rule that is a function of
  the labelled rooted tree `B_1(c)` (e.g. the least label), `T_∞ = {o, s}` for a neighbour
  `s` of `o`.

In both cases `dist_{G_n}(s,t) = dist_{T_d}(φ(s),φ(t))` on `𝒢_n` because a rooted isomorphism
of trees preserves distances; hence the polynomial `P_T` is well defined and independent of
which isomorphism `φ` the hypothesis supplies. This is exactly the "fixed deterministic
procedure from a radius-`R` neighbourhood" of the batch target, with no broadening: a rule
that is not a function of `B_R(c)` is not covered.

## 2. Exact algebra: tree resolvent and pattern kernels

**Lemma 2.1 (tree resolvent; (P)).** For `λ > e` and vertices `s,t` of `T_d`,
`(λ - A_{T_d})^{-1}_{ts} = G_d(λ) r(λ)^{dist(s,t)}`.

*Proof.* Put `h_x := G_d r^{dist(x,s)}`. Then `‖h‖² = G_d² Σ_n d(d-1)^{n-1} r^{2n} < ∞`
since `(d-1)r² < 1`, so `h ∈ ℓ²`. For `x ≠ s` with `dist(x,s) = j ≥ 1`, exactly one
neighbour of `x` lies at distance `j-1` from `s` and the other `d-1` at distance `j+1`
(true in a tree), hence

```
(A_{T_d} h)(x) = G_d r^j (1/r + (d-1) r) = G_d r^j λ = λ h_x .
```

At `x = s`, `(A h)(s) = d G_d r` while `λ h_s = λ G_d`, so
`((λ - A)h)(s) = G_d(λ - dr) = 1` by `G_d = 1/(λ-dr)`. Thus `(λ-A_{T_d})h = δ_s`. ∎

**Lemma 2.2 (kernels; (P)+(C)).** On `λ > e`, `r = r(λ)`:

```
λ - d r = (1-r²)/r > 0 ;     G_d = r/(1-r²) = 1/(λ-dr) .
T = {c,u}, dist 1 :  K_adj = G_d(2+2r) = 2r/(1-r) .
T = N(c), Δ = d    :  K_N   = G_d(d + d(d-1)r²) = d λ r/(λ - d r) .
```

*Proof.* `λ - dr = (d-1)r + 1/r - dr = 1/r - r = (1-r²)/r > 0` for `0 < r < 1`.
`G_d (2+2r) = r(2+2r)/(1-r²) = 2r/(1-r)`. For the last, `G_d(d+d(d-1)r²) =
dr(1+(d-1)r²)/(1-r²)` and `dλr/(λ-dr) = dλr²/(1-r²)`, and these agree because
`λ r = (d-1)r² + 1`. Independently, both kernels were re-derived from the exact reduced
systems in §10 and checked symbolically `(C)`. ∎

## 3. The rank-one Perron splitting and the exact walk identity

**Lemma 3.1 ((P); batch-050 Lemma 1, re-derived).** `PA' = A'P = 0`, `A' = QAQ = A'Q = QA'`,
`‖A'‖ = max_{i≥2}|λ_i(A)| = λ_2(A) ∨ |λ_n(A)|` for connected `G_n`, and for every `k ≥ 1`

```
(A'^k)_{yy'} = (A^k)_{yy'} - d^k/n      (all y,y').
```

Consequently, for `λ ∉ σ(A)`, `(A-λI)^{-1} = P/(d-λ) - Σ_{k≥0} A'^k/λ^{k+1}`, norm convergent
for `|λ| > ‖A'‖`.

*Proof.* `A'P = (A - dP)P = dP - dP = 0` and `PA' = 0`; the rest of (i) is immediate since
`im P = ker Q` is the Perron line. For the identity: `k=1` is `A' = A - (d/n)J`; assuming it at
`k`, `A'^{k+1} = (A - (d/n)J)(A^k - (d^k/n)J) = A^{k+1} - (d^k/n)AJ - (d/n)JA^k + (d^{k+1}/n²)J²`
and `AJ = dJ`, `JA^k = d^k J`, `J² = nJ` give `-d^{k+1}J/n - d^{k+1}J/n + d^{k+1}J/n`. ∎

**Lemma 3.2 (walk identity with the off-diagonal terms kept; (P)).** On `𝒢_n`, for every
`k ≤ L_n` and all `y,y' ∈ T_n`,

```
(A^k)_{yy'} = (A_{T_d}^k)_{φ(y)φ(y')} ,   so   1_{T_n}^T A^k 1_{T_n} = W_k := 1_{T_∞}^T A_{T_d}^k 1_{T_∞} .
```

*Proof.* A walk of length `k` from `y` stays within graph distance `k` of `y`; as `y ∈ B_R(c)`,
it stays in `B_{R+k}(c) ⊆ B_{R+L_n}(c)`, which on `𝒢_n` is isometric (as a rooted graph) to
`B_{R+L_n}^{T_d}(o)`. Walk counts are isomorphism invariants. ∎

This is the step where the separated-case argument is *not* reused: no off-diagonal term is
discarded, all of them are evaluated exactly as tree distances. Note `W_0 = Δ`,
`0 ≤ W_k ≤ Δ² e^k` since `‖A_{T_d}‖ = e`.

## 4. The marked-tree-embedding event and its probability

**Lemma 4.1 ((P)).** Fix `d ≥ 3`, `b > 0` with `2b·log d/log(d-1) < 1`, put
`L = L(n) = ⌊b log_{d-1} n⌋`, and fix a label `c`. Then for `n` large, with `B_m = B_m(c)`,

```
P( B_{R+L}(c) is not rooted-isomorphic to B_{R+L}^{T_d}(o) )  ≤  C(d,R) n^{-ε(b)} ,
ε(b) := 1 - 2b·log d/log(d-1) .
```

*Proof (pairing model).* Reveal `B_{R+L}(c)` level by level: attach `d` labelled stubs to every
vertex, take a uniform random perfect matching, reveal stub partners in order of increasing
depth. Let `R_0 := d^{R+L+1}`. At most `R_0` pairs are revealed and at most `2R_0` stubs are
used, so conditionally on the history the partner of the chosen stub is uniform among at least
`dn - 2R_0` unmatched stubs, of which at most `2R_0 + d` are "bad" (already used, or a stub of
the current vertex). A union bound gives, under the pairing measure `P_n`,

```
P_n(failure) ≤ R_0 (2R_0 + d)/(dn - 2R_0) ≤ 4 d^{2(R+L+1)}/(dn) ≤ C(d,R) n^{-ε(b)}
```

with `ε(b) = 1 - 2b·log d/log(d-1) > 0`, since `d^{2L} ≤ n^{2b log d/log(d-1)}`. Since every simple
`d`-regular graph arises from exactly `(d!)^n` pairings and `P_n(simple) → e^{-(d²-1)/4} > 0`
(Angel–van der Hofstad–Holmgren, Cor. 1.2, as verified in `.ultramath/smwgwbyn9/m6/THEOREM.md`
Lemma 1 (L)), the bound transfers to the uniform simple model at the cost of a constant. ∎

Taking `b = 1/4` (our choice below) gives `ε = γ(d) = 1 - (1/2)log d/log(d-1) > 0`, e.g.
`γ(3) = 0.2075`, `γ(4) = 0.5`; any `b < (1/2)log(d-1)/log d` is admissible. This is a
*marked-tree-embedding* statement: one event controls the ball, the
marked distances, the cycle-freeness of the ball, and the walk counts simultaneously, so no
separate "pairwise separation" event is needed and none is assumed.

**Input 4.2 ((L) Friedman/Bordenave; same statement as batch-050).** For fixed `d ≥ 3` and a
uniform simple `d`-regular graph, for every `δ > 0`,
`P(λ_2(A) ∨ |λ_n(A)| ≥ e + δ) → 0`, quantitatively `≤ n^{-a}` with rate
`e + c(d,a)((log log n)/log n)²` (Bordenave, arXiv:1502.04482v4, Thm 1 and eq. (2);
Friedman, Mem. AMS 195 (2008), no. 910). Also `P(G_n connected) → 1` (classical).
Combined with Lemma 4.1: for every `δ>0` there is `Ω_n` with `P(Ω_n) ≥ 1 - C n^{-γ(d)}` on
which `G_n` is connected, `‖A'‖ ≤ e + δ`, and `𝒢_n` holds.

## 5. Theorem 1: the clustered resolvent limit

Fix a compact `K ⊂ (e,∞)`, `λ_min := min K`, and `δ > 0` with `e + 2δ ≤ λ_min`. Put
`ρ_1 := e/λ_min < 1`, `ρ_* := (e+δ)/λ_min < 1`. Let `L = L_n = ⌊(1/4) log_{d-1} n⌋`.

On `Ω_n`, for `λ ∈ K`, `λ ≠ d`, Lemmas 3.1–3.2 give

```
1_T^T(A-λ)^{-1}1_T = Δ²/(n(d-λ)) - Σ_{k≥0} 1_T^T A'^k 1_T / λ^{k+1}
                   = Δ²/(n(d-λ)) - Σ_{k=0}^{L} (W_k - Δ²d^k/n)/λ^{k+1} + R_L ,
|R_L| ≤ Δ²(‖A'‖/λ)^{L+1}/(λ(1-‖A'‖/λ)) ≤ Δ²ρ_*^{L+1}/(λ_min(1-ρ_*)) .
```

Completing the tree series (`|λ| > ‖A_{T_d}‖ = e`, so absolutely convergent) and using
Lemma 2.1 plus `Σ_{k≥0}W_k/λ^{k+1} = G_d(λ)P_T(r(λ))`, which follows from
`Σ_k (A_{T_d}^k)_{st}λ^{-k-1} = (λ - A_{T_d})^{-1}_{st}`,

```
1_T^T(A-λ)^{-1}1_T + G_d(λ)P_T(r(λ)) = Δ²/(n(d-λ)) + E_n(λ),
E_n(λ) = Σ_{k>L} W_k/λ^{k+1} + (Δ²/(nλ))Σ_{k=0}^{L}(d/λ)^k + R_L ,
```

and the three terms are bounded uniformly in `λ ∈ K` by

```
|Σ_{k>L} W_k λ^{-k-1}| ≤ Δ² ρ_1^{L+1}/(λ_min(1-ρ_1))          (using |W_k| ≤ Δ² e^k),
(Δ²/(nλ))Σ_{k≤L}(d/λ)^k  ≤ (Δ²/(nλ_min))·(1 - d/λ)^{-1}              if λ > d,
                          ≤ (Δ²/(nλ_min))·(d/λ_min)^{L}(1 - λ_min/d)^{-1}  if λ < d,
|R_L| ≤ Δ² ρ_*^{L+1}/(λ_min(1-ρ_*)) .
```

Each vanishes: the first and third geometrically in `L`; the second is `O(1/n)` above `d` and
at most `n^{-1}(d/λ_min)^{L}·C` below `d`, where
`(d/λ_min)^{L} ≤ d^{log_{d-1}(n^{1/4})} = n^{(1/4)log d/log(d-1)} ≤ n^{0.397}`, so that term is
`≤ C n^{-0.603}`. Since `P(Ω_n^c) ≤ C n^{-γ(d)}`, Theorem 1 follows, including the uniformity
in `λ`. For the pole-free version use Lemma 3.1 applied to `Q1_{T_n}`:
`1_T^T(A-λ)^{-1}Q1_T = -Σ_k 1_T^TA'^k1_T/λ^{k+1}` exactly, with the same estimates, and this
is continuous at `λ = d` because `Φ_T` is (Lemma 6.1); the Perron term is exactly
`Δ²/(n(d-λ)) = 1_T^TP1_T/(d-λ)`. ∎

**Remark 5.1.** The three probabilistic inputs are exactly: connectivity, Friedman's bound
(Input 4.2), and the marked embedding event (Lemma 4.1). No local law, no second moment, no
bulk input. The mechanism is that `‖A'‖ < λ` turns the exterior resolvent into a geometrically
decaying operator, so a *fixed* bounded pattern sees only the ball of radius `O(log n)`, and on
that ball all walk counts are exactly tree counts — including the off-diagonal ones.
**Remark 5.2.** Uniformity in `λ` on `K` and in `n` is explicit; there is no tightness or
compactness argument anywhere, so no Vitali/Montel step is required (the batch-050 m6 approach
and this one agree on the answer but not on the mechanism).

## 6. Poles: algebraic representation versus spectrum

`Σ_n(λ) := λ + 1_T^T(A-λ)^{-1}1_T` (defined off `σ(A)`), and `Φ_T(λ) = λ - G_dP_T(r)`.

**Lemma 6.1 ((P)).** `Φ_T` is real analytic on `(e,∞)` and

```
Φ_T'(λ) = 1 + |G_d'(λ)| P_T(r) + G_d(λ) P_T'(r)|r'(λ)| > 1 .
```

*Proof.* `G_d' = dG_d/dr · r'`, `dG_d/dr = (1+r²)/(1-r²)² > 0`, and
`r' = 1/((d-1) - r^{-2}) = -r²/(1-(d-1)r²) < 0` on the branch. `P_T(r) = Σ r^{ρ(s,t)}` has
non-negative coefficients, so `P_T ≥ Δ > 0` and `P_T' ≥ 0` for `r ≥ 0`. Hence
`Φ_T' = 1 - G_d'P_T - G_d P_T' r' = 1 + |G_d'|P_T + G_d P_T'|r'| > 1`. ∎

**Lemma 6.2 (no pole of the pattern law; (P)).** `Φ_T` has no singularity in `(e,∞)`.
Moreover the representation `K_N = dλr(λ)/(λ - dr(λ))` is pole-free on the entire domain
`{λ : 0 < r(λ) < 1/√(d-1)}`.

*Proof.* `G_d = r/(1-r²)` is analytic for `|r| < 1`; on the branch `r < 1/√(d-1) < 1` for
`d ≥ 2`. The only candidate singularity of `dλr/(λ-dr)` is `λ = dr`, and with the branch
equation `λ = (d-1)r + 1/r` this forces `r = 1/r`, `r² = 1`, `λ = ±d`, which is excluded by
`0 < r < 1`. (By Lemma 2.2 the denominator equals `(1-r²)/r`, which is positive, so the
identity is an identity of two finite quantities and no removal of a singularity is needed.)
∎

**Lemma 6.3 (the genuine poles of `Σ_n`; (P)).** `Σ_n` has a simple pole at every eigenvalue of
`A`, in particular at `λ = d` (the host Perron point) with residue `Δ²/n`, because
`1_{T_n}^T1 = Δ ≠ 0`. Consequently

```
Σ_n(λ) = Δ²/(n(d-λ)) + Σ_n^⊥(λ),      Σ_n^⊥ := λ + 1_T^T(A-λ)^{-1}Q1_T ,
```

`Σ_n^⊥` is analytic on `R ∖ (σ(A)∖{d})` and Theorem 1 gives `Σ_n^⊥ → Φ_T` uniformly on
compacts of `(e,∞)` (including `λ = d`). Also `Σ_n'(λ) = 1 + ‖(A-λ)^{-1}1_T‖² > 0` off
`σ(A)`, so every zero of `Σ_n` off `σ(A)` is simple.

*Proof.* Residue at `μ ∈ σ(A)`: `1_T^T Π_μ 1_T` where `Π_μ` is the spectral projector; at
`μ = d`, `Π_d = P` and `1_T^TP1_T = Δ²/n ≠ 0`. At other `μ` the residue can vanish (that is
the "eigenvalue loss" case), but the pole structure of `Σ_n` at `d` is exact. ∎

So a pole of an algebraic representation is never confused with a spectral point: `Φ_T` has
none in the window, the `dλr/(λ-dr)` denominator has none on the branch, and the only actual
pole of `Σ_n` in the window is `d` itself, an artefact of the host Perron vector and *not* a
root of the pattern law except in the critical case of Theorem 5.

## 7. Theorem 2: existence, uniqueness, simplicity of the exterior root

`Φ_T(λ) → +∞` as `λ → ∞` because `r = 1/λ + O(λ^{-2})`, `G_d = 1/λ + O(λ^{-2})`, so
`Φ_T = λ - Δ/λ + O(λ^{-2})`. By Lemma 6.1 `Φ_T` is strictly increasing, so there is at most
one root. The limit at the bulk edge (Lemma 2.2, `G_d(e) = √(d-1)/(d-2)`, `r(e)=1/√(d-1)`) is

```
Φ_T(e) = √(d-1) [ 2 - P_T(1/√(d-1))/(d-2) ] .
```

Hence a root exists iff `P_T(1/√(d-1)) > 2(d-2)`; if `P_T(1/√(d-1)) = 2(d-2)` the root is at
the edge `λ_P = e` (marginal case), and if `<` then `Φ_T > 0` on all of `(e,∞)` and there is no
exterior root. In both families of Theorem 5 the marginal case does not occur (`(C)`).
Simplicity is `Φ_T' > 1`. ∎

## 8. Theorem 3: from the resolvent limit to the top-two eigenvalues

Notation: `λ_1 ≥ λ_2 ≥ …` for `A` and `ν_1 ≥ ν_2 ≥ …` for `A_{G'_n}`; `p_A(λ)=det(λI-A)`.

**Step 1 (exact secular identity; (P)).** For `λ ∉ σ(A)`, `p_{G'}(λ) = p_A(λ)Σ_n(λ)`, hence
`λ ∈ σ(G') ⟺ Σ_n(λ) = 0`. (Schur complement of the `1×1` block `(λ)`:
`p_{G'} = λ p_A - p_A · 1_T^T(λ-A)^{-1}1_T·… ` sign convention as in batch 050; the identity
is `p_{G'}(λ) = p_A(λ)(λ + 1_T^T(A-λ)^{-1}1_T)`, re-verified in exact rational arithmetic in
batch 050 §4.) Hence in any open gap `I` of `σ(A)`, the eigenvalues of `G'` in `I` are exactly
the zeros of `Σ_n` in `I`, with multiplicity.

**Step 2 ((P)).** `Σ_n` is strictly increasing on each gap of `σ(A)` (Lemma 6.3), so it has at
most one zero there, necessarily simple. The relevant gaps are `(λ_2(A), d)` and `(d, +∞)`
(the host `d` is simple because `G_n` is connected). Therefore `G'` has at most one eigenvalue
in each, and each such eigenvalue of `G'` is simple. In particular, **repeated host
eigenvalues do not create any ambiguity**: if `λ_2(A) = λ_3(A)`, the open gap is still
`(λ_2(A), d)` and still contains at most one eigenvalue of `G'`; the Cauchy count that `G'` has
exactly one eigenvalue in the union of gaps where `Σ_n` changes sign is unaffected.

**Step 3 (counting; (P)).** The number of eigenvalues of `G'` in an open gap `I` of `σ(A)` equals
the number of zeros of `Σ_n` in `I`, and `Σ_n` is strictly increasing there, so that number is
`≤ 1`; interlacing (`ν_1 ≥ λ_1 = d ≥ ν_2 ≥ λ_2(A) ≥ ν_3 ≥ …`) locates it. Concretely:

* if `Σ_n` has a zero `z ∈ (λ_2(A), d)` then `ν_2 = z` (an eigenvalue of `G'` in that gap must
  be `ν_2`, since `ν_1 ≥ d` and `ν_3 ≤ λ_2(A)`);
* if not, then `ν_2 ∈ {λ_2(A), d}` — the endpoint case `ν_2 = λ_2(A)` is the exact
  "eigenvalue preserved" case, which occurs precisely when `1_T^TΠ_{λ_2(A)}1_T = 0` (then
  `Σ_n` does not diverge at `λ_2(A)^+`); either way `ν_2 ∈ [λ_2(A), d]`.

The same argument in the gap `(d,∞)` gives: `ν_1` is the unique zero of `Σ_n` in `(d,∞)` if it
exists, and `Σ_n → +∞` while `Σ_n(d^+) = -∞`, so it always exists. Finally `d ∉ σ(G')` iff
`Σ_n^⊥(d) = h_n(d) ≠ 0`, where

```
h_n(λ) := λ + 1_T^T(A-λ)^{-1}Q1_T ,      h_n(d) = d - 1_T^T(A-d)^{+}1_T
```

(derive: `(A-d)u + t1_T = 0` and `1_T^Tu = dt` give `t·h_n(d) = 0`; here `(A-d)^+` is the
pseudo-inverse, `Q1_T ⊥ 1`). This is the precise replacement for the batch-050 claim
"`1_T^T1 ≠ 0` kills the Perron eigenvalue": that argument only shows the Perron *vector* does
not survive, not that `d ∉ σ(G')`. By Theorem 1, `h_n(d) → Φ_T(d)`, so `d ∈ σ(G'_n)` is
*asymptotically possible* exactly in the critical case `Φ_T(d) = 0` (Theorem 5, `d = 3`,
`T = N(c)`), where it is decided by a single exact scalar equation and no general exclusion
holds.

**Step 4 (identification; (P)).** Let `λ_P` be the exterior root, or `λ_P := e` if there is
none. Fix `η > 0` small.

* *Root below `d`* (`Φ_T(d) > 0`). Choose `η` with `Φ_T > 0` on `[λ_P+η, d-η]`. Then
  `Σ_n^⊥ > 0` there for large `n`, and `Σ_n = Σ_n^⊥ + Δ²/(n(d-λ)) > 0` there too. Since
  `Σ_n → -∞` just above `λ_2(A)` and `λ_2(A) < λ_P+η` eventually, `ν_2 ∈ (λ_2(A), λ_P+η)`.
  And `Σ_n(d+η) > 0 > Σ_n(d^+) = -∞` gives `ν_1 ∈ (d, d+η)`. So `ν_2 → λ_P`, `ν_1 → d`.
* *Root above `d`* (`Φ_T(d) < 0`). Then `Φ_T < 0` on `[d-η, d-η/1]`… precisely: `Φ_T < 0` on
  `(e, λ_P)`. So `Σ_n(d-η) < 0` and `Σ_n(d^-) = +∞` give `ν_2 ∈ (d-η, d)`; and
  `Σ_n(d+η) < 0 < Σ_n(λ_P+η)` gives `ν_1 ∈ (d+η, λ_P+η)`. So `ν_2 → d`, `ν_1 → λ_P`.
* *No root* (`Φ_T > 0` on `(e,∞)`). Then `Σ_n > 0` on `[e+η, d-η]`, and
  `Σ_n^⊥(d) = h_n(d) → Φ_T(d) > 0` gives `d ∉ σ(G'_n)` eventually, so `ν_2 ∈ [λ_2(A), e+η]`
  (Step 3, endpoint case included), while `λ_2(A) → e` in probability (Input 4.2) and
  `ν_2 ≥ λ_2(A)` by interlacing. So `ν_2 → e = λ_P` and `ν_1 → d`.
* *Critical case* `Φ_T(d) = 0`: `λ_P = d`; both zeros squeeze to `d`, Theorem 4.

This proves Theorem 3 and, with Lemma 6.3, the simplicity statement: on `Ω_n`, `ν_1` and `ν_2`
are zeros of the strictly increasing function `Σ_n`, hence simple eigenvalues of `G'_n`.

## 9. Theorem 4: near-Perron displacements

Let `τ := Φ_T(d)`, `c_1 := Φ_T'(d) > 1`. By Theorem 1 (pole-free form, which is continuous at
`d`) with `λ = d - s/n`, `0 < s ≤ C`, and `|λ-d| ≤ C/n`:

```
Σ_n(d - s/n) = τ - c_1 s/n + Δ²/s + o(1/n) + o(1)·(1/n error)      uniformly in s ∈ (0,C].
```

(For the last point: the error `E_n` of Theorem 1 is bounded uniformly on `|λ-d| ≤ C/n` by
`C(ρ_1^{L+1}+ρ_*^{L+1}+n^{-0.6})`, which is `o(1)`, and the `Δ²/(n(d-λ)) = Δ²/s` term is
exact. The `o(1)` is what matters; the `1/n` in the middle term is exact Taylor.)
The zero of this strictly increasing function satisfies, with `s = s_n`,

```
Δ²/s_n = -τ + c_1 s_n/n + o(1) .
```

* If `τ < 0`: `s_n → Δ²/|τ|`, i.e. `n(d - λ_2(G'_n)) → Δ²/|τ|`.
* If `τ > 0`: no zero of that size below `d`; instead put `λ = d + s/n`:
  `Σ_n(d+s/n) = τ + c_1 s/n - Δ²/s + o(1)`, so `n(λ_1(G'_n) - d) → Δ²/τ`. (This holds
  whether or not an exterior root exists: the sign condition `Σ_n(d^+) = -∞`,
  `Σ_n(d+η) > 0` only uses `τ > 0`, so `ν_1 ∈ (d, d+η)` for every `η` and `ν_1` is that zero.)
* If `τ = 0`: put `λ = d ± x/√n`. Then `Σ_n = c_1 x/√n ∓ Δ²/(x√n) + o(1/√n)`, so
  `x = ±Δ/√c_1` and the two zeros are at `λ = d ± Δ/√(n c_1)(1+o(1))`. This is the `√n` law.
  (Uniformity over `|λ - d| ≤ C/√n` is exactly what Theorem 1 provides; no other input is
  used.)

For `T = N(c)`: `τ = d(d-3)/(d-2)`, `c_1 = Φ_T'(d)`. At `d = 3`, `c_1 = 2(d+1) = 8` (Lemma 10.3
below gives `Φ_T'(λ_P) = 2(d+1)` and `λ_P = d` there), `Δ = 3`, so `Δ/√c_1 = 3/√8 = 1.06066`. ∎

**Remark 9.1 (this is where the batch target's "λ_f = d" lives).** The separated model's
critical value is `Δ = d²(d-2)/(d-1)`, non-integral for integer `d ≥ 3`, which is how batch 050
excluded it. Here `τ = 0` is `P_T(1/(d-1)) = d²(d-2)/(d-1)`, and `T = N(c)`, `d = 3` gives
`P_T(1/2) = 3 + 6/4 = 4.5 = 9/2 = d²(d-2)/(d-1)`, an integer pattern. So the critical case is
*realised*, and it does not merely shift the `1/n` constant: the displacement changes scale to
`n^{-1/2}`. Nothing about the separated exclusion is imported.

## 10. Theorem 5: the two families, exact

**Lemma 10.1 (`T = N(c)`, (P)+(C)).** `T_∞ = N_{T_d}(o)`, `Δ = d`, `dist(s,t) = 2` for
`s ≠ t`, so `P_T(r) = d + d(d-1)r²`. Reduced system (exact block inverse, `(C)`, checked for
`d = 2,3,4,5`): eliminate the `d-1` half-trees at each marked leaf (`self-energy r`, so leaf
diagonal `λ-(d-1)r = 1/r`, centre diagonal `λ`, couplings `1`), giving
`K_N = 1^T M^{-1}1 = ΔG_{ℓℓ} + Δ(Δ-1)G_{ℓℓ'} = dλr/(λ-dr)`; this is Lemma 2.2.
Roots: `r(1-r²)Φ_T = (1-r²)(1+(d-1)r²) - r²(d+d(d-1)r²) = 1 - 2r² - (d²-1)r^4` `(C)`, i.e.
with `y = r²`, `(d²-1)y² + 2y - 1 = 0` with roots `y = 1/(d+1)` and `y = -1/(d-1)`. So
`r_P² = 1/(d+1)` and `λ_P = 2d/√(d+1)` exactly, `Φ_T(λ_P) = 0` `(C)`;
`Φ_T'(λ_P) = 2(d+1)` `(C)`.
Threshold: `P_T(1/√(d-1)) = 2d > 2(d-2)` for every `d ≥ 3`, so the root always exists
(Theorem 2). Position: `λ_P = d ⟺ 4d² = d²(d+1) ⟺ d = 3`; for `d ≥ 4`,
`4d²/(d+1) > 4(d-1) ⟺ d² > d²-1`, so `e < λ_P < d`. At the Perron point,
`Φ_T(d) = d - [(d-1)/(d(d-2))]·d²/(d-1) = d(d-3)/(d-2)` `(C)`, vanishing exactly at `d = 3`.
∎

**Lemma 10.2 (adjacent pair, (P)+(C)).** `P_T(r) = 2+2r`,
`r(1-r²)Φ_T = 1 + (d-4)r² - 2r³ - (d-1)r^4` `(C)`. Threshold:
`Φ_T(e) = 2[√(d-1)(d-3) - 1]/(d-2)` `(C)`, which is `< 0` exactly when `d = 3` (for `d ≥ 4`,
`√(d-1)(d-3) ≥ √3 > 1`). For `d = 3`, `Numer` has exactly one root in `(0,1)` (exact Sturm
count, `(C)`), it lies below `1/√2` because `Numer(1/√2) = -1/√2 < 0` while `Numer(0) = 1 > 0`;
`2r^4+2r^3+r^2-1=0`, `r_P = 0.58975451230…`, `λ_P = 2.87512979416…`. For `d ≥ 4`, exact Sturm
count `(C)` gives exactly one root of `Numer` in `(0,1)` and `Numer(1/√(d-1)) > 0` with
`Numer(1) = -4 < 0`, so that root lies in `(1/√(d-1),1)`, outside the branch; hence no
exterior root and `Φ_T > 0` on `(e,∞)`. At `d = 3`, `Φ_T(d) = d - 2/(d-2) = 1 > 0`, so the
root is below the Perron point: `λ_2(G') → 2.87513`, `λ_1(G') → 3`. ∎

This settles the batch target's demand for "sensitivity to the attachment distances": the
attachment distance enters only through `P_T`, and the two families (distance 1 and distance
2, both bounded) give thresholds `2(d-2) < 2+2/√(d-1)` (only `d=3`) versus
`2(d-2) < 2d` (always).

## 11. Consistency: recovering the separated case

If the marked set has pairwise distances `→ ∞` (frozen batch-050 model), then `P_T → Δ`
pointwise on the branch (all off-diagonal `r^{ρ} → 0`), so `Φ_T → λ - ΔG_d` and Theorem 2's
threshold becomes `Δ > 2(d-2)`, the batch-050 threshold; Theorem 4 becomes
`n(d-λ_2) → Δ²/(ΔG_d(d)-d)`, the batch-050 constant. This is a *specialisation check* on the
new theorem, not a re-derivation or modification of the frozen proof, and the frozen files are
untouched. Note the two models differ qualitatively: the clustered threshold depends on the
distance profile, so a "degree census" reading of `Δ > 2(d-2)` is false for clustered
attachments (for `d=3`, `N(c)` has `Δ = d = 3` and always a defect, the adjacent pair has
`Δ = 2` and still always a defect at `d=3`).

## 12. Verification record

* `check_symbolic.py` → `out/symbolic.txt` (`(C)`, sympy, all `PASS`): branch identities,
  both kernels, both exact block inverses (`d=2..5`; adjacent pair `K=2G_d(1+r)=2r/(1-r)`),
  the tree-resolvent local identity, both numerator polynomials, `r_P²=1/(d+1)`,
  `λ_P=2d/√(d+1)` and `Φ_T(λ_P)=0`, `Φ_T'(λ_P)=2(d+1)`, `Φ_T(e)` and `Φ_T(d)` for both
  families, `Φ_T' = 1+|G_d'|P+G_dP'|r'|`, and exact Sturm root counts of the adjacent-pair
  quartic for `d = 3,4,5,6,7,8,10,20`.
* `num_check.py` → `out/numeric.jsonl`, `out/numeric_stage2_seedfix.jsonl`, summary
  `out/numeric_summary.md` `(N)`: certified-uniform sampler (pairing model with rejection to
  simplicity; each simple `d`-regular graph has exactly `(d!)^n` pairings), fixed seeds
  `20240601`, `20240602`, `scipy.sparse.linalg.eigsh(k=3,'LA')` and `splu`. Headline numbers:

  1. **Secular identity** (zero of `Σ_n` in `(λ_2(A),d)` and in `(d,∞)` versus the direct
     eigenvalues of `G'`): `max |zero − eigensolver| = 3.5·10^{-14}` over 48 comparisons
     (`d = 3,4`; `n = 1000,2000`; 2 seeds; patterns `N(c)`, adjacent pair, single vertex).
  2. **`1/n` law, `τ > 0`**: `n(ν_1 − d)` versus `Δ²/τ`:
     `d=4, N(c)`: `7.78, 7.78, 7.86, 7.86, 7.91, 7.96` at `n = 10³…8·10³` vs `8`;
     `d=3, adjacent pair`: `3.78, 3.80, 3.92, 3.89, 3.97, 3.97` vs `4 = 4/Φ_adj(3)`;
     `d=4, adjacent pair` (no exterior root, `λ_2` at the bulk edge): `1.3266…1.3323` vs
     `4/3`; single-vertex controls `0.4270…0.4285` vs `3/7` (`d=3`) and `0.2756…0.2758` vs
     `8/29` (`d=4`). The `1/n` constant is the *pattern* `Δ²/Φ_T(d)`, not `Δ²/(ΔG_d(d)−d)`.
  3. **`√n` law at the critical pattern `(d,T) = (3,N(c))`**: measured `ν_1 − ν_2` vs
     `6/√(8n)`: `0.067871/0.067082 = 1.012`, `1.020`, `1.003`, `1.012`, `0.993`, `1.003` at
     `n = 10³,2·10³,4·10³,8·10³` (two seeds where shown); and `n(3−ν_2) = 36.5, 49.8, 64.4,
     99.0` — growing like `√n`, so **no** `1/n` constant exists on this branch.
  4. **`λ_P` limit**: `ν_2 → λ_P` in all four non-critical defect cases; worst deviations
     `d=3, adjacent pair: −1.4·10^{-2} → −1.4·10^{-3}` and `d=4, N(c): −1.9·10^{-2} →
     −5.0·10^{-3}` from `n = 10³` to `8·10³`; for `d=4`, adjacent pair, `ν_2 − λ_2(A) ≤ 5·10^{-4}`
     (no defect, `λ_2 → e`), as Theorem 5 predicts.
  5. **Pointwise resolvent limit** `1_T^T(λ−A)^{-1}1_T` vs `−G_dP_T(r) + Δ²/(n(d−λ))`:
     absolute errors `1.6·10^{-2}, 6.7·10^{-3}, 2.6·10^{-3}` at `λ = 3.2` for `d=3`, `N(c)`,
     `n = 10³,2·10³,4·10³` falling to `4.5·10^{-3}` at `n = 8·10³`; `1.6·10^{-2} → 2.1·10^{-3}`
     for the adjacent pair. The approach is slow near `e` and near `λ_P`, exactly as the error
     bound `ρ_1^{L}` with `ρ_1 = e/λ` predicts; no numerical run at these sizes can certify the
     limit near the edge, and none is claimed to.
  Numerics corroborate; they are not used as a premise anywhere above.
* Not done: Lean formalisation (none claimed; the target's "any claimed formal proof must
  compile" is vacuous here because no formal proof is claimed), literature/novelty audit
  (nothing new is claimed as a theorem of the field; the exact value `2d/√(d+1)` for this
  specific cluster is an exact computation whose novelty I did not audit), bulk regime, and
  rates.
