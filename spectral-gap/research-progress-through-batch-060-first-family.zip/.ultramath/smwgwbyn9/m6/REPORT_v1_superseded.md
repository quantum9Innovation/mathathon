# m6 report — swarm smwgwbyn9, direction d4 (role 1)

**Strongest result (Tier-1 component): hypothesis (H) is PROVED**, in probability,
uniformly on compacta, for deterministic fixed `T` and fixed `d ≥ 3`:
`sup_{λ∈K}|1_T^T(A_{G_n}-λI)^{-1}1_T + ΔG_d(λ)| → 0` in probability for every compact
`K ⊂ (2√(d-1), d) ∪ (d, ∞)`. Stronger form on `ℂ∖[-2√(d-1)-η, 2√(d-1)+η]`:
`sup_K|1_T^T(z-A)^{-1}1_T − Δ²/(n(z-d)) − ΔG_d(z)| → 0`, i.e. the only correction is the
Perron term `Δ²/(n(z-d))`.

Proof (`THEOREM.md`, §2–3, all steps written out): walk-series convergence above `||A||=d`;
`O(1/n)` failure probability for the fixed-radius tree-likeness of the neighbourhood of a
fixed label set, by an explicit stub-exploration bound in the pairing model, with the
conditional statement via `P(simple) ≥ c_d > 0`; in-probability Montel lemma; the Perron
pole at `z=d` removed before continuing into `(2√(d-1), d)` (this is the step that a naive
analytic-continuation argument misses, and the pole-subtracted function is what converges
locally uniformly on the window); tightness from Friedman (arXiv:cs/0405020v1, fixed `d`,
uniform simple `d`-regular).

**Second result — corrected target.** The batch form `-ΔG_d(λ)` is the limit only for
asymptotically separated `T`. In general
`1_T^T(z-A)^{-1}1_T → G_d(z)Σ_{s,t∈T}r(z)^{dist(s,t)}`, so for a bounded-diameter pattern the
batch value is wrong by a `Θ(1)` factor. Exact: adjacent pair → `G_d(λ)(2+2r)`; `T=N(c)` →
`dλr/(λ-dr)`. The threshold `Δ > 2(d-2)` and the "degree census" reading fail for clustered
`T` (d=3, adjacent pair: exists although `Δ=2 ≤ 2(d-2)`). Confirmed numerically
(e.g. `d=3,n=8000,λ=3.2`: `T=N(c)` measured 2.1273, corrected 2.1264, batch 1.5605).

**Third result.** Certified exact-uniform sampler: pairing model conditioned on simplicity
(every simple `d`-regular graph has exactly `(d!)^n` pairings); acceptance rate measured to
agree with `e^{-(d²-1)/4}`. This removes the `networkx.random_regular_graph` caveat.

**Not done (stated plainly).** The transfer from (H) to `λ_1,λ_2 → max/min(d,λ_f)` is not
re-proved (root bookkeeping, exclusion of further roots, ordering); no rate in `n`; no
uniformity in `d`; nothing at the edge `λ=2√(d-1)` or `λ=d`; no growing-`Δ` case. No Lean.

**Files** (all in `.ultramath/smwgwbyn9/m6/`): `THEOREM.md` (proof + correction + numerics),
`resolvent_patterns.py`, `accept_check.py`, `out_8000.txt`, `out_small.txt`, `out_accept.txt`.

**Next unavoidable step.** Combine Theorem A with the root argument: on the pole-subtracted
secular function `λ − ΔG_d(λ) − Δ²/(n(λ−d))` prove that the two largest zeros converge to
`max(d,λ_f)`, `min(d,λ_f)`, using `F_n^⊥ → ΔG_d` uniformly on compacta plus interlacing, and
exclude further real roots of `Σ_n` above the bulk.
