# 3. Exact theorems

Throughout, `H` is `k`-uniform and `d`-regular with `n = |V|`, `m = |E| = nd/k`, incidence matrix
`X`, Feng-Li operator `A_H`, and `a = d-1`, `b = k-1`, `t = sqrt(ab)`. Hyperedges are a multiset and
a single edge never repeats a vertex. All statements here are deterministic. No asymptotics.

---

## T1. Gram identity, the floor, and the exact multiplicity of `-d`  [PROOF]

**Theorem T1.** `A_H + d I = X X^T`. Consequently

1. `spec(A_H) subset [-d, d(k-1)]`,
2. `lambda = -d` is an eigenvalue of `A_H` if and only if there is `x != 0` with `X^T x = 0`,
3. `mult_{A_H}(-d) = n - rank(X)`.

*Proof.* For `u, v in V`, `(X X^T)[u,v] = sum_e X[u,e] X[v,e] = #{e : {u,v} subset e}`. If `u != v`
this is `(A_H)[u,v]` by definition. If `u = v` it is `deg(u) = d`. So `X X^T = A_H + d I`. Since
`X X^T` is positive semidefinite, `A_H >= -d I`, which is 1. For 2, `x^T X X^T x = ||X^T x||^2`, so
the quadratic form vanishes only on `ker X^T`. For 3, `dim ker X^T = n - rank(X^T) = n - rank(X)`. QED

*Remark.* Points 1 and 3 are the whole reason the bottom of the spectrum behaves differently from
the top. Point 1 is in the literature (Storm's Eq. (3) argument, "this relation forces the
eigenvalues of `H` and `H*` to be at least `-d` and `-r`"), and point 3 is the exact form of the
statement that Storm and Song-Fan-Miao use only in the rectangular case.

*Verification.* `scripts/exp1_exact_structure.py`, section A, asserts `mult(-d) == n - rank(X)` on 31
explicit rows including complete multipartite families for `k = 3,4,5`, disjoint unions of up
to 4 copies, single repeated edges, and random regular instances with `d < k` and `d > k`. All pass,
output in `outputs/exp1_exact_structure.txt`.

---

## T2. The Perron value is simple per component  [PROOF]

**Theorem T2.** `A_H 1 = d(k-1) 1`. If `H` has `c` connected components then
`mult_{A_H}(d(k-1)) = c`. In particular `lambda_2(A_H) < d(k-1)` if and only if `H` is connected.

*Proof.* `(A_H 1)_u = sum_{v != u} #{e : {u,v} subset e} = sum_{e ni u} (k-1) = d(k-1)`. For the
multiplicity, order the vertices component by component. Every edge containing `u` lies entirely in
the component of `u`, so the block of `A_H` indexed by a component `C` is a nonnegative matrix with
all row sums equal to `d(k-1)`, and its support graph is connected, so the block is irreducible.
Perron-Frobenius gives a simple Perron root equal to the row sum for each block. QED

*Remark.* The hypothesis of connectedness in the literature statements (for example `rho(TH)` and
the definition of Ramanujan) is exactly what makes the top trivial value simple. It is not the same
as the hypothesis needed to control the bottom.

*Verification.* Section A of `exp1_exact_structure.py` asserts `mult(Perron) == components` in all 31
rows, including 1, 2, 3 and 4 disjoint copies of the same component.

---

## T3. Complete spectral dictionary for `A_H`  [PROOF]

**Theorem T3.** Let `sigma_1 >= ... >= sigma_r > 0` be the nonzero singular values of `X`, with
`r = rank(X)`. Then

```
spec(A_H) = { sigma_i^2 - d : i = 1..r }  union  { -d with multiplicity n - r },
```

and `sigma_1 = sqrt(dk)` with multiplicity one when `H` is connected.

*Proof.* `X X^T` has eigenvalues `sigma_i^2` for `i <= r` and `0` with multiplicity `n - r`, and
`A_H = X X^T - d I`. The top one is `sigma_1^2 = d k` because `X X^T 1 = (d(k-1)+d) 1 = dk 1` and
`X X^T 1 = X (X^T 1) = X (k 1) = k d 1`. QED

*Verification.* `scripts/exp4_biregular_nb.py`, last section, checks
`singvals(X) == sqrt(d + lambda_i(A_H))` entrywise to `8.9e-16` and `lambda_i(A_H) = -d` for all
`i > min(n,m)`.

---

## T4. The complete multipartite family has no nontrivial eigenvalue  [PROOF]

**Theorem T4.** Let `H` be the complete `k`-partite `k`-uniform hypergraph with `k` parts of size
`s` (all `k`-tuples meeting each part once). Then `n = ks`, `m = s^k`, `d = s^(k-1)`, and

```
spec(A_H) = { d(k-1) }  union  { 0 with multiplicity k(s-1) = n-k }  union  { -d with multiplicity k-1 }.
```

*Proof.* Two vertices in different parts lie together in exactly `s^(k-2)` edges (`k = 2` needs
separate handling and is the complete bipartite graph), two vertices in the same part lie in none.
So `A_H = s^(k-2) A(K_{s,...,s})`, the adjacency matrix of the complete `k`-partite graph. That
graph has spectrum `(k-1)s` once, `-s` with multiplicity `k-1`, and `0` with multiplicity `k(s-1)`.
Multiplying by `s^(k-2)` gives `d(k-1)`, `-s^(k-1) = -d`, and `0`. QED

*Verification.* `exp1_exact_structure.py` reproduces this exactly for `k = 3,4,5` and `s = 1,2,3`.
For example `k = 4, s = 2` gives `n = 8`, `d = 8`, and the measured spectrum is
`{24, 0, 0, 0, 0, -8, -8, -8}`.

*Why it matters.* In this family the entire spectrum is structurally forced. So there is no
"nontrivial" eigenvalue at all, and every gap that one might compute is arithmetic. Any definition of
a spectral gap must therefore be able to say "this hypergraph has no nontrivial spectrum", and the
index at which the forced values stop is `n + 1`.

---

## T5. Two independent sources of the eigenvalue `-d`  [PROOF]

**Theorem T5.** Let `H` be `k`-uniform and `d`-regular.

1. (rectangular source) `mult_{A_H}(-d) >= max(0, n - m) = n max(0, 1 - d/k)`.
2. (colouring source) Suppose `c : V -> {0,...,k-1}` is a strong `k`-colouring: `|e| = k` and
   `c|_e` is a bijection for every edge `e`. Then `mult_{A_H}(-d) >= k - 1`. In particular
   `mult_{A_H}(-d) >= k-1` for every `k`-partite `k`-uniform `d`-regular hypergraph, whatever the
   relation between `d` and `k`.

*Proof.* (1) `rank(X) <= min(n,m)`, so `n - rank(X) >= n - m`, and apply T1.
(2) Let `omega = exp(2 pi i / k)` and `x_j(v) = omega^(j c(v))` for `j = 1,...,k-1`. For an edge
`e` with colour set `{0,...,k-1}`,
`(X^T x_j)_e = sum_{v in e} omega^(j c(v)) = sum_{i=0}^{k-1} omega^(j i) = 0` because `omega^j != 1`.
So all `x_1,...,x_{k-1}` lie in `ker X^T`. They are linearly independent: the `k` functions
`x_0,...,x_{k-1}` take values `omega^(j c(v))`, which form a Vandermonde matrix on the `k` nonempty
classes (a strong colouring uses all `k` colours because every edge meets all of them), so any `k-1`
of them are independent. Hence `dim ker X^T >= k-1` and T1 gives the claim. QED

*Sharpness.* Both bounds are attained.
`k = 4, s = 2` (T4) has `n = 8`, `m = 16`, so `n - m < 0` and the rectangular bound is vacuous,
while `mult(-d) = 3 = k-1` exactly. Random `(2,3)`, `(2,4)`, `(2,5)` and `(3,5)` instances have
`mult(-d) = n - m` exactly, so the rectangular bound is attained too
(`outputs/exp1_exact_structure.txt`). A `2`-regular `k`-uniform hypergraph therefore has at least
`n(1 - 2/k)` eigenvalues equal to `-2`, which is at least a third of the spectrum for `k >= 3`.

---

## T6. Three exact square identities  [PROOF and CALC]

**Theorem T6.** With `t = sqrt((d-1)(k-1))`:

1. `d(k-1) - (k - 2 + 2t) = (t-1)^2`.
2. `(k - 2 - 2t) - (-d) = (sqrt(d-1) - sqrt(k-1))^2 = d + k - 2 - 2t`.
3. `(k - 2 + 2t) - 2 sqrt((k-1)d - 1) = (k-2) [ 1 - 2 / ( sqrt((k-1)d - k + 1) + sqrt((k-1)d - 1) ) ]`.

*Proof.* For 1, `d(k-1) = t^2 + (k-1)`, so `d(k-1) - k + 2 = t^2 + 1` and the difference is
`t^2 + 1 - 2t = (t-1)^2`. For 2, `k - 2 - 2t + d = (d + k - 2) - 2t = (sqrt(d-1)-sqrt(k-1))^2`. For
3, put `D = (k-1)d` and write the difference as `(k-2) + 2[sqrt(D-(k-1)) - sqrt(D-1)]`, then
rationalise `sqrt(D-k+1) - sqrt(D-1) = (2-k)/(sqrt(D-k+1)+sqrt(D-1))`. QED

*Consequences.*
(a) The Perron value exceeds the top of the Ramanujan window by exactly `(t-1)^2`, which is `0` only
for `d = k = 2` (the cycle).
(b) The floor `-d` lies below the bottom of the Ramanujan window by exactly
`(sqrt(d-1)-sqrt(k-1))^2`, which is `0` exactly when `d = k` and strictly positive otherwise. So
`-d` is *at* the window bottom precisely in the balanced case `d = k`.
(c) The number `k-2` in the Li-Sole window is exactly `-d` transported through the change of variable
of Proposition 1.3, and the `2` in `k-2` is the `-d` of the Gram identity, not an independent
constant.
(d) `t >= 1` with equality iff `d=k=2`, so `sqrt(ab)` is the Perron modulus of the Hashimoto operator
in all non-cycle cases.

*Verification.* Symbolically in `exp1_exact_structure.py` section B (25 combinations of `d` and `k`,
asserted with `sympy.simplify`), and section C for identity 3.

---

## T7. The naive tree benchmark is false for every `k >= 3`  [PROOF]

Write `B_tree(d,k) = 2 sqrt((k-1)d - 1)`. This is the Alon-Boppana threshold that would hold if
`A_H` were locally tree-like with degree `(k-1)d`, i.e. if the local limit of the Feng-Li operator
were the `(k-1)d`-regular tree. It is the natural naive guess and it appears in informal discussions.

**Theorem T7.**

1. `B_tree(d,k) = k - 2 + 2t` if and only if `k = 2`.
2. For every `k >= 3` and every `d >= 2`, `B_tree(d,k) < k - 2 + 2t`, with the exact deficit of T6(3),
   which lies between `(k-2)(1 - 1/sqrt((k-1)d - k + 1))` and `k-2`.
3. Hence there is no sequence of `(d,k)`-regular hypergraphs with `n -> infinity` and
   `lambda_2 <= B_tree(d,k) + o(1)`, for any `k >= 3`. In particular the "locally tree-like" heuristic
   fails, and it fails by a margin that tends to `k-2` as `d -> infinity`.

*Proof of 1 and 2.* Identity T6(3). The bracket is positive because
`sqrt(D-k+1) + sqrt(D-1) > 2` for `D = (k-1)d >= 2(k-1) >= 4` (indeed `sqrt(D-1) >= sqrt3 > 1.7`
and `sqrt(D-k+1) >= 1`). For `k = 2` the factor `k-2` vanishes, identically in `d`.
*Proof of 3.* By L1 (Feng-Li, verified through two independent verbatim quotations), for connected
`(d,k)`-regular `H_m` with `|V| -> infinity`,
`lim inf lambda_2(H_m) >= k - 2 + 2t > B_tree(d,k)`. So the inequality `lambda_2 <= B_tree + o(1)`
fails for every sufficiently large member. QED

*Remark on the reason.* The local limit of `A_H` is not a tree. It is the 2-section of the infinite
`(d,k)`-biregular incidence tree, which contains a `k`-clique through every vertex. Its spectral
radius is `k - 2 + 2t`, not `2 sqrt((k-1)d-1)`. In the language of the Friedman and Friedman-Kohler
dossiers, the correct "tree completion" of a single vertex is the biregular hypertree, and the
"universal cover spectral radius" is `rho(D_{d,k}) = k-2+2t` (Song-Fan-Miao Theorem 1.5 with the
value of `rho(D_{d,r})`, and Cioaba et al. who identify the universal cover as an infinite
distance-regular graph).

*Verification [NUM].* 34 random regular instances across `(d,k) = (2,3),(3,3),(2,4),(3,4),(4,3),
(5,3),(6,4),(2,5)`, `n` from 250 to 3000, 3 or 4 trials each. The minimum of
`lambda_2 - B_tree` over all runs is `0.339`, and no run came within `0.3` of the naive value. The
minimum of `k-2+2t - lambda_2` decreases with `n` in seven of the eight families (the exception is
`(d,k) = (2,5)` at `n = 2000`, where it rises from `0.012` to `0.029`), which is what one expects if
`lambda_2` tends to the true edge from below. See `outputs/exp2_random_regular.txt`,
`outputs/exp2b_random_regular.txt` and `outputs/fig1_thresholds_and_periodic_gap.png`.

---

## T8. The indexing theorem  [PROOF]

This is the formal answer to "the gaps `d - lambda_3`, `d - lambda_4` and so forth".

**Theorem T8.** Let `H` be connected, `k`-uniform, `d`-regular, with `r = rank(X)`.

1. `lambda_1 = d(k-1)` and `lambda_1 > lambda_2`. There is no second forced value at the top.
2. `lambda_j = -d` for every `j >= r+1`, that is for the last `n - r` positions.
3. If `r <= n-3` then `lambda_{n-2} = lambda_{n-1} = lambda_n = -d` and consequently
   `d - lambda_{n-2} = d - lambda_{n-1} = d - lambda_n = 2d`, identically.
4. `r <= n-3` holds whenever `H` is `k`-partite with `k >= 4`, and whenever `d <= k` and
   `n - m >= 3`, which for `d = 2` means `n >= 3k/(k-2)` and is therefore automatic once `n >= 3k`.
5. For the incidence adjacency `A_{B_H}` the two values `+sqrt(dk)` and `-sqrt(dk)` are the two
   largest in modulus, each simple when `H` is connected, so the first genuinely nontrivial
   eigenvalue of `A_{B_H}` sits at position 3 in the ordering by decreasing modulus, and its sharp
   threshold is `sqrt(d-1)+sqrt(k-1)`.
6. For the Hashimoto operator of `B_H`, `±sqrt(ab)` are the two largest in modulus, each simple, and
   every other eigenvalue has modulus at most `(ab)^(1/4)` almost surely for random `H` (and
   at most `(ab)^(1/4)` in every instance tested). Since `(ab)^(1/4) > 1` when `ab > 1`, exactly two
   trivial values are separated, and position 3 is again the first genuinely nontrivial one.

*Proof.* 1 is T2. 2 is T1(3) together with the ordering. 3 is immediate. 4: for `k`-partite,
`n - r >= k-1 >= 3` by T5(2). For `d <= k`, `n - r >= n - m = n(1 - d/k) >= 3` when `n >= 3k/(k-d)`, and for
`d = 2` this is `n >= 3k/(k-2) <= 3k` for `k >= 3`. 5: the singular values
of `X` are `sqrt(d + lambda_i(A_H))`, decreasing in `i`, and strictly less than `sqrt(dk)` for
`i >= 2` because `lambda_2 < d(k-1)`. So the bipartite adjacency eigenvalues `±sqrt(d+lambda_i)` have
`+sqrt(dk)` and `-sqrt(dk)` as the two largest moduli. 6: `prod` is by definition of the Hashimoto
operator, the Perron value is `t` by T13, and the bulk bound is the biregular Ramanujan statement of
Brito-Dumitriu-Decker Harris in Hashimoto form, verified numerically in `exp4`. QED

*Reading.* So the correct statements are:

* top of `A_H`: one trivial value, gap `d(k-1) - lambda_2`, normalised gap
  `1 - lambda_2/(d(k-1))`, whose sharp asymptotic value for random `H` is
  `1 - (k-2+2t)/(d(k-1))`, asymptotically `2/sqrt((k-1)d)` for large `d`.
* bottom of `A_H`: a plateau of length `n - r` at `-d`. Indices 3 and 4 counted from the bottom are
  inside the plateau whenever `n - r >= 3`.
* the only operators with exactly two separated trivial values, and hence the only ones for which
  "the gap at index 3" is the first genuine gap, are the incidence adjacency and the Hashimoto
  operator. Their normalising constants are `sqrt(dk)` and `t`, never `d`.

*Verification.* T4 gives an exact instance where the entire spectrum consists of the top value, the
`-d` plateau and zeros. `exp4_biregular_nb.py` verifies point 6 on six instances, with the measured
second-largest modulus equal to `(ab)^(1/4)` to five decimals in all six.

---

## T9. The two-sided Li-Sole condition is unsatisfiable for `k`-partite `H` with `d > k`  [PROOF]

**Theorem T9.** Let `H` be `k`-partite (`k >= 3`), `k`-uniform, `d`-regular, with `d > k`. Then
`-d` is an eigenvalue of `A_H` with multiplicity at least `k-1`, it is not one of the "obvious"
eigenvalues in the sense of Storm and Song-Fan-Miao (which are the rectangular ones, and there are
none because `d > k` gives `m > n`), and

```
|-d - (k-2)| = d + k - 2 > 2 sqrt((d-1)(k-1)),
```

with excess exactly `(sqrt(d-1)-sqrt(k-1))^2 > 0`. Hence `H` is not a Ramanujan hypergraph in either
reading of L2, because in both readings `-d` counts as a nontrivial eigenvalue when there are no
rectangular obvious eigenvalues.

*Proof.* T5(2) for the multiplicity. The inequality is AM-GM: `2 sqrt((d-1)(k-1)) <= (d-1)+(k-1)`
with equality iff `d = k`. The excess is T6(2). For `d > k`, `m = nd/k > n`, so `n - m < 0` and the
rectangular multiplicity `max(0, n-m)` is zero, so `-d` is not "obvious" in the literature sense.
QED

*Smallest witness [CALC].* The complete `4`-partite `4`-uniform hypergraph with part size `2`:
`n = 8`, `m = 16`, `d = 8`, `k = 4`, spectrum `{24, 0, 0, 0, 0, -8, -8, -8}` by T4. The window is
`[2 - 2 sqrt21, 2 + 2 sqrt21] = [-7.16515, 11.16515]` and `-8` is below it by
`(sqrt7 - sqrt3)^2 = 10 - 2 sqrt21 = 0.83460`. So this hypergraph is not Ramanujan, although it is
as symmetric as possible.

*Consequence for the definitions.* A correct two-sided definition must treat `-d` as trivial
whenever it is present, and by T1 it is present exactly when `rank(X) < n`. The exact criterion is
`n - rank(X) > 0`, not `d < k`. Equivalently, the intrinsic window for a hypergraph with
`rank(X) < n` is `[-d, k-2+2t]`, which is strictly narrower than the Li-Sole window at the bottom.
Song-Fan-Miao's left-sided condition does exclude `-d`, but their Remark "if `d < r` then `H` has an
obvious eigenvalue `-d`" identifies only the rectangular case, so for a `k`-partite `H` with `d > k`
their Definition 1.2 would classify `-d` as non-obvious and the left-sided condition would fail for
a reason unrelated to expansion.

*Verification.* `exp1_exact_structure.py` prints the window and `lambda_min` for all 26 cases, and
the complete 4-partite `s=2` row shows `lammin = -8.0000`, `win = (-7.1652, 11.1652)`, `mult(-d) = 3`.

---

## T10. When `d = k` the left-sided condition is automatic  [PROOF]

**Theorem T10.** If `d = k` then the Li-Sole window is `[-d, 3k-4]` and every `k`-uniform
`k`-regular hypergraph satisfies `lambda_min >= -d =` the window bottom. Consequently:

1. every `(d,d)`-regular hypergraph is left-sided Ramanujan in the sense of Song-Fan-Miao,
2. every cover of a `(d,d)`-regular hypergraph is left-sided Ramanujan,
3. by Song-Fan-Miao Theorem 1.6 (every connected `(d,r)`-regular hypergraph has a right-sided
   Ramanujan 2-covering), every connected `(d,d)`-regular hypergraph has a **two-sided** Ramanujan
   2-covering, and the infinite families of Song-Fan-Miao Theorem 1.7 are two-sided Ramanujan,
4. for `d = k` the three notions "Ramanujan", "right-sided Ramanujan" and "left-sided Ramanujan"
   coincide up to the single forced value `-d`.

*Proof.* T6 with `d = k` gives `t = k-1`, so the window is `[k-2-2(k-1), k-2+2(k-1)] = [-k, 3k-4]`,
and `-k = -d`. T1 gives `lambda >= -d` for every `k`-uniform `k`-regular hypergraph, and a cover of a
`(d,k)`-regular hypergraph is `(d,k)`-regular, so the bound applies to it too. Combining 1 with
Song-Fan-Miao Theorem 1.6 gives 3. QED

*Verification [NUM].* Exhaustive over all 2-covers of three `(3,3)`-regular bases and one
`(4,4)`-regular base: the left-sided condition holds for 128/128, 1024/1024, 8192/8192 and, in a
300-sample random scan, for all samples of the `(4,4)` base. For bases with `d < k` the left-sided
condition holds for 0 out of 32, 0 out of 300, 0 out of 512 and 0 out of 8192 covers, confirming T12.
See `outputs/exp7_lift_obstruction.txt`.

*What this does and does not say.* It does not contradict anything in Song-Fan-Miao, whose
statements are right-sided. It removes a qualifier: in the balanced case `d = r` their right-sided
2-covering is automatically two-sided, because the lower edge of the window is the universal floor.

---

## T11. The cyclic interval family: exact symbol and a `Theta(n^-2)` gap  [PROOF and NUM]

**Definition T11.0.** For integers `q >= 2k+1` and `k >= 2`, `C(q,k)` is the hypergraph with vertex
set `Z_q` and edges `{i, i+1, ..., i+k-1}` for `i in Z_q`. It is `k`-uniform and `k`-regular, so
`d = k`, and it is a quotient of the `Z`-periodic hypergraph with the same edge shape, hence a
natural "almost regular, exactly regular" lattice format.

**Theorem T11.**

1. The first row of `A_H` is `(A_H)[0,j] = k - |j|` for `1 <= |j| <= k-1` (cyclic distance) and `0`
   otherwise. Hence `A_H` is circulant and
   `spec(A_H) = { p(2 pi m / q) : m = 0,...,q-1 }` with `p(theta) = 2 sum_{j=1}^{k-1} (k-j) cos(j theta)`.
2. (Fejer identity) `p(theta) = |sum_{r=0}^{k-1} e^{i r theta}|^2 - k = (sin(k theta/2)/sin(theta/2))^2 - k`
   for `theta` not a multiple of `2 pi`, and `p(0) = k(k-1) = d(k-1)`.
3. `p(theta) <= k(k-1)` with equality if and only if `theta in 2 pi Z`. Hence for `q >= q_0(k)` the
   maximum of `p` over the nontrivial `q`-th roots of unity is attained at `m = 1`, and
   `lambda_2 = p(2 pi/q)`.
4. `p(theta) = -k` if and only if `theta = 2 pi j / k` for some `j = 1,...,k-1`. Hence `-k = -d` is an
   eigenvalue of `A_H(C(q,k))` corresponding to `m = jq/k` for every `j` with `(k/gcd(k,j)) | q`, and
   the multiplicity is exactly `gcd(k,q) - 1`. In particular `mult(-d) = k-1` when `k | q`, which is
   exactly the `k`-partite case, and `mult(-d) = 0` when `gcd(k,q) = 1`. This realises the colouring
   obstruction of T5 as a Bloch-wave statement at the `k`-th roots of unity.
5. As `q -> infinity`,
   `d(k-1) - lambda_2 = (pi^2 k^2 (k^2-1)/3) q^(-2) - (4 pi^4 S4/3) q^(-4) + O(q^(-6))`
   with `S4 = sum_{j=1}^{k-1} j^4 (k-j) = k^2 (k-1)(k+1)(2k^2-3)/60`.
   In particular the gap is `Theta(q^(-2)) = Theta(n^(-2))`.

*Proof.* 1: the number of `i` with `{i,...,i+k-1}` containing both `0` and `j` is `k - |j|` as long
as `1 <= |j| <= k-1` and `q >= 2k-1`. A circulant matrix has the stated eigenvalues.
2: `|sum_{r=0}^{k-1} e^{ir theta}|^2 = sum_{|j| <= k-1} (k-|j|) e^{ij theta} = k + 2 sum_{j=1}^{k-1}(k-j)cos(j theta) = k + p(theta)`,
and the geometric sum equals `e^{i(k-1)theta/2} sin(k theta/2)/sin(theta/2)`.
3: `|sum_{r=0}^{k-1} e^{ir theta}| <= k` with equality iff all summands coincide, i.e. `theta in 2 pi Z`.
For `|m| >= 2` the angle `2 pi m/q` lies in `[4 pi/q, 2 pi - 4 pi/q]`, and `p` is even around `0` and
symmetric under `theta -> 2 pi - theta`, so it suffices to bound `p` on the closed arc
`[4 pi/q, pi]`. By the equality case just established, `p(theta) < p(0)` for `theta in (0,pi]`, so
`delta_k := p(0) - max_{theta in (0,pi]} p(theta) > 0` by compactness, and
`max_{[4 pi/q, pi]} p <= p(0) - delta_k` as soon as `4 pi/q <= pi`. On the other hand
`p(2 pi/q) = k(k-1) - c2 (2 pi/q)^2 + O(q^-4)`, which exceeds `k(k-1) - delta_k` for `q` large. Hence
the maximum over `m != 0` is at `m = 1` and `lambda_2 = p(2 pi/q)`.
4: `p(2 pi j/k) = |sum_{r=0}^{k-1} omega^{jr}|^2 - k = 0 - k` for `j = 1,...,k-1`, and by point 3
those are the only zeros of `p + k` on `[0,2 pi)`. The equation `2 pi m/q = 2 pi j/k` has the
solution `m = jq/k`, which is an integer in `[0,q)` if and only if `k | jq`, i.e. if and only if
`(k/gcd(k,j)) | q`. Put `g = gcd(k,q)`. Writing `j = (k/g) t` with `t = 1,...,g-1` gives
`m = j q/k = t q/g`, and these are `g-1` distinct residues modulo `q`. Conversely if `k | j q` then
`(k/g) | j`, so no other `j` contributes. Hence the multiplicity of `-k` is exactly `g-1`.
5: expand `p` at `0`. From 2, `p(theta) = k(k-1) - c2 theta^2 + c4 theta^4 - ...` with
`c2 = sum_{j=1}^{k-1} j^2 (k-j) = k^2(k^2-1)/12` and `c4 = (1/12) sum_{j=1}^{k-1} j^4(k-j)`.
Substituting `theta = 2 pi/q` gives `d(k-1) - lambda_2 = c2 (2 pi/q)^2 - c4 (2 pi/q)^4 + O(q^-6)`
`= (pi^2 k^2(k^2-1)/3) q^-2 - (4 pi^4 S4/3) q^-4 + O(q^-6)`. QED

*Verification [CALC and NUM].* The Fejer identity is checked exactly (`max|spec - Fejer| < 1.3e-13`)
for `k = 2,...,6` and `q = 13,17,23,31,60`. The expansion coefficients `c2` and `S4` are computed
symbolically for `k = 2,...,7` and matched to `k^2(k^2-1)/12` and `k^2(k-1)(k+1)(2k^2-3)/60`. The
ratio `(d(k-1)-lambda_2) q^2 / (pi^2 k^2(k^2-1)/3)` equals `0.99726, 0.99931, 0.99983, 0.99996` for
`k=3` and `q = 60,120,240,480`, and the ratio of the residual to the predicted `q^-4` term equals
`0.99866, 0.99966, 0.99992, 0.99998`. Exact characteristic polynomials over `Q` are printed for
small `q` (`outputs/exp3_cyclic_interval.txt`), for example `k=3,q=9` gives
`(x-6)(x+3)^2(x^3-9x-9)^2`, exhibiting the `k-1 = 2` copies of `-d`. The identity
`mult(-k) = gcd(k,q) - 1` is checked with no mismatch for `k = 3,4,5,6` and every `q` from `2k+1` to
`2k+39` (`scripts/exp3b_fejer_and_gcd.py`, `outputs/exp3b_fejer_and_gcd.txt`), including the cases
`k=4,q=10` (multiplicity 1 though `4` does not divide `10`) and `k=6,q=9` (multiplicity 2).

*What it shows.* "Exactly `d`-regular and highly symmetric" is not a substitute for randomness in an
absolute spectral gap. The gap of this family is `Theta(n^-2)`, whereas a random `(k,k)`-regular
hypergraph has gap `Theta(1)`. So the sharp threshold `k-2+2t` is a property of the random model and
not of regularity, which is exactly the pattern the four local dossiers describe for graphs.

---

## T12. For `d < k` every regular cover has `-d` in its new spectrum  [PROOF]

**Setup.** Let `H` be `k`-uniform `d`-regular with incidence graph `B_H` connected, `d < k`, and let
`C -> H` be a connected `N`-fold covering of hypergraphs. Then `C` is `k`-uniform `d`-regular with
`Nn` vertices and `Nm` edges. Following Song-Fan-Miao Theorem 1.3 and the Bilu-Linial splitting, the
spectrum of `A_C` is the multiset union of an "old" part equal to `spec(A_H)` and a "new" part, which
for `N = 2` is the spectrum of the incidence-signed matrix
`S_uv = sum_{e ni u,v} (-1)^(volt[u,e] + volt[v,e])`.

**Theorem T12.** With `r = rank(X)` and `r_C = rank(X_C)`,

```
mult_new(-d) = (N-1) n - r_C + r  >=  (N-1) n - N m + r .
```

Consequently, if `r = m` (the generic case, and the case in every instance tested), then
`mult_new(-d) >= (N-1)(n - m) = (N-1) n (1 - d/k) > 0`. Since `d < k` forces
`(sqrt(d-1)-sqrt(k-1))^2 > 0`, the value `-d` lies strictly below the bottom of the Li-Sole window,
so **no cover of any degree is a Ramanujan hypergraph in the two-sided sense.**

*Proof.* By T1, `mult_{A_C}(-d) = Nn - r_C` and `mult_{A_H}(-d) = n - r`. The old part is exactly
`spec(A_H)`, so `mult_new(-d) = (Nn - r_C) - (n - r)`. For `d < k` the incidence matrix `X_C` is
`Nn x Nm` with `Nm < Nn`, so `r_C <= Nm`. QED

*Verification [NUM, exhaustive for N=2].* Four bases with `d < k`: random `(2,3)` with `n = 12`,
`r = 8`, `n - m = 4`, 32 covers, minimum observed `mult_new(-2) = 4` exactly. Random `(2,4)` with
`n = 16`, `r = 8`, `n - m = 8`, 512 covers, minimum `8`. Random `(2,5)` with `n = 20`, `r = 8`,
`n - m = 12`, 8192 covers, minimum `12`. Random `(3,4)` with `n = 12`, `r = 9`, `n - m = 3`, 300
random covers, minimum `3`. In every one of these the left-sided window condition fails for
**every** cover tested. `outputs/exp7_lift_obstruction.txt`.

*Open sub-question.* The hypothesis `r = m` is used only to get a clean positive count. When
`r < m` the exact formula still holds and can be zero or negative. Characterising the bases with
`r < m` and `d < k` is the same as characterising those whose dual hypergraph `H*` has `-k` as an
eigenvalue (T1 applied to `H*`), which is again a rank-deficiency question. I did not pursue it.

---

## T13. The relativised threshold cannot beat Alon-Boppana for a regular base  [PROOF]

**Theorem T13.** Let `H` be `k`-uniform `d`-regular with `B_H` connected and `|E(B_H)| > |V(B_H)|`, that is
`n d > n + m`, equivalently `d(k-1) > k`. Let `Hash` be the Hashimoto matrix of the bipartite graph `B_H`. Then
`rho(Hash) = sqrt(ab) = sqrt((d-1)(k-1))` exactly, and this number depends only on `(d,k)`.

*Proof.* `Hash^2 = diag(K D, D K)` where `K` is the `(u->e) -> (e->v)` block with `v != u` and `D`
the `(e->u) -> (u->f)` block with `f != e`. The matrix `K D` is nonnegative, and its row sums are
`(k-1)(d-1) = ab`: from a state `(u->e)` a two-step non-backtracking walk chooses `v in e`, `v != u`
(`k-1` ways) and then `f ni v`, `f != e` (`d-1` ways). So `rho(KD) = ab` by Perron-Frobenius (and `KD` is irreducible because
the two-step non-backtracking graph is connected when `B_H` is connected and `d(k-1) > k`), and
`rho(Hash)^2 = rho(Hash^2) = max(rho(KD), rho(DK)) = ab`. QED

*Consequence for relativised hypergraph expansions.* In the Friedman-Kohler / Bordenave framework a
random `N`-fold lift of a fixed base has its new Hashimoto eigenvalues bounded by `sqrt(rho_1)`,
where `rho_1` is the Perron value of the base Hashimoto matrix. For a `(d,k)`-regular hypergraph base
the relevant base graph is `B_H`, and `rho_1 = t = sqrt(ab)`, so the relative threshold is `(ab)^(1/4)`, which is
**identical** to the absolute universal-cover value. So for regular hypergraphs the relativised
programme cannot improve the threshold at all. What it can improve is the exponent: the probability
that a new eigenvalue exceeds `(ab)^(1/4) + eps` can be of order `N^(-eta)` with `eta` larger than the
exponent for a random `(d,k)`-regular hypergraph, and `eta` is governed by a hypergraph analogue of
the fundamental order of Friedman-Kohler. That is open target O1 in file 04.

*Verification [NUM].* `exp4_biregular_nb.py` builds `Hash` for six random `(d,k)`-regular instances
with `(d,k) = (2,3),(3,4),(4,3),(3,3),(2,5),(3,5)` and finds `max|mu| = t` in all six and the second
largest modulus equal to `(ab)^(1/4)` to five decimals in all six. The biregular Ihara-Bass
determinant identity `det(lam I - Hash) = (lam^2-1)^(|E|-|V|) det(lam^2 I - lam A + (D-I))` is
verified at three complex values of `lam` per instance with relative error below `1e-13`.

---

## T15. A signed Gram identity for 2-covers  [PROOF]

**Setup.** Let `H` be `k`-uniform `d`-regular, and let a `Z_2`-cover be given by voltages
`volt[v,e] in {0,1}` on the incidences, with an arbitrary gauge. By the sheet-swap involution the
spectrum of the cover is the multiset union of `spec(A_H)` (the symmetric part) and `spec(S)` (the
antisymmetric or "new" part), where

```
S_uv = sum_{e superset {u,v}} (-1)^(volt[u,e] + volt[v,e])    (u != v),     S_uu = 0.
```

This `S` is Song-Fan-Miao's "incidence-signed hypergraph". The identity below is the signed analogue
of T1.

**Theorem T15.** Let `Xtilde[v,e] = X[v,e] (-1)^(volt[v,e])`. Then `S + d I = Xtilde Xtilde^T`.
Consequently `S >= -d I` for **every** signing, and `mult_S(-d) = n - rank(Xtilde)`.

*Proof.* For `u != v`, `(Xtilde Xtilde^T)[u,v] = sum_e X[u,e]X[v,e] (-1)^(volt[u,e]+volt[v,e])`,
which is `S_uv` because both `u` and `v` lie in `e` exactly when `X[u,e]X[v,e] = 1`. On the diagonal,
`(Xtilde Xtilde^T)[u,u] = sum_{e ni u} 1 = d`, and `(S + d I)[u,u] = 0 + d`. QED

*Consequences.*

1. No signing can push the new spectrum below `-d`. In particular the left-sided condition in
   Song-Fan-Miao Definition 1.4 can never fail by more than the distance from `-d` to the window
   bottom, which is `(sqrt(d-1)-sqrt(k-1))^2` (T6(2)).
2. For `d = k` that distance is `0`, so the left-sided condition holds for **every** 2-cover, which
   is T10(1) with a self-contained proof that does not need the Perron argument.
3. For `d < k` the value `-d` is strictly below the window bottom and T12 puts it in the new
   spectrum, so the left-sided condition fails for every cover.
4. For `d > k` the left-sided condition is neither automatic nor impossible: it is a genuine
   condition on the signing.

*Verification [NUM].* The identity `S + d I = Xtilde Xtilde^T` is checked to `1e-12` for 40 random
signings on each of 11 bases with `(d,k)` equal to `(3,3),(4,3),(4,4),(3,4),(2,3),(2,5),(5,3),(2,4)`
and the cyclic interval bases `H(6,3), H(8,4), H(9,3)`. In all 440 signings `lambda_min(S) >= -d`.
The left-sided condition holds for all tested signings exactly when `d = k`, fails for all tested
signings when `d < k`, and is mixed when `d > k` (for the `(4,3)` base the worst signing reaches
`-3.9594`, below the window bottom `-3.8990`, while 243 of 300 random covers of the same base lie
inside the window). `outputs/exp8_signed_gram.txt`.

---

## Summary of what is sharp and what is only a benchmark

| statement | status |
| --- | --- |
| `lambda_2 <= k-2+2t + eps_n` a.a.s. for random `(d,k)`-regular `H` | [LIT], Dumitriu-Zhu Theorem 4.3 |
| `lim inf lambda_2 >= k-2+2t` along connected families | [LIT], Feng-Li, via two independent quotations |
| the extremal value `k-2+2t` is exactly the universal-cover spectral radius `rho(D_{d,k})` | [LIT], Song-Fan-Miao Theorem 1.5 and Cioaba et al. |
| `2 sqrt((k-1)d-1)` is the right threshold | **false for every `k >= 3`**, T7 |
| `d - lambda_2` is a gap | **false**: the trivial value is `d(k-1)`, T2 |
| `d - lambda_3` and `d - lambda_4` are gaps | **false at the top** (no second forced value), true only as a description of the `-d` plateau at the bottom, T8 |
| `-d` is trivial only when `d < k` | **false**, T5(2) and T9 |
| every `(d,k)`-regular hypergraph with `d < k` has a Ramanujan cover | **false**, T12 |
| `d = k` needs the right-sided qualifier | **no**, T10 and T15 |
| a signing can push the new spectrum below `-d` | **no**, T15 |
| `d > k` makes the left-sided condition automatic | **no**, T15(4) and `exp8` |
