import numpy as np, json, sys

def reg_config(n, d, rng):
    """Uniform simple d-regular graph on n vertices by configuration model
    with REJECTION of non-simple pairings. Conditional on simplicity this is
    exactly uniform over simple d-regular graphs (each simple graph has the
    same number (d!)^{n} of pairings). Certified-uniform honest sampler."""
    tries = 0
    while True:
        tries += 1
        stubs = np.repeat(np.arange(n), d)
        perm = rng.permutation(stubs.size)
        s = stubs[perm]
        a, b = s[0::2], s[1::2]
        if np.any(a == b):
            continue
        e = np.sort(np.stack([a, b], 1), 1)
        if np.unique(e, axis=0).shape[0] != e.shape[0]:
            continue
        A = np.zeros((n, n))
        A[a, b] = 1.0
        A[b, a] = 1.0
        return A, tries

def G_km(d, lam):
    """Kesten-McKay Stieltjes transform at real lam > 2 sqrt(d-1):
       G = 1/(lam - d*h), h=(lam - sqrt(lam^2-4(d-1)))/(2(d-1))"""
    h = (lam - np.sqrt(lam*lam - 4*(d-1)))/(2*(d-1))
    return 1.0/(lam - d*h)

def G_km_alt(d, lam):
    return 2*(d-1)/((d-2)*lam + d*np.sqrt(lam*lam-4*(d-1)))

def root_lambda(d, Delta, lo=None, hi=None):
    """unique exterior root of lam = Delta*G_km(lam) (exists iff Delta>2(d-2))"""
    lo = 2*np.sqrt(d-1)+1e-12 if lo is None else lo
    hi = 1.0 if hi is None else hi
    f = lambda x: x - Delta*G_km(d, x)
    if f(lo) > 0: return None
    while f(hi) < 0: hi *= 2
    for _ in range(300):
        mid = 0.5*(lo+hi)
        if f(mid) < 0: lo = mid
        else: hi = mid
    return 0.5*(lo+hi)

def run(n, d, Delta, seed):
    rng = np.random.default_rng(seed)
    A, tries = reg_config(n, d, rng)
    T = np.arange(Delta)                      # FIXED vertex set {0,...,Delta-1}
    ones = np.zeros(n); ones[T] = 1.0
    w, V = np.linalg.eigh(A)
    lam1_host = w[-1]
    s = (V.T @ ones)**2                       # s_j = (1_T . phi_j)^2
    # exact secular function of M (host + one vertex adjacent to T)
    def F(lam):
        return lam - np.sum(s/(lam - w))
    # top eigenvalue of M above d, by bisection
    lo = lam1_host*(1+1e-14) + 1e-13
    hi = lam1_host + 10.0
    assert F(lo) < 0 and F(hi) > 0
    for _ in range(200):
        mid = 0.5*(lo+hi)
        if F(mid) < 0: lo = mid
        else: hi = mid
    lam1_M_sec = 0.5*(lo+hi)
    # gap eigenvalue: unique root in (lam2_host, lam1_host)
    lo2 = w[-2]*(1+1e-12) + 1e-12; hi2 = lam1_host*(1-1e-12)
    lam2_M_sec = None
    if F(lo2) < 0 and F(hi2) > 0:
        for _ in range(200):
            mid = 0.5*(lo2+hi2)
            if F(mid) < 0: lo2 = mid
            else: hi2 = mid
        lam2_M_sec = 0.5*(lo2+hi2)
    # direct construction of M and its spectrum (certifies the secular function)
    M = np.zeros((n+1, n+1)); M[:n, :n] = A
    M[T, n] = 1.0; M[n, T] = 1.0
    wM = np.linalg.eigvalsh(M)
    # Perron-decomposed scalar: Gamma_n(d) = 1_T^T L^+ 1_T
    Lp = np.linalg.pinv(d*np.eye(n) - A)
    Gam = ones @ Lp @ ones
    # trace of pseudoinverse (Perron-removed)
    trLp = np.trace(Lp)
    out = dict(n=n, d=d, Delta=Delta, seed=seed, rej_tries=tries,
               lam1_host=float(w[-1]), lam2_host=float(w[-2]),
               lam1_M_direct=float(wM[-1]), lam2_M_direct=float(wM[-2]),
               lam1_M_secular=float(lam1_M_sec), lam2_M_secular=float(lam2_M_sec),
               n_times_shift=float(n*(wM[-1]-d)),
               Gamma=float(Gam), Delta_G=float(Delta*G_km(d, d)),
               pred_n_shift_exact=float(Delta**2/(d-Gam)) if abs(d-Gam)>1e-12 else None,
               pred_n_shift_limit=float(Delta**2/(d-Delta*G_km(d, d))) if abs(d-Delta*G_km(d,d))>1e-12 else None,
               trace_over_n=float(trLp/n), G_at_d=float(G_km(d, d)))
    return out

if __name__ == "__main__":
    rows = []
    for d in (3, 4):
        for Delta in (1, 2, 3):
            for n in (1000, 2000, 4000):
                for seed in (1, 2):
                    if d == 4 and n > 2000: continue
                    rows.append(run(n, d, Delta, 1000*seed + n))
    for r in rows:
        print(json.dumps({k: (round(v, 10) if isinstance(v, float) else v) for k, v in r.items()}))
