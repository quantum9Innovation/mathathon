"""Structural checks: bipartite obstruction, girth correlation, coset certificate."""
import sys
sys.path.insert(0, 'dossier/src')
import numpy as np
from fractions import Fraction
from cayley import *
from collections import Counter

import builtins
def pp(*a, **k):
    k.setdefault('flush', True)
    builtins.print(*a, **k)


def subgroups(G):
    """All subgroups of G as frozensets of indices (G small)."""
    n, T, inv = G.n, G.T, G.inv
    subs = []
    elts = list(range(n))
    # closure of a set
    def closure(gen):
        S = {0}
        frontier = [0]
        while frontier:
            nxt = []
            for x in frontier:
                for g in gen:
                    y = int(T[x, g])
                    if y not in S:
                        S.add(y)
                        nxt.append(y)
            frontier = nxt
        return frozenset(S)
    seen = set()
    for k in range(1, min(n, 4) + 1):
        import itertools
        for gen in itertools.combinations(range(1, n), k):
            H = closure(gen)
            if H not in seen:
                seen.add(H)
                subs.append(H)
    return subs


def coset_bound(d, dH, m):
    """Rayleigh quotient of 1_H - (1/m) 1 for a coset of a subgroup of index m."""
    if m == 1:
        return None
    return (dH * (m - 1) / m - 2 * (d - dH) / m
            + ((m - 1) * d - (d - dH)) / (m * (m - 1)))


def check_group(G, d, subs):
    thr = 2 * np.sqrt(d - 1)
    sets = [S for S in G.symmetric_sets(d) if G.connected(S)]
    pp("GROUP %s, d=%d, connected sets %d, threshold %.9f" % (G.name, d, len(sets), thr))
    # 1. bipartite iff there is an index-2 subgroup avoiding S
    n = G.n
    idx2 = [H for H in subs if len(H) * 2 == n]
    res = Counter()
    viol = 0
    worst = []
    for S in sets:
        lam = G.lambda_two_sided(S)
        bip = any(len(H & set(S)) == 0 for H in idx2)
        res[(bip, lam > thr + 1e-9)] += 1
        # coset certificate over all proper subgroups
        best = -1e9
        bestH = None
        for H in subs:
            m = n // len(H)
            if m == 1:
                continue
            dH = len(H & set(S))
            b = coset_bound(d, dH, m)
            if b > best:
                best, bestH = b, (len(H), m, dH)
        worst.append((lam, best, S, bestH, bip))
        if best > lam + 1e-9:
            viol += 1
    pp("  (bipartite?, lambda>thr) counts: %s" % dict(res))
    pp("  coset certificate never exceeds lambda: %s (%d violations)" % (viol == 0, viol))
    bad = [w for w in worst if w[0] > thr + 1e-9]
    cert = [w for w in bad if w[1] > thr + 1e-9]
    pp("  # non-Ramanujan sets: %d ; of these certified by a coset bound > thr: %d" % (len(bad), len(cert)))
    unc = [w for w in bad if w[1] <= thr + 1e-9]
    pp("  # non-Ramanujan NOT certified by any subgroup coset: %d" % len(unc))
    if unc:
        girths = Counter(G.girth(w[2]) for w in unc)
        pp("    girth distribution of the uncertified ones: %s" % dict(sorted(girths.items())))
        for w in unc[:3]:
            pp("    example S=%s  lam=%.9f  best coset=%.9f (%s)  girth=%d"
               % ([cycle_type(G.els[s]) for s in w[2]], w[0], w[1], w[3], G.girth(w[2])))
    # girth of all non-Ramanujan
    girths_all = Counter(G.girth(w[2]) for w in bad)
    pp("    girth distribution of ALL non-Ramanujan: %s" % dict(sorted(girths_all.items())))
    # distribution of the best coset bound
    pp("  distribution of best coset bound (rounded): %s"
       % dict(sorted(Counter(round(w[1], 6) for w in worst).items())))
    return worst


if __name__ == '__main__':
    for G, d in [(sym_group(4), 3), (alt_group(5), 3), (sym_group(5), 3)]:
        subs = subgroups(G)
        pp("  (%s has %d subgroups of order <= ... computed)" % (G.name, len(subs)))
        check_group(G, d, subs)
        pp()
