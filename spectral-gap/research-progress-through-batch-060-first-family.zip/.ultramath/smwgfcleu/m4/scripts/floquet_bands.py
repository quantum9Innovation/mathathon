"""
floquet_bands.py  --  exact band structure of spherically homogeneous trees
with periodic children counts, plus verification against truncated trees.

Conventions
-----------
T is spherically homogeneous with root r if every vertex at distance k from r
has exactly n_k children.  Radial eigenfunctions obey the continued fraction

    t_k = 1/(lambda - n_k t_{k+1})                (tail recursion)

with Moebius matrix M_k(lam) = [[0,1],[-n_k, lam]].  If n_{k+m} = n_k for k >= 1,
the period product is P(lam) = M_1...M_m and (Floquet condition)

    lam in sigma(A_T)   <=>   |tr P(lam)| <= 2 sqrt(det P(lam)),   det P = prod n_i.

For m = 2 this is closed form: sigma(A_T) = +- [ |sqrt(n1)-sqrt(n2)| , sqrt(n1)+sqrt(n2) ].

Parts: (a) m=2 closed form + truncated tree check, (b) m=3 exact edges via sympy,
(c) test that every eigenvalue of the truncated tree satisfies the Floquet condition.
"""
import numpy as np
import sympy as sp
import scipy.sparse as ss
from scipy.sparse.linalg import eigsh


def period_product(counts, lam):
    P = np.eye(2)
    for n in counts:
        P = P @ np.array([[0.0, 1.0], [-float(n), lam]])
    return P


def floquet_margin(counts, lam):
    P = period_product(counts, lam)
    return np.trace(P) ** 2 - 4.0 * np.linalg.det(P)


def floquet_margin_vec(counts, lams):
    return np.array([floquet_margin(counts, x) for x in lams])


def bands_from_margin(counts, lo=-10.0, hi=10.0, grid=200001):
    xs = np.linspace(lo, hi, grid)
    vals = floquet_margin_vec(counts, xs)
    ins = vals <= 0.0
    edges = []
    for i in range(1, len(xs)):
        if ins[i] != ins[i - 1]:
            a, b = xs[i - 1], xs[i]
            for _ in range(70):
                m = 0.5 * (a + b)
                if (floquet_margin(counts, m) <= 0.0) == ins[i - 1]:
                    a = m
                else:
                    b = m
            edges.append(0.5 * (a + b))
    return edges, xs, ins


def build_tree_sparse(n0, tail, depth):
    """Sparse adjacency of the truncated spherically homogeneous tree."""
    m = len(tail)
    rows, cols = [], []
    frontier = np.array([0])
    nid = 1
    for k in range(depth):
        nc = n0 if k == 0 else tail[(k - 1) % m]
        if nc == 0:
            break
        new = np.arange(nid, nid + frontier.size * nc)
        nid += frontier.size * nc
        parents = np.repeat(frontier, nc)
        rows.append(parents); cols.append(new)
        rows.append(new); cols.append(parents)
        frontier = new
    A = ss.coo_matrix((np.ones(sum(len(r) for r in rows)),
                       (np.concatenate(rows), np.concatenate(cols))),
                      shape=(nid, nid)).tocsr()
    return A, nid


def extremes(A, k=3):
    n = A.shape[0]
    k = min(k, n - 2)
    top = eigsh(A, k=k, which='LA', return_eigenvectors=False)
    bot = eigsh(A, k=k, which='SA', return_eigenvectors=False)
    return np.sort(top)[::-1], np.sort(bot)


def report_m2(a, b, depth, out):
    edges, xs, ins = bands_from_margin([a, b])
    s_plus, s_minus = np.sqrt(a) + np.sqrt(b), abs(np.sqrt(a) - np.sqrt(b))
    A, n = build_tree_sparse(a + 1, [b, a], depth)
    top, bot = extremes(A)
    ev_top, ev_bot = top[0], bot[0]
    marg = max(floquet_margin([a, b], x) for x in np.concatenate([top, bot]))
    out.write(f"m=2, tail counts (a,b)=({a},{b});  closed form |lam| in [{s_minus:.12f}, {s_plus:.12f}]\n")
    out.write(f"  Floquet-numeric band edges: {['%.12f' % e for e in edges]}\n")
    out.write(f"  truncated tree depth={depth}, vertices={n}\n")
    out.write(f"  top eigenvalue {ev_top:.10f}   (s_plus - top = {s_plus - ev_top:.3e})\n")
    out.write(f"  bottom eigenvalue {ev_bot:.10f}  (bot + s_plus = {ev_bot + s_plus:.3e})\n")
    out.write(f"  max Floquet margin over its extreme eigenvalues (must be <=0): {marg:.3e}\n")
    out.write(f"  is there a spectral gap? s_minus = {s_minus:.6f} > 0 : {s_minus > 1e-12}\n\n")
    return dict(a=a, b=b, s_plus=s_plus, s_minus=s_minus, top=ev_top, n=n)


def report_m3(counts, depth, out):
    lam = sp.symbols('lam')
    P = sp.eye(2)
    for n in counts:
        P = P * sp.Matrix([[0, 1], [-sp.Integer(n), lam]])
    expr = sp.expand(sp.trace(P) ** 2 - 4 * P.det())
    roots = sorted([complex(r).real for r in sp.nroots(expr, n=40) if abs(complex(r).imag) < 1e-20])
    edges, xs, ins = bands_from_margin(counts, lo=-10, hi=10, grid=100001)
    A, n = build_tree_sparse(counts[0] + 1, counts, depth)
    top, bot = extremes(A, k=4)
    out.write(f"m=3, tail counts {counts}\n  exact tr(P)^2-4det(P) = {sp.factor(expr)}\n")
    out.write(f"  real roots: {['%.10f' % r for r in roots]}\n")
    out.write(f"  numeric band edges: {['%.10f' % e for e in edges]}\n")
    out.write(f"  truncated tree depth={depth}, vertices={n}; top={top}; bottom={bot}\n")
    worst = max(floquet_margin(counts, x) for x in np.concatenate([top, bot]))
    out.write(f"  max Floquet margin over its 8 extreme eigenvalues (must be <=0): {worst:.3e}\n\n")


if __name__ == "__main__":
    import os
    os.makedirs("outputs", exist_ok=True)
    res = []
    with open("outputs/floquet_bands.txt", "w") as out:
        out.write("FLOQUET BAND STRUCTURE OF PERIODIC-TYPE UNIVERSAL COVERS\n" + "=" * 72 + "\n\n")
        out.write("(A) two-periodic case: closed form vs truncated universal cover\n\n")
        for (a, b, d) in [(1, 2, 16), (2, 3, 11), (1, 4, 11), (2, 2, 14), (3, 4, 8), (1, 8, 8)]:
            res.append(report_m2(a, b, d, out))
        out.write("(B) three-periodic case: exact band polynomial and numeric bands\n\n")
        report_m3([1, 2, 3], 12, out)
        report_m3([1, 1, 5], 12, out)
    txt = open("outputs/floquet_bands.txt").read()
    print(txt)
