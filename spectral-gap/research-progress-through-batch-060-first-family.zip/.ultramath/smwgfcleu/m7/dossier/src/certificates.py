"""Two failure mechanisms at degree 3: linear characters (coset cosets) and short relations."""
import sys
sys.path.insert(0, 'dossier/src')
import numpy as np, itertools
from cayley import *
from structural_checks import subgroups, coset_bound

import builtins
def pp(*a, **k):
    k.setdefault('flush', True)
    builtins.print(*a, **k)


def analyse(G, d):
    n = G.n
    thr = 2 * np.sqrt(d - 1)
    subs = [H for H in subgroups(G) if len(H) < n]
    idx2 = [H for H in subs if 2 * len(H) == n]
    sets = [S for S in G.symmetric_sets(d) if G.connected(S)]
    pp("== %s, d=%d: %d connected sets, threshold 2sqrt(d-1)=%.6f" % (G.name, d, len(sets), thr))
    table = {}
    for S in sets:
        lam = G.lambda_two_sided(S)
        g = G.girth(S, cap=14)
        bip = any(len(H & set(S)) == 0 for H in idx2)
        cert = 0.0
        best = None
        for H in subs:
            m = n // len(H)
            dH = len(H & set(S))
            R = abs(coset_bound(d, dH, m))
            if R > cert:
                cert, best = R, (len(H), m, dH)
        table[S] = (lam, g, bip, cert, best)
        assert cert <= lam + 1e-9, (S, cert, lam)
    nonram = {S: v for S, v in table.items() if v[0] > thr + 1e-9}
    ram = {S: v for S, v in table.items() if v[0] <= thr + 1e-9}
    pp("  non-Ramanujan: %d   Ramanujan: %d" % (len(nonram), len(ram)))
    pp("  joint (girth, Ramanujan?) : %s"
       % dict(sorted({(g, r): sum(1 for v in (ram if r else nonram).values() if v[1] == g)
                      for g in range(3, 15) for r in (True, False)}.items())))
    pp("  of the non-Ramanujan, bipartite: %d ; certified (|coset bound| > thr): %d"
       % (sum(1 for v in nonram.values() if v[2]), sum(1 for v in nonram.values() if v[3] > thr + 1e-9)))
    pp("  certified non-Ramanujan that are NOT bipartite: %d"
       % sum(1 for v in nonram.values() if v[3] > thr + 1e-9 and not v[2]))
    pp("  bipartite but Ramanujan: %d" % sum(1 for v in ram.values() if v[2]))
    pp("  max over all S of |coset certificate| = %.6f" % max(v[3] for v in table.values()))
    # exact spectra of extremal representatives
    bmin = min(table.items(), key=lambda kv: kv[1][0])
    bmax = max(table.items(), key=lambda kv: kv[1][0])
    for tag, (S, v) in [("MIN", bmin), ("MAX", bmax)]:
        pp("  %s lam=%.9f girth=%d bipartite=%s cert=%.9f S=%s"
           % (tag, v[0], v[1], v[2], v[3], [cycle_type(G.els[s]) for s in S]))
    return table


if __name__ == '__main__':
    out = {}
    for G, d in [(sym_group(4), 3), (alt_group(5), 3), (sym_group(5), 3)]:
        out[(G.name, d)] = analyse(G, d)
        pp()
