r"""Cross-check 1: the Bloch decomposition against brute-force spectra.

For every tested Z^d-periodic graph Gamma and every tested finite-index
sublattice Lambda, the multiset of Bloch eigenvalues over Lambda^*/Z^d must
equal the adjacency spectrum of the explicitly constructed finite graph
Lambda \ Gamma.
"""
import sys, os, itertools, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
from fractions import Fraction
import lib

np.set_printoptions(precision=12, suppress=False)


def canon(x, y, a, b, d):
    """Canonical representative of (x,y) mod <(a,b),(0,d)>."""
    for _ in range(100):
        k = y // d
        y2 = y - k*d
        m = x // a
        x2 = x - m*a
        y3 = y2 - m*b
        if 0 <= x2 < a and 0 <= y3 < d:
            return (x2, y3)
        x, y = x2, y3
    raise RuntimeError("canon did not terminate")


def finite_quotient_adjacency(G, a, b, d):
    r"""Adjacency matrix of Lambda \ Gamma, Lambda = <(a,b),(0,d)>."""
    reps = sorted({canon(x, y, a, b, d) for x in range(-2*a, 2*a+1)
                   for y in range(-2*d, 2*d+1)})
    assert len(reps) == a*d, (len(reps), a*d)
    idx = {c: i for i, c in enumerate(reps)}
    N = len(reps)*G.p
    A = np.zeros((N, N))
    for c in reps:
        for (u, v, g) in G.edges:
            t = canon(c[0]+g[0], c[1]+g[1], a, b, d)
            i = idx[c]*G.p + u
            j = idx[t]*G.p + v
            if i == j:
                # a listed edge that closes on itself: contributes 1 in the lift
                A[i, i] += 2
            else:
                A[i, j] += 1
                A[j, i] += 1
    return A, reps


def bloch_spectrum(G, a, b, d):
    pts = lib.dual_points_2d(a, b, d)
    vals = []
    for (kx, ky) in pts:
        vals.extend(list(np.linalg.eigvalsh(G.A((float(kx), float(ky))))))
    return np.array(sorted(vals))


def check(name, G, sublattices, out):
    rows = []
    for (a, b, d) in sublattices:
        A, reps = finite_quotient_adjacency(G, a, b, d)
        brute = np.sort(np.linalg.eigvalsh(A))
        bloch = bloch_spectrum(G, a, b, d)
        n = len(brute)
        assert len(bloch) == n, (len(bloch), n)
        err = float(np.max(np.abs(np.sort(brute) - np.sort(bloch))))
        rows.append(dict(a=a, b=b, d=d, N=a*d, nverts=n, maxabsdiff=err))
        print(f"  {name}: Lambda=<({a},{b}),(0,{d})>  |V|={n:5d}  "
              f"max|brute-bloch|={err:.3e}")
    out[name] = rows


def main():
    out = {}

    # 1. square lattice, S = {+-e1, +-e2}
    sq = lib.PeriodicGraph(1, [(0, 0, (1, 0)), (0, 0, (-1, 0)),
                               (0, 0, (0, 1)), (0, 0, (0, -1))])
    check("square", sq, [(n, 0, n) for n in (2, 3, 4)] +
          [(4, 1, 3), (6, 2, 5)], out)

    # 2. honeycomb lattice: 2 vertices per cell, A at 0, B at delta.
    #    Edges: A(cell u) - B(cell u), A(u) - B(u - a1), A(u) - B(u - a2)
    #    with a1 = (1,0), a2 = (0,1) in cell coordinates.  Oriented as A -> B.
    hon = lib.PeriodicGraph(2, [(0, 1, (0, 0)), (0, 1, (-1, 0)), (0, 1, (0, -1))])
    check("honeycomb", hon, [(n, 0, n) for n in (2, 3, 4)] + [(4, 1, 3)], out)

    # 3. a non-Cayley 3-vertex periodic graph, not bipartite
    tri = lib.PeriodicGraph(3, [(0, 1, (0, 0)), (1, 2, (0, 0)), (2, 0, (1, 0)),
                                (0, 0, (1, 0))])
    check("threecell", tri, [(n, 0, n) for n in (2, 3)] +
          [(4, 1, 3), (6, 5, 5)], out)

    # 4. 1D examples embedded with d=2 (period group Z^2, second direction free
    #    would disconnect, so use genuine 2D ones above only)
    json.dump(out, open(os.path.join(os.path.dirname(__file__), "..", "out",
                                     "s04_bloch_vs_explicit.json"), "w"),
              indent=1)
    print("OK: Bloch spectrum equals explicit spectrum in every case tested.")


if __name__ == "__main__":
    main()
