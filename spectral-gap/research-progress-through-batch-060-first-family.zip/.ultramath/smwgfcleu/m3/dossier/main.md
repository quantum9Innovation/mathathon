# The multiplicity face of the $2\sqrt{d-1}$ threshold

Research dossier, swarm smwgfcleu, member m3, direction d8.

Files in this directory: `main.md` (this document), `derivations.md` (longer proofs and
reproducibility notes), `code/` (four runnable scripts), `out/` (raw JSON output of every run).
Every numerical claim below is reproduced by one of the scripts in `code/` and stored in `out/`.

## 0. Summary, and what is claimed at which evidence level

The four local dossiers study one face of a single phenomenon. An infinite local limit supplies
an exact spectral threshold, and tangle or rare defect control shows that random finite quotients
attain it. All four thresholds are **values**. They say that $\lambda_2$ cannot exceed a number
(Friedman, Bordenave, Friedman and Kohler, Brito and Dumitriu and Decker Harris) and that it must
reach a number (Alon and Boppana).

The user's question about $d-\lambda_3$ and $d-\lambda_4$ is not a question of that type. It is a
question about **multiplicities** and about **counts of eigenvalues beyond a threshold**. This
dossier works that second face, and it makes the following claims.

| Claim | Kind | Where |
| --- | --- | --- |
| The Alon-Boppana constant $2\sqrt{d-1}$ is the fold of the nonbacktracking radius $\sqrt{d-1}$ through $\mu^2-\lambda\mu+(d-1)=0$ | checked literature plus exact computation | Sections 2, 4.5 |
| Seidel moment bound $k\le n(n-1)/(n-1+\theta^2)$ for the multiplicity of a Seidel eigenvalue, with equality iff $S$ has at most two eigenvalues | proof supplied here, classical in substance | Section 3.1 |
| The van Lint-Seidel relative bound for equiangular lines is precisely the case $\theta=-1/\alpha$, $k=n-d$ | proof supplied here | Section 3.2 |
| Graph corollary $\mathrm{mult}(\lambda)\le n(n-1)/(n-1+(1+2\lambda)^2)$ for eigenvectors orthogonal to $\mathbf 1$ | proof supplied here | Section 3.3 |
| Slack in the bound equals the variance of the remaining eigenvalues | proof plus machine check | Section 3.4 |
| Equality for a $d$-regular graph forces at most three distinct adjacency eigenvalues, hence $n\le d^2+1$ | proof supplied here, machine checked on all connected graphs with $n\le 8$ | Section 3.5 |
| $K_4\square C_k$ is 5-regular with $\Theta(n)$ eigenvalues above $2\sqrt{d-1}+1/2$ | exact computation | Section 4.6 |
| Connected bounded degree graphs have sublinear second eigenvalue multiplicity, $O_\Delta(n/\log\log n)$ | checked literature (JTYZZ) | Section 2.7 |
| Best known bounds for that multiplicity are between $\sqrt{n/\log n}$ and $O(n/\log\log n)$ | checked literature (Haiman, Schildkraut, Zhang, Zhao and McKenzie, Rasmussen, Srivastava) | Section 2.8 |
| The rank/moment mechanism is provably blind at fixed degree, and the structured equality family lives only at $n\le d^2+1$ | proof supplied here | Sections 5.1, 5.2 |
| Exact extremal second eigenvalue multiplicities: cubic up to $n=18$, quartic up to $n=14$, quintic up to $n=12$ | exact enumeration with nauty | Section 4.7 |

Nothing here is claimed as new mathematics except the assembly, the derivations labelled as
supplied here, and the exact computations. The relative bound, the equality case, the fold and the
sublinear multiplicity theorems are all in the literature, and Section 2 gives the sources.

## 1. Model, ordering, normalization, regime, and why the question matters

### 1.1 Graphs and the value face

$G$ is a finite simple graph on $n$ vertices with adjacency matrix $A\in\{0,1\}^{n\times n}$ and
degree $d$ throughout except where stated. Eigenvalues are ordered
$$\lambda_1=d\ \ge\ \lambda_2\ \ge\ \dots\ \ge\ \lambda_n,$$
counted with multiplicity. The normalisation used by all four sources is the **adjacency**
normalisation, not the random walk normalisation. The threshold is
$$\theta_d \,=\, 2\sqrt{d-1},$$
which is the operator norm of the adjacency operator of the infinite $d$-regular tree, and the
asymptotic regime is $d$ fixed and $n\to\infty$. The Alon-Boppana theorem says
$\liminf_n \lambda_2(G_n)\ge \theta_d$ along any sequence of $d$-regular graphs with girth tending
to infinity. Friedman, Bordenave, and Friedman and Kohler prove the matching upper bound for
random regular graphs, random lifts of a fixed base, and random covers of a regular base
respectively.

Why the value face is a fold. Let $B$ be the nonbacktracking matrix on directed edges of a
$d$-regular graph. The Ihara-Bass determinant identity, as stated and used in the biregular and
lift dossiers, is
$$\det(B-uI)\,=\,(u^2-1)^{|E|-n}\,\det\big((d-1)I-uA+u^2 I\big).$$
Every adjacency eigenvalue $\lambda$ therefore generates two nonbacktracking eigenvalues
$\mu_{1,2}(\lambda)$ solving
$$\mu^2-\lambda\mu+(d-1)=0,\qquad \lambda=\mu+\frac{d-1}{\mu}.$$
The critical point of the fold $\mu\mapsto \mu+(d-1)/\mu$ is $\mu=\sqrt{d-1}$, and the fold value
there is exactly $2\sqrt{d-1}$. So the Alon-Boppana constant is the image of the nonbacktracking
radius under a quadratic fold. Section 4.5 verifies the identity as an exact spectral multiset
identity on six graphs.

The biregular source uses the two degree version. For a $(d_1,d_2)$-biregular bipartite graph with
biadjacency matrix $X$ and squared singular values $y=\xi^2$, the quartic
$\lambda^4-(\xi^2-d_1-d_2+2)\lambda^2+(d_1-1)(d_2-1)=0$ becomes, with $x=\lambda^2$,
$$y=x+\frac{(d_1-1)(d_2-1)}{x}+(d_1-1)+(d_2-1).$$
The bulk sits at $x=\sqrt{(d_1-1)(d_2-1)}$, which gives $\xi=\sqrt{d_1-1}+\sqrt{d_2-1}$. This is the
same fold with a two degree shift. So all three regular-ish sources are one mechanism.

### 1.2 Seidel matrices and the multiplicity face

For a graph $G$ on $n$ vertices the **Seidel matrix** is
$$S(G)=J-I-2A(G).$$
It is symmetric, has zero diagonal and off-diagonal entries $\pm1$. **Switching** at a set
$T\subseteq V$ replaces $S$ by $DSD$ with $D=\mathrm{diag}(-1$ on $T$, $+1$ elsewhere$)$. Switching
preserves $\mathrm{spec}(S)$ exactly, and the equivalence classes are the **two-graphs**. Order the
Seidel spectrum decreasingly
$$\theta_{\max}=\theta_1\ \ge\ \dots\ \ge\ \theta_n=\theta_{\min}.$$

The dictionary to equiangular lines is exact. Let $x_1,\dots,x_m$ be unit vectors in
$\mathbb R^d$ with $|\langle x_i,x_j\rangle|=\alpha$ for all $i\ne j$ and some $\alpha\in(0,1)$.
Then the Gram matrix is
$$G_{\mathrm{gram}}=I+\alpha S$$
for a Seidel matrix $S$ of order $m$. Since $G_{\mathrm{gram}}$ is positive semidefinite of rank at
most $d$, and rank equals $d$ when the lines span $\mathbb R^d$, the system is exactly a Seidel
matrix with
$$\theta_{\min}=-\frac1\alpha,\qquad \mathrm{mult}(\theta_{\min})=m-d .$$
So the value face asks for an **interval edge**, and the equiangular question asks for a
**multiplicity floor**. This is the precise sense in which the two faces are dual, and Section 5
makes the duality quantitative.

Normalisation warning. The Seidel normalisation is not the adjacency normalisation. For a
$d$-regular graph, $\mathrm{spec}(S)=\{n-1-2d\}\cup\{-1-2\lambda:\lambda\in\mathrm{spec}(A),\,
\lambda\ne d\}$. So Seidel multiplicities away from the degree eigenvalue are adjacency
multiplicities, and the two normalisations differ by the affine map $\lambda\mapsto -1-2\lambda$.
All statements below keep the two normalisations separate.

### 1.3 Limiting regimes

There are three regimes, and the dossier keeps them apart.

1. **Fixed $d$, $n\to\infty$.** The four sources. Threshold $\theta_d$, tangle exponents, random
   quotients. This is where "does $\lambda_2$ reach $2\sqrt{d-1}$" lives.
2. **$d$ growing with $n$.** The two-graph and strongly regular world. Here
   $\mathrm{mult}(\lambda_2)$ can be $\Theta(n)$ and the rank/moment bound can be attained. This is
   where "how many eigenvalues can equal $\lambda_2$" lives in its exact form.
3. **Fixed $d$, $n\to\infty$, multiplicity questions.** The frontier of Jiang, Tidor, Yao, Zhang
   and Zhao, of McKenzie, Rasmussen and Srivastava, and of Haiman, Schildkraut, Zhang and Zhao.
   Here the rank/moment bound is trivial (Section 5), and the known mechanism is the support of
   closed walks.

The reason the question matters is that $d-\lambda_3$ and $d-\lambda_4$ are only independent
invariants if the eigenvalues $\lambda_2,\lambda_3,\lambda_4$ can be separated. They cannot in
general: Section 4.6 exhibits a 5-regular family with $\lambda_2=\lambda_3$ exactly and with
$\Theta(n)$ eigenvalues above $\theta_d+\tfrac12$. So "the gap $d-\lambda_k$" is not a family of
independent expansion measures. What is meaningful is (i) the value threshold, (ii) the
multiplicity of a single eigenvalue, and (iii) the count profile above a fixed level. The dossier
separates these three.

## 2. Verified literature

Each item below states what was verified and how. Version numbers are those recorded in the local
`SOURCE.md` files and, for the arXiv entries, re-checked against the arXiv API on 2026-11-14.

### 2.1 The four local sources (checked)

1. J. Friedman, *A proof of Alon's second eigenvalue conjecture and related problems*,
   arXiv:cs/0405020v1, submitted 5 May 2004, 118 pages, to appear in Memoirs of the AMS.
   Abstract confirmed online at https://arxiv.org/abs/cs/0405020. Exact statement, paraphrased:
   for fixed $d>2$ and $\epsilon>0$ the probability that a random $d$-regular graph has second
   adjacency eigenvalue greater than $2\sqrt{d-1}+\epsilon$ tends to zero, with polynomial decay
   in several models. Local dossier records the quantified version with
   $\tau_{\mathrm{fund}}=\lceil(\sqrt{d-1}+1)/2\rceil-1$ for the permutation model.
2. C. Bordenave, *A new proof of Friedman's second eigenvalue Theorem and its extension to random
   lifts*, arXiv:1502.04482v4, revised 5 March 2019, to appear in Annales scientifiques de l'ENS.
   Abstract confirmed through the arXiv API. Exact statement, paraphrased: new nonbacktracking
   eigenvalues of a random $n$-lift of a connected base with more edges than vertices are at most
   $\sqrt{\rho_1}+o(1)$, where $\rho_1$ is the Perron eigenvalue of the base nonbacktracking matrix.
   For a $d$-regular base the Ihara-Bass conversion gives $2\sqrt{d-1}+o(1)$.
3. J. Friedman and D.-E. Kohler, *The Relativized Second Eigenvalue Conjecture of Alon*,
   arXiv:1403.3462v1, 13 March 2014. Abstract confirmed through the arXiv API. Exact statement,
   quoted: a random covering map of degree $n$ to a $d$-regular base $B$, $d\ge3$, has a new
   eigenvalue greater than $2\sqrt{d-1}+\epsilon$ in absolute value with probability $O(1/n)$.
   If $B$ is Ramanujan the probability is proportional to $n^{-\eta_{\mathrm{fund}}(B)}$ with
   $\eta_{\mathrm{fund}}(B)$ the least order of a strict tangle. Note that the abstract's final
   sentence "for any $d$-regular graph $B$, $\eta_{\mathrm{fund}}(B)$ is greater than
   $\sqrt{d-1}$" is flagged in the local dossier as inconsistent with the paper's own bouquet
   example, so it is recorded here as a printed claim and not used.
4. G. Brito, I. Dumitriu, K. Decker Harris, *Spectral gap in random bipartite biregular graphs and
   applications*, arXiv:1804.07808v6, revised 2 June 2021, Combinatorics, Probability and
   Computing 31 (2022) 229 to 267, DOI 10.1017/S0963548321000249. Abstract and journal reference
   confirmed through the arXiv API. Exact statement, paraphrased: for fixed $d_1\ge d_2\ge3$ a
   uniform simple $(d_1,d_2)$-biregular bipartite graph satisfies, asymptotically almost surely,
   $\lambda_2(A)\le \sqrt{d_1-1}+\sqrt{d_2-1}+o(1)$.

### 2.2 Alon-Boppana

The lower bound $\lambda_2\ge 2\sqrt{d-1}-o(1)$ along graphs of growing girth is classical. It is
not re-proved here. The local dossiers record it as an external input, and Section 4.5 verifies the
Ihara-Bass fold that converts it into a nonbacktracking statement.

### 2.3 Seidel matrices and two-graphs

- J. J. Seidel, *A survey of two-graphs*, Colloquio Internazionale sulle Teorie Combinatorie
  (Rome 1973), Atti dei Convegni Lincei 17 (1976), 481 to 511. The switching class and the
  equivalence with equiangular line systems is the content used here. This is a classical
  reference, not re-read in full for this dossier, and it is used only for terminology.
- J. H. van Lint and J. J. Seidel, *Equilateral point sets in elliptic geometry*, Indagationes
  Mathematicae 28 (1966), 335 to 348. This is the source of the relative bound used in Section 3.2.
- P. W. H. Lemmens and J. J. Seidel, *Equiangular lines*, Journal of Algebra 24 (1973), 494 to 512,
  DOI 10.1016/0021-8693(73)90123-3. Standard reference for the absolute bound and for the
  classification of large systems in small dimension.
- G. Greaves, *Equiangular lines* mini-course notes, https://personal.ntu.edu.sg/gary/talks/Montreal_lectures.pdf,
  Lemma 1.8 and Theorem 1.9. Precise paraphrase, read from the search result text: if $X$ is a set
  of $n$ equiangular lines in $\mathbb R^d$ with common angle $\alpha$ and $d<1/\alpha^2$, then
  $n\le d(1-\alpha^2)/(1-d\alpha^2)$. The proof proceeds by taking the Seidel matrix with smallest
  eigenvalue $\lambda_0=-1/\alpha$ of multiplicity $n-d$ and applying Cauchy-Schwarz to the other
  eigenvalues. The notes also state that when the relative or absolute bound is attained the Seidel
  matrix has just two distinct eigenvalues. This is exactly the statement re-derived in Section 3,
  so it is recorded as checked literature and not as a new result.

### 2.4 The maximum number of equiangular lines

OEIS A002853, https://oeis.org/A002853, gives the maximum number of equiangular lines in
$\mathbb R^d$ for $d=1,\dots,16$ as
$$1,\,3,\,6,\,6,\,10,\,16,\,28,\,28,\,28,\,28,\,28,\,28,\,28,\,28,\,36,\,40 .$$
This is used in Section 4.2 to make one point: attaining the relative bound is not the same as
being optimal. The $4\times4$ rook graph gives 16 lines in $\mathbb R^{10}$ at angle $1/5$ and
attains the relative bound exactly, while the true maximum in $\mathbb R^{10}$ is 28.

### 2.5 The fixed angle theorem

Z. Jiang, J. Tidor, Y. Yao, S. Zhang, Y. Zhao, *Equiangular lines with a fixed angle*,
arXiv:1907.12466v5, Annals of Mathematics 194 (2021), 729 to 743,
DOI 10.4007/annals.2021.194.3.3. Abstract confirmed through the arXiv API. Quoted in part: for
$0<\alpha<1$ let $N_\alpha(d)$ be the maximum number of lines through the origin in $\mathbb R^d$
with pairwise common angle $\arccos\alpha$. Let $k$ be the minimum number, if it exists, of
vertices in a graph whose adjacency matrix has spectral radius exactly $(1-\alpha)/(2\alpha)$. If
$k<\infty$ then $N_\alpha(d)=\lfloor k(d-1)/(k-1)\rfloor$ for all sufficiently large $d$, and
otherwise $N_\alpha(d)=d+o(d)$. In particular $N_{1/(2k-1)}(d)=\lfloor k(d-1)/(k-1)\rfloor$ for
every integer $k\ge2$ and all sufficiently large $d$. The abstract also states the key spectral
ingredient, quoted: "the adjacency matrix of a connected bounded degree graph has sublinear second
eigenvalue multiplicity".

### 2.6 Why this matters for the multiplicity face

Item 2.5 is the missing connection between the four dossiers and the equiangular world. The
equiangular fixed angle problem is *solved by a theorem about multiplicities of graph eigenvalues*.
That is the sharpest available evidence that the multiplicity face is a real part of spectral graph
theory and not a bookkeeping device.

### 2.7 Sublinear second eigenvalue multiplicity (checked)

Y. Zhao's research blog post *Graphs with high second eigenvalue multiplicity*,
https://yufeizhao.com/blog/2021/09/28/eig-mult/, states, quoted: "A connected bounded-degree
$n$-vertex graph has second eigenvalue multiplicity $O(n/\log\log n)$", attributed to Jiang,
Tidor, Yao, Zhang and Zhao, for the adjacency matrix. The same post reports that Theo McKenzie,
Peter Rasmussen and Nikhil Srivastava improved this for regular graphs.

### 2.8 The current frontier (checked)

M. Haiman, C. Schildkraut, S. Zhang, Y. Zhao, *Graphs with high second eigenvalue multiplicity*,
arXiv:2109.13131v3, revised 21 February 2023. Abstract confirmed through the arXiv API. Quoted
facts: the best known upper bound is $O(n/\log\log n)$, the previously known best lower bound is
on the order of $n^{1/3}$ for infinitely many $n$, coming from Cayley graphs on
$\mathrm{PSL}(2,q)$, and the paper gives a lower bound of order $\sqrt{n/\log n}$ together with
Cayley graphs with second eigenvalue multiplicity at least $n^{2/5}-1$. The abstract also states
that earlier techniques give at most $O(n/\log\log n)$ eigenvalues within $O(1/\log n)$ of the
second eigenvalue, that a construction matches this up to a constant factor, and that this
"demonstrates a barrier to earlier techniques for upper bounding eigenvalue multiplicities".

T. McKenzie, P. M. R. Rasmussen, N. Srivastava, *Support of Closed Walks and Second Eigenvalue
Multiplicity of the Normalized Adjacency Matrix*, arXiv:2007.12819v3, STOC 2021. Abstract confirmed
through the arXiv API. Quoted: the multiplicity of the second normalized adjacency eigenvalue of a
connected graph of maximum degree $\Delta$ is at most $O(n\Delta^{7/5}/\log^{1/5-o(1)}n)$, and at
most $O(n\log^{1/2}d/\log^{1/4-o(1)}n)$ for simple $d$-regular graphs when $d\ge\log^{1/4}n$. The
same bounds hold for the number of eigenvalues in any interval of width
$\lambda_2/\log_\Delta^{1-o(1)}n$ containing $\lambda_2$.

### 2.9 What is not claimed as known

The literature search did not find the exact statement of Section 3.5, namely that equality in the
Seidel multiplicity bound for a $d$-regular graph forces $n\le d^2+1$. It is an elementary
consequence of the equality case of the relative bound plus the Moore bound, so it is very likely
folklore. It is presented as a derivation, not as a discovery.

## 3. Exact theorems on the multiplicity face

All five statements below are elementary. They are stated with full hypotheses because the point of
the dossier is that the exact side of the multiplicity face is completely pinned down, in contrast
with the asymptotic side.

### 3.1 Theorem (Seidel moment bound)

Let $S$ be a real symmetric $n\times n$ matrix with $S_{ii}=0$ and $S_{ij}\in\{+1,-1\}$ for $i\ne
j$. Let $\theta$ be an eigenvalue of $S$ with multiplicity $k\ge1$. Then
$$k\,\le\,\frac{n(n-1)}{n-1+\theta^2},$$
with equality if and only if all eigenvalues of $S$ other than $\theta$ are equal, that is, if and
only if $S$ has at most two distinct eigenvalues.

**Proof.** Since the diagonal vanishes and the off-diagonal entries have modulus one,
$$\operatorname{tr} S=0,\qquad \operatorname{tr} S^2=\sum_{i,j}S_{ij}^2=n(n-1).$$
Let $\theta_1,\dots,\theta_{n-k}$ be the remaining eigenvalues. Then
$\sum_i\theta_i=-k\theta$ and $\sum_i\theta_i^2=n(n-1)-k\theta^2$. By Cauchy-Schwarz,
$$k^2\theta^2=\Big(\sum_i\theta_i\Big)^2\le (n-k)\sum_i\theta_i^2=(n-k)\big(n(n-1)-k\theta^2\big).$$
Adding $(n-k)k\theta^2$ to both sides gives $kn\theta^2\le (n-k)n(n-1)$, that is,
$k\theta^2\le (n-k)(n-1)$, which rearranges to $k(n-1+\theta^2)\le n(n-1)$. Equality in
Cauchy-Schwarz holds exactly when all $\theta_i$ coincide.

### 3.2 Corollary (van Lint-Seidel relative bound)

Let $m$ equiangular lines in $\mathbb R^d$ have common angle $\alpha$ with $d\alpha^2<1$. Then
$$m\,\le\,d\,\frac{1-\alpha^2}{1-d\alpha^2}.$$

**Proof.** By Section 1.2 the associated Seidel matrix $S$ has $\theta_{\min}=-1/\alpha$ with
multiplicity $m-d$. Apply Theorem 3.1 with $n=m$, $k=m-d$, $\theta=-1/\alpha$:
$$m-d\,\le\,\frac{m(m-1)}{m-1+\alpha^{-2}}.$$
Multiply by the positive denominator: $(m-d)(m-1)+(m-d)\alpha^{-2}\le m(m-1)$. Subtract
$(m-d)(m-1)$: $(m-d)\alpha^{-2}\le d(m-1)$. Hence $m-d\le d\alpha^2(m-1)$, that is
$m(1-d\alpha^2)\le d(1-\alpha^2)$, and the claim follows because $1-d\alpha^2>0$.

Equality holds exactly when the Seidel matrix has two distinct eigenvalues. Writing them as
$-1/\alpha$ with multiplicity $m-d$ and $\tau$ with multiplicity $d$, the trace condition
$0=(m-d)(-1/\alpha)+d\tau$ forces
$$\tau=\frac{m-d}{d\alpha},$$
so the pair $(m,d,\alpha)$ is determined by the two eigenvalue data. Two classical extremes occur:
the **conference** case $m=2d$, $\alpha=1/\sqrt{m-1}$, where the two eigenvalues are
$\pm\sqrt{m-1}$ each of multiplicity $m/2$, and the **complete graph** case, where
$S(K_{d+1})=I-J$ has eigenvalues $1$ with multiplicity $d$ and $-d$ with multiplicity $1$, giving
$m=d+1$ lines in $\mathbb R^d$ at angle $1/d$.

### 3.3 Corollary (graph eigenvalue multiplicity)

Let $G$ be a graph on $n$ vertices with adjacency matrix $A$ and let $\lambda$ be an eigenvalue of
$A$ such that $\mathbf 1$ is not an eigenvector of $A$ with eigenvalue $\lambda$. Then
$$\operatorname{mult}_A(\lambda)\,\le\,\frac{n(n-1)}{n-1+(1+2\lambda)^2}.$$

**Proof.** For $x\perp\mathbf 1$ we have $Sx=(J-I-2A)x=-x-2Ax=-(1+2\lambda)x$ whenever $Ax=\lambda x$.
So the $\lambda$-eigenspace of $A$ injects into the $-(1+2\lambda)$-eigenspace of $S$, and the
hypothesis ensures that the whole eigenspace lies in $\mathbf 1^\perp$. Apply Theorem 3.1.

For a $d$-regular graph the hypothesis holds for every $\lambda\ne d$. In that case the bound reads
$\operatorname{mult}(\lambda)\le n(n-1)/(n-1+(1+2\lambda)^2)$, which is $\Theta(n/(1+2\lambda)^2)$
for $\lambda$ bounded away from $0$. At $\lambda=\lambda_2\approx 2\sqrt{d-1}$ and fixed $d$ this is
$\Theta(n)$, and it is attained only in the structured case of Section 3.5.

### 3.4 Theorem (stability identity)

With the notation of Theorem 3.1, put
$$\Delta\,=\,n(n-1)-k\theta^2-\frac{k^2\theta^2}{n-k}.$$
Then
$$\Delta\,=\,\sum_{i=1}^{n-k}\Big(\theta_i+\frac{k\theta}{n-k}\Big)^2 .$$
So the slack in the multiplicity bound is exactly the variance of the remaining Seidel eigenvalues:
near equality means that $S$ is near a two eigenvalue matrix, and the quantitative deficit is a
variance, not a spectral gap.

**Proof.** Expand the right hand side and use $\sum_i\theta_i=-k\theta$ and
$\sum_i\theta_i^2=n(n-1)-k\theta^2$.

The identity was checked on every test graph of Section 4.4 and matched to at least ten decimal
digits in every case. This is the multiplicity analogue of a "deficit equals variance" statement.
The value face of the four dossiers has an analogous phenomenon, namely the tangle exponent
measures the deficit from the local limit threshold.

### 3.5 Theorem (equality is confined to $n\le d^2+1$)

Let $G$ be a connected $d$-regular graph on $n$ vertices with $d\ge2$ and let $\lambda\ne d$ be an
eigenvalue with multiplicity $k$ for which equality holds in Corollary 3.3. Then $A(G)$ has at most
three distinct eigenvalues and
$$n\,\le\,d^2+1,\qquad\text{hence}\qquad k\le d^2 .$$

**Proof.** Equality in Corollary 3.3 forces equality in Theorem 3.1 for $S=S(G)$, so $S$ has at
most two distinct eigenvalues. Write $M=(I+S)/2$. Then $M$ has at most two distinct eigenvalues and
$$A=\tfrac12 J-M .$$
So $A$ is a rank one perturbation of $-M$. By Weyl interlacing, $A$ has at most three distinct
eigenvalues. Since $G$ is connected and regular, $J$ lies in the algebra generated by $A$, and that
algebra is spanned by $\{I,A,A^2\}$ because the minimal polynomial has degree at most three. Hence
$A^2=aI+bA+cJ$ for real $a,b,c$. For distinct non-adjacent $i,j$ we get $(A^2)_{ij}=c$. If $G$ is
complete then $n=d+1\le d^2+1$. Otherwise $G$ is connected and not complete, so some pair is at
distance two, which forces $c\ge1$ because $(A^2)_{ij}$ is then the positive number of common
neighbours. Then every non-adjacent pair has exactly $c\ge1$ common neighbours, so the diameter is
at most two, and the Moore bound for a $d$-regular graph of diameter two gives
$n\le 1+d+d(d-1)=d^2+1$.

The Moore bound conclusion was also checked by enumeration: over all connected graphs with $n\le8$
vertices there are 18 graphs with exactly three distinct eigenvalues, all have diameter at most two
and none violates $n\le d^2+1$ (script `code/three_eig.py`).

Consequence. At fixed $d$ the equality case of the moment method is a finite problem with
$n\le d^2+1$. The moment method therefore cannot describe linear multiplicity in the fixed degree
regime. This is the precise obstruction of Section 5.2.

## 4. Exact computations

Every number in this section is produced by a script in `code/` and stored in `out/`. The four
scripts are `seidel_core.py`, `mult_bound.py`, `defect_count.py`, `fold_and_equi.py`, plus
`extremal_cubic.py`, `extremal_more.py`, `srg_families.py`, `three_eig.py`. All were run with
numpy 2.5.3 and sympy 1.14.0 in this VM.

### 4.1 Conference two-graphs: the $m=2d$ equality family

For a prime $q\equiv1\pmod 4$ define $S$ of order $q+1$ by $S_{0,i}=S_{i,0}=1$ and
$S_{i+1,j+1}=\chi(i-j)$, where $\chi$ is the Legendre symbol mod $q$. Then $S^2=qI$ exactly (an
integer identity, verified by integer matrix multiplication), so $S$ has eigenvalues
$\pm\sqrt q$ with multiplicities $(q+1)/2$ each.

| $q$ | $m=q+1$ | $\operatorname{tr}S^2$ | eigenvalue | multiplicity | rank of $I+\alpha S$, $\alpha=1/\sqrt q$ | relative bound |
| --- | --- | --- | --- | --- | --- | --- |
| 5 | 6 | 30 | $\pm2.2360679$ | 3 and 3 | 3 | $6$ |
| 13 | 14 | 182 | $\pm3.6055513$ | 7 and 7 | 7 | $14$ |
| 17 | 18 | 306 | $\pm4.1231056$ | 9 and 9 | 9 | $18$ |

In each row the relative bound evaluates to exactly $m$ and the multiplicity bound of Theorem 3.1
evaluates to exactly $m/2$. The equiangular systems reconstructed from the Gram matrices have unit
columns to $10^{-15}$ and all pairwise inner products equal to $\alpha$ to at most $10^{-10}$.
For $q=5$ this is the classical 6 lines in $\mathbb R^3$ at angle $1/\sqrt5$.

### 4.2 A non-conference equality family: the $4\times4$ rook graph

The rook graph $K_4\square K_4$ has $n=16$, is $6$-regular, and its Seidel matrix has exactly two
eigenvalues,
$$-5\ \text{with multiplicity }6,\qquad 3\ \text{with multiplicity }10 .$$
So $\alpha=1/5$, $d=10$, and $I+\alpha S$ has rank $10$ and gives **16 equiangular lines in
$\mathbb R^{10}$ at angle $\arccos(1/5)$**. The relative bound evaluates to $10(1-1/25)/(1-10/25)
=16$ exactly, so this is a second, non-conference equality case, and it confirms that equality
requires $m=2d$ only in the conference subcase. This example also shows that attaining the relative
bound is not the same as being optimal: OEIS A002853 records the maximum in $\mathbb R^{10}$ as 28.

The complete graph gives a third family. $S(K_{d+1})=I-J$ has eigenvalues $1$ (multiplicity $d$)
and $-d$ (multiplicity $1$), so Theorem 3.1 is an equality and the system is $d+1$ lines in
$\mathbb R^d$ at angle $1/d$. Verified for $d=4$ (5 lines in $\mathbb R^4$ at angle $1/4$).

### 4.3 Equality and near equality in the bound

For every graph tested, the multiplicity bound of Theorem 3.1 and its graph corollary 3.3 hold.
Exact equality in the **Seidel** bound was found for $K_n$ with $4\le n\le6$, for $K_{3,3}$, for
$K_{4,4}$, for the Petersen graph and for the $4\times4$ rook graph. Exact equality in the **graph**
corollary 3.3 was found for $K_n$ at $\lambda=-1$ with multiplicity $n-1$, for the Petersen graph at
$\lambda=1$ with multiplicity $5$, and for the rook graph at $\lambda=2$ with multiplicity $6$. The
two lists differ by exactly one where they differ: for $K_{3,3}$ the Seidel eigenvalue $-1$ has
multiplicity $5$ while the adjacency eigenvalue $0$ has multiplicity $4$, because the all-ones
vector lies in that Seidel eigenspace and Corollary 3.3 only sees $\mathbf 1^\perp$.

Strict inequality with positive slack, and with the eigenvalue not a two eigenvalue case: Heawood
(slack $28.10$), hypercube $Q_4$ (slack $230.4$, four distinct Seidel eigenvalues), $C_5\square C_5$
(slack $588.24$, six distinct Seidel eigenvalues), random cubic on 40 vertices (slack $1517.89$),
random 4-regular on 30 vertices (slack $812.71$).

### 4.4 The stability identity, machine checked

The identity of Theorem 3.4 was evaluated on $K_4$, $K_5$, $K_6$, $K_{3,3}$, $K_{4,4}$, Petersen,
Heawood, $Q_4$, $C_5\square C_5$, the $4\times4$ rook graph and two random regular graphs. In every
case the computed slack and the computed variance of the remaining Seidel eigenvalues agreed to
better than $10^{-8}$ in absolute value (most agreed to $10^{-11}$). The exact equality cases
($K_n$, $K_{3,3}$, $K_{4,4}$, Petersen, $Q_4$, rook) have slack $0$ and variance $0$.

### 4.5 The fold, machine checked

For a $d$-regular graph $G$ with $n$ vertices and $m$ edges let $B$ be the nonbacktracking matrix on
directed edges. The predicted multiset is
$$\Big\{\mu:\ \mu^2-\lambda\mu+(d-1)=0,\ \lambda\in\operatorname{spec}(A)\Big\}\ \cup\ \{+1\}^{m-n}\ \cup\ \{-1\}^{m-n}.$$
Matching the predicted and computed multisets by greedy nearest neighbour gave maximum deviation

| graph | $n$ | $m$ | $d$ | maximum deviation | $\sqrt{d-1}$ |
| --- | --- | --- | --- | --- | --- |
| $K_4$ | 4 | 6 | 3 | $1.3\times10^{-15}$ | 1.41421356 |
| $K_{3,3}$ | 6 | 9 | 3 | $2.9\times10^{-15}$ | 1.41421356 |
| Petersen | 10 | 15 | 3 | $2.4\times10^{-15}$ | 1.41421356 |
| Heawood | 14 | 21 | 3 | $4.7\times10^{-15}$ | 1.41421356 |
| random 3-regular | 40 | 60 | 3 | $8.8\times10^{-15}$ | 1.41421356 |
| random 4-regular | 30 | 60 | 4 | $7.5\times10^{-15}$ | 1.73205081 |

The critical non-real modulus of the fold is $\sqrt{d-1}$ in every row, which is the statement that
the Alon-Boppana constant is the fold value.

### 4.6 The defect count is unbounded: $K_4\square C_k$

**Proposition.** Let $R$ be a $d$-regular graph on $N$ vertices and let $k\ge3$. Then
$G=R\square C_k$ is $(d+2)$-regular on $Nk$ vertices and
$$\operatorname{spec}(G)=\Big\{\mu+2\cos\frac{2\pi j}{k}:\ \mu\in\operatorname{spec}(R),\
0\le j\le k-1\Big\}$$
with multiplicity. If $d\ge9$ then all $k$ eigenvalues $d+2\cos(2\pi j/k)$ coming from the Perron
eigenvalue of $R$ satisfy
$$d+2\cos\frac{2\pi j}{k}\ \ge\ d-2\ >\ 2\sqrt{d+1}\ =\ 2\sqrt{\deg G-1}.$$
Hence $G$ has at least $k=n/N$ eigenvalues strictly above the Alon-Boppana threshold of its own
degree.

The spectrum formula is the standard Cartesian product formula and was verified against numpy for
$R=$ Petersen and $k=4,7,12$ with maximum deviation at most $7.2\times10^{-15}$. The inequality
$d-2>2\sqrt{d+1}$ is equivalent to $d^2>8d$, that is $d>8$.

Numerical run with $R=K_4$ (so $d=3$, $\deg G=5$, threshold $4$):

| $k$ | $n=Nk$ | $\#\{i:\lambda_i>4\}$ | $\lambda_2$ | $d-\lambda_2=d-\lambda_3$ |
| --- | --- | --- | --- | --- |
| 5 | 20 | 1 | 3.61803399 | 1.38196601 |
| 10 | 40 | 3 | 4.61803399 | 0.38196601 |
| 20 | 80 | 7 | 4.90211303 | 0.09788697 |
| 40 | 160 | 13 | 4.97537668 | 0.02462332 |
| 80 | 320 | 27 | 4.99383467 | 0.00616533 |
| 160 | 640 | 53 | 4.99845807 | 0.00154193 |

In every row $\lambda_2=\lambda_3$ exactly, and the count grows like $k/3=n/12$. The last column
shows that $d-\lambda_3\to0$ while $\lambda_3$ stays strictly above the threshold. So $d-\lambda_3$
carries no independent information here, and the count of eigenvalues above the threshold is not
bounded by any function of $(d,\varepsilon)$.

### 4.7 Exact extremal second eigenvalue multiplicities

For connected $d$-regular graphs on $n$ vertices the maximum multiplicity of $\lambda_2$ was
computed by exhaustive enumeration with `nauty-geng`. Record holders were unique in every case.

Cubic graphs, all connected graphs with $4\le n\le18$:

| $n$ | number of graphs | max multiplicity of $\lambda_2$ | $\lambda_2$ | ratio |
| --- | --- | --- | --- | --- |
| 4 | 1 | 3 | $-1$ | 0.75 |
| 6 | 2 | 4 | 0 | 0.6667 |
| 8 | 5 | 3 | 1 | 0.375 |
| 10 | 19 | 5 | 1 | 0.5 |
| 12 | 85 | 3 | 2 | 0.25 |
| 14 | 509 | 6 | $\sqrt2$ | 0.4286 |
| 16 | 4060 | 4 | $\sqrt3$ | 0.25 |
| 18 | 41301 | 6 | $\sqrt3$ | 0.3333 |

The record holders are $K_4$, $K_{3,3}$, the cube $Q_3$, the Petersen graph, a 12 vertex graph with
spectrum $\{-2^3,-1^3,0^2,2^3,3\}$, the Heawood graph, a 16 vertex graph with spectrum
$\{-3,-\sqrt3^4,-1^3,1^3,\sqrt3^4,3\}$ and an 18 vertex graph with spectrum
$\{-3,-\sqrt3^6,0^4,\sqrt3^6,3\}$.

Quartic graphs, $6\le n\le14$: maximum multiplicities $3,6,4,4,3,6,4,6$ for
$n=6,8,9,10,11,12,13,14$. The holders at $n=6,8,9,14$ are the octahedron $K_{2,2,2}$ (spectrum
$\{4,0^3,(-2)^2\}$), $K_{4,4}$ (spectrum $\{4,0^6,-4\}$), the $3\times3$ rook graph (spectrum
$\{4,1^4,(-2)^4\}$) and a bipartite graph with spectrum $\{4,\sqrt2^6,(-\sqrt2)^6,-4\}$. All
spectra are recorded in `out/extremal_more.json`. Quintic graphs, $n=6,8,10,12$: maximum
multiplicities $5,2,8,6$, with $K_6$ (spectrum $\{5,(-1)^5\}$) at $n=6$ and $K_{5,5}$ (spectrum
$\{5,0^8,-5\}$) at $n=10$.

Two cautions about this table. First, the record holders at small $n$ are complete bipartite graphs
$K_{d,d}$, whose degree grows with $n$, so they do not contradict the fixed degree sublinear
theorems. Second, the record holders are all highly symmetric, which is exactly what the structured
equality analysis of Section 3.5 predicts.

### 4.8 Degree against multiplicity in the structured families

| family | $n$ | degree | $\lambda_2$ | multiplicity | ratio |
| --- | --- | --- | --- | --- | --- |
| Paley(13) | 13 | 6 | 1.30277564 | 6 | 0.4615 |
| Paley(29) | 29 | 14 | 2.1925824 | 14 | 0.4828 |
| Paley(41) | 41 | 20 | 2.70156212 | 20 | 0.4878 |
| Rook(4) | 16 | 6 | 2 | 6 | 0.375 |
| Rook(8) | 64 | 14 | 6 | 14 | 0.2188 |
| $Q_4$ | 16 | 4 | 2 | 4 | 0.25 |
| $Q_5$ | 32 | 5 | 3 | 5 | 0.1562 |

The Paley graphs have $\lambda_2=(-1+\sqrt q)/2$ with multiplicity $(q-1)/2$, so their ratio tends
to $1/2$ while the degree grows like $n/2$. The rook graph $K_m\square K_m$ has $\lambda_2=m-2$ with
multiplicity $2(m-1)$ and $n=m^2$, so the multiplicity is $2\sqrt n-2$ with degree $2\sqrt n-2$. The
hypercube $Q_r$ has $\lambda_2=r-2$ with multiplicity $r$. In all three structured families a linear
multiplicity costs a linear degree, which is the content of Section 3.5 in examples.

## 5. The two mechanisms, and the two obstructions

### 5.1 Mechanism V, the value mechanism of the four dossiers

All four sources have the same three ingredients.

(V1) **An operator on an infinite local limit whose norm is the threshold.** The $d$-regular tree
gives $2\sqrt{d-1}$, the $(d_1,d_2)$-biregular tree gives $\sqrt{d_1-1}+\sqrt{d_2-1}$, and a
random lift of a base $B$ gives $\sqrt{\rho_1}$ with $\rho_1$ the Perron eigenvalue of the base
nonbacktracking matrix.

(V2) **An exact transfer between the two natural normalisations.** For graphs this is the
Ihara-Bass fold $\mu^2-\lambda\mu+(d-1)=0$, verified in Section 4.5. For biregular graphs it is the
quartic of Section 1.1. The transfer is exact, not asymptotic.

(V3) **Rare defect control.** A finite subgraph $\psi$ has order $\operatorname{ord}(\psi)=-\chi(\psi)$
and the expected number of copies in the random model is $n^{-\operatorname{ord}(\psi)+O(1)}$.
Tangled subgraphs above the critical nonbacktracking radius force spectral outliers, and the
tangle-free stratum restores the trace expansion. The output is a bound on the *value* of $\lambda_2$
or on the new spectrum, with an explicit polynomial exceptional probability.

The mechanism is about a single eigenvalue. It has nothing to say about how many eigenvalues sit
near the threshold, and Section 5.3 shows that it cannot have anything to say, because the answer
in that direction is not a function of $(d,\varepsilon)$.

### 5.2 Obstruction O1, the moment mechanism is blind at fixed degree

**Theorem.** Let $G$ be a connected $d$-regular graph with $d\ge3$ and let $\lambda\ne d$ be an
eigenvalue with multiplicity $k$. Then
$$k\,\le\,\frac{n(n-1)}{n-1+(1+2\lambda)^2}\,\le\,n\Big(1-\frac{(1+2\lambda)^2}{n-1+(1+2\lambda)^2}\Big).$$
In particular, for fixed $d$ and $\lambda=O(d)$ the right hand side is $n(1-o(1))$. Moreover, if
equality holds then $n\le d^2+1$.

**Proof.** The first inequality is Corollary 3.3 and the second is algebra. The equality statement
is Theorem 3.5.

So the rank and moment mechanism of Sections 3.1 to 3.5 gives a linear bound at fixed degree and
its exact extremal family lives only at $n\le d^2+1$. Note where the weakness comes from: the two
inputs $\operatorname{tr}S=0$ and $\operatorname{tr}S^2=n(n-1)$ hold **identically for every graph**
and carry no information about the graph. Theorem 3.1 is the strongest one-eigenvalue consequence of
those two identities, and at fixed degree it is $n(1-o(1))$. Any proof of
$\mathrm{mult}(\lambda_2)\le n^{1-\delta}$ for $d$-regular graphs therefore has to use information
beyond the first two moments of the Seidel matrix. This is not a defect of one calculation. It is a
feature of the method, and it is the precise sense in which the two-graph and equiangular world and
the fixed degree multiplicity frontier are disjoint.

This is the analogue, on the multiplicity face, of the observation in the Friedman dossier that
ordinary traces fail and that selective traces are needed: the naive moment object is provably
inadequate, and the reason can be isolated exactly.

### 5.3 Obstruction O2, no defect count bound in $(d,\varepsilon)$

Proposition 4.6 gives, for every $d\ge9$ and every $k\ge3$, a $(d+2)$-regular graph on $(d+1)k$
vertices with at least $k=n/(d+1)$ eigenvalues above $2\sqrt{d+1}$. With a fixed margin $\varepsilon$
the same count holds whenever $0<\varepsilon\le d-2-2\sqrt{d+1}$, because then every eigenvalue
$d+2\cos(2\pi j/k)$ from the Perron block is at least $2\sqrt{d+1}+\varepsilon$. So the count
$$\mathrm{def}(G,\varepsilon)\,=\,\#\{i\ge2:\ \lambda_i(G)\ \ge\ 2\sqrt{\deg G-1}+\varepsilon\}$$
satisfies $\mathrm{def}\ge n/(d+1)$ for those $d$ and $\varepsilon$, with an explicit constant
depending only on the degree.

Therefore no inequality of the form $\mathrm{def}(G,\varepsilon)\le C(d,\varepsilon)$ can hold, and
no inequality of the form $\mathrm{def}(G,\varepsilon)\le n^{1-\delta}$ with $\delta=\delta(d,\varepsilon)>0$
can hold either. Any statement about "how many eigenvalues are beyond the threshold" must be either
a statement about a *window* whose width shrinks with $n$, or a statement about a *single*
eigenvalue, or a statement that counts a specific combinatorial structure.

The $K_4\square C_k$ table in Section 4.6 makes the failure quantitative: $\lambda_2=\lambda_3$ for
every $k$, so $d-\lambda_3=d-\lambda_2$ identically, and $d-\lambda_3\to0$ while $\lambda_3$ stays
above the threshold.

### 5.4 Mechanism M, walk support in the fixed degree regime

The mechanism that does work at fixed degree is not a moment inequality. It is a lower bound on the
support of a closed random walk, which converts information about $\mathrm{tr}(A^{2k})$ into an
upper bound on the multiplicity of a single eigenvalue. The two verified statements are:

(M1) **JTYZZ.** Every connected $n$-vertex graph with maximum degree $\Delta$ has second adjacency
eigenvalue multiplicity $O_\Delta(n/\log\log n)$. Source: Section 2.7.

(M2) **MRS.** The multiplicity of the second eigenvalue of the normalized adjacency matrix of a
connected graph of maximum degree $\Delta$ is $O(n\Delta^{7/5}/\log^{1/5-o(1)}n)$, and
$O(n\log^{1/2}d/\log^{1/4-o(1)}n)$ for simple $d$-regular graphs when $d\ge\log^{1/4}n$. The same
bounds hold for the number of eigenvalues in any interval of width
$\lambda_2/\log_\Delta^{1-o(1)}n$ containing $\lambda_2$. Source: Section 2.8.

(M3) **The barrier.** Haiman, Schildkraut, Zhang and Zhao construct graphs with
$\Theta(n/\log\log n)$ eigenvalues within $O(1/\log n)$ of the second eigenvalue, so any method
that only bounds the approximate multiplicity cannot prove a sublinear bound better than
$n/\log\log n$. Source: Section 2.8.

### 5.5 The resulting picture, and where the "d - lambda_3" question actually lives

| quantity | regime | answer | source |
| --- | --- | --- | --- |
| $\lambda_2$ versus $2\sqrt{d-1}$ | fixed $d$, $n\to\infty$ | sharp threshold, exact fold | the four dossiers, Section 4.5 |
| multiplicity of one eigenvalue $\lambda_2$ | fixed $d$ | between $\sqrt{n/\log n}$ and $O(n/\log\log n)$ | Sections 2.7, 2.8 |
| count in a window of width $O(1/\log n)$ around $\lambda_2$ | fixed $d$ | $\Theta(n/\log\log n)$ | Haiman, Schildkraut, Zhang, Zhao |
| count above $2\sqrt{d-1}+\varepsilon$, $\varepsilon$ fixed | fixed $d$ | $\Theta(n)$, no bound in $(d,\varepsilon)$ | Proposition 4.6 |
| multiplicity of one eigenvalue at degree $\Theta(n)$ | $d\to\infty$ | exactly bounded, equality at two-graphs | Theorems 3.1, 3.5 and Section 4 |

So $d-\lambda_3$ and $d-\lambda_4$ are not invariant statements about expansion. They coincide with
$d-\lambda_2$ whenever $\lambda_2$ has multiplicity at least two, and the multiplicity of a single
eigenvalue is a genuinely different quantity from the count of eigenvalues beyond a level. The
useful reformulation for the user's question is:

- If the question is "how large can $\lambda_2$ be", the four dossiers answer it.
- If the question is "how often can $\lambda_3$ equal $\lambda_2$", the answer is governed by the
  multiplicity of $\lambda_2$, whose exact structured extremal family is the two-graph family of
  Section 3 and whose fixed degree theory is the JTYZZ, MRS and Haiman et al. frontier.
- If the question is "how many eigenvalues lie beyond the threshold", the answer is $\Theta(n)$ and
  there is no threshold statement at all.

## 6. Theorem targets, with hypotheses and the hardest missing estimate

### 6.1 Target T1, exact and feasible now

**Hypothesis.** Connected cubic graphs on $n$ vertices, $n\le20$, and connected quartic graphs on
$n\le15$.

**Statement to establish.** Extend the exact table of Section 4.7 and decide whether every record
holder is vertex-transitive. Conjecture, supported by all rows with $n\le18$: every record holder
is vertex-transitive, and for cubic graphs the record multiplicities are exactly the largest
$d_\rho^2$ type sums arising from a group action.

**Strategy.** `nauty-geng` enumeration (already used), then a vertex-transitivity test, then
identification against the census of small vertex-transitive graphs. The cubic case $n=20$ has
510489 connected graphs, which is about ten minutes of compute at the observed rate.

**Why it matters.** If the conjecture holds, the extremal fixed degree examples are exactly the
symmetric ones, which points at representation theory as the right tool for T2.

### 6.2 Target T2, the real open problem

**Hypothesis.** $d\ge3$ fixed, $G$ connected $d$-regular on $n$ vertices, $m_d(n)$ the maximum
multiplicity of $\lambda_2(G)$.

**Statement to establish.** Determine the order of $m_d(n)$. Known: $m_d(n)\ge n^{2/5}-1$ for
infinitely many $n$ (Haiman, Schildkraut, Zhang, Zhao, Cayley graphs) and
$m_d(n)\le O(n/\log\log n)$ (JTYZZ), with the regular case improved by MRS.

**A concrete reduction that is missing from the literature as far as this search went.** Take $G$ to
be a *normal* Cayley graph: $G=\mathrm{Cay}(\Gamma,S)$ with $\Gamma$ finite and $S$ a union of
conjugacy classes, $|S|=d$. By Schur's lemma each irreducible representation $\rho$ acts on its
$d_\rho$-dimensional space by the scalar $\chi_\rho(S)/d_\rho$, so
$$\operatorname{spec}(A)=\Big\{\frac{\chi_\rho(S)}{d_\rho}:\ \rho\in\operatorname{Irr}(\Gamma)\Big\}$$
with multiplicity $d_\rho^2$ attached to $\rho$. Hence for a normal Cayley graph the multiplicity of
any eigenvalue is a **Plancherel mass**,
$$\operatorname{mult}(\lambda)=\sum_{\rho:\ \chi_\rho(S)/d_\rho=\lambda} d_\rho^2 ,$$
and the fixed degree multiplicity problem becomes a *character ratio* problem: bound the Plancherel
mass of the set of irreducibles whose normalized character at $S$ takes a prescribed value.

**Strategy.** (a) Verify the identity exactly on small groups and on the known extremal families.
(b) For $\Gamma=\mathrm{PSL}(2,q)$ and $S$ a union of a bounded number of conjugacy classes,
compute the character ratios by Deligne-Lusztig theory and estimate the Plancherel mass at the
second largest value. (c) Convert a lower bound on that mass into a lower bound on $m_d(n)$.

**The single hardest missing estimate.** A bound of the form
$$\sum_{\rho\in\mathrm{Irr}(\Gamma):\ \chi_\rho(S)/d_\rho\ \ge\ \lambda}\, d_\rho^2\ \le\ |\Gamma|^{1-\delta}$$
for a fixed symmetric class sum $S$ and $\lambda$ equal to the second largest character ratio. This
is a *dimension weighted* character estimate. It is genuinely hard because the Plancherel mass of a
single block is $d_\rho^2/|\Gamma|$, because many inequivalent $\rho$ can share a character ratio,
and because for groups of Lie type the number of irreducibles with a given ratio can grow with the
group. A bound of the form $|\Gamma|^{1-\delta}$ therefore needs an equidistribution or separation
statement for the ratios $\chi_\rho(S)/d_\rho$, not merely a dimension count. For
$\mathrm{PSL}(2,q)$ the Steinberg representation already has dimension $q$ out of $|\Gamma|$ of
order $q^3$, so a mass estimate has to use cancellation in $\chi_\rho(S)$.

**Fatal obstruction to watch for.** If the extremal configurations really are normal Cayley graphs,
then the multiplicity is a union of full representation blocks and is therefore either $1$ or at
least the square of the smallest nontrivial degree. For groups of Lie type that smallest degree
grows, which caps the achievable multiplicity density at $|\Gamma|^{-1+o(1)}$ in the worst case.
This suggests, but does not prove, that normal Cayley graphs cannot reach $n/\log\log n$ and that
non-normal connection sets are essential. That would explain why the known constructions use
random or non-normal sets.

### 6.3 Target T3, an exact strengthening of the Seidel bound

**Hypothesis.** $S$ a Seidel matrix of order $n$ with eigenvalue $\theta$ of multiplicity $k$.

**Statement to establish.** A three moment bound using $\operatorname{tr}S^3=6\sum_{i<j<l}
S_{ij}S_{jl}S_{li}$, which is six times the signed triangle count. Such a bound would refine
Theorem 3.1 by the two-graph's triangle structure and would give a multiplicity bound that is not
determined by $(\theta,k,n)$ alone.

**Strategy.** Maximize $k$ subject to fixed $\operatorname{tr}S=0$, $\operatorname{tr}S^2=n(n-1)$,
$\operatorname{tr}S^3=6t$ and $\operatorname{tr}S^4$ bounded by the combinatorial count of closed
walks of length four. This is a finite moment problem with four constraints, solvable by the same
Cauchy-Schwarz step plus a correction term. The hardest part is the fourth moment, which depends on
the number of four cycles in the two-graph.

**Why this is worth doing.** It would show that the equiangular multiplicity bound is not the end of
the exact story: two Seidel matrices with the same order and the same extreme multiplicity can be
separated by their triangle structure. This is the natural next exact question after Section 3.

## 7. Unresolved steps, and what evidence would decide them

1. **Is the fixed degree extremal multiplicity attained by symmetric graphs?** Decided by T1 for
   cubic $n\le20$. If a non-vertex-transitive record holder appears, the representation-theoretic
   route of T2 needs replacing.
2. **Is the truth for $m_d(n)$ closer to $\sqrt n$ or to $n/\log\log n$?** Decided by either a new
   construction above $n^{1/2}$ or a new upper bound below $n/\log\log n$ that survives the
   Haiman-Schildkraut-Zhang-Zhao barrier. Note that the barrier is about windows of width
   $O(1/\log n)$, so a proof for a single eigenvalue is not excluded by it.
3. **Do non-conference equality cases of the relative bound exist beyond the rook graph?** Decided
   by tabulating regular two-graphs of order 16, 26, 28, 30, 36 and checking which have unequal
   multiplicities. This is finite and mechanical.
4. **Is the count above a fixed threshold extremal for products with cycles?** Decided by an upper
   bound, which is genuinely open. The exact data in Section 4.6 only give the lower bound.
5. **Can Theorem 3.1 be strengthened with the third moment?** Decided by T3. A negative answer would
   itself be informative, since it would show that the Seidel multiplicity bound is best possible for
   every moment order that does not see the two-graph's cycle structure.

## 8. Prioritized next steps

1. Run T1. Cost: one `nauty-geng` pass at $n=20$ for cubic and $n=15$ for quartic. Payoff: a clean
   exact table for the fixed degree frontier at small $n$.
2. Tabulate all regular two-graphs of order $m\le36$ from the classical tables and compute
   $(m,d,\alpha)$ for each. Payoff: a complete list of relative bound equality cases. Classical
   tables exist, so this is a reading and verification task.
3. Prove or disprove the conjecture that equality in Theorem 3.1 for a graph implies vertex
   transitivity. The proof of Theorem 3.5 already reduces it to strongly regular graphs of diameter
   two with a rank-one relation.
4. Compute $\operatorname{tr}S^3$ for the equality families to see whether the third moment is
   constant on them. If it is, T3 is dead in the form stated.
5. Test the normal Cayley reduction on $\mathrm{PSL}(2,q)$ for small $q$ by exact character tables,
   and measure the Plancherel mass at the second character ratio. Payoff: either a new construction
   or evidence that normal sets are too rigid.
6. For random cubic graphs at $n=1000$, measure the number of eigenvalues within $O(1/\log n)$ of
   $\lambda_2$ and compare with the Haiman et al. tight example.
7. If a formal check is wanted, state Theorem 3.1 and Theorem 3.5 in Lean 4 with Mathlib. Neither
   was formalised here, and no formal verification is claimed.

## 9. Common ground with the four dossiers, and with other swarm directions

**With `alon-second-eigenvalue` (Friedman).** The tree completion threshold of Friedman's Theorem
3.13 says $\lambda_1(\operatorname{Tree}_d(\psi))>2\sqrt{d-1}$ if and only if
$\lambda_{\mathrm{Irred}}(\psi)>\sqrt{d-1}$. That is the value face version of the fold of Section
1.1, with the nonbacktracking radius $\sqrt{d-1}$ as the critical level. The multiplicity face has no
analogue of tree completion, which is exactly Obstruction O2.

**With `biregular-spectral-gap`.** The biregular quartic is the two degree fold. The biregular tree
is also the natural test object for the hypergraph incidence operator, so this dossier's
$(\sqrt{d_1-1}+\sqrt{d_2-1})$ threshold is the value side of the hypergraph nonbacktracking
question, while the multiplicity side is the rank of the incidence matrix. The biregular source's
full rank conclusion (rank $X=n$ with high probability) is a statement about *zero* multiplicity,
which is the one multiplicity statement that source makes.

**With `friedman-second-eigenvalue-lifts` (Bordenave).** The lift threshold $\sqrt{\rho_1}$ with
$\rho_1$ the base nonbacktracking Perron value is the general value face statement. The
corresponding multiplicity statement is not available, and the reason is the same: the proof is a
trace and support argument about one eigenvalue.

**With `relativized-second-eigenvalue` (Friedman and Kohler).** The exceptional probability
$n^{-\eta_{\mathrm{fund}}(B)}$ is a *count* statement: it counts copies of the least strict tangle.
It is a precedent for the kind of statement that the multiplicity face needs, namely a count of a
combinatorial structure rather than a scalar threshold. The difference is that tangles are rare
subgraphs, while the cylindrical defects of Proposition 4.6 are not rare and are not local.

**With direction d1 (hypergraph gap normalisation).** Both directions find that the Perron value
and the naive gap are the wrong object. The present dossier adds the complementary statement that
even after the correct normalisation is chosen, the *multiplicity* face and the *value* face need
different mechanisms.

**With direction d2 (band edge sampling in periodic quotients).** Cartesian products with cycles
are exactly periodic quotients of a lattice, so Proposition 4.6 is a lattice example. It shows that
the band edge of a periodic quotient can have constant fraction of the spectrum above the bulk
threshold of the degree, which is a sharp counterpoint to the band edge sampling defect.

**With directions d5 and d7 (Cayley graphs).** The normal Cayley reduction of Section 6.2 is the
multiplicity face of the Cayley question. A Cayley graph's multiplicities are $d_\rho^2$ blocks, so
the "spectrum beyond $\lambda_2$" question is exactly a Plancherel mass question.

**With direction d3 (almost regular spikes), d4 (covers) and d6 (directed).** The value face
mechanisms of those directions all sit on the same fold. The multiplicity face statements of this
dossier are separate from all three, and Section 5.5 gives the three regime table that locates them.

## 10. Evidence ledger

Category (1) checked literature statement, (2) exact calculation, (3) proof supplied here,
(4) numerical experiment, (5) conjecture or speculation.

- (1) Friedman \(cs/0405020v1\), Bordenave \(1502.04482v4\), Friedman-Kohler \(1403.3462v1\),
  Brito-Dumitriu-Decker Harris \(1804.07808v6\), with the exact statements of Section 2.1.
- (1) van Lint-Seidel relative bound, Greaves Lemma 1.8 and Theorem 1.9, and the equality statement.
- (1) OEIS A002853 values for $d\le16$.
- (1) Jiang-Tidor-Yao-Zhang-Zhao fixed angle theorem and its sublinear multiplicity ingredient.
- (1) JTYZZ $O(n/\log\log n)$, MRS bounds, Haiman-Schildkraut-Zhang-Zhao lower bounds and barrier.
- (2) The conference table of Section 4.1, the rook graph spectrum of Section 4.2, the exact spectra
  in Section 4.6 and Section 4.7, the degree against multiplicity table of Section 4.8, and the
  fold deviations of Section 4.5.
- (3) Theorem 3.1, Corollary 3.2, Corollary 3.3, Theorem 3.4, Theorem 3.5 and Proposition 4.6. All
  are elementary and are proved in place. None is claimed as new in substance, with the exception of
  the explicit statement of Theorem 3.5 and the use of Proposition 4.6 as an obstruction to a
  multiplicity defect count.
- (4) The stability identity checks, the fold checks, the Cartesian product spectrum checks, the
  nauty enumeration of Section 4.7 and the three eigenvalue diameter check.
- (5) The conjecture of Section 6.1 that record holders are vertex-transitive. The speculation of
  Section 6.2 that non-normal connection sets are needed for high multiplicity. The conjecture of
  Section 7 item 4 that products with cycles are extremal for the fixed threshold count.

No claim in this dossier is a formal verification. No Lean or other proof assistant was run.
