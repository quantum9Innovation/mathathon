"""Figures: (left) where lambda_2 of random (d,k)-regular hypergraphs sits relative to the
two candidate thresholds, (right) the Theta(1/n^2) gap of the cyclic interval hypergraph."""
import json
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from hyp import cyclic_interval_hypergraph, fengli, spec

rows = json.load(open("../outputs/exp2_random_regular.json")) + json.load(
    open("../outputs/exp2b_random_regular.json"))

fig, ax = plt.subplots(1, 2, figsize=(11.5, 4.3))

groups = {}
for r in rows:
    groups.setdefault((r["d"], r["k"]), []).append(r)
styles = ["o-", "s-", "^-", "v-", "D-", "P-"]
for (key, rs), st in zip(sorted(groups.items()), styles):
    rs = sorted(rs, key=lambda r: r["n"])
    ns = np.array([r["n"] for r in rs], float)
    l2 = np.array([r["lam2_mean"] for r in rs])
    te = rs[0]["true_edge"]
    nv = rs[0]["naive"]
    ax[0].plot(ns, l2, st, label=f"$(d,k)=({key[0]},{key[1]})$, measured $\\lambda_2$", ms=5)
    ax[0].axhline(te, color="k", lw=1.0, ls="--")
    ax[0].axhline(nv, color="k", lw=1.0, ls=":")
    ax[0].annotate("", xy=(ns.max() * 1.02, te), xytext=(ns.max() * 1.02, nv),
                   arrowprops=dict(arrowstyle="<->", color="k", lw=0.8))
    ax[0].text(ns.max() * 0.30, (te + nv) / 2, f"$({key[0]},{key[1]})$: naive to true", fontsize=6.5)
ax[0].set_xscale("log")
ax[0].set_xlabel("number of vertices $n$")
ax[0].set_ylabel("second largest Feng-Li eigenvalue $\\lambda_2$")
ax[0].set_title("random $(d,k)$-regular hypergraphs:\nmeasured $\\lambda_2$ vs true edge (--) and naive tree bound (:)", fontsize=9)
ax[0].legend(fontsize=6.5, loc="lower right")
ax[0].grid(alpha=0.3)

for k in (3, 4, 5, 6):
    qs = np.array([60, 120, 240, 480], float)
    gaps = []
    for q in qs.astype(int):
        E, n = cyclic_interval_hypergraph(q, k)
        A, _ = fengli(E, n)
        w = spec(A)
        gaps.append(k * (k - 1) - w[1])
    gaps = np.array(gaps)
    coef = np.pi ** 2 * k ** 2 * (k ** 2 - 1) / 3
    ax[1].plot(1 / qs ** 2, gaps, "o-", label=f"$k={k}$")
    ax[1].plot(1 / qs ** 2, coef / qs ** 2, "k--", lw=0.8)
ax[1].set_xscale("log")
ax[1].set_yscale("log")
ax[1].set_xlabel("$1/q^2$")
ax[1].set_ylabel("$d(k-1)-\\lambda_2$ for the $q$-cyclic interval hypergraph")
ax[1].set_title("periodic family: gap $\\asymp \\pi^2k^2(k^2-1)/(3q^2)$\n(dashed: leading term only)", fontsize=9)
ax[1].legend(fontsize=7)
ax[1].grid(alpha=0.3, which="both")

plt.tight_layout()
plt.savefig("../outputs/fig1_thresholds_and_periodic_gap.png", dpi=160)
print("wrote ../outputs/fig1_thresholds_and_periodic_gap.png")
