# Erratum 2 (batch 060, m1/direction 4): the `T=N(c)` block-inverse diagonal

**Affected statements (both wrong in the same way):**

1. `results/060-clustered-attachment-target.md`, section "Neighbourhood of one centre":
   > the explicit block inverse has diagonal $G_d+r^2/(\lambda-dr)$ and every
   > off-diagonal entry $r^2/(\lambda-dr)$, wherever that expression is nonsingular.
2. frozen input `.ultramath/smwgwbyn9/m6/THEOREM.md`, §4.1(b):
   > `G_{ℓℓ} = r(λ - Δ r + r)/(λ - Δ r)`, `G_{ℓℓ'} = r²/(λ - Δ r)` [...] `= G_d(z)(Δ + Δ(Δ−1)r²)`

   (the closed forms on the right are **correct**; the displayed diagonal is not
   consistent with them).

Neither file is edited. This is an auxiliary-formula defect only: every theorem statement
that uses the **sum** or the closed form `Δ λ r/(λ-Δr)` is unaffected.

## Correct statement

Eliminating the `Δ` half-trees at each leaf and then the centre (Sherman–Morrison on
`(1/r)I − (1/λ)11^T`), with `λ=(d−1)r+1/r`, on the physical branch `0<r<1/√(d−1)`:

$$G_{\ell\ell}=r+\frac{r^2}{\lambda-\Delta r}
=\frac{r(\lambda-\Delta r+r)}{\lambda-\Delta r},\qquad
G_{\ell\ell'}=\frac{r^2}{\lambda-\Delta r}\ (\ell\ne\ell'),$$

$$\sum_{s,t\in N(c)}G_{st}=\Delta G_{\ell\ell}+\Delta(\Delta-1)G_{\ell\ell'}
=\frac{\Delta\lambda r}{\lambda-\Delta r}=G_d\big[\Delta+\Delta(\Delta-1)r^2\big].$$

Verified exactly for `Δ=3,4,5,6` against the explicit matrix inverse
(`scripts/verify_symbolic.py` §F, `out/verify_symbolic.txt`).

**With `Δ = d` the diagonal is exactly `G_d`**, by transitivity of the `d`-regular tree:
`λ − d r = (1−r²)/r` gives `r + r²/(λ-dr) = r + r³/(1−r²) = r/(1−r²) = G_d`.
The printed `G_d + r²/(λ-dr)` equals `G_d + r³/(1−r²) = G_d(1+r²) ≠ G_d`.

## Numerical inconsistency (this is how the slip shows)

`d=3`, `λ=3.2`: `r = 0.425834`, `G_d = 0.520160`, `r²/(λ-3r) = 0.094320`.

| quantity | correct | as printed |
|---|---|---|
| diagonal `G_{ℓℓ}` | `0.520160` | `0.614480` |
| ordered-pair sum | `3(0.520160)+6(0.094320) = 2.12637` | `3(0.614480)+6(0.094320) = 2.40936` |

The same document's closed form is `dλr/(λ-dr) = 2.12637`, so the two displayed formulas
in the target cannot both hold; the diagonal is the wrong one. Direct numerical
measurement at `d=3, n=8000, λ=3.2` gives `2.1306` (`out/numerics_all.txt`), i.e. the
correct value plus the known `Δ²/(n(λ-d))` Perron term.

## Provenance

Found by m1 (this file). The off-diagonal entry and both closed forms are confirmed
correct, so no downstream formula changes; the fix is to replace the diagonal by
`r + r²/(\lambda-\Delta r)` (or, for `Δ=d`, by `G_d`).
