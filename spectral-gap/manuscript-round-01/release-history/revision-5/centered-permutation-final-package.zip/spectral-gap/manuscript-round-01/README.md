# Centered permutation products

Problem 21 is selected for this conversation. This round delivers a direct proof of the requested matching-product estimate, two asymptotic transitions for diagonal moments, and a clear explanation of their role in spectral-gap arguments.

## Reading copies

- [Mathematical manuscript](output/pdf/centered-permutation-products.pdf).
- [Five-page illustrated reading guide](output/pdf/reading-guide.pdf).
- [Updated priority and citation audit](presubmission-01/PRIORITY_AUDIT_V2.md).
- [Submission-readiness note](presubmission-01/SUBMISSION_READINESS.md).
- [Current claim ledger](../CLAIM_LEDGER.md).

The mixed bound has exact factorial correction F_n(a-h) and the optimal universal prefactor sqrt(e). The original diagonal leading term is relatively accurate exactly when k^3/N tends to zero. The parity-dependent hyperbolic approximation remains relatively accurate through k=o(sqrt N). At k^2/N tending to d, its multiplicative correction is exp(d/4). Including that correction gives uniform relative accuracy for bounded k/sqrt N.

The known recurrence, normalized parity recurrences, leading terms, mixed estimate and classical Laguerre identity remain credited to their sources. The elementary raw factorial bound yielding sqrt(e) is also explicitly credited to Bordenave and Zhu. A bounded primary-source search found no exact duplicate of the refined full mixed bound or diagonal transition statements. This is not an exhaustive historical-priority certificate or a new graph spectral-gap theorem.

## Proof and review records

- [Run contract](RUN_CONTRACT.md) and [owned coordinator board](TEAM_BOARD.md).
- [Frozen starting inputs](inputs/MANIFEST.json).
- [Fresh core audit](proof/core-audit-v1.md), [sharpened mixed proof](proof/permutation-proof-v3.md), and [independent reconstruction](reviews/mixed-v3-integrator-review.md).
- [Wider-window and boundary proof](extensions/hyperbolic-window-v1.md), [independent extension review](reviews/extension-review-v1.md), and their finite-check records.
- [Fresh assembled-manuscript referee report](reviews/manuscript-referee-v1.md) and [final acceptance of revision 4](reviews/manuscript-referee-v4.md).
- [Source map](priority/SOURCE_MAP.md), [search log](priority/SEARCH_LOG.md) and [verified bibliography](priority/references.bib).
- [Published Bordenave comparison](presubmission-01/BORDENAVE_JOURNAL_CHECK.md), [independent source review](presubmission-01/INDEPENDENT_SOURCE_REVIEW.md), [additional search log](presubmission-01/SEARCH_LOG.md) and [expanded bibliography](presubmission-01/references-v2.bib).
- [Verification and acceptance record](VERIFICATION.md) and [continuation handoff](HANDOFF.md).

Frozen sources remain unchanged after review. Revision 4 preserves the completed theorem-chain review. The maintained manuscript and guide match [frozen revision 5](frozen-manuscript-v5/MANIFEST.json), incorporating the journal source check, precise priority additions and the abstract clarification. The [revision-5 review](reviews/manuscript-referee-v5.md) assesses this specific delta. Acceptance is tied to exact hashes, not agreement counts.

## Rebuild

Requirements: Python 3 with matplotlib, numpy and mpmath, plus a standard LaTeX installation with pdflatex, Latin Modern and the packages named in the source preambles. Poppler supplies optional page rendering. The current build uses the installed toolchain and requires no network access.

From this directory run:

```bash
python3 build_artifacts.py
```

The script regenerates the scientific figures and their data, compiles both documents three times, rejects unresolved references or overflowing text, and writes the two PDFs under output/pdf. It does not run the mathematical checks automatically.

The separate checks are:

```bash
python3 proof/check_core.py
python3 extensions/check_extension.py
python3 reviews/extension-review-checks.py
```

They use their own directory paths. Exact arithmetic checks establish only the recorded finite identities. High-precision calculations and figures corroborate examples, while the general claims rest on the written proofs.

To check the supplied frozen package, run `python3 checks/verify_package.py` before rebuilding. Rebuilt PDF timestamps can change byte hashes. The portable release check distinguishes byte integrity from identical content: `python3 checks/verify_release.py path/to/centered-permutation-final-package.zip` extracts a fresh copy, verifies its included files and links, replays four recorded check programs, rebuilds both PDFs, and compares their text and every rendered page with revision 5. It also compares plot data and images. The receipt is saved outside the tested archive in `checks/release-verification.json`.

The [release assembler](package_release.py) uses an explicit file selection and a portable project index. It includes all build and check inputs, while downloaded third-party papers and the separate historical import remain outside the archive.

The imported snapshot and the concurrent problem 138 work remain separately owned. No registration, publication, competition submission, or external message was performed in this round.
