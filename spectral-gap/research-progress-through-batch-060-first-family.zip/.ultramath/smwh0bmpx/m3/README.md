# m3 / swarm `smwh0bmpx` — direction 2: full-neighbourhood clustered secular law

Family: $T_n=N_{G_n}(c)$ (all $d$ neighbours of a fixed label $c$) in a uniform simple
$d$-regular graph, one new vertex adjacent to all of $T_n$.

## Files

| file | content |
|---|---|
| `secular-law-Nc.md` | the full proof: exact kernel, pole audit, resolvent limit, complete root law, eigenvalue assignment, critical degree $d=3$, finite-size laws, scope |
| `erratum-050-scaled-rate.md` | separate erratum: the $O(\log n/n)$ rate claim of `m2` Theorem C is not established (its $1/n$ *limit* survives) |
| `checks/sym_kernel.py` | sympy: three kernel forms, secular polynomial, roots, $\Phi'(\lambda_*)$, endpoint values (`checks/out/sym_kernel.txt`) |
| `checks/exact_small.py` | exact rationals: reduced tree inverse, truncated balls $R\le5$, secular identity on six small graphs, spectra (`checks/out/exact_small.txt`, `.json`) |
| `checks/numeric_gprime.py` | pairing-model sampler (uniform after conditioning) + eigensolver/bisection comparisons; one JSON line per $(d,n,\text{seed})$ |
| `checks/out/numeric.jsonl` | raw output, seeds 11/12/13/21 |
| `checks/diag_d5.py` | diagnostic for the bisection bracket |

## Headline results (all proved in `secular-law-Nc.md`)

* Kernel: $\mathbf1_T^\top(\lambda-A_{T_d})^{-1}\mathbf1_T
  =G_d[d+d(d-1)r^2]=\dfrac{d\lambda r}{\lambda-dr}=dr+\dfrac{d^2r^2}{\lambda-dr}$,
  identical on the physical branch; $\lambda-dr=(1-r^2)/r$ never vanishes there.
* Resolvent limit, Perron term kept: $\frac{d^2}{n(d-\lambda)}-K_{N(c)}(\lambda)$,
  uniform on compacts of $(2\sqrt{d-1},d)\cup(d,\infty)$, probability $\ge1-Cn^{-1/2}$.
* Root: unique exterior zero $\lambda_*=\dfrac{2d}{\sqrt{d+1}}$, simple, $\Phi'(\lambda_*)=2(d+1)$;
  threshold $\sum_{s,t}r(b)^{\rho}=2d\ge2(d-2)$, slack $4$, so a root exists for every $d\ge3$.
* Eigenvalues: $\lambda_1(G_n')\to d$, $\lambda_2(G_n')\to\lambda_*$ for all $d\ge3$.
* $d=3$: $\lambda_*=d$ — the critical case is realised by an integer parameter; both top
  eigenvalues $\to3$, at scale $n^{-1/2}$: $\sqrt n(\lambda_1-3)\to3/\sqrt8$,
  $\sqrt n(3-\lambda_2)\to3/\sqrt8$.
* $d\ge4$: $n(\lambda_1-d)\to d(d-2)/(d-3)$ ($=8$ at $d=4$), which is *not* the
  separated-model constant ($6.4$ at $d=4$).

## Reproduce

```sh
python3 checks/sym_kernel.py
python3 checks/exact_small.py
python3 checks/numeric_gprime.py 3 8000 11      # ~15 s
python3 checks/numeric_gprime.py 4 8000 21
```
