#!/usr/bin/env python3
"""Direction 4 (m1, swarm smwh0bmpx): fixed-seed numerical verification of the
clustered-attachment secular law.

Families (all determined by the radius-1 neighbourhood of the fixed label c=0):
  adj : T = {c, u}, u = min N(c)           rho: one pair at distance 1
  N   : T = N(c)                           rho: all distinct pairs at distance 2
  C   : T = {c} u N(c)  (extra family, mixed distances 1 and 2)

Conventions
  lambda = (d-1)r + 1/r,  G_d = r/(1-r^2) = 1/(lambda - d r)
  Sigma_n(lambda) = lambda - 1_T^T (lambda I - A)^{-1} 1_T   (zeros = new eigenvalues)
  Phi_T(lambda)   = lambda - G_d(lambda) * sum_{s,t in T} r(lambda)^{rho(s,t)}
  finite size: Sigma_n = Phi_T(lambda) - |T|^2/(n(lambda-d)) + o(1)   [Perron term]

Sampler: pairing model with rejection on loops/multi-edges, i.e. EXACTLY uniform on
simple d-regular graphs after acceptance.  Seeds printed and stored.

Checks per graph:
  (i)  |Sigma_n(lambda_i(G'))| ~ 0 for the two top eigenvalues (secular identity);
  (ii) bracket-and-bisect the interior zero in (lambda_2(A), d) and compare;
  (iii) resolvent value 1_T^T(lambda I - A)^{-1}1_T against the pattern prediction
        and against the separated prediction |T| G_d;
  (iv) limit comparison of lambda_1, lambda_2 with the exact pattern-law roots.
"""
import json

import numpy as np
import scipy.sparse as sp
import scipy.sparse.linalg as spla


# ---------------------------------------------------------------- exact pattern laws
def km(d, lam):
    disc = lam * lam - 4.0 * (d - 1)
    r = (lam - np.sqrt(disc)) / (2.0 * (d - 1))
    return r, r / (1.0 - r * r)


def sigma_tree(pattern, d, r):
    """sum over ORDERED pairs of r^{rho(s,t)} for the three families."""
    if pattern == 'adj':
        return 2.0 + 2.0 * r
    if pattern == 'N':
        return d + d * (d - 1) * r * r
    if pattern == 'C':
        return (d + 1) + 2 * d * r + d * (d - 1) * r * r
    raise ValueError


def phi(pattern, d, lam):
    r, G = km(d, lam)
    return lam - G * sigma_tree(pattern, d, r)


def pattern_root(pattern, d, lo=None, hi=None, iters=200):
    b = 2 * np.sqrt(d - 1)
    lo = lo if lo is not None else b + 1e-12
    hi = hi if hi is not None else 20.0
    if phi(pattern, d, lo + 1e-12) * phi(pattern, d, hi) > 0:
        return None
    for _ in range(iters):
        mid = 0.5 * (lo + hi)
        if np.sign(phi(pattern, d, mid)) == np.sign(phi(pattern, d, lo + 1e-12)):
            lo = mid
        else:
            hi = mid
    return 0.5 * (lo + hi)


# ---------------------------------------------------------------- graph machinery
def sample_regular(n, d, seed, max_attempts=600):
    rng = np.random.default_rng(seed)
    nstub = n * d
    for att in range(max_attempts):
        stubs = np.repeat(np.arange(n), d)
        perm = rng.permutation(nstub)
        a = stubs[perm[0::2]]
        b = stubs[perm[1::2]]
        if np.any(a == b):
            continue
        key = np.minimum(a, b).astype(np.int64) * n + np.maximum(a, b)
        if np.unique(key).size != nstub // 2:
            continue
        return a.copy(), b.copy(), att + 1
    raise RuntimeError("sampler failed")


def build_adj(n, a, b, extra=()):
    rows = list(a) + list(b)
    cols = list(b) + list(a)
    for (i, j) in extra:
        rows += [i, j]
        cols += [j, i]
    nn = max(max(rows), max(cols)) + 1
    return sp.csr_matrix((np.ones(len(rows)), (rows, cols)), shape=(nn, nn))


def quad(A, T, lam):
    n = A.shape[0]
    e = np.zeros(n)
    e[np.asarray(T)] = 1.0
    M = sp.csc_matrix(lam * sp.identity(n) - A)
    x = spla.spsolve(M, e)
    return float(e @ x)


def secular(A, T, lam):
    return lam - quad(A, T, lam)          # Sigma_n = lambda - 1^T (lam I - A)^{-1} 1


def top_eigs(A, k):
    v = spla.eigsh(A, k=k, which='LA', return_eigenvectors=False, tol=1e-12,
                   maxiter=40000)
    return np.sort(v)[::-1]


def bisect_secular(A, T, lo, hi, iters=45):
    flo = secular(A, T, lo)
    assert flo < 0, f"left end not negative: {flo}"
    for _ in range(iters):
        mid = 0.5 * (lo + hi)
        if secular(A, T, mid) < 0:
            lo = mid
        else:
            hi = mid
    return 0.5 * (lo + hi)


def main():
    lines, runs = [], []

    preds = {}
    for d in (3, 4):
        for pat in ('adj', 'N', 'C'):
            preds[(d, pat)] = pattern_root(pat, d)
    lines.append("EXACT PATTERN-LAW EXTERIOR ROOTS lambda* (Phi_T(lambda)=0, bracketed to 1e-13):")
    for d in (3, 4):
        for pat in ('adj', 'N', 'C'):
            lam = preds[(d, pat)]
            b = 2 * np.sqrt(d - 1)
            lines.append(f"  d={d} T={pat:3s}: lambda* = "
                         f"{'none (Phi>0 on (b,inf))' if lam is None else f'{lam:.13f}'}"
                         f"   b={b:.13f}   d={d}")
    lines.append("")

    plan = {3: [(1000, 20250606), (2000, 20250607), (4000, 20250608), (8000, 20250609)],
            4: [(1000, 20250610), (2000, 20250611), (4000, 20250612)]}

    for d, lst in plan.items():
        for (n, seed) in lst:
            a, b, att = sample_regular(n, d, seed)
            A = build_adj(n, a, b)
            assert np.all(np.asarray(A.sum(axis=1)).ravel() == d)
            nbrs0 = sorted(A[0].indices.tolist())
            host = top_eigs(A, k=6)
            lam2A = float(host[1])
            pats = {'adj': [0, nbrs0[0]], 'N': list(nbrs0), 'C': [0] + nbrs0}
            for pat, T in pats.items():
                A2 = build_adj(n, a, b, extra=[(j, n) for j in T])
                spec = top_eigs(A2, k=6)
                l1, l2 = float(spec[0]), float(spec[1])
                s_at_l2 = secular(A, T, l2)
                s_at_l1 = secular(A, T, l1)
                root = None
                if lam2A + 5e-3 < d - 5e-3:
                    try:
                        root = bisect_secular(A, T, lam2A + 5e-3, d - 5e-3)
                    except AssertionError:
                        root = None
                res = {}
                for lam_t in ((3.2, 4.5) if d == 3 else (4.5, 6.0)):
                    r, G = km(d, lam_t)
                    pred = G * sigma_tree(pat, d, r)
                    meas = quad(A, T, lam_t)
                    res[str(lam_t)] = dict(measured=meas, pattern=pred,
                                           pattern_perron=pred + len(T) ** 2 / (n * (lam_t - d)),
                                           separated=len(T) * G)
                rec = dict(d=d, n=n, seed=seed, pattern=pat, T=T, attempts=att,
                           lam2_host=lam2A, lambda_1=l1, lambda_2=l2,
                           Sigma_at_lambda2=s_at_l2, Sigma_at_lambda1=s_at_l1,
                           interior_secular_root=root,
                           lam_star=preds[(d, pat)], resolvent=res)
                runs.append(rec)

                lines.append(f"d={d} n={n} seed={seed} T={pat:3s} |T|={len(T)} attempts={att} "
                             f"lam2(host)={lam2A:.8f}")
                lines.append(f"   lambda_1={l1:.10f}  lambda_2={l2:.10f}   "
                             f"Sigma_n(lambda_2)={s_at_l2:+.2e}  Sigma_n(lambda_1)={s_at_l1:+.2e}")
                if root is not None:
                    lines.append(f"   interior secular zero = {root:.10f} "
                                 f"(|lambda_2 - zero| = {abs(l2-root):.2e})")
                for kk, v in res.items():
                    lines.append(f"   lam={kk}: measured={v['measured']:.6f} "
                                 f"pattern={v['pattern']:.6f} "
                                 f"+Perron={v['pattern_perron']:.6f} "
                                 f"separated(=|T|G_d)={v['separated']:.6f}")
            lines.append("")

    lines.append("=" * 88)
    lines.append("LIMIT COMPARISON (rows converge to the pattern-law roots)")
    lines.append("=" * 88)
    for d in (3, 4):
        b = 2 * np.sqrt(d - 1)
        lines.append(f"d={d}: bulk edge b={b:.10f}, Perron point d={d}")
        for pat in ('adj', 'N', 'C'):
            rs = sorted([r for r in runs if r['d'] == d and r['pattern'] == pat],
                        key=lambda z: z['n'])
            tgt = preds[(d, pat)]
            lines.append(f"  T={pat}: lambda*={tgt if tgt is None else round(tgt, 10)}"
                         f"   [lambda_1 -> max(d,lambda*), lambda_2 -> min(d,lambda*)]")
            for r in rs:
                extra = ""
                if d == 3 and pat == 'N' and tgt is not None and abs(tgt - 3.0) < 1e-9:
                    extra = (f"  sqrt(n)(3-lam2)={np.sqrt(r['n'])*(3-r['lambda_2']):.5f}"
                             f"  sqrt(n)(lam1-3)={np.sqrt(r['n'])*(r['lambda_1']-3):.5f}")
                lines.append(f"     n={r['n']:5d} lam2={r['lambda_2']:.8f} lam1={r['lambda_1']:.8f}{extra}")
        lines.append("")

    txt = "\n".join(lines)
    print(txt)
    with open("out/numerics_all.txt", "w") as f:
        f.write(txt + "\n")
    with open("out/numerics_raw.json", "w") as f:
        json.dump(dict(preds={f"{d}_{p}": v for (d, p), v in preds.items()}, runs=runs),
                  f, indent=1)


if __name__ == "__main__":
    main()
