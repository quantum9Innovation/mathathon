import numpy as np, networkx as nx
from fractions import Fraction

import numpy as np

def config_model_regular(n, d, rng):
    """Configuration model for d-regular; returns simple graph or None."""
    stubs = np.repeat(np.arange(n), d)
    rng.shuffle(stubs)
    A = np.zeros((n, n), dtype=np.int64)
    ok = True
    for i in range(0, len(stubs), 2):
        a, b = stubs[i], stubs[i+1]
        if a == b or A[a, b]:
            ok = False
            break
        A[a, b] = A[b, a] = 1
    return A if ok else None

def km_moment(d, k):
    """k-th moment of Kesten-McKay measure = number of closed walks of length k
    from root of d-regular tree.  Exact integer recursion on the tree."""
    # level counts: state = 'root' or 'interior'
    # closed walk count from root: w_k(root). Use transfer on generating functions:
    # R(z) = 1/(1 - d*z^2*I(z)),  I(z) = 1/(1-(d-1)z^2 I(z)) ; count via series
    N = 400
    # truncate series in z^2: represent as arrays of length N in variable y=z^2
    I = np.zeros(N); I[0] = 1.0
    # iterate fixed point
    for _ in range(60):
        newI = np.zeros(N); newI[0] = 1.0
        # newI = 1 + (d-1)*y*I*newI  -> solve by convolution
        tmp = np.convolve(I, (d-1)*np.array([0.0]+[1.0]+[0.0]*(N-2)))[:N]
        # newI = 1/(1-tmp)
        # do via power series inversion
        newI = np.zeros(N); newI[0] = 1.0
        neg = -tmp
        for m in range(1, N):
            s = 0.0
            for j in range(1, m+1):
                s += neg[j]*newI[m-j]
            newI[m] = s
        I = newI
    tmp = np.convolve(I, d*np.array([0.0]+[1.0]+[0.0]*(N-2)))[:N]
    R = np.zeros(N); R[0] = 1.0
    neg = -tmp
    for m in range(1, N):
        s = 0.0
        for j in range(1, m+1):
            s += neg[j]*R[m-j]
        R[m] = s
    return int(round(R[k//2])) if k % 2 == 0 else 0

for d in (3,4,5):
    print("d =", d, " KM moments m_0..m_10:", [km_moment(d,k) for k in range(11)])
