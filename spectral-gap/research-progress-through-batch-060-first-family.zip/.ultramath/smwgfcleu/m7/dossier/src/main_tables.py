"""Main exact tables: extremal lambda over all symmetric generating sets."""
import sys
sys.path.insert(0, 'dossier/src')
import numpy as np
import sympy as sp
from cayley import *
from blocks import sn_data, a5_data, block_spectra

import builtins
def pp(*a, **k):
    k.setdefault('flush', True)
    builtins.print(*a, **k)


def exact_charpoly(G, S):
    A = G.adjacency(S).astype(int)
    return sp.factor(sp.Matrix(A.tolist()).charpoly('x').as_expr())


def analyse(G, d, data, do_exact=True):
    sets = G.symmetric_sets(d)
    thr = 2.0 * np.sqrt(d - 1)
    rows = []
    for S in sets:
        if not G.connected(S):
            continue
        ev = G.spectrum(S)
        idx = int(np.argmin(np.abs(ev - d)))
        rest = np.delete(ev, idx)
        lam = float(np.max(np.abs(rest)))
        rows.append((lam, int(np.sum(np.abs(rest) > thr + 1e-12)), S, ev))
    rows.sort(key=lambda r: r[0])
    pp("=" * 78)
    pp("GROUP %s (order %d), degree d = %d" % (G.name, G.n, d))
    pp("  symmetric sets: %d ; connected (generating): %d" % (len(sets), len(rows)))
    pp("  Ramanujan threshold 2 sqrt(d-1) = %.12f" % thr)
    pp("  lambda_min = %.12f  (girth %d)" % (rows[0][0], G.girth(rows[0][2])))
    pp("  lambda_max = %.12f  (girth %d)" % (rows[-1][0], G.girth(rows[-1][2])))
    pp("  # connected S with lambda <= threshold: %d / %d" % (sum(1 for r in rows if r[0] <= thr + 1e-12), len(rows)))
    pp("  # S with lambda > threshold:              %d" % sum(1 for r in rows if r[0] > thr + 1e-12))
    # quasi index distribution
    from collections import Counter
    cnt = Counter(r[1] for r in rows)
    pp("  #eigenvalues with |lambda| > threshold (besides Perron): distribution %s" % dict(sorted(cnt.items())))
    # distinct spectra
    spec_count = Counter(tuple(np.round(r[3], 8)) for r in rows)
    pp("  # distinct spectra: %d ; multiplicities of spectra %s" % (len(spec_count), sorted(spec_count.values(), reverse=True)[:8]))
    for tag, r in [("MIN", rows[0]), ("MAX", rows[-1])]:
        lam, above, S, ev = r
        pp("  -- %s: lambda = %.12f, |above| = %d, girth = %d" % (tag, lam, above, G.girth(S)))
        pp("     S (cycle types) = %s" % ([cycle_type(G.els[s]) for s in S],))
        pp("     S (elements) = %s" % ([G.els[s] for s in S],))
        if do_exact:
            pp("     exact char poly = %s" % exact_charpoly(G, S))
        rows_block, evA, uni = block_spectra(G, S, data, verbose=False)
        pp("     multiset law error = %.2e" % float(np.max(np.abs(uni - evA))))
        for (label, deg, mx, bev) in rows_block:
            pp("       block %-10s deg=%2d  max|lambda|=%9.6f  spec=%s" % (label, deg, mx, np.round(np.sort(bev), 6)))
    return rows


if __name__ == '__main__':
    S4 = sym_group(4)
    d4 = sn_data(S4, 4)
    A5 = alt_group(5)
    dA5 = a5_data(A5)
    S5 = sym_group(5)
    d5 = sn_data(S5, 5)
    for G, data, ds in [(S4, d4, [3]), (A5, dA5, [3]), (S5, d5, [3])]:
        for d in ds:
            analyse(G, d, data)
            pp()
