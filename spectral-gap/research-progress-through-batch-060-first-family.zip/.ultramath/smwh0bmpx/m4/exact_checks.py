"""Exact / symbolic checks for the adjacent-pair clustered secular law, T = {c,u}, rho(c,u)=1.

EVERY identity claimed exact below is checked in exact arithmetic (sympy symbolic or
fractions.Fraction).  No floating point enters any claimed identity; floats appear only in
"corroboration" lines that are explicitly labelled numeric.
"""
import sympy as sp
from fractions import Fraction as F
import itertools, json, sys

LOG = []
def rep(s=""):
    LOG.append(str(s)); print(s)

d, r, z, lam = sp.symbols('d r z lam', positive=True)

rep("="*78); rep("A. one-sided rooted-tree self-energy")
# (Gamma_D) = (z - A_D)^{-1}_{oo} satisfies g = 1/(z - (d-1) g)   [D = half-tree, root degree d-1]
g = sp.symbols('g')
eq = sp.Eq(g, 1/(z - (d-1)*g))
sols = sp.solve(sp.Eq(g*(z-(d-1)*g), 1), g)
rep("  self-consistency g = 1/(z-(d-1)g)  <=>  (d-1)g^2 - z g + 1 = 0")
rep("  roots: %s" % [sp.simplify(s) for s in sols])
# small branch: g = r  <=>  z = (d-1)r + 1/r  and r -> 0 as z -> oo, r < 1/sqrt(d-1)
rep("  small branch g=r with z=(d-1)r+1/r; check: %s" % sp.simplify(
        (d-1)*r + 1/r - ((d-1)*r + 1/r)))
rep("  branch condition |r|<1/sqrt(d-1) is the root with sign  r=(z-sqrt(z^2-4(d-1)))/(2(d-1))")

rep(); rep("="*78); rep("B. pair kernel by exact 2x2 Schur complement (both d-1 side-half-trees eliminated)")
# gadget: c ~ u; c also adjacent to d-1 half-trees, u likewise.  After eliminating the
# half-trees each of c,u carries self-energy (d-1)r.
a = z - (d-1)*r
S = sp.Matrix([[a, -1], [-1, a]])
Sinv = S.inv()
Kred = sp.simplify(sum(Sinv[i, j] for i in range(2) for j in range(2)))
rep("  Schur complement  S = [[z-(d-1)r, -1],[-1, z-(d-1)r]]")
rep("  1_T^T S^{-1} 1_T  = %s" % Kred)
Ksub = sp.simplify(Kred.subs(z, (d-1)*r + 1/r))
rep("  substituting the tree relation z=(d-1)r+1/r :  %s" % Ksub)
rep("  == 2r/(1-r) ?  %s" % sp.simplify(Ksub - 2*r/(1-r)))
Gd = r/(1-r**2)
rep("  G_d = r/(1-r^2);   G_d*(2+2r) - 2r/(1-r) = %s"
    % sp.simplify(Gd*(2+2*r) - 2*r/(1-r)))
rep("  G_d*(2+2r) - (2x2 Schur complement)    = %s"
    % sp.simplify(Gd*(2+2*r) - Ksub))
rep("  so K_adj = G_d(2+2r) = 2r/(1-r)  [checked identically]")

rep(); rep("  singular set of the 2x2 representation: det S = a^2-1 = 0 <=> a = +-1")
rep("  a = z-(d-1)r = 1/r  (tree relation).  a=1 <=> r=1 <=> z=d ;  a=-1 <=> r=-1 <=> z=-d.")
rep("  On the exterior branch 0<r<1/sqrt(d-1)<=1/sqrt(2)<1, so det S > 0: no pole at all.")
rep("  At z=d: r(d)=1/(d-1), K_adj(d)=2/(d-2)  (finite).")

rep(); rep("="*78); rep("C. secular sign algebra:  Phi_adj(lam) = lam - 2r/(1-r)")
Ph = lam - 2*r/(1-r)
P = (d-1)*r**3 - (d-3)*r**2 + r - 1          # claimed numerator (r-cubic)
expr = sp.simplify(sp.together((Ph.subs(lam, (d-1)*r + 1/r)) + P/(r*(1-r))))
rep("  [lam(lam=r) - 2r/(1-r)] + P(r)/(r(1-r)) = %s   (so Phi=0 <=> P(r)=0 on r>0)" % expr)
rep("  P(r) = (d-1)r^3-(d-3)r^2+r-1 ;  sign(Phi) = -sign(P) since r(1-r)>0")
Psp = sp.Poly(P, r)
rep("  P(0) = %s ;  P(1) = %s" % (Psp.eval(0), Psp.eval(1)))
rb = 1/sp.sqrt(d-1)
Pb = sp.simplify(P.subs(r, rb))
rep("  P(1/sqrt(d-1)) = %s" % sp.simplify(Pb))
rep("  = %s" % sp.radsimp(sp.simplify(Pb)))

rep(); rep("="*78); rep("D. crossing/threshold algebra at the bulk edge b=2 sqrt(d-1), r_b=1/sqrt(d-1)")
Kb = sp.simplify((2*r/(1-r)).subs(r, rb))
Phi_b = sp.simplify(2*sp.sqrt(d-1) - Kb)
rep("  K_adj(b) = %s  = %s" % (Kb, sp.radsimp(Kb)))
rep("  2r_b/(1-r_b) = 2/(sqrt(d-1)-1) ; check: %s"
    % sp.simplify(2*rb/(1-rb) - 2/(sp.sqrt(d-1)-1)))
rep("  (the target file states 2/(1-1/sqrt(d-1)) = 2 sqrt(d-1)/(sqrt(d-1)-1); ratio to truth: %s)"
    % sp.simplify((2/(1-rb))/(2*rb/(1-rb))))
Phi_b = sp.radsimp(sp.simplify(Phi_b))
rep("  Phi_adj(b) = b - K_adj(b) = %s" % Phi_b)
rep("  Phi_adj(b) < 0  <=>  2 sqrt(d-1)(sqrt(d-1)-1) < 2  <=>  s^2-s-1<0, s=sqrt(d-1)")
rep("  <=>  s < phi=(1+sqrt5)/2  <=>  d < 1+phi^2 = (5+sqrt5)/2 = %s"
    % sp.N((5+sp.sqrt(5))/2, 12))
rep("  integer d>=3 with Phi_adj(b)<0 : only d=3.  %s"
    % [dd for dd in range(3, 12) if sp.N(Phi_b.subs(d, dd)) < 0])
for dd in range(3, 9):
    rep("    d=%2d : b=%s  K_adj(b)=%s  Phi_adj(b)=%s   [target-formula value %s]"
        % (dd, sp.N(2*sp.sqrt(dd-1), 10), sp.N(Kb.subs(d, dd), 10),
           sp.N(Phi_b.subs(d, dd), 10), sp.N((2/(1-rb)).subs(d, dd), 10)))

rep(); rep("="*78); rep("E. strict monotonicity of Phi on the exterior branch (=> no repeated roots)")
# Phi'(lam) = 1 - dK/dlam,  dr/dlam = r^2/((d-1)r^2-1)
drdl = r**2/((d-1)*r**2 - 1)
dK = sp.simplify(sp.diff(2*r/(1-r), r)*drdl)
Phip = sp.simplify(1 - dK)
rep("  Phi'(lam) = %s" % Phip)
claim = 1 + 2*r**2/((1-r)**2*(1-(d-1)*r**2))
rep("  Phi'(lam) - [1+2r^2/((1-r)^2 (1-(d-1)r^2))] = %s"
    % sp.simplify(Phip - claim))
rep("  all three factors positive on 0<r<1/sqrt(d-1)  =>  Phi'>0, so Phi is a bijection")
rep("  (b,inf) -> (Phi(b), inf) and a root, if it exists, is simple and unique.")

rep(); rep("="*78); rep("F. Perron point versus a root of the pattern law")
Phid = sp.solve(sp.Eq(d - 2/(d-2), 0), d)
rep("  Phi_adj(d) = d - 2/(d-2) ;  Phi_adj(d)=0 <=> d^2-2d-2=0 <=> d = %s" % Phid)
rep("  1+sqrt3 = %s is irrational, so no integer d>=3 has Phi_adj(d)=0." % sp.N(1+sp.sqrt(3), 12))
for dd in range(3, 8):
    rep("    d=%d: Phi_adj(d)=%s" % (dd, sp.Rational(int((dd*(dd-2)-2)), int(dd-2))))

rep(); rep("="*78); rep("G. lambda-space elimination and its SPURIOUS branch")
# lam = 2r/(1-r)  =>  r = lam/(lam+2);  insert into (d-1)r+1/r = lam
lp = sp.symbols('lp', positive=True)
elim = sp.simplify(sp.together(sp.expand(((d-1)*lp/(lp+2) + (lp+2)/lp - lp)*lp*(lp+2))))
rep("  eliminating r between lam=2r/(1-r) and (d-1)r+1/r=lam gives %s = 0" % elim)
cub = lp**3 - (d-2)*lp**2 - 4*lp - 4
rep("  check equal to lam^3-(d-2)lam^2-4lam-4 : %s" % sp.simplify(elim - cub))
rep("  BUT r = lam/(lam+2) must equal the SMALL root r(lam) of (d-1)r^2-lam r+1=0.")
rep("  The quadratic's other root is 1/((d-1)r); roots of the cubic that sit on that")
rep("  large branch are spurious.  Worked instance d=4 (exact check below):")
for dd in [4]:
    roots = sp.nroots(cub.subs(d, dd))
    for rl in roots:
        if abs(sp.im(rl)) < 1e-20:
            rl = sp.re(rl)
            q = sp.Poly((dd-1)*r**2 - rl*r + 1, r)
            rr = sp.nroots(q)
            rep("    lam=%s : roots of (d-1)r^2-lam r+1 : %s ; r_b=1/sqrt(d-1)=%s"
                % (sp.N(rl, 12), [sp.N(t, 10) for t in rr], sp.N(1/sp.sqrt(dd-1), 10)))
            small = min([t for t in rr], key=lambda t: abs(sp.N(t)))
            rep("      small branch r=%s ; lam/(lam+2)=%s  -> %s"
                % (sp.N(small, 10), sp.N(rl/(rl+2), 10),
                   "GENUINE root" if abs(sp.N(small - rl/(rl+2))) < 1e-9 else "SPURIOUS"))

rep(); rep("="*78); rep("H. finite-size displacement near the Perron point d")
D = 2  # |T|
rep("  Sigma_n(lam) = Phi_T(lam) + |T|^2/(n(d-lam)) + o(1)   [exact Perron term, batch-050 sign]")
rep("  put lam = d + s/n :  |T|^2/(n(d-lam)) = -|T|^2/s, so the zero has s -> |T|^2/Phi_T(d)")
for dd in range(3, 8):
    phid = sp.Rational(int(dd*(dd-2)-2), int(dd-2))
    sep = dd - 2*sp.Rational(int(dd-1), int(dd*(dd-2)))    # separated case, Delta=2
    rep("    d=%d : clustered s_inf = 4/Phi_adj(d) = %s ; separated (Delta=2) s_inf = 4/(d-2G_d(d)) = %s"
        % (dd, sp.Rational(4, 1)/phid, sp.Rational(4, 1)/sep))

rep(); rep("="*78); rep("I. exact rational finite-ball verification of K_adj (no floating point)")
def K_trunc(dd, zz, R):
    """exact K for the ball of radius R around the pair, via exact self-energies."""
    s = F(1)/zz                       # depth-0 leaf
    for _ in range(R):
        s = F(1)/(zz - (dd-1)*s)
    a = zz - (dd-1)*s                 # reduced diagonal of c and u
    M = [[a, F(-1)], [F(-1), a]]
    det = a*a - 1
    return (2*a)/det                  # 1^T M^{-1} 1
tests = [(3, F(2,5)), (4, F(2,7)), (5, F(1,3)), (3, F(1,2)), (6, F(1,4))]
for dd, rr in tests:
    zz = (dd-1)*rr + 1/rr
    Kinf = 2*rr/(1-rr)
    rep("  d=%d, r=%s (=> z=%s = %s), K_inf=2r/(1-r)=%s" % (dd, rr, zz, sp.N(F(zz), 12), Kinf))
    prev = None
    for R in [1, 2, 3, 4, 6, 8, 10, 12]:
        KR = K_trunc(dd, zz, R)
        err = KR - Kinf
        rep("     R=%2d  K_R=%s  K_R-K_inf=%s  ratio=%s"
            % (R, sp.N(KR, 15), sp.N(err, 6),
               "-" if prev is None else sp.N(err/prev, 6)))
        prev = err
    rep("     predicted geometric ratio r^2 = %s" % sp.N(F(rr)**2, 6))

rep(); rep("="*78); rep("J. exact secular identity on a finite graph (Petersen, d=3, adjacent pair)")
def petersen():
    # standard Petersen: outer 5-cycle 0-4, inner pentagram 5-9, spokes i - i+5
    n = 10
    A = [[0]*n for _ in range(n)]
    def e(i, j):
        A[i][j] = 1; A[j][i] = 1
    for i in range(5):
        e(i, (i+1) % 5); e(5+i, 5+((i+2) % 5)); e(i, 5+i)
    return A
A = petersen(); n = 10
T = [0, 1]                     # an edge of the Petersen graph
# exact determinant / inverse via Fraction Gaussian elimination
def det_frac(M):
    M = [row[:] for row in M]; n_ = len(M); det = F(1)
    for c in range(n_):
        p = next((i for i in range(c, n_) if M[i][c] != 0), None)
        if p is None: return F(0)
        if p != c: M[c], M[p] = M[p], M[c]; det = -det
        det *= M[c][c]
        inv = F(1)/M[c][c]
        for i in range(c+1, n_):
            f = M[i][c]*inv
            if f:
                for j in range(c, n_): M[i][j] -= f*M[c][j]
    return det
def solve_frac(M, b):
    n_ = len(M)
    Aug = [M[i][:] + [b[i]] for i in range(n_)]
    for c in range(n_):
        p = next((i for i in range(c, n_) if Aug[i][c] != 0), None)
        assert p is not None
        Aug[c], Aug[p] = Aug[p], Aug[c]
        inv = F(1)/Aug[c][c]
        for j in range(c, n_+1): Aug[c][j] *= inv
        for i in range(n_):
            if i != c and Aug[i][c]:
                f = Aug[i][c]
                for j in range(c, n_+1): Aug[i][j] -= f*Aug[c][j]
    return [Aug[i][n_] for i in range(n_)]
lamvals = [F(5,2), F(7,3), F(23,10), F(31,10), F(4), F(17,4)]
for lv in lamvals:
    Mm = [[(lv if i == j else F(0)) - A[i][j] for j in range(n)] for i in range(n)]
    x = solve_frac(Mm, [F(1) if i in T else F(0) for i in range(n)])
    S_ = lv - (x[T[0]] + x[T[1]])
    # det(lam - A_{G'}) with x adjacent to both T-vertices
    A2 = [row[:] + [F(1) if k in T else F(0)] for k, row in enumerate(A)]
    A2.append([F(1) if k in T else F(0) for k in range(n)] + [F(0)])
    d2 = det_frac([[(lv if i == j else F(0)) - A2[i][j] for j in range(n+1)] for i in range(n+1)])
    d1 = det_frac(Mm)
    rep("  lam=%s : det(lam-A)=%s  Sigma_n=%s  Sigma_n*det = %s  det(lam-A_{G'}) = %s  EQ=%s"
        % (lv, d1, S_, S_*d1, d2, S_*d1 == d2))
# integer-spectrum check of the root->eigenvalue map (deterministic lemma)
import numpy as np
ev_host = sorted(np.linalg.eigvalsh(np.array(A, dtype=float)))[::-1]
A2n = np.array([[1.0 if (i < n and j < n and A[i][j]) or (i == n and j in T) or (j == n and i in T) else 0.0
                 for j in range(n+1)] for i in range(n+1)])
ev_gp = sorted(np.linalg.eigvalsh(A2n))[::-1]
rep("  sigma(A)  = %s" % [round(v, 12) for v in ev_host])
rep("  sigma(A_G')= %s" % [round(v, 12) for v in ev_gp])
rep("  lam_2(A)=%s ; lam_2(A_G')=%s ; interlacing ok=%s"
    % (ev_host[1], ev_gp[1], ev_host[1] - 1e-12 <= ev_gp[1] <= ev_host[0] + 1e-12))

rep(); rep("="*78); rep("K. order of contact at the critical real degree d_c=(5+sqrt5)/2")
eps = sp.symbols('eps', positive=True)
dc = (5+sp.sqrt(5))/2
rep("  Phi(d;s) := 2sqrt(d-1) - 2/(sqrt(d-1)-1)   (value at the edge)")
Phs = lambda dd: 2*sp.sqrt(dd-1) - 2/(sp.sqrt(dd-1)-1)
rep("  Phi(d_c) = %s" % sp.simplify(Phs(dc)))
rep("  d/dd Phi(d)|_{d_c} = %s" % sp.simplify(sp.diff(Phs(d), d).subs(d, dc)))
rep("  edge singularity: Phi(b+eps)-Phi(b) ~ c*sqrt(eps) because 1-(d-1)r^2 ~ C sqrt(eps)")
# r(b+eps): (d-1)r^2-(b+eps)r+1=0 -> r = r_b r_b'(...); expand
rr = sp.symbols('rr')
b_ = 2*sp.sqrt(d-1)
rbb = 1/sp.sqrt(d-1)
sols = sp.solve(sp.Eq((d-1)*rr**2 - (b_+eps)*rr + 1, 0), rr)
small = [s for s in sols if sp.limit(s, eps, 0) == rbb][0]
rep("  r(b+eps) = %s" % sp.series(small, eps, 0, 2))
k_eps = sp.series(2*small/(1-small), eps, 0, 2)
rep("  K_adj(b+eps) = %s" % k_eps)
rep("  => Phi(b+eps)-Phi(b) = eps - (K(b+eps)-K(b)) ~ -C sqrt(eps) + eps")
rep("  hence root displacement  delta ~ C' (d-d_c)^2 : contact order 1/2 at the edge.")

rep(); rep("="*78)
rep("ALL EXACT CHECKS COMPLETED.")
with open('out/exact_checks.txt', 'w') as f:
    f.write("\n".join(LOG) + "\n")
