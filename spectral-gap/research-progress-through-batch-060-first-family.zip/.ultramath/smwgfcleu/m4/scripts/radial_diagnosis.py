"""
radial_diagnosis.py -- corrected diagnosis of the spherically homogeneous tree with
root children 3 and children counts 2,1,2,1,...

Key objects:
  tree ball B_D of radius D, and its radial compression, which in level
  coordinates g(k)=sqrt(w_k) f(k) is the Jacobi matrix with zero diagonal and
  off-diagonals b_k = sqrt(n_k), k = 0..D-1,  n = (3,2,1,2,1,...).
The Floquet (transfer matrix) computation gives the ESSENTIAL spectrum of the
radial operator, i.e. the bands.  A boundary defect b_0 = sqrt(3) versus the
periodic value can create one discrete eigenvalue above the top band.
This script quantifies all three statements.
"""
import numpy as np
from floquet_bands import build_tree_sparse, floquet_margin


def jacobi(counts, N):
    """Jacobi matrix with off-diagonals sqrt(counts[k]) for k=0..N-1, zero diagonal."""
    b = np.sqrt(np.array(counts[:N], dtype=float))
    J = np.diag(b, 1) + np.diag(b, -1)
    return J


def main():
    import os
    os.makedirs("outputs", exist_ok=True)
    out = open("outputs/radial_diagnosis.txt", "w")
    n0, tail = 3, [2, 1]
    out.write("TREE: root children 3, children counts 2,1,2,1,...\n")
    out.write("Floquet band top (radial ESSENTIAL spectrum) = sqrt2+1 = %.13f\n\n" % (np.sqrt(2)+1))
    out.write("  depth D |  tree ball top  |  radial Jacobi top (size D+1) |  difference\n")
    for D in (6, 9, 12, 15, 18):
        M, n = build_tree_sparse(n0, tail, D)
        ev_tree = np.linalg.eigvalsh(M.toarray())[-1]
        # off-diagonals for the radial compression of the ball: levels 0..D, n_k children
        counts = [n0] + [tail[(k-1) % 2] for k in range(1, D+1)]
        J = jacobi(counts, D)
        ev_J = np.linalg.eigvalsh(J)[-1]
        out.write(f"  {D:7d} |  {ev_tree:.13f}  |  {ev_J:.13f}  |  {abs(ev_tree-ev_J):.2e}\n")
    out.write("\nEIGENVALUE CERTIFICATE for the top of the radius-15 ball:\n")
    M, n = build_tree_sparse(n0, tail, 15)
    A = M.toarray()
    ev, V = np.linalg.eigh(A)
    lam = ev[-1]; v = V[:, -1]
    out.write(f"  vertices = {n}, lambda_max = {lam:.16f}\n")
    out.write(f"  residual ||A v - lambda v||_2 = {np.linalg.norm(A @ v - lam * v):.3e}\n")
    out.write(f"  lambda_max - (sqrt2+1) = {lam - (np.sqrt(2)+1):.6e}\n")
    out.write(f"  Floquet margin at lambda_max = {floquet_margin(tail, lam):.6e} (positive = outside the bands)\n\n")
    out.write("LARGE JACOBI SPECTRUM: is 2.4488 an isolated eigenvalue above the band?\n")
    for N in (200, 400):
        counts = [n0] + [tail[(k-1) % 2] for k in range(1, N+1)]
        J = jacobi(counts, N)
        ev = np.linalg.eigvalsh(J)
        above = ev[ev > np.sqrt(2)+1]
        out.write(f"  N={N}: eigenvalues above sqrt2+1: {len(above)}  top = {ev[-1]:.10f}\n")
        if len(above):
            out.write(f"       second largest = {ev[-2]:.10f}, gap to it = {ev[-1]-ev[-2]:.6f}\n")
    out.close()
    print(open("outputs/radial_diagnosis.txt").read())


if __name__ == "__main__":
    main()
