r"""Higher gaps d - lambda_j for abelian Cayley tori and successive minima.

For Gamma = Cay(Z^d,S) and Lambda = n Z^d the eigenvalues are
    lambda(kappa) = sum_{s in S} cos(2 pi <kappa,s>),  kappa in n^{-1}Z^d/Z^d,
and near kappa = 0 one has lambda = |S| - 2 pi^2 kappa^T G kappa + O(|kappa|^4)
with G = sum_s s s^T.  Hence, up to O(n^-4), the sorted values of |S| - lambda
are 2 pi^2 / n^2 times the sorted values of z^T G z over z in Z^d \ {0},
counted with multiplicity.  The successive minima of the form G therefore
determine the whole top of the spectrum of the torus, not only lambda_2.
"""
import sys, os, json, itertools
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
import lib

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "out")


def main():
    log = []
    cases = {
        "square S={+-e1,+-e2}": [(1, 0), (-1, 0), (0, 1), (0, -1)],
        "triangular S={+-e1,+-e2,+-(1,1)}": [(1, 0), (-1, 0), (0, 1), (0, -1),
                                             (1, 1), (-1, -1)],
    }
    for name, S in cases.items():
        G = sum(np.outer(np.array(s, float), np.array(s, float)) for s in S)
        log.append(f"\n{name}: G = {G.tolist()}")
        R = 3
        vals = sorted((int(z @ G @ z), z) for z in itertools.product(range(-R, R+1), repeat=2)
                      if z != (0, 0))
        log.append("  smallest values of z^T G z with multiplicity (successive "
                   "minima of the form):")
        log.append("   " + ", ".join(str(v) for v, _ in vals[:16]))
        n = 24
        pts = np.array(list(itertools.product(range(n), repeat=2)), dtype=float)/n
        spec = np.sort(np.cos(2*np.pi*pts @ np.array(S, float).T).sum(axis=1))[::-1]
        top = spec[0]
        gaps = top - spec[1:13]
        pred = [2*np.pi**2*v/n**2 for v, _ in vals[:12]]
        log.append(f"  n = {n}: exact gaps d - lambda_j for j = 2..13 and the "
                   f"successive-minima prediction")
        log.append("   exact      " + " ".join(f"{g:.6e}" for g in gaps))
        log.append("   predicted  " + " ".join(f"{g:.6e}" for g in pred))
        log.append("   ratio      " + " ".join(f"{g/p:.6f}" for g, p in zip(gaps, pred)))
    txt = "\n".join(log)
    open(os.path.join(OUT, "s08_higher_gaps.log"), "w").write(txt)
    print(txt)


if __name__ == "__main__":
    main()
