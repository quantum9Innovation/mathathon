"""Shared helpers for the one-sided spectra experiments (member m2, direction d6)."""
import numpy as np
import scipy.sparse as sp
import scipy.sparse.linalg as spla


def perm_digraph(k, n, rng):
    """k-regular digraph: sum of k independent uniform permutation matrices (0/1 matrix)."""
    A = np.zeros((n, n), dtype=np.int8)
    for _ in range(k):
        p = rng.permutation(n)
        A[np.arange(n), p] += 1
    return A


def biadjacency_to_digraph(X):
    """(2m)x(2m) adjacency of the bipartite digraph with all arcs left->right."""
    m = X.shape[0]
    A = np.zeros((2 * m, 2 * m), dtype=np.int8)
    A[:m, m:] = X
    return A


def hashimoto(G):
    """Hashimoto (non-backtracking) matrix of an undirected simple graph given as
    a list of edges.  Rows/cols indexed by directed edges (u,v); entry 1 when
    (u,v)->(v,w) with w != u."""
    arcs = []
    for (u, v) in G:
        arcs.append((u, v)); arcs.append((v, u))
    idx = {a: i for i, a in enumerate(arcs)}
    B = np.zeros((len(arcs), len(arcs)))
    for (u, v) in arcs:
        for w in [z for z in neighbors(G, v) if z != u]:
            B[idx[(u, v)], idx[(v, w)]] += 1
    return B, arcs


def neighbors(G, v):
    out = []
    for (a, b) in G:
        if a == v: out.append(b)
        elif b == v: out.append(a)
    return out


def adj_undirected(G, n):
    A = np.zeros((n, n))
    for (a, b) in G:
        A[a, b] += 1; A[b, a] += 1
    return A


def top_eigs(A, howmany=8, sparse_ok=True, n_dense_limit=700):
    """Return eigenvalues sorted by decreasing modulus (largest few)."""
    n = A.shape[0]
    if (not sparse_ok) or n <= n_dense_limit:
        w = np.linalg.eigvals(A.astype(float))
        order = np.argsort(-np.abs(w))
        return w[order][:howmany], w
    A = sp.csr_matrix(A.astype(float))
    w = spla.eigs(A, k=howmany, which='LM', return_eigenvectors=False, maxiter=5000, tol=1e-9)
    order = np.argsort(-np.abs(w))
    return w[order], w


def top_singular(A, howmany=4, n_dense_limit=700):
    n = A.shape[0]
    if n <= n_dense_limit:
        s = np.linalg.svd(A.astype(float), compute_uv=False)
        return s[:howmany]
    A = sp.csr_matrix(A.astype(float))
    s = spla.svds(A, k=howmany, which='LM', return_singular_vectors=False, maxiter=20000, tol=1e-10)
    return np.sort(s)[::-1]
