# 4. Open directions: three precise targets

The exact results in file 03 close the questions they touch. They also point at three targets that
are not closed. O1 is the main one and it is the natural meeting point of all four local dossiers.
O2 is the technical core of O1. O3 is the correct replacement for "the gaps `d - lambda_3` and
`d - lambda_4`" once the threshold question is settled.

---

## O1. Relative Alon-Boppana for random regular hypergraph lifts

### The question

Fix a connected `(d,k)`-regular hypergraph `B` with `d,k >= 2` and `d(k-1) > k`, and let `H` be a
uniform random `N`-fold lift of `B`, that is a uniform random `Z_N`-cover of the incidence graph
`B_H = Inc(B)` that preserves the bipartition (equivalently, a random cover in the hypergraph sense of
Song-Fan-Miao Definition 1.1, so each edge lifts to `N` edges and each vertex to `N` vertices).
"New" means: the eigenvalues of `A_H` that are not eigenvalues of `A_B`, using the exact splitting
`spec(A_H) = spec(A_B) union spec(new)` which holds as multisets by Song-Fan-Miao Theorem 1.3.

**Conjecture O1.** For every connected `(d,k)`-regular `B` with `d(k-1) > k` and every `eps > 0`
there are `C = C(B,eps)` and `eta = eta(B) > 0` such that

```
Pr[ there is a new eigenvalue lambda of A_H with lambda > k - 2 + 2 sqrt((d-1)(k-1)) + eps ]
   <= C N^(-eta).
```

The eventual optimum is `eta = eta_fund(B)`, the least order of a strict feasible `B`-tangle in a
hypergraph sense that is not yet defined in the literature (see O2).

### What is known, and why this is not in the literature

* The `N = 2` case with the upper bound only: **known**. Song-Fan-Miao Theorem 1.6 obtains a
  right-sided Ramanujan 2-covering of every connected `(d,r)`-regular hypergraph, by an interlacing
  family of polynomials in the style of Marcus-Spielman-Srivastava. That is an existence statement
  for one cover. It says nothing about a random cover and nothing about a probability exponent.
* The `N = 2` case with the lower bound: **settled here** for `d = k` (T10 and T15: automatic) and
  for `d < k` (T12: impossible). So Conjecture O1 for `N = 2` and `d = k` reduces to the upper bound.
* The upper bound in the *absolute* setting: **known**. Dumitriu-Zhu Theorem 4.3 (through the
  biregular theorem of Brito-Dumitriu-Decker Harris).
* The general random-lift setting for hypergraphs: **not found**. The arXiv API query
  `abs:"random lift" AND abs:hypergraph` returns zero results (2026-11-14). The whole
  Broder-Shamir / Bilu-Linial / Friedman-Kohler / Bordenave apparatus is for graphs.
* The threshold cannot be improved: by T13 the base Hashimoto Perron value is exactly `sqrt(ab)`,
  the same as the universal cover, so `sqrt(rho_1) = (ab)^(1/4)` and no relative gain in the
  threshold is available. So O1 is a statement about the exponent, and only about the exponent.

### The reduction chain, with the exact conversion

**Step 1 (exact transport, done).** `A_H + d I = X_H X_H^T` and `A_B + d I = X_B X_B^T` (T1). The
cover projection `pi : V(H) -> V(B)` makes `Z_N` act freely on the fibres, `X_H` commutes with the
action, and the `X_B`-spectrum is exactly the trivial-isotypic part. So new singular values of `X_H`
correspond to new eigenvalues of `A_H` through `sigma^2 = d + lambda` (T3). Both statements are
exact and need no analysis.

**Step 2 (base threshold pinned, done).** By T13, `rho(Hash(B_H)) = sqrt(ab)` exactly. So the
relative Hashimoto threshold is `(ab)^(1/4)`, the same as the absolute one.

**Step 3 (the published lift theorem, [SECONDARY]).** Bordenave's Theorem 23 (arXiv:1502.04482v4,
as described in the local dossier) states that for a uniform random `N`-fold lift of a connected base
graph `G_0` with `|E| > |V|`, the largest new Hashimoto eigenvalue satisfies
`|lambda_1| <= sqrt(rho_1) + o(1)` with probability tending to 1, where `rho_1` is the Perron value of
the base Hashimoto matrix. Applied to `G_0 = Inc(B)` this gives: every new Hashimoto eigenvalue `mu`
of the cover satisfies `|mu| <= (ab)^(1/4) + o(1)`. The hypothesis `|E| > |V|` for `Inc(B)` is
`n d > n + m`, i.e. `d(k-1) > k`, which holds for all `d,k >= 2` except `d = 1` and `(d,k) = (2,2)`.
**I did not re-check this theorem against Bordenave's PDF in this run.** It is the load-bearing
external input of O1 and must be verified before O1 can be claimed.

**Step 4 (the conversion, exact).** For a real Hashimoto eigenvalue `mu` of a `(d,k)`-biregular
graph, the associated singular value is

```
xi = sqrt( mu^2 + ab/mu^2 + a + b ),
```

from the biregular Ihara-Bass quartic `x^2 - (y - a - b)x + ab = 0` with `x = mu^2`, `y = xi^2`.
The map `mu |-> xi` is decreasing in `|mu|` on `(0, (ab)^(1/4))` and increasing on
`((ab)^(1/4), sqrt(ab))`, has its minimum `sqrt(a)+sqrt(b)` at `|mu| = (ab)^(1/4)`, and satisfies
`xi = sqrt(dk)` at `|mu| in {1, sqrt(ab)}`. The consequences, which are the ones that matter:

* non-real Hashimoto eigenvalues of a `(d,k)`-biregular graph have modulus exactly `(ab)^(1/4)`,
  because for `y in ((sqrt a - sqrt b)^2, (sqrt a + sqrt b)^2)` the quadratic in `x` has complex
  conjugate roots whose product is `ab`,
* a singular value in `(sqrt a + sqrt b, sqrt(dk)]` is equivalent to a **real** Hashimoto eigenvalue
  of modulus in `((ab)^(1/4), sqrt(ab))`,
* a singular value below `|sqrt a - sqrt b|` is equivalent to a real Hashimoto eigenvalue of modulus
  in `(1, (ab)^(1/4))`.

So `|mu| <= (ab)^(1/4) + eps` for all new real Hashimoto eigenvalues gives
`lambda <= k - 2 + 2 sqrt((d-1)(k-1)) + O(eps)` for all new eigenvalues of `A_H`, and the converse
also holds. **This step is exact and is the part most likely to be got wrong.** Note in particular
that a bound of the form `|mu| <= (ab)^(1/4)` does not by itself bound `xi`, because the map is
decreasing below `(ab)^(1/4)`. One must either rule out real new eigenvalues of modulus below
`(ab)^(1/4)` (they would correspond to singular values below `|sqrt a - sqrt b|`, which are excluded
by the lower Alon-Boppana side of the biregular theorem) or argue the two-sided range directly.

### The single hardest missing lemma

**Lemma needed (blockwise biregular Ihara-Bass).** Let `B` be connected `(d,k)`-regular and let
`H -> B` be a `Z_N`-cover with character group `Z_N^`. For each character `chi` let `Hash_chi`,
`A_chi`, `X_chi` be the `chi`-isotypic blocks of the Hashimoto operator, the adjacency of `Inc(B)`,
and the incidence matrix. Then for every `chi` and every `lam`,

```
det(lam I - Hash_chi) = (lam^2 - 1)^(|E(B_H)| - |V(B_H)|) det(lam^2 I - lam A_chi + (D - I)),
```

with `D - I = diag(d-1 on the vertex side, k-1 on the edge side)`, so that specialising the second
factor to the biregular block structure gives `x^2 - (y_chi - a - b)x + ab = 0` with `x` an
eigenvalue of `Hash_chi^2` and `y_chi` a singular value of `X_chi^2`.

*Why this is the hard part.* The un-blocked identity is a classical determinant computation. What is
not automatic is the exponent `|E| - |V|`: for the trivial character the block is the base graph and
the exponent is `|E(B)| - |V(B)|`, while for a nontrivial character the block is a matrix-weighted
"graph" and the naive count would give `N(|E| - |V|)`. The correct statement is that the exponent is
`|E(B)| - |V(B)|` for every character, because the `(lam^2-1)` factor counts the excess of edge
variables over vertex variables in the ascending/descending operators, and that count is per-block.
For abelian covers of graphs this is the content of the Stark-Terras factorization of the Ihara zeta
function of a cover (H. M. Stark and A. A. Terras, *Zeta functions of finite graphs and coverings*,
Adv. Math. 121 (1996), and the subsequent papers in that series). I have not verified that the
biregular specialisation with the shifted degree matrix `D - I` appears in that literature, and I have
not proved it. **This is the one place where the argument can fail.**

*The fallback if the lemma is false or unproven.* Replace Step 3 plus Step 4 by a direct variational
argument. Given new vectors `f` on the edge fibres and `g` on the vertex fibres with `X_H f = xi g` and
`X_H^T g = xi f`, build a test function on the directed edges of the cover and compute its Hashimoto
Rayleigh quotient. The needed estimate is a lower bound

```
max over directed-edge test functions phi built from (f,g) of   <phi, Hash phi> / <phi, phi>
   >= (ab)^(1/4) + c (xi - sqrt a - sqrt b),
```

uniformly in the character, for an explicit small constant `c = c(d,k) > 0`. This is finite
dimensional and could in principle be done by hand, and it avoids the character bookkeeping entirely.
I did not attempt it. It is the second thing I would try.

### Falsification plan

* Find a base `B` and a sequence `N -> infinity` of lifts with a new eigenvalue
  `lambda > k-2+2t + eps` with probability at least `N^(-eta)` for a small `eta`, ideally not
  vanishing. This would not refute O1 for large `eta` but would pin the exponent. A clean refutation
  would be a base with a new eigenvalue above the edge with probability bounded below.
* Test the extreme case `N = 2` exhaustively against the claim "some signing is right-sided
  Ramanujan". Song-Fan-Miao Theorem 1.6 guarantees this exists, and my enumerations confirm it:
  e.g. 109 of 128 covers of `H(6,3)`, 878 of 1024 covers of `H(9,3)`, 7441 of 8192 covers of a
  random `(3,3)` base. If a base were found where no 2-cover is right-sided Ramanujan, either that
  theorem or my signed-matrix model is wrong, and I would first check the model.
* Compute the empirical exponent for a fixed base: for `N = 2^j`, `j <= 10`, estimate
  `Pr[new eigenvalue > edge + eps]` and fit a power of `N`. A base with small fundamental order
  would show a clean slope.

### What would decide it

A proof of the blockwise lemma above settles O1 at the `N^(-1)` level with `eta = 1` for every base,
because Step 3 gives probability `1 - o(1)` with an explicit `N^(-1)` rate for graphs. Getting the
base-dependent exponent `eta_fund(B) > 1` then needs O2. Conversely, a counterexample to the
blockwise lemma (a character for which the exponent differs) would not necessarily refute O1, but it
would force the variational route.

---

## O2. The hypergraph fundamental order: what replaces the tangle calculus

In the Friedman-Kohler framework the exponent in O1 is the least order `-chi(psi) = |E| - |V|` of a
strict feasible tangle `psi`, that is a finite piece with degrees bounded by `d` whose
"irreducible" growth strictly exceeds the critical value `sqrt(d-1)`. For hypergraphs the critical
value becomes `(ab)^(1/4)` and the pieces are finite hypergraphs with boundary degrees bounded by `d`
on the vertex side and `k` on the edge side.

**The first unsolved computation.** Take the simplest candidate piece: a single `k`-edge `e` with
`k` vertices of degree `1` in the piece and residual capacity `d-1` at each vertex. Its `2`-section is
the complete graph `K_k`, with spectral radius `k-1`. Compare with the target value:
`k-1 < k-2+2 sqrt((d-1)(k-1))` if and only if `2t > 1`, which holds for every `d,k >= 2`. So by the
naive spectral-radius comparison a single edge is **subcritical**, and it is not a tangle. But the
tangle criterion in the Friedman-Kohler machinery is not the raw spectral radius, it is the growth
rate of irreducible (non-backtracking, boundary-avoiding) walks through the piece. For `k >= 3` the
piece already contains a `k`-clique, so it has short cycles and the "irreducible" operator is not the
`2`-section operator. Computing the irreducible growth rate of the one-edge completion, and then of
the two-edge and "cycle" completions, is the concrete technical step that O2 needs and that I did not
carry out.

**Why it is worth doing.** The answer determines `eta_fund(B)` and therefore the exact exponent in
O1, and it is the hypergraph analogue of the tangle classification that Friedman and Friedman-Kohler
had to perform, in which the answer for graphs is a two-loop vertex or a short cycle depending on the
model. The `k`-clique structure means the hypergraph answer will be qualitatively different from the
graph answer, and this is precisely the "missing connection" that the four dossiers do not contain.

**A cheap sanity check that could be done immediately.** For `d = 2` and `k = 3`, the local limit is
the `2`-section of the `(2,3)`-biregular tree, whose critical value is `(ab)^(1/4) = 2^(1/4) = 1.189`.
Since `d = 2`, a finite piece can have degree at most `2` at each vertex, so the only possible
degenerate pieces are single edges and pairs of edges. Enumerating those two cases exactly is a
finite computation and would give `eta_fund` for every `(2,3)`-regular base. This is the smallest
case in which the hypergraph tangle calculus can be tested against the graph one.

---

## O3. Beyond `lambda_2`: fluctuations, not thresholds

The question "what are the gaps `d - lambda_3` and `d - lambda_4`" has a threshold answer which is
degenerate (T8: there is no second forced value at the top, so `lambda_3` and `lambda_4` are not
distinguished from `lambda_2` by structure). But it has a non-degenerate answer as a *fluctuation*
question, and that is arguably what "beyond `lambda_2`" should mean.

**Question O3.** For a uniform random `(d,k)`-regular hypergraph with `d,k` fixed and `n -> infinity`,
what is the joint limiting law of the top few nontrivial eigenvalues of `A_H`, rescaled at the edge
`k-2+2t` at rate `n^(-2/3)`? Is it the GOE Tracy-Widom law, as for Wigner matrices, or does the
`k`-clique structure of the local limit change the edge law?

**Why it is unclear.** Random regular graphs are locally trees, and the Kesten-McKay measure has a
square-root edge, the same edge exponent as Wigner. The Feng-Li operator of a random regular
hypergraph has a local limit which is not a tree but a tree of cliques, and the limiting spectral
measure is the Godsil-Mohar pushforward, whose density near the edge can be computed from the
Godsil-Mohar formula. The vanishing order of that density at the edge decides the `n^(-2/3)` scaling,
and it is not the same as for Kesten-McKay. So the first step is a computation, not an analysis.

**First step (concrete and cheap).** Expand the Godsil-Mohar density near `y = (sqrt a + sqrt b)^2`
and near `y = (sqrt a - sqrt b)^2`, and read off the edge exponent. For `a = b` (so `d = k`) the
measure is the pushforward of the Kesten-McKay measure and the exponent should be `1/2`. For `a != b`
the density near the upper edge has the form `(const) times sqrt((sqrt a + sqrt b)^2 - y)` divided by
a factor that may vanish, and the ratio `d_1/d_2` enters. I did not carry this out.

**Why it is a real research direction and not a technicality.** If the edge exponent differs from
`1/2`, then the top eigenvalues of random regular hypergraphs fluctuate at a rate different from
`n^(-2/3)`, and every threshold statement of the form `lambda_k <= edge + eps` is then at the wrong
scale for `k` fixed. That is the precise sense in which "the gap at index 3 or 4" is the wrong
object: the right object is the joint law at the edge, and it is not yet known.

**Caveat.** I did not verify the state of the art for the `k = 2` case (random regular graphs), so I
do not claim that O3 is open even for `k = 2`. It should be checked before investing.

---

## 4.4 Prioritised next steps

In the order I would actually do them, cheapest decisive item first.

1. **Check Bordenave Theorem 23 against arXiv:1502.04482v4.** It is the single load-bearing
   external input of O1 and I only have it second hand. Cost: one hour. A mismatch in hypotheses
   (in particular the exact meaning of "new" and the `|E| > |V|` requirement) would force reworking
   O1.
2. **Test the blockwise biregular Ihara-Bass lemma numerically on a `Z_3` cover.** Take a small base
   with `d(k-1) > k` and `|E| - |V| != 0` for `Inc(B)` (so the exponent is nonzero and a wrong
   exponent shows), compute the three character blocks of `Hash` by Fourier transform over `Z_3`, and
   compare `det(lam I - Hash_chi)` with `(lam^2-1)^(|E(B)|-|V(B)|) det(lam^2 I - lam A_chi + (D-I))`
   at several complex `lam`. This is a finite linear-algebra computation and it settles the hardest
   missing lemma of O1 either way. Cost: half a day.
3. **Compute the Godsil-Mohar edge exponent.** Expand the density of the limiting spectral measure of
   `A_H` near `y = (sqrt a + sqrt b)^2` in closed form and read off the vanishing order. This decides
   whether the edge fluctuations of O3 are at `n^(-2/3)` or at a different scale, and therefore
   whether O3 is even the right question. Cost: one day with sympy.
4. **Enumerate the `(2,3)` tangles.** Pieces with degrees at most `2` on the vertex side are unions of
   at most two edges through any vertex, so the irreducible growth of every candidate piece can be
   computed by hand or by a short enumeration. This gives `eta_fund` for every `(2,3)`-regular base
   and is the smallest test of the hypergraph tangle calculus of O2. Cost: one day.
5. **Close the `r < m` gap in T12.** Characterise the `(d,k)`-regular hypergraphs with `d < k` whose
   incidence matrix does not have full row rank. By T1 applied to the dual hypergraph this is the
   same as characterising those whose dual has `-k` as an eigenvalue. Cost: a week, and possibly a
   paper.
6. **Equality case of T15.** `mult_S(-d) > 0` if and only if `ker Xtilde^T != 0`. Characterising the
   signings with a nontrivial kernel would sharpen the left-sided statement of T10 from "automatic"
   to "automatic with an exact count". Cost: a week.
