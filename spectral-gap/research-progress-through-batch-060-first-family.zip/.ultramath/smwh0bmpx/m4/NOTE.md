# Batch 060 / member m4 / direction d1
## Adjacent-pair clustered attachment: the complete secular, root and eigenvalue law

**Status.** Theorems A–D below are complete proofs for one explicitly clustered family,
$T=\{c,u\}$ with $\rho(c,u)=1$. Nothing in them is inferred from the separated model.
Theorem A (resolvent limit) is proved from scratch by the rank-one Perron splitting with the
*finite off-diagonal pattern terms kept*. Theorem B is the exact root law. Theorem C is the
limiting eigenvalue law with all special cases. Theorem D is the $1/n$ displacement at the
host Perron point, derived (not obtained by substituting $\Delta$ into batch 050's constant).
Every algebraic identity used is verified in exact arithmetic (`exact_checks*.py`,
`out/exact_checks*.txt`) and the numerical corroboration is in `numerics.py`,
`numerics2.py`, `out/*.json`. The one thing **not** proved is stated in §10.

Legend: **(P)** proved here, **(C)** exact computation (symbolic or rational),
**(N)** numerics (corroboration only), **(L)** literature import with hypotheses checked.

---

## 0. The results

Fix $d\ge 3$. Let $G_n$ be uniform among simple $d$-regular graphs on $[n]$, $nd$ even.
Let $c$ be a fixed label and $u_n$ the least-labelled neighbour of $c$; put $T_n=\{c,u_n\}$
(a deterministic function of the labelled radius-$1$ neighbourhood of $c$, so it is an
admissible pattern in the sense of the target file). Let $G'_n$ be $G_n$ plus one new vertex
$x$ adjacent to exactly $c$ and $u_n$. Write $A=A_{G_n}$, $A^{+}=A_{G'_n}$, and
$\mathbf 1_T=\mathbf 1_{T_n}$. Let
$r(\lambda)=\big(\lambda-\sqrt{\lambda^2-4(d-1)}\big)/(2(d-1))$ be the root of
$(d-1)r+1/r=\lambda$ with $|r|<1/\sqrt{d-1}$, and $G_d(\lambda)=r/(1-r^2)$.

**Theorem A (resolvent limit; (P)).** For every compact
$K\subset(2\sqrt{d-1},d)\cup(d,\infty)$ there are $C=C(d,K)$ and events $\Omega_n$ with
$\mathbb P(\Omega_n)\ge 1-Cn^{-3/4}$ such that on $\Omega_n$, for all $\lambda\in K$,
$$
\Big|\mathbf 1_T^\top(A-\lambda I)^{-1}\mathbf 1_T+\frac{2r(\lambda)}{1-r(\lambda)}\Big|
\;\le\;\frac{4}{n|d-\lambda|}+\frac{4}{n\lambda_{\min}}+\frac{4\rho_\ast^{L_n}}{\lambda_{\min}(1-\rho_\ast)}+\frac{4\rho_1^{L_n}}{\lambda_{\min}(1-\rho_1)}+\frac{4}{n\lambda_{\min}}\sum_{k<L_n}\Big(\frac d{\lambda_{\min}}\Big)^{k},
\qquad L_n=\lfloor\tfrac18\log_{d-1}n\rfloor,
$$
with $\rho_1=2\sqrt{d-1}/\lambda_{\min}<1$, $\rho_\ast=(\lambda_{\min}+2\sqrt{d-1})/(2\lambda_{\min})<1$.
Hence convergence to
$$K_{\rm adj}(\lambda):=\frac{2r(\lambda)}{1-r(\lambda)}=G_d(\lambda)\big(2+2r(\lambda)\big)$$
holds uniformly on $K$, with probability $\to1$. Moreover the exact splitting is (corrected
form; the batch 050 display omits the last term, see `ERRATUM-050-rank-one-resolvent-identity.md`)
$$
\mathbf 1_T^\top(A-\lambda I)^{-1}\mathbf 1_T=\frac{4}{n(d-\lambda)}-\sum_{k\ge0}\frac{\mathbf 1_T^\top A'^k\mathbf 1_T}{\lambda^{k+1}}+\frac{4}{n\lambda},
\qquad A'=A-dP,\; P=\tfrac1n\mathbf 1\mathbf 1^\top .
$$

**Theorem B (exact root law of the pattern limit; (P),(C)).** Put
$\Phi_{\rm adj}(\lambda)=\lambda-K_{\rm adj}(\lambda)$ on $(2\sqrt{d-1},\infty)$.
1. $\Phi_{\rm adj}'( \lambda)=1+\dfrac{2r(\lambda)^2}{(1-r(\lambda))^2\big(1-(d-1)r(\lambda)^2\big)}>0$.
   So $\Phi_{\rm adj}$ is a real-analytic strictly increasing bijection onto
   $(\Phi_{\rm adj}(b),\infty)$, $b=2\sqrt{d-1}$, and **no exterior root is ever repeated**.
2. $K_{\rm adj}(b)=\dfrac{2}{\sqrt{d-1}-1}$ and
   $\Phi_{\rm adj}(b)=\dfrac{2(d-\sqrt{d-1}-2)}{\sqrt{d-1}-1}$.
3. $\Phi_{\rm adj}(b)<0\iff\sqrt{d-1}<\varphi=\frac{1+\sqrt5}{2}\iff d<d_c:=\frac{5+\sqrt5}{2}=3.6180\ldots$
   Therefore, **among integers $d\ge3$, $\Phi_{\rm adj}$ has an exterior root if and only if
   $d=3$**, and then it is unique, simple, and lies in $(b,d)$:
   $$\lambda_\star=2.8751297941627788\ldots,\qquad \lambda_\star-b=0.046702669\ldots,\qquad \Phi_{\rm adj}'(\lambda_\star)=14.579\ldots$$
   exactly: $r_\star=\sqrt[3]{\tfrac14+\sqrt{\tfrac{29}{432}}}+\sqrt[3]{\tfrac14-\sqrt{\tfrac{29}{432}}}=0.5897545\ldots$
   is the unique real root of $2r^3+r-1=0$ and $\lambda_\star=2r_\star+1/r_\star$
   (equivalently the unique real root of $\lambda^3-\lambda^2-4\lambda-4=0$).
   For $d\ge4$, $\Phi_{\rm adj}>0$ on all of $(b,\infty)$: no exterior root.

**Theorem C (limiting eigenvalues; (P)).** Assume $G_n$ connected (probability $\to1$). Then
$d\notin\sigma(A^+)$, and in probability
$$\lambda_1(G'_n)\longrightarrow d,\qquad
\lambda_2(G'_n)\longrightarrow\lambda_{\rm adj}:=\begin{cases}\lambda_\star=2.875129\ldots,&d=3,\\[2pt] 2\sqrt{d-1},&d\ge4,\end{cases}$$
i.e. $\lambda_1\to\max(d,\lambda_{\rm adj})$, $\lambda_2\to\min(d,\lambda_{\rm adj})$ with
$\lambda_{\rm adj}=\lambda_\star$ if an exterior root exists and $=b$ if not. Moreover
$\lambda_1(G'_n)>d>\lambda_2(G'_n)$ for every $n$, and $\lambda_3(G'_n)\le\lambda_2(G_n)$.

**Theorem D ($1/n$ displacement at the Perron point; (P)).** For every $d\ge3$,
$$n\big(\lambda_1(G'_n)-d\big)\longrightarrow\frac{4}{\Phi_{\rm adj}(d)}=\frac{4(d-2)}{d^2-2d-2}$$
in probability (the denominator never vanishes: $d^2-2d-2=0$ has only the irrational roots
$1\pm\sqrt3$). E.g. $d=3$: limit $4$; $d=4$: $4/3$. The separated pair with the *same*
$\Delta=2$ has limits $12/5$ and $16/13$ instead — the constant is pattern-dependent and is
*derived* here, not obtained by substituting $\Delta=2$ in batch 050's formula.

**Sharp separation from the separated model.** With the same $d=3$ and the same
$|T|=\Delta=2$, batch 050 gives $\Delta\le2(d-2)$, i.e. **no** exterior root, hence
$\lambda_2\to2\sqrt2=2.8284$. The adjacent pair gives $\lambda_2\to2.8751$. The two
predictions differ by $0.0467$, five times the observed seed standard deviation at $n=8000$
(§9). This is the quantitative content of "clustered attachment changes the law".

---

## 1. Setting, conventions, and the two branch warnings

Throughout, $(z-A)^{-1}$ is the resolvent; $F_n(z):=\mathbf 1_T^\top(z-A)^{-1}\mathbf 1_T$ and
$\Sigma_n(z):=z-F_n(z)$. Both conventions appear in the input files; the dictionary is
$\mathbf 1_T^\top(A-\lambda I)^{-1}\mathbf 1_T=-F_n(\lambda)$.

$r(z)$: the root of $(d-1)r+1/r=z$ with $|r(z)|<1/\sqrt{d-1}$; for $z>2\sqrt{d-1}$ it is real
with $0<r(z)<1/\sqrt{d-1}\le1/\sqrt2$, strictly decreasing in $z$, and $r(z)\to0$ as $z\to\infty$.
$G_d(z)=r/(1-r^2)=1/(z-dr)$, so $G_d>0$ on $(b,\infty)$ and $G_d(z)\sim1/z$.
The map $\lambda\mapsto r(\lambda)$ is a decreasing bijection $(b,\infty)\to(0,1/\sqrt{d-1})$
and $\lambda(r)=(d-1)r+1/r$ is its inverse.

*Warning 1 (full transform).* $G_d\ne r$: never use the one-sided branch (batch 050, §6.3).
*Warning 2 (branch, not algebra).* Any elimination of $r$ produces roots that may belong to
the **large** branch $r\mapsto1/((d-1)r)$; those are not secular roots. See §5.3.

---

## 2. Exact pattern algebra: the kernel and its poles  ((C), all identities checked symbolically)

**Lemma 2.1 (one-sided self-energy).** Let $D$ be the half-tree (root $o$ with $d-1$ children,
each rooting a copy of $D$). For $z\notin[-2\sqrt{d-1},2\sqrt{d-1}]$,
$$\big(z-A_D\big)^{-1}_{oo}=r(z).$$
*Proof.* Both sides are the unique $\ell^2$ solution of the corresponding equation: an
eigenvector-type argument gives $\gamma=1/(z-(d-1)\gamma)$, i.e. $(d-1)\gamma^2-z\gamma+1=0$,
whose roots are $r$ and $1/((d-1)r)$; only $|r|<1/\sqrt{d-1}$ makes the geometric profile
$\gamma^{\rm depth}$ square summable. $\square$

**Lemma 2.2 (two-point Green function; (C)).** On the infinite $d$-regular tree $T_d$,
$$\big(z-A_{T_d}\big)^{-1}_{sv}=G_d(z)\,r(z)^{{\rm dist}(s,v)} .$$
*Proof.* For fixed $s$ put $h(v)=G_d r^{{\rm dist}(s,v)}$. The profile is in $\ell^2$ because
$\#\{v:{\rm dist}(s,v)=j\}\le d(d-1)^{j-1}$ and $(d-1)r^2<1$. For $v\ne s$ at distance $j\ge1$
the neighbours sit at distances $j-1$ and $j+1$, so
$\sum_{w\sim v}h(w)=r^{j-1}+(d-1)r^{j+1}=r^{j}\big(r^{-1}+(d-1)r\big)=z\,r^j$. At $v=s$:
$zh(s)-\sum_{w\sim s}h(w)=zG_d-d\,G_d r=G_d(z-dr)=1$. Since $z\notin\sigma(A_{T_d})$ the
$\ell^2$ solution of $(z-A)h=e_s$ is unique. $\square$

**Proposition 2.3 (the pair kernel).** Let the gadget be $c\sim u$ with $c,u$ each carrying
$d-1$ half-trees. For $z$ in the exterior domain,
$$\mathbf 1_{\{c,u\}}^\top(z-A)^{-1}\mathbf 1_{\{c,u\}}=G_d(z)\big(2+2r(z)\big)=\frac{2r(z)}{1-r(z)}=:K_{\rm adj}(z).$$
*Proof 1 (via Lemma 2.2).* $\sum_{s,t\in T}r^{{\rm dist}(s,t)}=r^0+r^1+r^1+r^0=2+2r$, times
$G_d$. *Proof 2 (exact $2\times2$ Schur complement, independent).* Eliminate the $2(d-1)$
half-trees using Lemma 2.1. The Schur complement of $(z-A)$ on $\{c,u\}$ is
$$S=\begin{pmatrix}a&-1\\-1&a\end{pmatrix},\qquad a=z-(d-1)r=\frac1r ,$$
(the last equality is the tree relation), so
$\mathbf 1^\top S^{-1}\mathbf 1=\frac{2a+2}{a^2-1}=\frac{2}{a-1}=\frac{2r}{1-r}$.
Both forms agree because $\frac{2r(1+r)}{1-r^2}=\frac{2r}{1-r}$. sympy: both differences
are identically $0$ (`out/exact_checks.txt` §B). $\square$

**Proposition 2.4 (poles of the algebraic representation vs spectral poles).**
1. $\det S=a^2-1$, so the $2\times2$ representation is singular iff $a=\pm1$ iff $r=\pm1$ iff
   $z=\pm d$, and both solutions sit on the **large** branch. On the exterior branch
   $0<r<1/\sqrt{d-1}<1$, hence $\det S>0$: **$K_{\rm adj}$ has no pole anywhere in
   $[b,\infty)$**, in particular not at $d$.
2. $K_{\rm adj}(d)=2/(d-2)$ (finite, positive for $d\ge3$); $K_{\rm adj}(b)=2/(\sqrt{d-1}-1)$.
3. The **genuine** spectral pole at $z=d$ belongs to the host, not to the pattern: for every
   $n$, $F_n$ has a simple pole at $z=d$ with residue
   $|\langle\mathbf 1_T,\mathbf 1/\sqrt n\rangle|^2=|T|^2/n=4/n$, and the exact split
   $\mathbf 1_T^\top(A-\lambda I)^{-1}\mathbf 1_T=-4/(n(\lambda-d))+\text{(finite)}$ is the
   statement that the Perron term is removed by hand (Theorem A).
*Consequence (the target's demand).* A pole of an algebraic representation is not a spectral
pole and vice versa: here the representation has no pole in the window while the host has a
real Perron pole, and the *removed* object $K_{\rm adj}$ is finite at $d$ with the nonzero
value $2/(d-2)$.

**Correction to the target file (separate erratum, target file left untouched).** The target
states $K_{\rm adj}(b)=2/(1-1/\sqrt{d-1})$. That value is too large by the factor
$\sqrt{d-1}=1/r_b$; the correct value is $2r_b/(1-r_b)=2/(\sqrt{d-1}-1)$ (sympy: the ratio is
exactly $\sqrt{d-1}$). At $d=4$: truth $2.7320508$, stated formula $4.7320508$. This is not
cosmetic: it moves the sign change of $\Phi_{\rm adj}(b)$ from "$d=3,4$ and $d=5$ critical" to
"only $d=3$", i.e. it changes which degrees carry a defect eigenvalue. See
`ERRATUM-060-target-edge-value.md`.

---

## 3. Exact host algebra: the secular function, monotonicity, interlacing  ((P))

**Lemma 3.1 (rank-one splitting; corrected form of batch 050's Lemma 1(iii)).** Let $A$ be the
adjacency of a simple $d$-regular graph, $P=\mathbf 1\mathbf 1^\top/n$, $Q=I-P$, $A'=A-dP$. Then
$PA'=A'P=0$, $A'=QA'Q$, $(A'^k)_{yy'}=(A^k)_{yy'}-d^k/n$ for $k\ge1$, and for
$\lambda\notin\sigma(A)$
$$(A-\lambda I)^{-1}=\frac{P}{d-\lambda}+\frac{P}{\lambda}-\sum_{k\ge0}\frac{A'^k}{\lambda^{k+1}}
=\frac{P}{d-\lambda}+Q\frac{1}{A'-\lambda}Q .$$
*Proof.* $A=dP+A'$ is an orthogonal direct sum on ${\rm span}\{\mathbf 1\}\oplus\mathbf 1^\perp$,
with $A'=0$ on the first summand, so $(A-\lambda I)^{-1}=\frac{P}{d-\lambda}+(A'-\lambda)^{-1}Q$.
On $\mathbf 1^\perp$ one has $-\sum_{k\ge0}A'^k/\lambda^{k+1}=(A'-\lambda)^{-1}$, while on
${\rm span}\{\mathbf 1\}$ the same series equals $-\frac1\lambda P$ (because $A'^k\mathbf 1=0$ for
$k\ge1$ and $A'^0\mathbf 1=\mathbf 1$), which differs from $(A'-\lambda)^{-1}P=0$ by exactly
$+\frac1\lambda P$: hence the $+P/\lambda$. The walk identity is batch 050's induction from
$AJ=JA=dJ$, $J^2=nJ$. $\square$
**Warning (erratum).** The batch 050 / m2 display omits the $+P/\lambda$, i.e. the scalar
relation there is missing $+\frac{|T|^2}{n\lambda}$. It is $O(1/n)$ and changes none of batch
050's limit theorems, but the identity as printed is false; see
`ERRATUM-050-rank-one-resolvent-identity.md` for an exact rational refutation (Petersen graph:
error exactly $|T|^2/(n\lambda)=0.16$ against a rigorous tail bound $6.1\times10^{-6}$) and the
repair. Everything below uses the repaired form.

**Lemma 3.2 (secular identity).** For all $z$,
$\det(z-A^+)=\det(z-A)\,\Sigma_n(z)$, where $\Sigma_n=z-F_n$.
*Proof.* Expand $\det(z-A^+)$ along the added row/column: the $(x,x)$ cofactor gives
$\det(z-A)$ and the rank-two correction gives $-\det(z-A)\sum_{s,t\in T}(z-A)^{-1}_{st}$
(the standard Schur complement for bordering). Verified in exact rational arithmetic on the
Petersen graph at six rational points, including one in a gap: `out/exact_checks.txt` §J
(all six comparisons `EQ=True`). $\square$

**Lemma 3.3 (strict monotonicity).** $F_n(z)=\sum_i a_i/(z-\lambda_i)$ with
$a_i=\langle\mathbf 1_T,v_i\rangle^2\ge0$, $\sum_i a_i=|T|^2=4$, $a_1=4/n>0$. Hence on every
component of $\mathbb R\setminus\sigma(A)$,
$\Sigma_n'(z)=1+\|(z-A)^{-1}\mathbf 1_T\|^2>0$. In particular $\Sigma_n$ has **at most one**
zero in each component and every zero is **simple**; on $(\lambda_2(A),d)$ there are no poles
at all.

**Lemma 3.4 (the Perron point is not an eigenvalue of $A^+$).** If $d$ is a simple eigenvalue
of $A$ (i.e. $G_n$ is connected), then $d\notin\sigma(A^+)$; indeed
$\det(d-A^+)=\frac4n\prod_{i\ge2}(d-\lambda_i)\ne0$.
*Proof.* $F_n(z)=a_1/(z-d)+h(z)$ with $h$ holomorphic near $d$ and $a_1=4/n$; so
$\Sigma_n(z)=\frac{4}{n(z-d)}+(z-h(z))$ has a simple **pole** at $d$, and
$\det(z-A)=(z-d)\prod_{i\ge2}(z-\lambda_i)$; multiply and let $z\to d$. $\square$
(For a disconnected host $d$ has multiplicity $\#$components and $d$ *does* survive in $A^+$;
we work on the connectedness event, which has probability $\to1$.)

**Lemma 3.5 (zeros of $\Sigma_n$ = eigenvalues of $A^+$).** For $z\notin\sigma(A)$:
$z\in\sigma(A^+)\iff\Sigma_n(z)=0$ (Lemma 3.2).

**Lemma 3.6 (root–eigenvalue bookkeeping; no genericity assumed).** Let $G_n$ be connected.
1. $\lambda_1(A^+)$ is the unique zero of $\Sigma_n$ in $(d,\infty)$.
2. If $\lambda_2(A)<x<y<d$ and $\Sigma_n(x)<0<\Sigma_n(y)$, then
   $\lambda_2(A^+)\in(x,y)$.
3. If $\lambda_2(A)<x<d$ and $\Sigma_n>0$ on $[x,d)$, then $\lambda_2(A^+)<x$.
4. Always $\lambda_1(A^+)\ge d\ge\lambda_2(A^+)\ge\lambda_2(A)\ge\lambda_3(A^+)$ (Cauchy
   interlacing, $A$ is a principal submatrix of $A^+$), and $\lambda_1(A^+)>d>\lambda_2(A^+)$.

*Proof.* (1) On $(d,\infty)$, $\Sigma_n$ is holomorphic and strictly increasing (3.3), tends to
$-\infty$ at $d+$ (pole, Lemma 3.4) and to $+\infty$ at $+\infty$; so a unique zero $\zeta$
exists; $\zeta\notin\sigma(A)$ hence $\zeta\in\sigma(A^+)$; any eigenvalue of $A^+$ larger than
$d$ is (by 3.5) a zero, so $\lambda_1(A^+)=\zeta$, and $\lambda_1(A^+)\ge d$ with equality
excluded by Lemma 3.4. (2) Let $\zeta$ be the unique zero in $(x,y)$ (exists by 3.3 +
intermediate value, unique by strict monotonicity). Then $\zeta\in\sigma(A^+)$ and
$\zeta>\lambda_2(A)$, while interlacing gives $\lambda_3(A^+)\le\lambda_2(A)$; so
$\zeta\in\{\lambda_1(A^+),\lambda_2(A^+)\}$, and $\zeta<d<\lambda_1(A^+)$, so
$\zeta=\lambda_2(A^+)$. (3) Suppose $\lambda_2(A^+)\ge x$; then $\lambda_2(A^+)<d$ and
$\lambda_2(A^+)>\lambda_2(A)$, so $\lambda_2(A^+)\notin\sigma(A)$ and Lemma 3.5 gives
$\Sigma_n(\lambda_2(A^+))=0$, contradicting $\Sigma_n>0$ on $[x,d)$. (4) Interlacing is
Cauchy's; strictness follows from Lemma 3.4.
**No hypothesis $a_2>0$ is used anywhere**, so host-eigenvalue multiplicity is handled: if
$\mathbf 1_T\perp v_2$ then $\Sigma_n$ has no pole at $\lambda_2(A)$ and part (3) still gives
the desired upper bound, while part (2) is used only when a genuine sign change is exhibited.

---

## 4. Theorem A: the resolvent limit, with the finite off-diagonal pattern terms kept  ((P))

**Lemma 4.1 (marked tree-embedding event).** Fix $d\ge3$, $c=1$, and
$L_n=\lfloor\frac18\log_{d-1}n\rfloor$. Then
\mathbb P\big(\mathcal E_n\big)\ge1-C_d\,n^{-3/4},\qquad
\mathcal E_n:=\{B_{L_n}(c)\ \text{is a tree}\}\cap\{G_n\ \text{connected}\}\cap\{\|A'\|\le2\sqrt{d-1}+\delta\}$$
for any fixed $\delta>0$ and all large $n$.
*Proof.* (i) Tree-likeness: reveal $B_L(c)$ in the pairing model level by level; at each of the
at most $\sum_{j\le L}d(d-1)^{j}\le 2d(d-1)^{L}$ revelations the partner of an open stub is
uniform among $\ge nd-2R_0$ unmatched stubs of which at most $2R_0$ are forbidden, so
$\mathbb P(B_L(c)\text{ not a tree})\le R_0\cdot 2R_0/(nd-2R_0)=O((d-1)^{2L}/n)=O(n^{-3/4})$
(batch 050 Lemma 3 / m6 Lemma 2, re-instantiated at the single root $c$). Since
$\mathbb P_{\text{uniform}}=\mathbb P_{\text{pairing}}(\cdot\mid\text{simple})$ and
$\mathbb P(\text{simple})\to e^{-(d^2-1)/4}>0$, the bound transfers. (ii) Connectedness:
classical, probability $1-O(1/n)$. (iii) $\|A'\|=\lambda_2\vee|\lambda_n|\le2\sqrt{d-1}+\delta$
with probability $\to1$ by Friedman's theorem in Bordenave's quantitative form
(**(L)** C. Bordenave, arXiv:1502.04482v4, Theorem 1 and Eq. (2): uniform simple $d$-regular,
$d$ fixed $\ge3$, two-sided statement about $\lambda_2\vee|\lambda_n|$; the same import as in
m2/m6, hypotheses identical). Union bound. $\square$

*Remark.* On $\mathcal E_n$ the set $T_n=\{c,u_n\}$ has ${\rm dist}(c,u_n)=1$ and, for every
$k\le L_n-1$, every walk of length $k$ starting in $T_n$ lies in $B_{k+1}(c)\subseteq B_{L_n}(c)$,
which is a tree isometric to the corresponding ball of $T_d$. Hence
$$\mathbf 1_T^\top A^k\mathbf 1_T=\mathbf 1_T^\top A_{T_d}^k\mathbf 1_T\qquad(k\le L_n-1),$$
**including the off-diagonal terms** $(A^k)_{cu}=(A^k_{T_d})_{cu}$, which are nonzero for odd
$k$ (for $k=1$ this is the edge itself). This is exactly where the separated argument does not
apply and where "finite local off-diagonal terms must not be discarded".

*Proof of Theorem A.* Fix $K$ compact in $(b,d)\cup(d,\infty)$, put
$\delta_K=\frac12{\rm dist}(K,\{b,d\})>0$, $\lambda_{\min}=\min K$, and let $\Omega_n$ be
$\mathcal E_n$ of Lemma 4.1 with $\delta=\frac12(\lambda_{\min}-b)$, so that
$\rho_\ast:=(b+\delta)/\lambda_{\min}=(\lambda_{\min}+b)/(2\lambda_{\min})<1$. On $\Omega_n$,
for $\lambda\in K$, Lemma 3.1 (repaired form) and $\mathbf 1_T^\top A'^0\mathbf 1_T=\mathbf 1_T^\top\mathbf 1_T=2$ give
$$
\mathbf 1_T^\top(A-\lambda I)^{-1}\mathbf 1_T
=\frac{4}{n(d-\lambda)}+\frac{4}{n\lambda}-\frac{2}{\lambda}
-\sum_{k=1}^{L_n-1}\frac{\mathbf 1_T^\top A'^k\mathbf 1_T}{\lambda^{k+1}}+R_1,
\qquad R_1:=-\sum_{k\ge L_n}\frac{\mathbf 1_T^\top A'^k\mathbf 1_T}{\lambda^{k+1}} .
$$
On $\mathcal E_n$ Lemma 1(ii) gives $\mathbf 1_T^\top A'^k\mathbf 1_T=\mathbf 1_T^\top A^k\mathbf 1_T-\frac4n d^k$
for $1\le k\le L_n-1$, and $\mathbf 1_T^\top A^k\mathbf 1_T=\mathbf 1_T^\top A_{T_d}^k\mathbf 1_T$; also
$|R_1|\le\frac{2\rho_\ast^{L_n}}{\lambda_{\min}(1-\rho_\ast)}$ because
$|\mathbf 1_T^\top A'^k\mathbf 1_T|\le\|\mathbf 1_T\|^2\|A'\|^k=2\|A'\|^k$. Since
$-K_{\rm adj}(\lambda)=-\frac2\lambda-\sum_{k\ge1}\frac{\mathbf 1_T^\top A_{T_d}^k\mathbf 1_T}{\lambda^{k+1}}$
(absolutely convergent: $\lambda>b=\|A_{T_d}\|$, Proposition 2.3 with Lemma 2.2), the $-\frac2\lambda$
cancels and
$$
\mathbf 1_T^\top(A-\lambda I)^{-1}\mathbf 1_T+K_{\rm adj}(\lambda)
=\underbrace{\frac{4}{n(d-\lambda)}}_{\rm(i)}+\underbrace{\frac{4}{n\lambda}}_{\rm(ii)}
+\underbrace{\sum_{k\ge L_n}\frac{\mathbf 1_T^\top A_{T_d}^k\mathbf 1_T}{\lambda^{k+1}}}_{\rm(iii)}
+\underbrace{\frac4n\sum_{k=1}^{L_n-1}\frac{(d/\lambda)^k}{\lambda}}_{\rm(iv)}+R_1 .
$$
Uniformly in $\lambda\in K$:
(i) $\le\frac{4}{n|d-\lambda|}$; (ii) $\le\frac{4}{n\lambda_{\min}}$;
(iii) $\le\frac{4\rho_1^{L_n}}{\lambda_{\min}(1-\rho_1)}$ with $\rho_1=b/\lambda_{\min}<1$
(because $|\mathbf 1_T^\top A_{T_d}^k\mathbf 1_T|\le2b^k$);
(iv) $\le\frac{4}{n\lambda_{\min}}\sum_{k<L_n}(d/\lambda_{\min})^k$;
and $|R_1|\le\frac{4\rho_\ast^{L_n}}{\lambda_{\min}(1-\rho_\ast)}$.
The only term that is not manifestly $o(1)$ is (iv): if $\lambda_{\min}>d$ then
$d/\lambda_{\min}<1$ and it is $O(L_n/n)$. If $\lambda_{\min}<d$ then
$d/\lambda_{\min}>1$ and (iv) $\le\frac{4}{n\lambda_{\min}}\cdot\frac{(d/\lambda_{\min})^{L_n}}{1-\lambda_{\min}/d}=o(1)$,
because $\frac1n(d/\lambda_{\min})^{L_n}\le n^{\frac18\log d/\log(d-1)-1}=o(1)$ as
$\frac18\frac{\log d}{\log(d-1)}\le\frac18\cdot1.585<1$ for $d\ge3$. Both geometric tails vanish
like $n^{-\gamma}$ since $\rho_1,\rho_\ast<1$ are $n$-independent. Hence the display of
Theorem A holds with $C=C(d,K)$; and $\mathbb P(\Omega_n)\to1$ at rate $n^{-3/4}$ except for
Friedman's term, which is $n^{-a}$ for every fixed $a$.

*Remark 4.2 (why no local-law input is needed, and why no weaker claim suffices).* On
$\Omega_n$, $\|A'\|<\lambda$, so the walk series is *geometrically contracting* and a fixed
pattern sees only the ball of radius $O(\log n)$; this is a genuinely different mechanism from
the bulk, and it is the reason the pattern correction survives (m6 §4, m2 §6.3: local weak
convergence alone would give the spiked-tree value $2\lambda r/(2r-\lambda)$, which is false).

---

## 5. Theorem B: the exact root law  ((P),(C))

### 5.1 Strict monotonicity

$K_{\rm adj}(\lambda)=2r/(1-r)$ with $r=r(\lambda)$ and $\mathrm dr/\mathrm d\lambda=r^2/((d-1)r^2-1)<0$ on $(b,\infty)$. Hence
$$\Phi_{\rm adj}'=1-\frac{\mathrm dK}{\mathrm d\lambda}
=1-\frac{2r^2}{(1-r)^2\big((d-1)r^2-1\big)}
=1+\frac{2r^2}{(1-r)^2\big(1-(d-1)r^2\big)}>0,$$
all factors positive since $0<r<1/\sqrt{d-1}$ (sympy: the difference of the two displayed
forms is identically $0$, `out/exact_checks.txt` §E). So $\Phi_{\rm adj}$ is a strictly
increasing real-analytic bijection $(b,\infty)\to(\Phi_{\rm adj}(b),\infty)$. **A repeated
(exterior) root would need $\Phi_{\rm adj}=\Phi_{\rm adj}'=0$, which is impossible**: the
simple-root premise is proved, not imported. Since $\Phi_{\rm adj}(\lambda)\to+\infty$,
$\Phi_{\rm adj}$ has an exterior root iff $\Phi_{\rm adj}(b)<0$, and then exactly one.

### 5.2 The edge evaluation and the threshold

$r_b=r(b)=1/\sqrt{d-1}$. Using $K_{\rm adj}=2r/(1-r)$:
$K_{\rm adj}(b)=2r_b/(1-r_b)=2/(\sqrt{d-1}-1)$, and
$$\Phi_{\rm adj}(b)=2\sqrt{d-1}-\frac{2}{\sqrt{d-1}-1}=\frac{2\big(d-\sqrt{d-1}-2\big)}{\sqrt{d-1}-1}.$$
With $s=\sqrt{d-1}$: $\Phi_{\rm adj}(b)<0\iff s(s-1)<1\iff s<\varphi\iff d<1+\varphi^2=\frac{5+\sqrt5}2$.
Numerically $\Phi_{\rm adj}(b)=-2.000$ ($d=3$), $+0.732$ ($d=4$), $+2.000$ ($d=5$),
$+2.854$ ($d=6$), and increasing in $d$ thereafter. **So only $d=3$.**
Equivalently, in the language of the pattern distance sum (m6 §4.1(c)): the threshold is
$\sum_{s,t}r_b^{\rho(s,t)}>2(d-2)$, i.e. $2+2/\sqrt{d-1}>2(d-2)$, i.e. $1+1/\sqrt{d-1}>d-2$,
true only for $d=3$. Both routes agree with the exact-kernel route (checked symbolically).

### 5.3 The exact root for $d=3$, and the spurious branch

For $d=3$: $\Phi_{\rm adj}(\lambda)=0\iff P_3(r)=2r^3+r-1=0$, $r\in(0,1/\sqrt2)$
(the identity $\Phi_{\rm adj}(\lambda(r))+P_d(r)/(r(1-r))=0$ is checked symbolically for all
$d$). $P_3'(r)=6r^2+1>0$, so $r_\star$ is the unique real root,
$r_\star=\sqrt[3]{\frac14+\sqrt{\frac{29}{432}}}+\sqrt[3]{\frac14-\sqrt{\frac{29}{432}}}=0.5897545123\ldots<\frac1{\sqrt2}$,
and $\lambda_\star=2r_\star+1/r_\star=2.8751297941627788\ldots\in(2\sqrt2,3)$.
Equivalently $\lambda_\star$ is the unique real root of $\lambda^3-\lambda^2-4\lambda-4=0$
(the other two roots are $-0.9376\pm0.7157i$).

**The elimination trap.** Eliminating $r$ between $\lambda=2r/(1-r)$ and
$\lambda=(d-1)r+1/r$ gives $\lambda^3-(d-2)\lambda^2-4\lambda-4=0$, which for **every** $d\ge3$
has a unique real root exceeding $b$ ($d=4$: $3.4798157$; $d=5$: $4.1843872$; $d=6$:
$4.9673651$). For $d\ge4$ **these are not secular roots**: the elimination uses
$r=\lambda/(\lambda+2)$, and for $d=4$ that equals the *large* root $0.63502$ while the small
root at $\lambda=3.4798$ is $0.52491$; consequently $\Phi_{\rm adj}(3.4798)=+1.270\ne0$. This is
precisely the "pole/root of an algebraic representation is not a spectral statement" warning
in the target, and it is the reason I do the root analysis in the $r$ variable with the branch
condition made explicit.

### 5.4 Order of contact and the critical degree

At the critical real degree $d_c=\frac{5+\sqrt5}2$ one has $\Phi_{\rm adj}(b(d_c);d_c)=0$
exactly, while $\frac{\mathrm d}{\mathrm dd}\Phi_{\rm adj}(b(d);d)|_{d_c}=2.2360679\ldots\ne0$.
Since the edge is a square-root branch point, $K_{\rm adj}(b+u^2)=K_{\rm adj}(b)-C u+O(u^2)$
with $C=2(d-1)^{1/4}/(d-2\sqrt{d-1})$ ($C=6.660$ at $d_c$), so
$\Phi_{\rm adj}(b+\varepsilon)-\Phi_{\rm adj}(b)=-C\sqrt\varepsilon+O(\varepsilon)$: **the
contact at the bulk edge is of order $1/2$** (Hölder-$\frac12$, as in batch 050 correction 4).
Therefore the root displacement from the edge near $d_c$ is quadratic:
$\lambda_\star-b\;\sim\;\big[(\mathrm d\Phi/\mathrm dd)/C\big]^2(d-d_c)^2=0.11271\,(d-d_c)^2$
(numerically $0.1158,0.1144,0.1137,0.1130,0.1127$ at $d=3.4,3.5,3.55,3.6,3.617$: converging).
Hence $d=3$ is *strictly* inside the root region (not a tangency), with the fixed gap
$\lambda_\star-b=0.0467$; the tangent case is never an integer degree.

### 5.5 The Perron point versus a root of the pattern law

$\Phi_{\rm adj}(d)=d-2/(d-2)>0$ for all $d\ge3$; it would vanish only for
$d^2-2d-2=0$, i.e. $d=1\pm\sqrt3$, both irrational. So **the host Perron point is never a root
of the pattern law for integer $d\ge3$** — this is a different equation from batch 050's
(where the exclusion was $\Delta=d^2(d-2)/(d-1)$), and it is proved here rather than inherited.
Note also $\Phi_{\rm adj}(d)>0$ together with strict increase gives immediately: **no exterior
root above $d$ for any $d\ge3$**.

---

## 6. Theorem C: the limiting eigenvalues  ((P))

Fix $\varepsilon>0$ and work on $\Omega_n$ of Lemma 4.1, whose probability is $\ge1-Cn^{-3/4}$;
on it $\lambda_2(A)\le b+\varepsilon$ (Lemma 4.1(iii)).

*The eigenvalue above $d$.* $\Sigma_n$ is strictly increasing on $(d,\infty)$, $\to-\infty$ at
$d+$, $\to+\infty$ at $+\infty$; its unique zero $\zeta_n$ satisfies $\lambda_1(A^+)=\zeta_n$
(Lemma 3.6(1)). Since $\Sigma_n(d+\varepsilon)=\Phi_{\rm adj}(d+\varepsilon)+O(1/n)+o(1)$
(Theorem A, applied on the compact $\{d+\varepsilon\}$; the Perron term is $-4/(n\varepsilon)$)
and $\Phi_{\rm adj}(d+\varepsilon)>0$, we get $\zeta_n\in(d,d+\varepsilon)$ for large $n$.
Hence $\lambda_1(G'_n)\to d$, always, for every $d\ge3$.

*Case $d=3$.* Let $0<\eta<\frac12(\lambda_\star-b)=0.0233$ so that $[\lambda_\star-\eta,\lambda_\star+\eta]\subset(b,d)$.
On that compact Theorem A gives $\sup|\Sigma_n-\Phi_{\rm adj}-\frac4{n(d-\lambda)}-\frac4{n\lambda}|\to0$;
since $\Phi_{\rm adj}<0$ below $\lambda_\star$ and $>0$ above, $\Sigma_n(\lambda_\star-\eta)<0<\Sigma_n(\lambda_\star+\eta)$
for large $n$, and $\lambda_\star-\eta>\lambda_2(A)$. Lemma 3.6(2) gives
$\lambda_2(A^+)\in(\lambda_\star-\eta,\lambda_\star+\eta)$. As $\eta$ is arbitrary,
$\lambda_2(G'_n)\to\lambda_\star$.

*Case $d\ge4$.* Fix $\varepsilon>0$; $\Phi_{\rm adj}>0$ on $[b+\varepsilon,d)$ and, since
$\Sigma_n\to\Phi_{\rm adj}$ uniformly on that compact and $\Sigma_n$ is increasing up to the
pole at $d$, $\Sigma_n>0$ on all of $[b+\varepsilon,d)$ for large $n$ (at $d-\varepsilon'$ by
uniform convergence, on the rest by monotonicity). Lemma 3.6(3) gives $\lambda_2(A^+)<b+\varepsilon$;
interlacing gives $\lambda_2(A^+)\ge\lambda_2(A)\ge b-\varepsilon$. Hence
$\lambda_2(G'_n)\to b=2\sqrt{d-1}$.

Both cases are $\lambda_1\to d$, $\lambda_2\to\lambda_{\rm adj}$, and the special cases are
exhausted: $d=3$ (unique exterior root, simple, inside $(b,d)$), $d\ge4$ (no exterior root),
and $\Phi_{\rm adj}(d)\ne0$ (Perron point never a root) — so there is **no** critical degree,
**no** repeated root, and **no** case with $\lambda_{\rm adj}=d$ in the claimed range. If a
future pattern did produce $\Phi_T(d)=0$, the correct treatment is the one batch 050 used:
both limits equal $d$ and the $1/n$ law degenerates; for the adjacent pair that case is
excluded by the irrationality of $1+\sqrt3$.

## 7. Theorem D: the $1/n$ displacement at the Perron point  ((P))

Let $\lambda=d+s/n$ with $s\in(0,S]$, $S$ fixed. On $\Omega_n$, Theorem A's error terms are
uniform for $\lambda\ge d$ (all ratios of the form $b/\lambda\le b/d<1$, and
$(d/\lambda)^k\le1$), so
$$\Sigma_n(d+s/n)=\Phi_{\rm adj}(d+s/n)+\frac{4}{n(d-\lambda)}+\frac{4}{n\lambda}+O\!\Big(\frac{L_n}{n}\Big)+O(\rho_\ast^{L_n}+\rho_1^{L_n})
=\Phi_{\rm adj}(d)-\frac4s+O(s/n)+O\!\Big(\frac{L_n}{n}\Big)+O\!\Big(\frac1n\Big)+o(1),$$
using $\frac{4}{n(d-\lambda)}=-\frac4s$ for $\lambda=d+s/n$ and $\frac{4}{n\lambda}\le\frac{4}{nd}$;
the truncated $(d/\lambda)$-sum of Theorem A's term (iv) is $\le4L_n/(n\lambda_{\min})$ here
because $d/\lambda\le1$ on this window. The unique zero $\zeta_n=d+s_n/n$ of $\Sigma_n$ in
$(d,\infty)$ therefore satisfies $s_n\to4/\Phi_{\rm adj}(d)=4(d-2)/(d^2-2d-2)$, and
$\zeta_n=\lambda_1(G'_n)$ by Lemma 3.6(1). $\square$

*Comparison (the constants differ, and one must not just substitute $\Delta$).* For a
separated pair, batch 050's formula gives $\Delta^2/(d-\Delta G_d(d))=4/(d-2G_d(d))$, which at
$d=3$ is $12/5$ and at $d=4$ is $16/13$, whereas the clustered pair gives $4$ and $4/3$.
Numerically (`out/numerics_trend.json`): $n(\lambda_1-d)=3.9556\pm0.011$ ($n=4000$, 6 seeds)
and $3.9754\pm0.003$ ($n=8000$, 6 seeds) for $d=3$ vs. the predicted $4$; $1.3317\pm0.001$ for
$d=4$ vs. $4/3$. The separated predictions $2.4$ and $1.2308$ are excluded.

*Why the Perron term is the whole $1/n$ effect.* The only non-geometric error in the
decomposition of Theorem A at $\lambda=d+s/n$ is the explicit $-4/s$; the tree tail and the
$\|A'\|$-tail are $o(1)$, and the "$-4/n\sum(d/\lambda)^k$" sum is $O(L_n/n)$. This is the
clustered analogue of batch 050 §5, with $K_{\rm adj}(d)$ in place of $\Delta G_d(d)$.

---

## 8. Consistency: recovery of the separated-case limit (no rewriting of the frozen proof)

Take instead $T=\{c,w\}$ with ${\rm dist}(c,w)=D$ and let $D\to\infty$. Then
$K=G_d(2+2r^D)\to2G_d=\Delta G_d$ with $\Delta=2$, so Theorem A's limit reduces exactly to
batch 050's $-\Delta G_d$, and the root equation reduces to $\lambda=2G_d(\lambda)$, i.e.
batch 050's $f(\lambda)=0$ with $\Delta=2$ (whose threshold $\Delta>2(d-2)$ is *not* met at
$d=3$ — critical — and not met above). Numerically (`out/numerics_resolvent2.json`) the far
pair at distance $10$ and $13$ reproduces $2G_d+4/(n(\lambda-d))$ to $\le3\cdot10^{-3}$ while
the adjacent pair reproduces $K_{\rm adj}+4/(n(\lambda-d))$, at $\lambda=3.2$: $1.48381$ vs
$1.48581$ predicted (adjacent) and $1.04100$ vs $1.04281$ (far). The frozen batch 050 files are
untouched.

---

## 9. Verification performed

**Exact arithmetic ((C), no floating point in any claimed identity).**
`exact_checks.py`, `exact_checks2.py`, `exact_checks3.py`; logs in `out/exact_checks*.txt`.
(i) one-sided self-energy quadratic and its small-branch selection; (ii) the $2\times2$ Schur
complement $2/(a-1)=2r/(1-r)=G_d(2+2r)$ symbolically for all $d$ (difference identically $0$);
(iii) $\Phi_{\rm adj}(\lambda(r))+P_d(r)/(r(1-r))=0$ identically; (iv) $\Phi_{\rm adj}'$ identity
and positivity; (v) $K_{\rm adj}(b)=2/(\sqrt{d-1}-1)$ and the ratio to the target file's stated
value equals $\sqrt{d-1}$ exactly; (vi) the threshold inequality reduced to $s^2-s-1<0$;
(vii) $\Phi_{\rm adj}(d)=0\iff d=1\pm\sqrt3$; (viii) **finite-ball exact rational check** of
$K_{\rm adj}$: with the exact self-energy recursion
$s_0=1/z$, $s_{k+1}=1/(z-(d-1)s_k)$ and $a_R=z-(d-1)s_R$, the rational number
$2(a_R+1)/(a_R^2-1)$ converges to $2r/(1-r)$ with the predicted ratio $(d-1)r^2$ at every test
$(d,r)\in\{(3,2/5),(4,2/7),(5,1/3),(3,1/2),(6,1/4)\}$ — all in `fractions.Fraction`, no floating
point; the case $(d,r,z)=(3,1/2,3)$ (the Perron point) is exactly $K_R=2-2^{-(R+1)}$, so the
convergence ratio is verified in closed form; (ix) **exact rational check of the repaired rank-one
identity with a rigorous tail bound** (Petersen, $\lambda=5/2$, $\|A'\|=2$): the repaired form
holds to $9.1\cdot10^{-8}$ against the tail bound $6.1\cdot10^{-6}$, while the frozen batch-050
form fails by exactly $0.160=|\mathbf 1_T|^2/(n\lambda)$, i.e. $26\,000$ bound-widths — see
`check_rank_one_identity.py`, `out/rank_one_identity_check.txt` and the erratum; (x) the secular
identity on the Petersen graph at six rational
$\lambda$, all exact matches; (xi) the $d=3$ Cardano root and
$\lambda_\star^3-\lambda_\star^2-4\lambda_\star-4=0$; (xii) the contact constant
$C=2(d-1)^{1/4}/(d-2\sqrt{d-1})$ and the coefficient $0.11271$ of $(d-d_c)^2$; (xiii) the
spurious-branch demonstration at $d=4$.

**Numerics ((N), corroboration only; exactly uniform sampler = pairing model conditioned on
simplicity, fixed seeds, all raw values kept).**
`numerics.py`, `numerics2.py`, `out/numerics_*.json`.
* The secular zero equals the direct eigensolver value of $\lambda_2(G')$ to $\le1.3\times10^{-13}$
  in **all 30** runs (14 in `numerics.py`, 16 in `numerics2.py`) — a machine-precision check of
  Lemmas 3.2–3.6 including interlacing.
* $d=3$: $\lambda_2(G')$ at $n=4000$ (6 seeds): $2.874085\pm0.002914$; at $n=8000$ (6 seeds):
  $2.874880\pm0.000929$, against $\lambda_\star=2.875130$; the separated prediction $2.828427$
  is $50$ standard deviations away.
* $d=4$: $\lambda_2(G')=3.463571\pm0.004573$ at $n=4000$ against $2\sqrt3=3.464102$: no defect
  eigenvalue above the edge.
* $n(\lambda_1-d)$: $3.9754$ ($d=3,n=8000$) vs $4$; $1.3317$ ($d=4,n=4000$) vs $4/3$.
* Resolvent values at $\lambda=2.95,3.2,3.5$ ($d=3$) and $3.8,4.5$ ($d=4$) match
  $K_{\rm adj}+4/(n(\lambda-d))$ to $10^{-3}$–$10^{-2}$, with the largest errors nearest the
  bulk edge, exactly as Theorem A's $\rho^{L}$ rate predicts.

---

## 10. What is not proved here (explicit)

1. **No rate uniform in $d$ or up to the bulk edge.** Theorem A's constants degenerate as
   $K$ approaches $b$, and nothing here says anything about $\lambda\in[-b,b]$ (the bulk).
2. **One pattern only.** The complete law is proved for $T=\{c,u\}$ with $\rho=1$. For a
   general bounded pattern the same skeleton applies, but the two required inputs are
   pattern-specific and are *not* supplied here: (a) the exact kernel
   $K_T=G_d\sum_{s,t}r^{\rho(s,t)}$ (for $T=N(c)$ this is direction d2's object) and (b) the
   root analysis of $\Phi_T=\lambda-K_T$, where $\Phi_T$ need *not* be monotone and where
   $\Phi_T(d)=0$ may occur (a real branch that the target forbids excluding).
3. **No formalisation.** Nothing is claimed in Lean; all exact checks are sympy/rational.
4. **Novelty.** The ingredients (rank-one Perron splitting; $A'^k=A^k-d^kJ/n$; tree walk
   counts; Friedman/Bordenave) are batch 050's, and $G_d(2+2r)$ is stated in m6 §4.1 as the
   adjacent-pair limit. What is new here is the *root-level* completion for this family: the
   exact edge value and threshold, monotonicity (killing the simple-root premise), the
   eigenvalue assignment with multiplicities, the spurious-branch analysis, the contact order,
   and the $1/n$ Perron displacement with its pattern-dependent constant. I have not done a
   forward citation audit for a published "clustered attachment secular law in random regular
   graphs"; if such a statement exists it would supersede the novelty claim, not the proofs.
