"""
biregular_checks.py -- exact checks for (d1,d2)-biregular graphs:
  (1) the Ihara-Bass quartic correspondence  (mu^2+a)(mu^2+b) = xi^2 mu^2
  (2) the injection: |xi| > sqrt a + sqrt b  =>  |mu| > (ab)^{1/4}
  (3) rho(A_T) = sqrt a + sqrt b  via truncated universal cover (lower bounds)
  (4) exact sigma(A_T) for b=1 via the subdivision identity
"""
import numpy as np
from cover_tools import universal_cover_ball, top_eigs

def codeg_to_bireg(nL, nR, edges):
    """B left-degree d1, right-degree d2.  edges: list of (left,right)."""
    X = np.zeros((nL, nR))
    for u, v in edges:
        X[u, v] = 1.0
    A = np.zeros((nL+nR, nL+nR))
    A[:nL, nL:] = X; A[nL:, :nL] = X.T
    return X, A

def nb_matrix(A):
    """Hashimoto / non-backtracking matrix on directed edges (u->v)."""
    n = A.shape[0]
    dirs = [(u, v) for u in range(n) for v in range(n) if A[u, v] > 0]
    idx = {d: i for i, d in enumerate(dirs)}
    B = np.zeros((len(dirs), len(dirs)))
    for (u, v) in dirs:
        for w in range(n):
            if A[v, w] > 0 and w != u:
                B[idx[(u, v)], idx[(v, w)]] = 1.0
    return B, dirs

def quartic_check(X, A, d1, d2, out, name):
    a, b = d1-1, d2-1
    sv = np.linalg.svd(X, compute_uv=False)
    B, _ = nb_matrix(A)
    mu = np.linalg.eigvals(B)
    out.write(f"[{name}] d1={d1} d2={d2} a={a} b={b}; |E|={int(X.sum())}, #verts={A.shape[0]}, #directed={B.shape[0]}\n")
    out.write(f"  sqrt a + sqrt b = {np.sqrt(a)+np.sqrt(b):.12f};  (ab)^(1/4) = {(a*b)**0.25:.12f}\n")
    out.write(f"  rho(NB) = {max(abs(mu)):.12f}   (expected sqrt(ab) = {np.sqrt(a*b):.12f})\n")
    captured, missing = 0, []
    for xi in sv:
        # roots of  w^2 - (xi^2-a-b) w + ab = 0
        S = xi**2 - a - b
        disc = S*S - 4*a*b
        if disc >= 0:
            ws = [(S + np.sqrt(disc))/2, (S - np.sqrt(disc))/2]
        else:
            ws = [(S + 1j*np.sqrt(-disc))/2, (S - 1j*np.sqrt(-disc))/2]
        for w in ws:
            for sgn in (1, -1):
                target = sgn*np.sqrt(w) if np.isreal(w) and w >= -1e-12 else sgn*np.sqrt(complex(w))
                j = int(np.argmin(np.abs(mu - target)))
                err = abs(mu[j] - target)
                if err < 1e-7:
                    captured += 1
                else:
                    missing.append((xi, w, target, err))
    out.write(f"  singular values: {np.round(sv,6)}\n")
    out.write(f"  captured NB eigenvalues via quartic: {captured} of {len(mu)} (spurious predicted: 2n(d1-2) = {2*X.shape[0]*(d1-2)} with a=d1-1)\n")
    if missing:
        out.write(f"  unmatched (first 4): {[('%.4f'%m[0], '%.4f'%abs(m[2]), '%.2e'%m[3]) for m in missing[:4]]}\n")
    # injection check
    bad = 0
    for xi in sv:
        if abs(xi) > np.sqrt(a)+np.sqrt(b) + 1e-9:
            S = xi**2 - a - b
            wtop = (S + np.sqrt(S*S - 4*a*b))/2
            if np.sqrt(wtop) <= (a*b)**0.25 + 1e-12:
                bad += 1
    out.write(f"  injection violations (|xi|>sqrt a+sqrt b but top branch <=(ab)^(1/4)): {bad}\n\n")
    return dict(name=name, a=a, b=b, rho_nb=max(abs(mu)), sv=sv)

if __name__ == "__main__":
    import os
    os.makedirs("outputs", exist_ok=True)
    out = open("outputs/biregular_checks.txt","w")
    out.write("EXACT CHECKS FOR BIREGULAR BASES\n" + "="*70 + "\n\n")
    # (3,2): subdivision of K4, left = vertices of K4 (degree 3), right = edges
    K4 = [(i,j) for i in range(4) for j in range(i+1,4)]
    X32, A32 = codeg_to_bireg(4, 6, [(i, e) for e,(i,j) in enumerate(K4)] + [(j, e) for e,(i,j) in enumerate(K4)])
    quartic_check(X32, A32, 3, 2, out, "subdivision of K4")
    # (4,2): subdivision of K5
    K5 = [(i,j) for i in range(5) for j in range(i+1,5)]
    X42, A42 = codeg_to_bireg(5, 10, [(i,e) for e,(i,j) in enumerate(K5)] + [(j,e) for e,(i,j) in enumerate(K5)])
    quartic_check(X42, A42, 4, 2, out, "subdivision of K5")
    # (3,3): Heawood graph, 7+7
    H = [(i,(i+j) % 7) for i in range(7) for j in (0,1,3)]
    X33, A33 = codeg_to_bireg(7, 7, list(H))
    quartic_check(X33, A33, 3, 3, out, "Heawood (3,3)-biregular")
    # rho(A_T) lower bounds from truncated universal covers
    out.write("TRUNCATED UNIVERSAL COVER: top eigenvalue (rigorous lower bound for rho(A_T))\n")
    for (X, A, d1, d2, nm) in [(X32,A32,3,2,"(3,2) K4 subdivision"), (X42,A42,4,2,"(4,2) K5 subdivision"), (X33,A33,3,3,"(3,3) Heawood")]:
        a, b = d1-1, d2-1
        elist = [(u, v) for u in range(A.shape[0]) for v in range(u, A.shape[0])
                 for _ in range(int(round(A[u, v])))]
        for D in (4, 6, 8, 10, 12):
            T = universal_cover_ball(A.shape[0], elist, 0, D)
            t, _ = top_eigs(T, 1)
            n = T.shape[0]
            out.write(f"  {nm}: depth={D} cover-ball vertices={n} top={t[0]:.10f}  bound sqrt a+sqrt b={np.sqrt(a)+np.sqrt(b):.10f}  gap={np.sqrt(a)+np.sqrt(b)-t[0]:.2e}\n")
            if n > 60000: break
        out.write("\n")
    out.close()
    print(open("outputs/biregular_checks.txt").read())
