# The clustered secular law for the full neighbourhood $T=N(c)$

Member m3, swarm `smwh0bmpx`, direction **2** (full-neighbourhood pattern).
Status of every item is marked **(P)** proved here, **(C)** exact computation,
**(L)** literature input with hypotheses checked, **(N)** numerics (corroboration only),
**(S)** not proved.

---

## 0. What is proved

Fix an integer $d\ge 3$ and let $G_n$ be a uniformly random **simple** $d$-regular graph on
$[n]$, $nd$ even. Fix a label $c$ (the "centre"), let
$$T_n \;=\; N_{G_n}(c)$$
be its set of $d$ neighbours (so $|T_n|=d$ **deterministically**), and let $G_n'$ be $G_n$
plus one new vertex $x$ adjacent exactly to $T_n$. Write $A_n$ for the host adjacency,
$\mathbf 1_T=\mathbf 1_{T_n}$, $P=\mathbf 1\mathbf 1^\top/n$, $A'=A_n-dP$.

Throughout, for $\lambda>2\sqrt{d-1}$,
$$r(\lambda)=\frac{\lambda-\sqrt{\lambda^2-4(d-1)}}{2(d-1)}\in\Big(0,\tfrac1{\sqrt{d-1}}\Big),
\qquad G_d(\lambda)=\frac{r}{1-r^2}=\frac1{\lambda-dr},$$
with the *small* root convention of `results/050-finite-defect.md`.

**Theorem 1 (exact clustered kernel; (P),(C)).** Let $T_d$ be the $d$-regular tree, $o$ a
vertex, $T_\infty=N(o)$. For every $\lambda\in\mathbb C\setminus[-2\sqrt{d-1},2\sqrt{d-1}]$,
$$\mathbf 1_{T_\infty}^\top\big(\lambda-A_{T_d}\big)^{-1}\mathbf 1_{T_\infty}
=G_d(\lambda)\big[d+d(d-1)r(\lambda)^2\big]
=\frac{d\,\lambda\,r(\lambda)}{\lambda-d\,r(\lambda)}
=d\,r(\lambda)+\frac{d^2r(\lambda)^2}{\lambda-d\,r(\lambda)} .$$
All three right-hand sides are *identical* rational functions of $(\lambda,r)$ on the
algebraic curve $(d-1)r+1/r=\lambda$; on the physical branch the denominators never vanish
(Proposition 2).

**Theorem 2 (resolvent limit with the host Perron term kept; (P)).** For every compact
$K\subset(2\sqrt{d-1},d)\cup(d,\infty)$,
$$\sup_{\lambda\in K}\Big|\mathbf 1_{T_n}^\top(A_n-\lambda I)^{-1}\mathbf 1_{T_n}
-\Big[\frac{d^2}{n(d-\lambda)}-G_d(\lambda)\big(d+d(d-1)r(\lambda)^2\big)\Big]\Big|\longrightarrow0$$
in probability; more strongly, on an event $\Omega_n$ of probability $\ge 1-Cn^{-1/2}$ (up to
the connectivity event, which holds with probability $1-o(1)$), the error is
$O(\rho_\ast^{L_n}+\rho_0^{L_n}+L_n/n)$ with $L_n=\lfloor c\log_{d-1}n\rfloor$, $c<\tfrac12$,
$\rho_\ast,\rho_0<1$ depending on $d,\mathrm{dist}(K,\{2\sqrt{d-1},d\})$.

**Theorem 3 (complete root law; (P),(C)).** Let
$\Phi(\lambda)=\lambda-G_d(\lambda)[d+d(d-1)r(\lambda)^2]$, extended by continuity to
$\lambda=2\sqrt{d-1}$.
1. $\Phi$ is **holomorphic** on $\mathbb C\setminus[-2\sqrt{d-1},2\sqrt{d-1}]$.
2. Its zero set in that domain is exactly $\{\lambda_*,-\lambda_*\}$ with
$$\boxed{\;\lambda_*=\frac{2d}{\sqrt{d+1}},\qquad r(\lambda_*)^2=\frac1{d+1}\;}$$
and both zeros are **simple**, $\Phi'(\lambda_*)=2(d+1)>0$.
3. Sign pattern on the real exterior: $\Phi<0$ on $(2\sqrt{d-1},\lambda_*)$ and $\Phi>0$ on
$(\lambda_*,\infty)$. In particular there is **no repeated root** and no root other than
$\lambda_*$ in the exterior window.
4. Endpoint values: $\Phi(2\sqrt{d-1})=-\dfrac{4\sqrt{d-1}}{d-2}$,
$K_{N(c)}(2\sqrt{d-1})=\dfrac{2d\sqrt{d-1}}{d-2}$, and $\Phi(d)=\dfrac{d(d-3)}{d-2}$.
5. $\lambda_*$ sits relative to the host Perron point as
$$\lambda_*\lessgtr d\iff d\gtreqless 3;\qquad
\lambda_*-2\sqrt{d-1}=\frac{2}{\sqrt{d+1}\,(d+\sqrt{d^2-1})}\;>\;0 .$$
So $d=3$ is an **integral realisation of the critical case $\lambda_*=d$**, and the
batch-050 non-integrality exclusion ($\Delta=d^2(d-2)/(d-1)\notin\mathbb Z$) does **not**
carry over to clustered attachments.

**Theorem 4 (limiting eigenvalues; (P)).** On the connectedness event, $d\notin\sigma(G_n')$,
$\lambda_1(G_n')$ is the unique zero of $\Sigma_n$ in $(d,\infty)$ and $\lambda_2(G_n')$ the
unique zero in $(\lambda_2(G_n),d)$, where
$\Sigma_n(\lambda)=\lambda+\mathbf 1_{T_n}^\top(A_n-\lambda I)^{-1}\mathbf 1_{T_n}$; and
$$\lambda_1(G_n')\xrightarrow{\ \mathbb P\ }d,\qquad
\lambda_2(G_n')\xrightarrow{\ \mathbb P\ }\frac{2d}{\sqrt{d+1}}$$
for every $d\ge3$ (at $d=3$ both limits equal $3$). Moreover
$\mathbb P(\lambda_3(G_n')\ge 2\sqrt{d-1}+\varepsilon)\to0$ for every $\varepsilon>0$, so
there is no competing eigenvalue: the top two eigenvalues are exhausted by the host Perron
point and the pattern root.

**Theorem 5 (finite-size laws; (P)).**
* For $d\ge4$: $\displaystyle n\big(\lambda_1(G_n')-d\big)\xrightarrow{\ \mathbb P\ }
  \frac{d^2}{\Phi(d)}=\frac{d(d-2)}{d-3}$.
* For $d=3$: $\displaystyle \sqrt n\,\big(\lambda_1(G_n')-3\big)\xrightarrow{\ \mathbb P\ }
  \frac{3}{\sqrt 8}$, $\displaystyle \sqrt n\,\big(3-\lambda_2(G_n')\big)
  \xrightarrow{\ \mathbb P\ }\frac{3}{\sqrt 8}$.

The $d\ge4$ constant is *not* the separated-model constant with $\Delta=d$: the separated
value would be $d^2/(d-dG_d(d))=d^2(d-2)/(d^2-3d+1)$ (e.g. $6.4$ at $d=4$), while the
clustered value is $8$ at $d=4$. Measured (Table 3): $7.49,7.75,7.85,7.96,7.98$ for
$n=500,1000,2000,4000,8000$.

Everything above is for the **explicit** family $T_n=N(c)$; no general-pattern or
universality claim is made (§10).

---

## 1. Exact algebra of the local gadget

### 1.1 One-sided messages and the reduced system (P)

Let $T_d^+$ be the one-sided $d$-regular tree: a root $u$ with $d-1$ children, each of which
roots a copy of $T_d^+$. Put $m:=\big((\lambda-A_{T_d^+})^{-1}\big)_{uu}$ (the root
self-energy; note $m>0$ for $\lambda>2\sqrt{d-1}$). Eliminating the $d-1$ children (each
contributing $m$ to the effective diagonal of $u$) gives
$$m=\frac1{\lambda-(d-1)m}\iff (d-1)m^2-\lambda m+1=0 .$$
The two roots are $r(\lambda)$ and $1/((d-1)r(\lambda))$; only $r$ satisfies
$|r|<1/\sqrt{d-1}<1$, so $m=r(\lambda)$ **(C)**. Hence for any vertex $v$ of $T_d$ the
effective diagonal after deleting the $d$ branches at $v$ is
$\lambda-dr(\lambda)=(1-r^2)/r=1/G_d(\lambda)$.

Now take the centre $o$ and its neighbourhood $T_\infty=N(o)$. Eliminating every pendant
branch leaves the $1+d$ dimensional reduced matrix
$$M=\begin{pmatrix}\lambda&-\mathbf 1^\top\\-\mathbf 1& r^{-1}I_d\end{pmatrix},
\qquad\text{so}\qquad
\big[(\lambda-A_{T_d})^{-1}\big]_{T_\infty\times T_\infty}
=\Big(r^{-1}I_d-\tfrac1\lambda J_d\Big)^{-1},$$
with $J_d=\mathbf 1\mathbf 1^\top$ ($d\times d$); the Schur complement of the $o$-block of
$M$ is exactly $r^{-1}I_d-\lambda^{-1}J_d$. Its eigenvalues are $r^{-1}$ (on $\mathbf 1^\perp$,
multiplicity $d-1$) and $r^{-1}-d/\lambda$ (on $\mathbf 1$), hence
$$\big[(\lambda-A_{T_d})^{-1}\big]_{uu}=r+\frac{r^2}{\lambda-dr},\qquad
\big[(\lambda-A_{T_d})^{-1}\big]_{uv}=\frac{r^2}{\lambda-dr}\ (u\ne v),$$
and summing over the $d$ diagonal and $d(d-1)$ off-diagonal ordered pairs,
$$\mathbf 1_{T_\infty}^\top(\lambda-A_{T_d})^{-1}\mathbf 1_{T_\infty}
=d\,r+\frac{d^2r^2}{\lambda-dr}
=\frac{d\lambda r}{\lambda-dr}
=\frac{r}{1-r^2}\big(d+d(d-1)r^2\big). \tag{1.1}$$
The last identity is $\lambda r^2=r\big(1+(d-1)r^2\big)$, i.e. $\lambda=(d-1)r+1/r$.
This is Theorem 1. $\square$

An equivalent derivation uses $\big[(\lambda-A_{T_d})^{-1}\big]_{uv}=G_d\,r^{\mathrm{dist}(u,v)}$
on the tree (proved from the message recursion by the geodesic decomposition), giving
$$G_d\sum_{s,t\in T_\infty}r^{\mathrm{dist}(s,t)}
=G_d\big(\underbrace{d}_{s=t}+\underbrace{d(d-1)}_{s\ne t}r^2\big).$$
The $d(d-1)r^2$ term is the **finite local off-diagonal contribution**; it is not
negligible (Table 2: it moves the resolvent value by 27–37% at $d=3$).

### 1.2 Independent exact checks (C)

`checks/sym_kernel.py`, `checks/exact_small.py`, raw output `checks/out/exact_small.txt`.

1. Sympy, symbolic $d$ and $r$: the three forms in (1.1) are equal as rational functions;
   $G_d=1/(\lambda-dr)$; $(d-1)r^2-\lambda r+1=0$.
2. Exact inverse of the reduced $(d+1)\times(d+1)$ matrix for $d=3,4,5,6,7$ with symbolic
   $r$: diagonal $r+r^2/(\lambda-dr)$, off-diagonal $r^2/(\lambda-dr)$, sum
   $\mathbf 1^\top G\mathbf 1=d\lambda r/(\lambda-dr)$ — all five identities per degree pass.
3. Exact rational inverses of the *truncated balls* $B_R(o)$, $R=1,\dots,5$, confirm
   convergence to (1.1):

| $d$ | $r$ | $\lambda$ | $R=1$ | $R=2$ | $R=3$ | $R=4$ | $R=5$ | closed form |
|---|---|---|---|---|---|---|---|---|
| 3 | 1/2 | 3 | 1.5 | 2.25 | 2.625 | 2.8125 | 2.90625 | 3 |
| 3 | 1/3 | 11/3 | 1.0531914894 | 1.3026315789 | 1.3588752665 | 1.3714146023 | 1.3742031400 | 1.375 |
| 4 | 1/2 | 7/2 | 1.6969696970 | 2.6666666667 | 3.2733017378 | 3.6745406824 | — | 4.6666666667 |

   (Table 1. Truncation error decays geometrically, ratio $2r^2$ at $d=3$ and $3r^2$ at
   $d=4$ — the two/three boundary channels.)
4. Exact added-vertex identity (Lemma 4.1 below) verified at $n+2$ rational points —
   a certificate for the polynomial identity — on $K_4,K_{3,3},Q_3$,Petersen $(d=3)$ and
   $K_5,K_{4,4}$ $(d=4)$.

---

## 2. Pole bookkeeping: an algebraic pole is not a spectral pole

**Proposition 2.1 (no pole on the physical branch; (P)).** On
$\mathbb C\setminus[-2\sqrt{d-1},2\sqrt{d-1}]$,
$$\lambda-d\,r(\lambda)=\frac{1-r(\lambda)^2}{r(\lambda)}\neq0 ,$$
because $|r(\lambda)|<1/\sqrt{d-1}<1$. Hence:
1. $K_{N(c)}(\lambda):=G_d[d+d(d-1)r^2]=\dfrac{d\lambda r}{\lambda-dr}$ is **holomorphic** on
   the whole exterior domain; the "pole $\lambda=dr$" of the algebraic representation is
   **never attained**. The formal solutions of $\lambda=dr(\lambda)$ are $r=\pm1$, i.e.
   $\lambda=\pm d$ **on the conjugate branch** $r\mapsto\frac1{(d-1)r}$ (the large root of
   $(d-1)r+1/r=\lambda$). There $r_+(d)=1$ and the reduced system is degenerate — but that is
   an artefact of the other branch, not of the graph.
2. Consequently there is no "spectral pole at $\lambda=dr$": the spectrum of $A_{T_d}$ is
   $[-2\sqrt{d-1},2\sqrt{d-1}]$, and the resolvent is analytic off it.
3. The true **spectral** pole at $\lambda=d$ is the *host* Perron eigenvalue: for every $n$,
   $\Sigma_n$ has there the simple pole $\dfrac{d^2}{n(d-\lambda)}$ (residue $-d^2/n$), while
   the *pattern law* $\Phi$ is finite at $d$, $\Phi(d)=d(d-3)/(d-2)$ (Theorem 3.4). At $d=3$
   this finite value is $0$: the pattern law has a **root** exactly at the host Perron point,
   which is a genuinely different phenomenon from the pole (see §5).
4. At $\lambda=\pm2\sqrt{d-1}$ there is no pole either: $G_d$ stays finite,
   $G_d(2\sqrt{d-1})=\sqrt{d-1}/(d-2)$, and $\Phi$ extends continuously although it is not
   analytic there (branch point of $r$). The resolvent *limit theorem* is not claimed at the
   edge; only the value of $\Phi$ is used there, for the threshold.

**Remark 2.2.** Equivalently: in $\lambda$, $K_{N(c)}$ is a rational function of
$r(\lambda)$ with denominator $1-r^2$; since $r$ never reaches $\pm1$ in the domain, the only
singularity in $\lambda$ is the square-root branch point at $\pm2\sqrt{d-1}$. A computation
that "cancels" $\lambda-dr$ and then reports a pole at $\lambda=d$ is reporting the pole of
the *other* branch (that is exactly the trap in the batch target's warning).

---

## 3. The resolvent limit, keeping the finite off-diagonal terms

Notation: $A=A_n$, $J=\mathbf 1\mathbf 1^\top$, $P=J/n$, $Q=I-P$, $A'=A-dP=QAQ$.

**Lemma 3.1 (Perron splitting; (P), re-proved here).** (i) $PA'=A'P=0$, $A'=QA'Q$,
$\|A'\|=\max_{2\le i\le n}|\lambda_i(A)|$.
(ii) For $k\ge1$ and all $y,y'$: $(A'^k)_{yy'}=(A^k)_{yy'}-\dfrac{d^k}{n}$.
(iii) For $\lambda>\|A'\|$:
$\displaystyle(A-\lambda I)^{-1}=\frac{P}{d-\lambda}-\sum_{k\ge0}\frac{A'^k}{\lambda^{k+1}}$.

*Proof.* (i) is $A\mathbf 1=d\mathbf 1$. (ii) induction: $A'=A-\frac dnJ$, $AJ=dJ$, $JA^k=d^kJ$,
$J^2=nJ$. (iii) On $\mathrm{span}\{\mathbf 1\}$ and its orthogonal complement $A$ acts as $d$
and $A'$; geometric series with ratio $\|A'\|/\lambda<1$. $\square$

**Lemma 3.2 (exact decomposition with the Perron term isolated; (P)).** For
$\lambda>\|A'\|$, $\lambda\ne d$,
$$\mathbf 1_T^\top(A-\lambda)^{-1}\mathbf 1_T
=\frac{d^2}{n(d-\lambda)}
-\sum_{k\ge0}\frac{\mathbf 1_T^\top A^k\mathbf 1_T-\frac{d^{2+k}}{n}}{\lambda^{k+1}} ,$$
the series converging absolutely; truncating at $L$ costs at most
$\dfrac{d^2\rho^{L+1}}{\lambda(1-\rho)}$, $\rho=\|A'\|/\lambda<1$.

*Proof.* $\mathbf 1_T^\top P\mathbf 1_T=|T|^2/n=d^2/n$; apply Lemma 3.1 and
$\sum_{k\ge0}(d/\lambda)^{k+1}=\frac{d}{\lambda-d}$. $\square$

**Lemma 3.3 (tree-likeness at a marked centre; (P)).** Fix $d\ge3$, $R\ge1$ and a label $c$.
Then
$$\mathbb P\Big(B_R(c)\ \text{is not isomorphic as a rooted graph to the radius-}R
\text{ ball of }T_d\Big)\;\le\;C_d\,(d-1)^{2R}/n .$$
The same bound holds for the event that $T_n=N(c)$ fails to correspond to $N(o)$ — in fact
$T_n=N(c)$ always, and on the event the rooted isomorphism carries $N(c)$ onto $N(o)$.

*Proof.* Work in the pairing model and reveal $B_R(c)$ level by level: at each revelation at
most $2R_0$ half-edges are used, $R_0\le\sum_{j\le R}d^j$, and a partner among the used
half-edges would create a cycle, a loop, a repeated edge, or identify two images; union
bound over $\le R_0$ revelations gives $\le C_d(d-1)^{2R}/n$. Conditioning on simplicity is
harmless because every simple $d$-regular graph corresponds to exactly $(d!)^n$ pairings, so
$\mathbb P_{\text{uniform}}(\mathcal A)\le \mathbb P_\Gamma(\mathcal A)/\mathbb P_\Gamma(S_n)$
and $\liminf_n\mathbb P_\Gamma(S_n)=e^{-(d^2-1)/4}>0$ (Angel–van der Hofstad–Holmgren
Cor. 1.2 as quoted in `.ultramath/smwgwbyn9/m6/THEOREM.md`; I did not re-read the source
this run — **(L)** with that caveat). $\square$

**Lemma 3.4 (walk counts on the good event; (P)).** On
$\mathcal G_R=\{B_R(c)\cong B_R^{T_d}(o)\}$, for every $k\le R-1$,
$$\mathbf 1_T^\top A^k\mathbf 1_T=\sum_{s,t\in N(o)}\big(A^k_{T_d}\big)_{st}
=d\big(A_{T_d}^k\big)_{oo}+d(d-1)\big(A^k_{T_d}\big)_{o'\!,\,o''}$$
(the last equality by transitivity of the tree ball; $o',o''$ distinct neighbours of $o$).

*Proof.* A walk of length $k$ starting at $T_n=N(c)$ stays inside $B_{k+1}(c)\subseteq B_R(c)$,
which is isometric to the tree ball. $\square$

**Proof of Theorem 2.** Fix $K$ compact in the exterior window; put
$b=2\sqrt{d-1}$, $\lambda_{\min}=\min K>b$, and choose $0<\delta_0<\lambda_{\min}-b$
(possible since $\lambda_{\min}>b$). Let
$$L=L_n=\lfloor c\log_{d-1}n\rfloor,\quad c<\tfrac12,\qquad
\Omega_n=\{\text{$G_n$ connected}\}\cap\{\|A'\|\le b+\delta_0\}\cap\mathcal G_{L+1}.$$
By Lemma 3.3, $\mathbb P(\mathcal G_{L+1}^c)\le C_d(d-1)^{2L+2}/n=O(n^{-1/2})$;
$\mathbb P(\|A'\|\ge b+\delta_0)=O(n^{-a})$ for every $a$ by the Friedman–Bordenave
second-eigenvalue theorem (quantitative form quoted in `m2/proof.md`, Input 1; **(L)**, model
and hypotheses matched there: fixed $d\ge3$, uniform simple $d$-regular, adjacency spectrum
including $|\lambda_n|$); connectivity holds with probability $1-O(1/n)$.
So $\mathbb P(\Omega_n)\ge1-Cn^{-1/2}$.

On $\Omega_n$, for $\lambda\in K$: $\rho=\|A'\|/\lambda\le(b+\delta_0)/\lambda_{\min}
=:\rho_\ast<1$ (for $K$ below $d$ we chose $\delta_0<\lambda_{\min}-b$ and note
$\lambda_{\min}>b$; for $K$ above $d$, $\lambda_{\min}>d>b$). Lemmas 3.2, 3.4 and the
completion of the tree series give, for $\lambda\in K$,
$$
\mathbf 1_T^\top(A-\lambda)^{-1}\mathbf 1_T
-\Big[\frac{d^2}{n(d-\lambda)}-K_{N(c)}(\lambda)\Big]
=\underbrace{\frac{d^2}{n}\sum_{k=1}^{L}\Big(\frac d\lambda\Big)^{k}}_{(\mathrm{I})}
+\underbrace{\sum_{k>L}\frac{\mathbf 1_{N(o)}^\top A^k_{T_d}\mathbf 1_{N(o)}}{\lambda^{k+1}}}_{(\mathrm{II})}
+\underbrace{R_L(\lambda)}_{(\mathrm{III})},
$$
using Theorem 1 to identify the completed series. Then, uniformly in $\lambda\in K$:
$|(\mathrm{II})|\le d^2\lambda_{\min}^{-1}\rho_0^{L+1}/(1-\rho_0)$ with
$\rho_0=b/\lambda_{\min}<1$; $|(\mathrm{III})|\le d^2\rho_\ast^{L+1}\lambda_{\min}^{-1}/(1-\rho_\ast)$;
and $(\mathrm{I})$ is $O(1/n)$ if $K$ lies above $d$, while if $K$ lies below $d$ then
$|(\mathrm{I})|\le\frac{d^2}{n}\frac{(d/\lambda_{\min})^{L}}{\lambda_{\min}-d}$ and
$(d/\lambda_{\min})^{L}/n\le n^{c\log_{d-1}(d/\lambda_{\min})-1}\to0$ because
$c<\frac12<\frac{\log(d-1)}{\log(d/\lambda_{\min})}$ for every $\lambda_{\min}>2\sqrt{d-1}$
and $d\ge3$. All three terms vanish uniformly. $\square$

**Remark 3.5 (what makes this a *clustered* proof).** The frozen separated-case argument
discards off-diagonal tree entries because the labels separate; here separation fails badly
($\mathrm{dist}(s,t)=2$ for all $s\ne t\in N(c)$), and the whole point is Lemma 3.4: the
*exact* walk counts over the clustered set are the tree ones for $k\le L$, including all
$d(d-1)$ off-diagonal ordered pairs. No local-weak-limit argument is used: the limit is
obtained from $\|A'\|<\lambda$ (Friedman) plus the exact rank-one identity, so it is a
deterministic statement on a high-probability event, hence a statement in probability.

---

## 4. Root structure: the complete exterior law

### 4.1 The change of variable $r$

$r:(\lambda)$ is the unique root of $(d-1)r+1/r=\lambda$ in $(0,1/\sqrt{d-1})$; the map
$\lambda\mapsto r(\lambda)$ is a strictly decreasing bijection $(2\sqrt{d-1},\infty)\to
(0,1/\sqrt{d-1})$, with $r\to\frac1{\sqrt{d-1}}$ at the edge and $r\to0$ at $\infty$.
As a map of domains, $r$ is the inverse of the Joukowski-type map and is a biholomorphism
$\mathbb C\setminus[-2\sqrt{d-1},2\sqrt{d-1}]\to\{0<|r|<1/\sqrt{d-1}\}$.

### 4.2 The secular polynomial

With $s=r^2$ and $\lambda=(d-1)r+1/r$,
$$\Phi(\lambda)=\lambda-K_{N(c)}(\lambda)
=\frac{1-2s-(d^2-1)s^2}{r\,(1-s)}=:\frac{P(s)}{r(1-s)} . \tag{4.1}$$
This is exact algebra: multiply (1.1) by $r(1-r^2)$ and use
$\lambda r(1-r^2)=((d-1)r^2+1)(1-r^2)$. **(C)** verified symbolically.

$P(s)=1-2s-(d^2-1)s^2$ is strictly decreasing on $s\ge0$, $P(0)=1>0$,
$P\big(\frac1{d-1}\big)=1-\frac2{d-1}-1=-\frac2{d-1}<0$. Its roots are
$$s=\frac{-1\pm d}{d^2-1}\quad\Longrightarrow\quad s=\frac1{d+1}\ \text{or}\ s=-\frac1{d-1}.$$
Hence:

* On the real exterior, $r(1-s)>0$ and the sign of $\Phi$ is the sign of $P(r^2)$. Since
  $P$ decreases and vanishes exactly at $s_*=\frac1{d+1}\in(0,\frac1{d-1})$,
  $$\Phi<0\ \text{on}\ (2\sqrt{d-1},\lambda_*),\qquad \Phi>0\ \text{on}\ (\lambda_*,\infty),$$
  with $\lambda_*=(d-1)r_*+\frac1{r_*}$ at $r_*=\frac1{\sqrt{d+1}}$, i.e.
  $$\lambda_*=\frac{d-1}{\sqrt{d+1}}+\sqrt{d+1}=\frac{2d}{\sqrt{d+1}}.$$
  The root is **simple** because $P$ has a simple zero at $s_*$ and $r$ is locally
  invertible; quantitatively $\Phi'(\lambda_*)=2(d+1)$ (see 4.4).
* The negative root $s=-\frac1{d-1}$ has $|r|=1/\sqrt{d-1}$, i.e. it lies exactly on the
  boundary of the $r$-disk, which is the branch cut $\lambda\in[-2\sqrt{d-1},2\sqrt{d-1}]$;
  it is not attained in the domain. Hence on the whole exterior domain the zeros of $\Phi$
  are exactly $r=\pm\frac1{\sqrt{d+1}}$, i.e. $\lambda=\pm\lambda_*$, both simple. **There is
  no other zero, real or complex, and no repeated zero.** In particular the batch's
  instruction to keep "the case of a repeated root" as a real branch of the target is
  vacuous *for this family*, and I prove it rather than assume it.

### 4.3 Threshold

The exterior root exists iff $\Phi(2\sqrt{d-1})\le0$, i.e. iff
$$G_d(b)\sum_{s,t}r(b)^{\rho(s,t)}\ \ge\ b
\iff \frac{\sqrt{d-1}}{d-2}\sum_{s,t}r(b)^{\rho}\ \ge\ 2\sqrt{d-1}
\iff \sum_{s,t}r(b)^{\rho(s,t)}\ \ge\ 2(d-2),$$
using $r(2\sqrt{d-1})=1/\sqrt{d-1}$, $G_d(2\sqrt{d-1})=\sqrt{d-1}/(d-2)$. For $T=N(c)$,
$$\sum_{s,t}r(b)^{\rho(s,t)}=d+d(d-1)\cdot\frac1{d-1}=2d
\quad\Longrightarrow\quad
2d\ \ge\ 2(d-2)\ \text{with slack }4 .$$
So **the full neighbourhood always has an exterior root, for every $d\ge3$**, with a
degree-independent slack $4$ in the threshold inequality; and directly
$\Phi(b)=-\frac{4\sqrt{d-1}}{d-2}<0$, $K_{N(c)}(b)=\frac{2d\sqrt{d-1}}{d-2}$ **(C)**.
(For comparison the adjacent pair has $\sum=2+2/\sqrt{d-1}$ and satisfies the threshold only
at $d=3$; that is direction 1's territory.)

### 4.4 Simplicity constant

Write $K_{N(c)}=\phi(r)$, $\phi(r)=\dfrac{dr(1+(d-1)r^2)}{1-r^2}$, so that
$\Phi'(\lambda)=1-\dfrac{\phi'(r)}{\lambda'(r)}$ with
$\lambda'(r)=(d-1)-\frac1{r^2}<0$ on the branch. A direct computation gives
$$\phi'(r)=d\,\frac{1+(3d-2)r^2-(d-1)r^4}{(1-r^2)^2},\qquad
\phi'(r_*)=4d+2,\qquad \lambda'(r_*)=(d-1)-(d+1)=-2,$$
$$\Phi'(\lambda_*)=1-\frac{4d+2}{-2}=2(d+1)>0 . \tag{4.2}$$
(Independently: $\Phi'(d)=\frac{d^3-5d^2+12d-10}{(d-2)^3}$, which at $d=3$ equals $8=2(d+1)$
— the required consistency at the critical degree **(C)**.)

### 4.5 The host Perron point versus the pattern root

$\Phi(d)=d-\frac{d-1}{d(d-2)}\Big(d+\frac{d}{d-1}\Big)=d-\frac{d}{d-2}=\frac{d(d-3)}{d-2}$.
Thus
* for $d\ge4$: $\Phi(d)>0$ — the pattern root $\lambda_*=\frac{2d}{\sqrt{d+1}}<d$ lies
  strictly **below** the host Perron point, and the eigenvalue limits are
  $\lambda_2\to\lambda_*$, $\lambda_1\to d$. The "above-$d$" limit is the *host Perron value*
  $d$ itself, not a root of $\Phi$: the Perron eigenvalue of $G_n$ survives as the limit of
  $\lambda_1(G_n')$ and is *not* described by a secular root. This is a genuine structural
  difference from the separated model, where both limits are roots of $\lambda-\Delta G_d$.
* for $d=3$: $\Phi(3)=0$ — the unique pattern root **is** the host Perron point. This is the
  critical case; §5.3 shows both top eigenvalues converge to $3$, at scale $n^{-1/2}$.
* The exclusion $\lambda_f\ne d$ of batch 050 is therefore **not** inherited: for integers
  $d\ge3$, $\lambda_*=d\iff d=3$, which is a perfectly admissible finite-graph parameter
  ($|T|=d=3$).

---

## 5. From the resolvent limit to the eigenvalues

### 5.1 Three exact lemmas (P)

**Lemma 5.1 (added-vertex secular identity).** Let $G$ be any graph on $n$ vertices, $T\ne\emptyset$
a vertex subset, $x\notin V$ adjacent exactly to $T$, and let $p_G(\lambda)=\det(\lambda I-A_G)$.
Then, as polynomials,
$$p_{G'}(\lambda)=p_G(\lambda)\,\Sigma(\lambda),\qquad
\Sigma(\lambda)=\lambda+\mathbf1_T^\top(A_G-\lambda I)^{-1}\mathbf1_T .$$
Consequently, on any open interval $I$ with $I\cap\sigma(A_G)=\emptyset$, the zeros of
$\Sigma$ in $I$ are exactly the eigenvalues of $G'$ in $I$, with multiplicity.

*Proof.* Block determinant: $\lambda I-A_{G'}=\begin{pmatrix}\lambda I-A_G&-\mathbf1_T\\
-\mathbf1_T^\top&\lambda\end{pmatrix}$, so
$p_{G'}=p_G\cdot\big(\lambda-\mathbf1_T^\top(\lambda I-A_G)^{-1}\mathbf1_T\big)
=p_G\big(\lambda+\mathbf1_T^\top(A_G-\lambda I)^{-1}\mathbf1_T\big)$. $\square$
**(C)** certified at $n+2$ rational points on six graphs.

**Lemma 5.2 (monotonicity).** On $\mathbb R\setminus\sigma(A_G)$,
$\Sigma'(\lambda)=1+\|(A_G-\lambda I)^{-1}\mathbf1_T\|^2>0$. Hence $\Sigma$ has **at most
one** zero per component of the complement of $\sigma(A_G)$; all such zeros are **simple**.

**Lemma 5.3 (interlacing and Perron exclusion).** Suppose $G$ is $d$-regular and connected,
$T\ne\emptyset$. Then the eigenvalues of $G'$ interlace:
$$\lambda_1(G')\ge\lambda_1(G)=d\ge\lambda_2(G')\ge\lambda_2(G)\ge\cdots\ge\lambda_n(G')\ge\lambda_n(G),$$
and $d\notin\sigma(G')$ whenever $\mathbf1_T^\top\mathbf1=|T|\ne0$.

*Proof.* Interlacing of a symmetric matrix and a principal submatrix of codimension $1$
(Cauchy). For the exclusion: if $A_{G'}v=dv$ with $v=(w,a)$, the block equations read
$(A-d)w=-a\mathbf1_T$ and $\mathbf1_T^\top w=da$. Applying $\mathbf1^\top$ to the first
($\mathbf1^\top A=d\mathbf1^\top$) gives $-a|T|=0$, so $a=0$; then $w\in\ker(A-d)=\mathrm{span}\{\mathbf1\}$
by connectedness, and $\mathbf1_T^\top w=c|T|=0$ forces $c=0$, i.e. $v=0$. $\square$

**Corollary 5.4.** For $G$ connected and $T\ne\emptyset$:
$$\{\text{zeros of }\Sigma\ \text{in }(d,\infty)\}=\{\lambda_1(G')\},\qquad
\{\text{zeros of }\Sigma\ \text{in }(\lambda_2(G),d)\}=\{\lambda_2(G')\},$$
each a singleton and simple.

*Proof.* By Lemma 5.3, $G'$ has exactly one eigenvalue in $[d,\infty)$ and exactly one in
$[\lambda_2(G),d]$; $d$ itself is not an eigenvalue; and by Lemma 5.1 the zeros of $\Sigma$
in these gap intervals are exactly the eigenvalues there. $\square$

**Remark 5.5 (host-pole estimates used, not assumed).** In the arguments below I use that
$\Sigma_n$ is continuous and strictly increasing on the closed gap
$[\varepsilon,d-\varepsilon]\cap(\lambda_2(G_n),d)$ — true by Lemma 5.2 — and that the
*explicit* Perron term makes $\Sigma_n\to+\infty$ as $\lambda\uparrow d$ and
$\Sigma_n\to-\infty$ as $\lambda\downarrow d$:
$$\Sigma_n(\lambda)=\frac{d^2}{n(d-\lambda)}+\underbrace{\lambda+\mathbf1_T^\top(A_n-\lambda I)^{-1}Q\mathbf1_T}_{\text{bounded near }d}
=\frac{d^2}{n(d-\lambda)}+O(1).$$
So the existence of a zero on each side of $d$ is guaranteed, and the only question is its
location, which Theorem 2 answers.

### 5.2 Proof of Theorem 4

Fix $\varepsilon>0$ and let $\eta>0$ be small (choices below). Work on $\Omega_n$ of Theorem 2
with $\delta_0$ small enough that $(b+\delta_0)\le b+\varepsilon/2$.

*Case $d\ge4$.* Here $b<\lambda_*<d$ (Theorem 3.5), so choose $\eta<\frac13\min\{\lambda_*-b,d-\lambda_*\}$.
Since $\Phi(\lambda_*-\eta)<0<\Phi(\lambda_*+\eta)$ and $\Sigma_n\to\Phi$ uniformly on
$[\lambda_*-\eta,\lambda_*+\eta]$ (Theorem 2), for $n$ large $\Sigma_n(\lambda_*-\eta)<0<\Sigma_n(\lambda_*+\eta)$;
by monotonicity there is a zero in that interval. By Corollary 5.4 that zero is the only
eigenvalue of $G_n'$ in $[\lambda_2(G_n),d]$, i.e. $\lambda_2(G_n')$, provided
$\lambda_*-\eta>\lambda_2(G_n)$, which holds for large $n$. Hence
$\mathbb P(|\lambda_2(G_n')-\lambda_*|>\eta)\to0$.
For the top eigenvalue: $\Phi(d)>0$, so $\Phi(d+\eta)>0$ for small $\eta$, hence
$\Sigma_n(d+\eta)>0$ for large $n$, while $\Sigma_n(\lambda)\to-\infty$ as
$\lambda\downarrow d$ (Remark 5.5). A zero lies in $(d,d+\eta)$ and equals
$\lambda_1(G_n')$. Hence $\lambda_1(G_n')\to d$.

*Case $d=3$.* Here $\lambda_*=d=3$. For $0<\eta<3-2\sqrt2$: $\Phi<0$ on
$[2\sqrt2+\eta,3-\eta]$, so for large $n$ also $\Sigma_n<0$ there; the (unique, existing)
zero in $(2\sqrt2+\eta,3)$ must therefore lie in $(3-\eta,3)$. By Corollary 5.4 it is
$\lambda_2(G_n')$, so $\lambda_2(G_n')\to3$. Similarly $\Phi>0$ on $(3,\infty)$ gives
$\Sigma_n(3+\eta)>0$ vs $\Sigma_n\to-\infty$ at $3^+$, so $\lambda_1(G_n')\in(3,3+\eta)$ and
$\lambda_1(G_n')\to3$.

*No competing eigenvalue.* By Lemma 5.3, $\lambda_3(G_n')\le\lambda_2(G_n)\le b+\delta_0$, so
$\mathbb P(\lambda_3(G_n')>b+\varepsilon)\le\mathbb P(\lambda_2(G_n)>b+\varepsilon/2)+o(1)\to0$
(Friedman). $\square$

### 5.3 A model remark: $G_n'$ is $d$-regular with a twin pair

Because $|T_n|=d$, the added vertex also has degree $d$, so $G_n'$ is a **$d$-regular** graph
on $n+1$ vertices: it is the graph obtained by *duplicating* the vertex $c$. Two elementary
consequences, both checked exactly on $K_4,K_{3,3},Q_3$,Petersen,$K_5,K_{4,4}$
(`checks/out/exact_small.txt`):

* $x$ and $c$ are twins (identical neighbourhoods), so $A_{G'}(e_x-e_c)=0$ and $0\in\sigma(G_n')$
  with multiplicity at least $1$ — outside the window, and a useful check of the model;
* nevertheless $d\notin\sigma(G_n')$ (Lemma 5.3), so $\lambda_1(G_n')>d$ strictly: duplicating
  a vertex pushes the top eigenvalue strictly above $d$, by $\Theta(1/n)$ for $d\ge4$ and
  $\Theta(n^{-1/2})$ at $d=3$ (Theorem 5). This is larger than the Tracy–Widom scale
  $n^{-2/3}$ at $d=3$, so it is a genuine $O(1)$-in-$n^{1/2}$ effect, not an edge fluctuation.

### 5.4 Proof of Theorem 5 (finite-size laws)

Put $\tau_n=\lambda_1(G_n')-d$; Theorem 4 gives $\tau_n\to0$. On $\Omega_n$ the exact
identity
$$\Sigma_n(\lambda)=\Phi(\lambda)+\frac{d^2}{n(d-\lambda)}+\epsilon_n(\lambda),
\qquad |\epsilon_n(\lambda)|\le C_K\big(\rho_\ast^{L_n}+\rho_0^{L_n}+L_n/n\big)
=: C_K n^{-\kappa}$$
holds uniformly for $\lambda$ in a fixed compact neighbourhood
$K_0=[d-c_0,d+c_0]$ of $d$ inside the exterior window, with $b=2\sqrt{d-1}$,
$c_0=\frac14(d-b)$, $\delta_0=\frac12(d-b)$ (so $b+\delta_0<d-c_0$), and
$$\rho_0=\frac{b}{d-c_0}=\frac{4b}{3d+b}<1,\qquad
\rho_\ast=\frac{b+\delta_0}{d-c_0}=\frac{2(d+b)}{3d+b}<1,\qquad
\kappa=c\min\{\log_{d-1}(1/\rho_\ast),\log_{d-1}(1/\rho_0)\}\in(0,\tfrac12).$$
Both ratios are $>1/(d-1)$ (e.g. at $d=3$: $0.956$ and $0.985$, versus $0.5$), so both
logarithms are $<1$ and $c<\frac12$ gives $\kappa<\frac12$; consequently
$\epsilon_n=o(n^{-1/2})$. Since $\lambda_1(G_n')$ is a zero of $\Sigma_n$,
$$0=\Sigma_n(d+\tau_n)=\Phi(d+\tau_n)-\frac{d^2}{n\tau_n}+\epsilon_n(d+\tau_n).$$

*$d\ge4$: $\Phi(d)\ne0$.* Multiplying by $n\tau_n$:
$n\tau_n\Phi(d)+O(n\tau_n^2)-d^2+n\tau_n\epsilon_n=0$, i.e.
$$n\tau_n=\frac{d^2}{\Phi(d)+O(\tau_n)+\epsilon_n}\longrightarrow\frac{d^2}{\Phi(d)}
=\frac{d^2(d-2)}{d(d-3)}=\frac{d(d-2)}{d-3},$$
using $\tau_n\to0$, $\epsilon_n\to0$ and $\Phi(d)\ne0$.

*$d=3$: $\Phi(d)=0$, $\Phi'(d)=8$.* Then $\Phi(d+\tau)=8\tau+O(\tau^2)$, so
$$0=8\tau_n+O(\tau_n^2)-\frac{9}{n\tau_n}+\epsilon_n .$$
Existence at scale $n^{-1/2}$: evaluating at $\tau=\pm cn^{-1/2}$ for suitable constants
$c$ gives opposite signs because the leading terms are $\pm 8cn^{-1/2}\mp 9c^{-1}n^{-1/2}$
and $\epsilon_n=o(n^{-1/2})$. Multiplying the equation by $\tau_n$:
$8\tau_n^2+O(\tau_n^3)-9/n+\epsilon_n\tau_n=0$, hence $\tau_n^2=\frac{9}{8n}(1+o(1))$ and
$$\sqrt n\,\tau_n\to\frac{3}{\sqrt 8}\quad(\tau_n>0\ \text{for }\lambda_1),\qquad
\sqrt n\,\tau_n\to-\frac{3}{\sqrt 8}\quad(\tau_n<0\ \text{for }\lambda_2). \qquad\square$$

**Remark 5.6 (why the critical case changes the scale).** In the non-critical case the
displacement of $\lambda_1$ from $d$ is driven by the competition
$\Phi(d)\tau\sim d^2/(n\tau)$, whose solution is $\tau\sim d^2/(n\Phi(d))=\Theta(1/n)$.
At $d=3$ the two sides balance at $\tau\asymp n^{-1/2}$: $\Phi$ vanishes at $d$, so the
pattern's own restoring force is $O(\tau)$ instead of $O(1)$. This is a real change of
exponent, not a refinement, and it is testable without any large parameter (see Table 3).

---

## 6. Consistency: the separated case is the $\rho\to\infty$ specialisation

The general pattern formula of the batch target reads
$\Phi_T(\lambda)=\lambda-G_d(\lambda)\sum_{s,t\in T}r(\lambda)^{\rho(s,t)}$ with $\rho$ the
tree distance in the pattern. Two attachment points at tree distance $\ell$ give
$$\sum_{s,t}r^{\rho}=2+2r^{\ell}
\quad\Longrightarrow\quad
K_{[2,\ell]}(\lambda)=G_d(\lambda)\big(2+2r(\lambda)^\ell\big)
\ \xrightarrow[\ell\to\infty]{}\ 2G_d(\lambda),$$
which is exactly the frozen separated-case kernel $-\Delta G_d$ with $\Delta=2$. At $\ell=1$
this reduces to the adjacent-pair kernel $2r/(1-r)$ (verified symbolically, and $\ell=1$
matches $2G_d(1+r)$). So:

* the frozen formula is recovered, and only as the $\ell\to\infty$ limit;
* the correction at bounded distance is $\Delta G_d(r^{\ell}-1)$, i.e. of order $1$ for
  $\ell=2$ and $3$ — precisely the terms the separated proof discards;
* for $T=N(c)$ the correction *factor* is
  $K_{N(c)}/(dG_d)=1+(d-1)r^2$ — at $d=3,\lambda=3.2$ ($r=0.425834$) this is
  $1+2r^2=1.3627$, i.e. the clustered kernel is $36\%$ larger than the separated one, and the
  excess is exactly the $d(d-1)r^2$ off-diagonal term. Table 2 shows the consequence:
  measured $-2.12789$ against the clustered prediction $-2.13203$ and the separated value
  $-1.56047$. The frozen proof is not reinterpreted: it remains valid exactly where its
  hypothesis (separation) holds.

---

## 7. Numerical evidence (N) — corroboration only

Sampler: pairing model with rejection (exactly uniform after conditioning, each simple graph
has $(d!)^n$ pairings); fixed seeds; `checks/numeric_gprime.py`; raw output
`checks/out/numeric.jsonl`. All linear algebra with `scipy` sparse `eigsh`/`spsolve`; the
secular zero is obtained by bisection of the *exact* $\Sigma_n$ on the host gap, so it is an
independent object from the eigensolver's output.

**Table 2.** Resolvent values $\mathbf1_T^\top(A_n-\lambda)^{-1}\mathbf1_T$, $d=3$, $n=8000$,
seed 11, versus the clustered prediction $\frac{d^2}{n(d-\lambda)}-K_{N(c)}(\lambda)$ and the
separated prediction $-dG_d(\lambda)$.

| $\lambda$ | measured | clustered prediction | error | separated $-dG_d$ | error |
|---|---|---|---|---|---|
| 3.2 | $-2.12789$ | $-2.13203$ | $+4.1\cdot10^{-3}$ | $-1.56047$ | $-5.7\cdot10^{-1}$ |
| 4.0 | $-1.12605$ | $-1.12716$ | $+1.1\cdot10^{-3}$ | $-0.96113$ | $-1.6\cdot10^{-1}$ |
| 5.0 | $-0.75728$ | $-0.75784$ | $+5.6\cdot10^{-4}$ | $-0.69087$ | $-6.6\cdot10^{-2}$ |
| 6.0 | $-0.58301$ | $-0.58338$ | $+3.8\cdot10^{-4}$ | $-0.54858$ | $-3.4\cdot10^{-2}$ |

The clustered kernel is right to $\le0.2\%$ and the separated one is wrong by 13–37%; the
residual decays with $n$ ($4.1\cdot10^{-3}$, $1.9\cdot10^{-2}$, $7.5\cdot10^{-3}$,
$4.1\cdot10^{-3}$ at $\lambda=3.2$ for $n=1000,2000,4000,8000$).

**Table 3.** Eigenvalues. "zero" is the secular zero in the gap (bisection), "$\lambda_2(G')$"
the direct eigensolver output.

| $d$ | $n$ | seed | $\lambda_2(G')$ | $\lambda_*$ | zero $-\lambda_2(G')$ | $\lambda_1(G')-d$ | finite-size law |
|---|---|---|---|---|---|---|---|
| 3 | 1000 | 11 | 2.961245702 | 3 | $-8\cdot10^{-15}$ | $+0.030306$ | $\sqrt n$ law: $1.2255,\ 0.9584$ vs $1.06066$ |
| 3 | 2000 | 11 | 2.972815750 | 3 | $-9\cdot10^{-16}$ | $+0.021457$ | $1.2157,\ 0.9596$ |
| 3 | 4000 | 11 | 2.982616975 | 3 | $-3\cdot10^{-15}$ | $+0.016236$ | $1.0994,\ 1.0269$ |
| 3 | 8000 | 11 | 2.987689645 | 3 | $+5\cdot10^{-15}$ | $+0.011469$ | $1.1011,\ 1.0258$ |
| 4 | 500 | 12 | 3.531794344 | 3.577708764 | $-5\cdot10^{-15}$ | $+0.014981$ | $n(\lambda_1-4)=7.49$ vs $8$ |
| 4 | 1000 | 12 | 3.552948120 | 3.577708764 | $+7\cdot10^{-15}$ | $+0.007751$ | $7.75$ |
| 4 | 2000 | 12 | 3.558418174 | 3.577708764 | $-6\cdot10^{-15}$ | $+0.003923$ | $7.85$ |
| 4 | 4000 | 12 | 3.576843422 | 3.577708764 | $+4\cdot10^{-15}$ | $+0.001989$ | $7.96$ |
| 4 | 8000 | 21 | 3.579195617 | 3.577708764 | $-2\cdot10^{-14}$ | $+0.000998$ | $7.98$ |
| 5 | 800 | 13 | 4.024137441 | 4.082482905 | $-7\cdot10^{-15}$ | $+0.009187$ | $7.35$ vs $7.5$ |
| 5 | 1600 | 13 | 4.063677420 | 4.082482905 | $-9\cdot10^{-16}$ | $+0.004641$ | $7.43$ |

Readings.
1. **The root identifies the eigenvalue exactly**: the secular zero equals $\lambda_2(G')$ to
   $\le2\cdot10^{-14}$ in all eleven runs — the identification of Theorem 4/Corollary 5.4 is
   verified to machine precision, not just asymptotically.
2. $\lambda_2(G')\to\lambda_*$ and $\lambda_1(G')\to d$ in every case, including $d=3$ where
   both targets coincide. At $d=4$ the observed $\lambda_2$ values $3.5318,3.5529,3.5584,
   3.5768,3.5792$ lie clearly above the bulk edge $2\sqrt3=3.4641$ and converge to
   $3.57771$.
3. $n(\lambda_1-d)$ at $d=4$: $7.49,7.75,7.85,7.96,7.98\to8$ — and *not* $6.4$, which is what
   the separated-model constant $\Delta^2/(d-\Delta G_d(d))$ with $\Delta=d$ would predict.
   This is a clean discrimination of the clustered finite-size constant.
4. $d=3$: the $\sqrt n$ law holds only in the limit, with a visible slow residual. The two
   displacements are asymmetric; the *asymmetry* itself measures the residual
   $\epsilon_n$: from §5.3 the quadratic in $\tau$ has the same coefficients for both signs,
   so $8(|\tau_-|-\tau_+)=\epsilon_n+o(\cdot)$. Measured:
   $\epsilon_n\approx0.068,\ 0.046,\ 0.0092,\ 0.0067$ for $n=10^3,2\cdot10^3,4\cdot10^3,8\cdot10^3$
   — decreasing, consistent with $\epsilon_n\to0$ at rate $n^{-\kappa}$. The
   $\epsilon_n$-independent part $\tfrac12(|\tau_-|+\tau_+)\cdot\sqrt n$ equals
   $1.0920,\ 1.0877,\ 1.0632,\ 1.0635$ against the predicted $1.06066$: agreement to $0.27\%$
   at $n=8000$. So the numerics support the $\sqrt n$ law and simultaneously exhibit the
   slow rate of the resolvent limit near $d$ — exactly as the error analysis of Theorem 2
   predicts. No numerical claim is used as a proof anywhere in this note.

---

## 8. What is *not* inherited from the separated model

1. The off-diagonal terms are not negligible: $K_{N(c)}=G_d\,d\,[1+(d-1)r^2]$, so the ratio to
   the separated value $dG_d$ is $1+(d-1)r^2\in(1,2]$, equal to $2$ exactly at the bulk edge
   ($r^2=1/(d-1)$) and tending to $1$ as $r\to0$. Setting $r=0$ "by separation" is the only
   case in which the two agree.
2. The threshold is **not** $\Delta>2(d-2)$ with $\Delta=|T|$: with $|T|=d$ the separated
   criterion would demand $d>2(d-2)\iff d<4$, i.e. only $d=3$; the clustered criterion
   $\sum_{s,t}r(b)^{\rho}=2d\ge2(d-2)$ holds for all $d\ge3$.
3. The exclusion $\lambda_f\ne d$ is not inherited: $\lambda_*=d$ exactly at $d=3$.
4. The above-$d$ limit need not be a root of the pattern law: for $d\ge4$ it is the host
   Perron value $d$, with $\Phi(d)>0$.
5. The finite-size constant at $d$ is different: $\frac{d^2}{\Phi(d)}=\frac{d(d-2)}{d-3}$
   versus the separated $\frac{d^2(d-2)}{d^2-3d+1}$.
6. The simple-root premise is *proved* here (Theorem 3.2), not assumed: $\Phi'(\lambda_*)=2(d+1)$
   and the only other complex zero of $\Phi$ is $-\lambda_*$.

**Erratum note.** While transplanting the near-$d$ analysis I found that the *rate* claimed
in `m2/proof.md` Theorem C ("the proof establishes the stronger scaled error
$O(\log n/n)$") is not established by the displayed decomposition: the tree-tail and
$A'$-tail terms are geometric in $L_n=c\log_{d-1}n$, i.e. $n^{-\kappa}$ with
$\kappa\in(0,\tfrac12)$, not $O(\log n/n)$. The *limit* statement
$n(d-\lambda_2)\to\Delta^2/(\Delta G_d(d)-d)$ is unaffected (it needs only
$\epsilon_n\to0$). See the separate file `erratum-050-scaled-rate.md`; the frozen proofs are
not edited.

---

## 9. Scope, gaps, and what is deliberately not claimed

* **Family.** Only $T_n=N(c)$ for a fixed label $c$ and fixed $d\ge3$; $|T_n|=d$
  deterministically. Not covered: growing $d$, random/growing $T$, multiple added vertices,
  patterns whose local limit is random, arbitrary graph-dependent $T$ (§10).
* **Spectral window.** Real $\lambda$ in $(2\sqrt{d-1},d)\cup(d,\infty)$, plus the value of
  $\Phi$ at the edge for the threshold. Nothing is claimed inside the bulk
  $[-2\sqrt{d-1},2\sqrt{d-1}]$, nor at Tracy–Widom scale, nor for complex $z$ near the cut.
* **External inputs.** (i) Friedman–Bordenave second-eigenvalue bound (fixed $d$, uniform
  simple model, two-sided, with the quantitative form quoted in `m2/proof.md`); I did not
  re-read the source this run — it is used exactly as in the frozen proof and its hypotheses
  were checked there. (ii) $\liminf\mathbb P_\Gamma(\text{simple})>0$ for the regular
  configuration model (Angel–van der Hofstad–Holmgren, as quoted in `m6/THEOREM.md`; also not
  re-read this run). (iii) classical connectivity of random regular graphs. Everything else
  (Lemmas 3.1–3.4, 5.1–5.3, Theorems 1–5) is proved in this file.
* **Rates.** Theorem 2 gives an explicit error on a set of probability $1-O(n^{-1/2})$; no
  optimal rate is claimed. Theorem 5 needs only $\epsilon_n=o(n^{-1/2})$, which the
  decomposition does give. The kernel $\kappa$ of that error is small for small $d$
  ($\kappa\approx0.03$ at $d=3$ for $c=\tfrac12$), which is why the numerical approach to the
  $\sqrt n$ law is slow.
* **Lean.** No formalisation is claimed. All algebra and all identities used in the proof
  were verified by exact symbolic/rational computation (scripts retained), and the
  finite-graph secular identity was certified pointwise on six graphs.
* **Novelty.** Not audited. The ingredients are classical (rank-one Perron removal,
  $A'^k=A^k-d^kJ/n$, tree walk counts, Kesten–McKay resolvent, Friedman's theorem); the
  assembly (exact clustered kernel for $N(c)$, the closed-form root $\lambda_*=2d/\sqrt{d+1}$,
  the integral critical case $d=3$, the two finite-size constants) is what I claim to have
  proved here. I have not searched the literature for prior occurrences of
  $\lambda_*=2d/\sqrt{d+1}$; see the batch's standing instruction to check novelty before
  claiming it.

## 10. Interface to the other directions

* Direction 1 (adjacent pair): the same machinery gives
  $K_{\rm adj}=2r/(1-r)=2G_d(1+r)$, secular cubic $(d-1)r^3-(d-3)r^2+r-1=0$, root at
  $d=3$ equal to $\approx2.8752$; the threshold $\sum=2+2/\sqrt{d-1}\ge2(d-2)$ holds only at
  $d=3$. Structurally the same conclusions (one simple exterior root, $\lambda_1\to d$),
  but the root is not algebraic of degree $2$ in $r$.
* Direction 3 (rooted bounded cluster embedding): Theorem 2 here is the special case
  $T_n=N(c)$ of the general marked-pattern statement; the only place the pattern enters is
  Lemma 3.4, where the walk counts of the pattern must be matched on the tree-likeness event,
  and Theorem 1, where the pattern resolvent is computed inside the tree. A general bounded
  pattern $(C,T)$ of radius $\le R$ needs $L\ge R$ and deterministic distances
  $\rho(s,t)$; then $\Phi_T=\lambda-G_d\sum_{s,t}r^{\rho(s,t)}$. What a general-pattern
  theorem additionally needs is a *root count* for that sum — which for $N(c)$ and for
  pairs is a low-degree polynomial in $r^2$ but in general need not be.
* Direction 4 (counterexamples/verification): the exact claims to attack are
  $\lambda_*=2d/\sqrt{d+1}$, $\Phi'(\lambda_*)=2(d+1)$, $\Phi(d)=d(d-3)/(d-2)$, the
  $\sqrt n$ law at $d=3$, and the assertion that the pole $\lambda=dr$ is never on the
  physical branch. Each has a machine-checkable certificate in `checks/`.
