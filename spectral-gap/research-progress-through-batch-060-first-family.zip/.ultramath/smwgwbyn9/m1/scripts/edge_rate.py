import numpy as np, scipy.sparse as sp, scipy.sparse.linalg as spla, json
def config_regular(n,d,rng):
    while True:
        stubs=np.repeat(np.arange(n),d); rng.shuffle(stubs)
        a=stubs[0::2]; b=stubs[1::2]
        if np.any(a==b): continue
        lo=np.minimum(a,b).astype(np.int64); hi=np.maximum(a,b).astype(np.int64)
        if len(np.unique(lo*n+hi))!=len(a): continue
        return sp.coo_matrix((np.ones(2*len(a)),(np.concatenate([a,b]),np.concatenate([b,a]))),shape=(n,n)).tocsr()
def g_d(lam,d):
    disc=lam*lam-4*(d-1); r=(lam-np.sqrt(disc))/(2*(d-1)); return r/(1-r*r), r
def theta_pred(lam,d,eps=None):
    """predicted exponent theta_* = log(rho)/log(d-1), Chebyshev ellipse of I_eps=[-d, 2sqrt(d-1)+eps]"""
    if eps is None: eps = 0.5*(lam-2*np.sqrt(d-1))
    lo,hi=-d, 2*np.sqrt(d-1)+eps
    c=(lo+hi)/2; a=(hi-lo)/2
    tau=(lam-c)/a
    rho=tau+np.sqrt(tau*tau-1)
    return np.log(rho)/np.log(d-1), rho, eps
d=3; T=[0]
data=[]
ns=[500,1000,2000,4000,8000]
for lam in (2.85,2.90,2.95,3.20,3.60):
    G,r=g_d(lam,d)
    meds=[]
    for n in ns:
        vals=[]
        for s in range(6):
            rng=np.random.default_rng(31000+s)
            A=config_regular(n,d,rng).astype(float)
            x=np.zeros(n); x[0]=1.0
            z=spla.spsolve((A-lam*sp.identity(n,format='csr')).tocsc(),x)
            vals.append(float(x@z))
        dev=np.abs(np.array(vals)+1*G)
        meds.append(float(np.median(dev)))
    th,rho,eps=theta_pred(lam,d)
    # least-squares slope
    sl=np.polyfit(np.log(ns),np.log(np.array(meds)+1e-16),1)[0]
    data.append(dict(lam=lam,r=r,G=G,theta_pred=th,rho=rho,eps=eps,ns=ns,med=meds,slope=sl))
    print(f"lam={lam:.3f} (edge {2*np.sqrt(d-1):.4f}) r={r:.5f} G_d={G:.5f} theta_pred={th:.3f}")
    print("   med dev:", " ".join(f"{m:.2e}" for m in meds), f"  fitted slope={sl:.2f}")
json.dump(data,open('out/edge_rate.json','w'),indent=1)
