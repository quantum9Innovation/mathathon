# Erratum to the batch-050 scaled-error claim near $\lambda=d$

**Separate file, as required by `results/spectral-research/batch-060/FROZEN-SEPARATED-CASE.md`.**
No frozen proof is edited, rewritten or reinterpreted. This note is a self-contained
erratum about one *rate* claim; it does not touch the separated-case resolvent theorem, the
$1/n$ *limit*, or any clustered assertion.

Affected statements (identifiers as frozen):

* `.ultramath/smwgwbyn9/m2/proof.md`, **Theorem C** and its proof (§5), in particular the
  displayed chain
  $$\Sigma_n(d-s/n)=f(d-s/n)+\frac{\Delta^2}{s}+O_{\Delta,d}\Big(\frac{\log n}{n}\Big),$$
  and the following sentence "so the unique zero ... is at $d-s_n/n$ with
  $|s_n-\Delta^2/c_1|=O(\log n/n)\to0$".
* `results/050-finite-defect.md` §1: "The proof establishes the stronger scaled error
  $O(\log n/n)$ about the limiting value."

## 1. What is claimed, and what the argument actually gives

The decomposition used is Lemma 2 / Theorem A of `m2/proof.md`. On the good event, uniformly
in $\lambda$,
$$\mathbf 1_T^\top(A-\lambda)^{-1}\mathbf 1_T
=\frac{\Delta^2}{n(d-\lambda)}
-\sum_{k=0}^{L}\frac{\mathbf 1_TA^k\mathbf 1_T-\Delta d^{k}/n}{\lambda^{k+1}}+R_L(\lambda),
\qquad |R_L(\lambda)|\le \frac{\Delta^2\rho_\ast^{L+1}}{\lambda(1-\rho_\ast)},$$
where $\rho_\ast=\|A'\|/\lambda$, and the tree series is completed with error
$$(\mathrm{II})=\Delta\sum_{k>L}\frac{(A^k_{T_d})_{oo}}{\lambda^{k+1}},
\qquad |(\mathrm{II})|\le \frac{\Delta\,\rho_1^{L+1}}{\lambda(1-\rho_1)},
\qquad \rho_1=\frac{2\sqrt{d-1}}{\lambda}.$$
The remaining explicit term is $\frac{\Delta^2}{n}\sum_{k\le L}(d/\lambda)^{k}$, which is
indeed $O(L/n)$ near $\lambda=d$ (the proof's estimate, correct).

The proof of Theorem C describes $(\mathrm{II})$ and $R_L$ as "exponentially small" and
concludes that all errors are $O(\log n/n)$ or exponentially small, i.e. negligible against
$\Theta(1/n)$. That step is not valid: with $L=L_n=\lfloor c\log_{d-1}n\rfloor$, $c<\tfrac12$,
$$\rho^{L_n}=n^{\,c\log_{d-1}\rho}=n^{-\kappa(\rho)},\qquad
\kappa(\rho):=c\log_{d-1}\frac1\rho\in(0,\tfrac12).$$
The decay is *exponential in $L$* but $L$ is only logarithmic in $n$, so the decay is
*polynomial with a small exponent* — not $O(1/n)$ and not $O(\log n/n)$.

## 2. Why the difficulty is not an artefact of a loose bound

To force $(\mathrm{II})=o(1/n)$ one needs $\rho_1^{L}=o(1/n)$, i.e.
$L\gtrsim \dfrac{\log n}{\log(1/\rho_1)}$. At the relevant energy ($\lambda\approx d$,
$d=3$) $\rho_1=2\sqrt2/3=0.942809$, $\log(1/\rho_1)=0.058892$, so one needs
$L\gtrsim 16.98\ln n$. But the tree-likeness event of Lemma 3 requires
$(d-1)^{2L}\lesssim n$, i.e. at $d=3$, $4^{L}\lesssim n$, i.e. $L\lesssim 0.7213\ln n$.
The two requirements differ by a factor $\approx23.5$; no choice of $L$ satisfies both, and
$L$ cannot be taken larger without losing the event. The growth of the tree walk counts is
governed by $\|A_{T_d}\|=2\sqrt{d-1}$, so the ratio $\rho_1$ cannot be improved by a sharper
estimate of $(A^k_{T_d})_{oo}$ either.

## 3. Corrected statement (replacement for Theorem C)

Everything else in the proof stands, so the honest version is:

> **Theorem C$'$.** Assume $\Delta G_d(d)>d$, and let $\kappa=\kappa(d;K)\in(0,\tfrac12)$ be
> the exponent produced by the decomposition ($\kappa\ge c\log_{d-1}\big((3d+b)/(4b)\big)$
> for $b=2\sqrt{d-1}$ and any fixed compact $K\ni d$ inside the exterior window, e.g.
> $\kappa\approx0.03$ at $d=3$ with $c=\tfrac12$). Then the unique zero of $\Sigma_n$ in
> $[d-c_1/n,d)$ is $d-s_n/n$ with
> $$\Big|s_n-\frac{\Delta^2}{\Delta G_d(d)-d}\Big|\;=\;O\big(n^{-\kappa}\big),$$
> and consequently $n\big(d-\lambda_2(G_n')\big)\to\dfrac{\Delta^2}{\Delta G_d(d)-d}$
> in probability, as asserted.

*Derivation.* With $\epsilon_n=O(n^{-\kappa})$ uniform in $s\in(0,C_1]$, the zero equation
$\Delta^2/s-c_1-c_2s/n+\epsilon_n=0$ has its root within
$|s-s_0|\le 2|\epsilon_n|s_0^2/\Delta^2$ of $s_0=\Delta^2/c_1$. So the **limit is unaffected**
(the relative error in $s_n$ is $O(n^{-\kappa})\to0$); only the rate $O(\log n/n)$ is
withdrawn.

## 4. What is and is not being asserted

* **Withdrawn:** the claim that the argument establishes an $O(\log n/n)$ (equivalently
  $o(1/n)$) localization of $s_n$, and any downstream statement that needs $1/n$-accuracy in
  $\lambda$ near $d$.
* **Not asserted:** that the rate is false. The bound in $(\mathrm{II})$ is lossy, and the
  batch-050 numerics ($n(d-\lambda_2)=30.77,33.72,35.94,36.17$ at
  $n=10^3,2\cdot10^3,4\cdot10^3,8\cdot10^3$, tending to $36$ from below) are *consistent*
  with a true $O(1/n)$ rate. The claim is only that the cited proof does not establish it.
* **Unaffected:** Theorem A (the exterior resolvent limit, in probability and with the stated
  high-probability bound), Theorem B (the eigenvalue limits), Proposition D and E, all exact
  identities and all numerics. The limit in Theorem C is unaffected, as shown in §3.
* The same defect would affect any later argument that imports the $O(\log n/n)$ rate
  (including the phrase "with the stronger scaled error $O(\log n/n)$" in
  `results/050-finite-defect.md`).

## 5. Consequence taken in this project

The clustered finite-size laws of `.ultramath/smwh0bmpx/m3/secular-law-Nc.md` (Theorem 5)
were deliberately stated so that only $\epsilon_n=o(n^{-1/2})$ is required, which the
decomposition *does* give ($\kappa<\tfrac12$). This is why the $d=3$ law there is
$\sqrt n\,(\lambda_1-3)\to 3/\sqrt8$ rather than a $1/n$ statement, and why the $d\ge4$ law
$n(\lambda_1-d)\to d(d-2)/(d-3)$ is derived from $\Phi(d)\ne0$ rather than from any
second-order accuracy of $\Sigma_n$.

## 6. Provenance

Inputs as listed in `FROZEN-SEPARATED-CASE.md` (SHA256 of `m2/proof.md`
`0e7f5b98…13c98`, of `results/050-finite-defect.md` `f06df232…dae5a`). The numbers in §2 are
elementary: $\log(2\sqrt2/3)=-0.0588915$, $\ln 4=1.386294$, $16.98/0.7213=23.54$. Exact
check of the $\Theta$-claim: `checks/sym_kernel.py` verifies the symbolic identities used in
the clustered replacement, and `checks/numeric_gprime.py` produces the raw data quoted.
