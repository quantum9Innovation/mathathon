# Band-edge sampling for abelian covers of periodic graphs

Research dossier, swarm smwgfcleu, member m1. Direction d2.
Written 2026-11-14. All file paths are relative to this directory.

Evidence labels used throughout.

* **(LIT)** a statement I read in a public source, with the exact version recorded.
* **(CALC)** an exact computation, arithmetic or exact linear algebra, reproducible from `code/`.
* **(PROOF)** a mathematical argument supplied here, written out in `PROOF-band-edge-law.md`.
* **(NUM)** a numerical experiment. It supports a claim, it never establishes it.
* **(CONJ)** a conjecture or a research target, explicitly not proved.

The dossier has seven parts: the model and why the question is the right one
(Section 1), the verified literature (2), the exact results (3), the
falsification material (4), the theorem target and the hardest missing estimate
(5), the unresolved steps and the deciding evidence (6), and the common ground
with the four source dossiers plus a prioritised work list (7).

-------------------------------------------------------------------------------

## 1. The question, the normalisation, and why it is not the standard one

### 1.1 Model

`Gamma` is a locally finite undirected graph (multiple edges and loops allowed)
with a free action of `Z^d` by automorphisms such that `B = Gamma / Z^d` is
finite. Put `p = |V(B)|`. Such a `Gamma` is what the user's brief calls a
periodic lattice. `B` is the collapsed graph, also called the fundamental graph
in the Floquet literature.

Every edge of `Gamma` is `((x,u),(x+g,v))` with `x` in `Z^d`, `u,v` in `[p]` and
`g` in `Z^d`. For `kappa` in `T^d = R^d/Z^d` the Bloch matrix is

    A(kappa) = sum_{g in Z^d} A_g exp(2 pi i <kappa,g>),
    (A_g)_{uv} = number of edges from (0,u) to (g,v),

with eigenvalues `Lambda_1(kappa) >= ... >= Lambda_p(kappa)`. For a finite index
subgroup `Lambda <= Z^d` of index `N` the finite graph is `G_Lambda = Lambda \ Gamma`
with `N p` vertices, and `Lambda^* = { x in R^d : <x,l> in Z for all l in Lambda }`
is its dual lattice, a superlattice of `Z^d` with `[Lambda^* : Z^d] = N`.

**Eigenvalue ordering.** `lambda_1 >= lambda_2 >= ...` by value, not by modulus.
This is the convention of the biregular dossier and of the statement of Alon's
conjecture in Friedman's paper (where the bound is on `max_{i>1} |lambda_i|`, a
different and stronger quantity). For `q`-regular graphs the two differ only on
the negative end, and I flag every place where it matters.

**Normalisation.** Unnormalised adjacency. The normalised Laplacian gap is
`(lambda_1-lambda_2)/q` for a `q`-regular graph, so all the statements below
about `lambda_1-lambda_2` can be read as statements about the normalised gap by
dividing by `q`.

**Limiting regime.** `Gamma` and `B` are fixed, `Lambda` varies over
finite-index subgroups, `N = [Z^d:Lambda] -> infinity`. This is the abelian
analogue of the tower of covers in the relativized second eigenvalue paper, and
the exact analogue of the finite quotients of a periodic operator studied in the
Floquet literature.

### 1.2 Why the four-source mechanism degenerates here

All four source papers prove an upper bound of the shape

    (new or nontrivial eigenvalue) <= (norm of the infinite local limit operator) + o(1),

with the error being a probability, and the norm being the spectral radius of the
universal cover (a regular tree, `2 sqrt(d-1)` for adjacency) or, in Bordenave's
lift theorem, `sqrt(rho_1)` for the non-backtracking Perron value of the base.
The mechanism is a sharp local limit plus rare-defect control: finite tangles
produce the failure probability, and their absence makes the trace method
converge to the tree value.

For a `Z^d`-periodic graph this mechanism degenerates on both sides.

(i) The Benjamini-Schramm limit is the periodic graph itself, which is amenable
(large boxes of `Z^d` are Folner sets). For a `q`-regular `Gamma` this forces the
adjacency spectral radius to equal `q` and the spectrum to fill the whole
interval `[-q,q]`. The threshold equals the trivial Perron bound and nothing is
gained.

(ii) The tangle order of the whole quotient is `|E|-|V| = N(|E(B)|-p)`, so the
"fundamental order" of every large quotient diverges linearly. No fixed-order
tangle can explain the defect, and for `q >= 3` and `0 < eps < q - 2 sqrt(q-1)`
the failure probability of the `eps`-Ramanujan event is not merely large, it
tends to 1.

So for abelian covers the only content is in the RATE, and the rate turns out to
be an invariant of the geometry of numbers attached to the pair
`(Gamma, Lambda)`. That is the subject of this dossier. In the language of the
user's brief: the sharp infinite-local-limit threshold is trivial, so the
research question is the sampling defect, and the sampling defect is arithmetic.

### 1.3 The one-line answer

For a `q`-regular `Gamma`, `Spec(A_{G_Lambda})` is the set of Bloch eigenvalues
sampled on the finite dual group `Lambda^*/Z^d` (Lemma 2 of the proof file,
verified numerically in 13 cases). The top band has its maximum at the trivial
character, so the second eigenvalue of the quotient is the top band evaluated at
the lattice point of the dual group closest to the origin in the metric given by
minus the Hessian of the band. Hence

    lambda_1 - lambda_2 (G_Lambda) = (1/2) min { kappa^T M kappa : 0 != kappa in Lambda^*/Z^d }
                                    + O(mu^2),

with `M = -Hess Lambda_1(0)` the inverse effective mass tensor at the band edge.
The minimum of a positive definite quadratic form over the nonzero cosets of
`Z^d` in `Lambda^*` is a coset minimum in the classical geometry of numbers: each
coset is represented by the point of `(1/N)Z^d` closest to the origin, so the
computation is a finite scan, and the result is not a shortest lattice vector
(Section 3.4). So the spectral gap of a finite abelian quotient of a periodic
lattice is an arithmetic invariant, exactly computable, and not a function of the
number of vertices.

-------------------------------------------------------------------------------

## 2. Verified literature, and what it does not contain

### 2.0 Source URLs and versions actually read

* `https://arxiv.org/abs/1804.07808` version 6 (biregular spectral gap)
* `https://arxiv.org/abs/1502.04482` version 4 (Bordenave, new proof and lifts)
* `https://arxiv.org/abs/1403.3462` version 1 (Friedman and Kohler, relativized)
* `https://arxiv.org/abs/cs/0405020` version 1 (Friedman, Alon's conjecture)
* `https://arxiv.org/abs/1311.3268` version 2 (group-based lifts), text in `lit/agarwal.txt`
* `https://arxiv.org/abs/2402.07202` version 1 (Breuer and Seelig), text in `lit/breuer.txt`
* `https://arxiv.org/abs/1301.6896` version 1 (Badanin, Korotoyaev, Saburova), text in `lit/ks2013.txt`
* `https://arxiv.org/abs/1502.02989` version 2 (Korotyaev and Saburova, effective masses), text in `lit/ks2015.txt`
* `https://arxiv.org/abs/1710.01157` version 2 (Fabila-Carrasco, Lledo, Post)
* `https://arxiv.org/abs/2208.12685` version 2 (McKenzie and Saburova)
* `https://arxiv.org/abs/1306.1409` version 4 (Louis, spanning trees of degenerating tori)
* `https://doi.org/10.1016/j.jctb.2005.06.012` (Friedman, Murty, Tillich), abstract read through a publisher index, full text refused with a bot check
* `https://doi.org/10.1016/j.crma.2006.03.005` (Cioaba), text in `lit/cioaba.txt`

### 2.1 The four sources (as instructed, exact versions from their SOURCE.md)

* **(LIT)** J. Friedman, *A proof of Alon's second eigenvalue conjecture and
  related problems*, arXiv:cs/0405020v1, 118 pages. Read here: `.paper-mastery/alon-second-eigenvalue/`
  (executive map, main results, assumptions). Key statement, Theorem 1.1, for
  `d` even and `eps > 0`:
  `Pr[max_{i>1}|lambda_i| <= 2 sqrt(d-1)+eps] >= 1 - c n^{-tau_fund}` with
  `tau_fund = ceil((sqrt(d-1)+1)/2) - 1`. Also the matching lower bound
  `Pr[lambda_2 > 2 sqrt(d-1)] >= c' n^{-s}` with `s = floor((sqrt(d-1)+1)/2)`
  from hypercritical loop tangles.
* **(LIT)** G. Brito, I. Dumitriu, K. Decker Harris, *Spectral gap in random
  bipartite biregular graphs and applications*, arXiv:1804.07808v6, CPC 31 (2022)
  229-267. Theorem 4: a.a.s. `lambda_2 <= sqrt(d_1-1)+sqrt(d_2-1)+o(1)`,
  `eta^+_min >= sqrt(d_1-1)-sqrt(d_2-1)-o(1)`, and full row rank when
  `d_1 > d_2`. The two edges come from the two roots of the Ihara-Bass quadratic.
* **(LIT)** C. Bordenave, *A new proof of Friedman's second eigenvalue theorem
  and its extension to random lifts*, arXiv:1502.04482v4, to appear Ann. ENS.
  Theorem 2 (configuration model non-backtracking) and Theorem 23 (new
  non-backtracking eigenvalues of a random `n`-lift of a fixed base at most
  `sqrt(rho_1)+o(1)`), Corollary 24 for regular bases.
* **(LIT)** J. Friedman, D.-E. Kohler, *The relativized second eigenvalue
  conjecture of Alon*, arXiv:1403.3462v1, 144 pages. Theorem 0.1.1:
  `Pr[rho_B^new(A_G) >= 2 sqrt(d-1)+eps] <= C_{B,eps} n^{-1}`. Theorem 0.1.3: for
  Ramanujan `B`, the failure probability is `Theta(n^{-eta_fund(B)})` with
  `eta_fund(B)` the least order of a strict feasible tangle.

Common mechanism, as stated in their own dossiers: a sharp infinite local limit
(the regular tree) plus tangle or rare-defect control. Nothing in the four
sources addresses amenable local limits, and none of them computes a rate that
is polynomial in the size with an explicit geometric constant.

### 2.2 The closest known work on the abelian side

* **(LIT)** J. Friedman, R. Murty, J.-P. Tillich, *Spectral estimates for Abelian
  Cayley graphs*, J. Combin. Theory Ser. B 96 (2006) 111-121, doi
  `10.1016/j.jctb.2005.06.012`. Abstract as served by the publisher index: "We
  give two short proofs that for fixed `d`, a `d`-regular Cayley graph on an
  Abelian group of order `n` has second eigenvalue bounded below by
  `d - O(d n^{-4/d})`, where the implied constant is absolute." Same statement
  paraphrased in **(LIT)** S. M. Cioaba, *Closed walks and eigenvalues of Abelian
  Cayley graphs*, C. R. Acad. Sci. Paris Ser. I (2006), doi
  `10.1016/j.crma.2006.03.005`, lines 68-70 of `lit/cioaba.txt`: "the second
  largest eigenvalue of a `k`-regular Abelian Cayley graph with `n` vertices is at
  least `k - O(k n^{-4/k})`". The full text of FMT is behind a publisher paywall,
  which returned a bot check, so I rely on two secondary renderings and mark the
  inner constant as unverified.

  Consequence for the present work, checked arithmetically: for a `d`-dimensional
  torus quotient the number of generators is `q = 2d` and the true exponent is
  `N^{-2/d} = N^{-4/q}`, so FMT's exponent is sharp. My Theorem 4 does not
  improve the exponent. It replaces `O(.)` by the exact second-order constant,
  which is a geometry-of-numbers invariant, extends the statement from Cayley
  graphs of abelian groups to all `Z^d`-periodic graphs including non-Cayley ones
  such as the honeycomb, covers all finite-index sublattices rather than the
  cubic ones, and identifies the two ends of the range at fixed `N`.

* **(LIT)** N. Agarwal, K. Chandrasekaran, A. Kolla, V. Madan, *On the expansion
  of group-based lifts*, arXiv:1311.3268v2, Theorem 4: "For every `n`-vertex
  `d`-regular graph `G`, `eps` in `(0,1)`, and abelian group `Gamma` of size at
  least `k = exp((n d log(1/eps) + log n)/log(1/eps))`, all `Gamma`-lifts `H` of
  `G` have `lambda(H)` at least `sqrt(eps) d`." Their proof is a diameter
  argument: the layers reachable within distance `Delta` are contained in a box
  of `exp(O(nd log Delta))` group elements. Read in `lit/agarwal.txt` lines
  491-530. Their Remark 3 says this "complements the known result on no-expansion
  of abelian Cayley graphs [FMT06]". Their regime is a growing base and a
  doubly exponentially large group. My regime is a fixed base and index `N`,
  where the quotient is a lattice quotient.

* **(LIT)** J. Breuer, E. Seelig, *Spectral gaps for Jacobi matrices on graphs*,
  arXiv:2402.07202v1. Theorem 1.1 (they attribute the argument to Greenberg):
  for a tower of finite covers `G_n` of a fixed `G_0` with `|V(G_n)| -> infinity`,
  `liminf lambda_2(J_n) >= sup spec(J_T)` where `T` is the universal cover. Their
  Theorem 1.2 improves the error to `O(1/r)` with `r` a distance parameter, and
  their Conjecture 1.1 asks whether `spec(J_T)` is contained in the support of
  every limiting eigenvalue counting measure. Read in `lit/breuer.txt`.
  For my setting their lower bound is the tree bound, which for a `q`-regular
  lattice is `2 sqrt(q-1)` and is strictly weaker than the exact value `q`. The
  correct object is the amenable cover, not the universal cover.

* **(LIT)** A. Badanin, E. Korotyaev, N. Saburova, *Laplacians on periodic
  discrete graphs*, arXiv:1301.6896v1: constructs the Floquet-Bloch
  decomposition for `Z^2`-periodic discrete graphs. **(LIT)** E. Korotyaev,
  N. Saburova, *Effective masses for Laplacians on periodic graphs*,
  arXiv:1502.02989v2: defines `M_{alpha beta} = d^2 lambda(theta_0)/d theta_alpha
  d theta_beta` and calls `m = M^{-1}` the effective mass tensor (lines 40-52 of
  `lit/ks2015.txt`). The Hessian in my Theorem 4 is exactly minus their `M` at a
  band maximum, so the leading constant of the abelian quotient gap is the
  inverse effective mass tensor evaluated on the shortest dual vector. They also
  give two-sided estimates of effective masses in geometric terms, which is
  precisely the input a uniform version of my theorem would need.

* **(LIT)** J. S. Fabila-Carrasco, F. Lledo, O. Post, *Spectral gaps and discrete
  magnetic Laplacians*, arXiv:1710.01157v2, LAA 547 (2018) 183-216. They
  interpret the vector potential on the finite quotient as the Floquet parameter
  and bracket the spectrum by eigenvalues of the associated magnetic matrices.
  This is the same `A(kappa)` that I use, stated in the language of magnetic
  Laplacians.

* **(LIT)** T. McKenzie, M. Saburova, *Quantum ergodicity for periodic graphs*,
  arXiv:2208.12685v2. Treats the adjacency matrix on `Z^d`, the triangular and
  the honeycomb lattice and the eigenfunctions of large finite periodic graphs,
  under an assumption on the Floquet eigenvalues. Establishes that the family of
  finite quotients I study is an active object in spectral theory.

* **(LIT)** J. Louis, *Asymptotics for the number of spanning trees in circulant
  graphs and degenerating d-dimensional discrete tori*, arXiv:1306.1409v4,
  Ann. Comb. 19 (2015) 513-543. Computes the determinant asymptotics of
  degenerating discrete tori `Z^d / Lambda_n Z^d` through theta functions. This
  is the product-of-eigenvalues analogue of my second-largest-eigenvalue
  statement, and it confirms that the sublattice language is the right one.

### 2.3 What I did not find

Searches for the exact second-order constant (the arithmetic minimum of the
effective-mass tensor over the dual lattice), for the range of the gap over
index-`N` sublattices, and for the arithmetic-versus-analytic minimum phenomenon
returned nothing. The elementary special case (the second eigenvalue of the
`d`-dimensional torus is `2(d-1)+2 cos(2 pi/n)`, gap `2-2 cos(2 pi/n) =
Theta(n^{-2})`) is folklore, and it is stated in that form in public discussion
(for example the worked computation at
<https://cs.stackexchange.com/questions/19800/calculating-eigenvalue-gap-of-a-torus-graph>).
I therefore claim the following as the new content: the exact second-order law
with the arithmetic-minimum constant for all periodic graphs and all sublattices,
the two-sided range theorem with both orders attained, the strict positivity
conjecture for the band-edge Hessian, and the replacement of the tangle exponent
by a geometric exponent in the amenable regime. I cannot
exclude that part of this is folklore in the Floquet community, and I say so.

-------------------------------------------------------------------------------

## 3. The exact results

Full proofs are in `PROOF-band-edge-law.md`. Statements here are compressed.

### 3.1 Theorem A (band-edge sampling law) **(PROOF)**

Assume `Gamma` connected. Let `Lambda <= Z^d` have index `N`, let
`M = -Hess Lambda_1(0)` be the real symmetric matrix of Lemma 3 of the proof file,
explicitly

    M_ij = (2 pi)^2 [ sum_g g_i g_j <psi,A_g psi>
                      - 2 < H_i psi, (Lambda_1(0)-A(0))^+ H_j psi > ],

with `psi` the Perron vector of `A(0)` and `H_i = sum_g g_i A_g`. Then

    (i)  lambda_1(G_Lambda) = Lambda_1(0), equal to q when Gamma is q-regular,
    (ii) lambda_2(G_Lambda) = max( Lambda_2(0),
                                   Lambda_1(0) - (1/2) mu + O(mu^2) ),
         mu = min { kappa^T M kappa : 0 != kappa in Lambda^*/Z^d }.

If `M` is positive definite and `Lambda_2(0) < Lambda_1(0)` then
`lambda_1-lambda_2 = (1/2) mu (1+O(mu))`.

Three ingredients, each verified independently.

* The Bloch decomposition (Lemma 2). **(NUM)** 13 explicit corroborations in
  `out/s04_bloch_vs_explicit.json`, deviations below `1e-13`.
* The closed form for `M` (Lemma 3). **(NUM)** checked against central
  differences in 1 dimension (4 bases, `out/s05_cyclic.log`, agreement `1e-7`)
  and in 2 dimensions (`out/s10_M_formula_2d.log`, agreement `4e-6`).
* The strict maximum of the top band at the trivial character (Lemma 1).
  **(PROOF)** plus the warning example in Section 4.4.

### 3.2 Theorem B (Cayley case, exact constant, arithmetic minimum) **(PROOF)**

For `Gamma = Cay(Z^d,S)` with `S` symmetric and generating `Z^d`, the Hessian is
`M = 4 pi^2 G` with `G = sum_{s in S} s s^T`, so for every finite-index `Lambda`

    lambda_1 - lambda_2 = 2 pi^2 min { sum_{s in S} <kappa,s>^2 : 0 != kappa in Lambda^*/Z^d }
                          + O(mu^2),

and for `Lambda = n Z^d`

    lambda_1 - lambda_2 = (2 pi^2/n^2) m(G) + O(n^{-4}),
    m(G) = min { z^T G z : 0 != z in Z^d }.

**(CALC)** and **(NUM)** in `out/s01_abelian.log`. Three lattices:
`G = 2I` (square), `G = [[4,2],[2,4]]` (triangular), `G = [[6,6],[6,12]]`.
At `n = 80` the observed values of `n^2 (lambda_1-lambda_2)` are `39.4581`,
`78.9163`, `118.3744`, against the predicted `2 pi^2 m(G) = 39.4784`, `78.9568`,
`118.4353`, all three ratios equal to `0.99949`. The common ratio is not an
accident: the correction is the quartic term of the cosine, which is the same
function of `n` for every lattice, so the relative error at fixed `n` is
universal across `G`.

### 3.3 The arithmetic minimum is not the analytic minimum **(CALC)**, **(NUM)**

`m(G) >= lambda_min(G)` with equality if and only if the soft eigenspace of `G`
contains a nonzero integer vector. Measured ratios `m(G)/lambda_min(G)`:

* square lattice, `1`
* triangular lattice, `2`
* the eight-generator set `{+-e_1, +-e_2, +-(1,1), +-(1,2)}`, `2.618033989 = phi^2`
* honeycomb lattice (non-Cayley, `G = (1/3)[[2,-1],[-1,2]]`), `2`

The honeycomb is the cleanest instance. The top band is `|1+e^{2 pi i k_1}+e^{2 pi i k_2}|`,
so `G = (1/3)[[2,-1],[-1,2]]` with `lambda_min = 1/3` but `m(G) = 2/3`. The exact
second eigenvalue of the `n x n` hexagonal torus is `sqrt(5+4 cos(2 pi/n))`,
**(CALC)** confirmed against direct diagonalisation for `n <= 80` in
`out/s03_honeycomb.log`, and

    lambda_1 - lambda_2 = 4 pi^2/(3 n^2) + O(n^{-4}),
    N = 2 n^2, so the gap is 8 pi^2/(3N) + O(N^{-2}).

A prediction based on `lambda_min` would give half of the true constant. The soft
direction of `G` is `(1,1)`, and the shortest integer vectors `(1,0)`, `(0,1)`,
`(1,1)` all have `z^T G z = 2/3`: the hexagonal softness is invisible to
integer quasimomenta. This is the precise spectral sense in which the
honeycomb lattice is not isotropic.

### 3.4 Theorem C (the range of the gap at fixed index) **(PROOF)**, **(NUM)**

Bookkeeping first. `Lambda <= Z^d` has index `N`, the quotient has `N p` vertices,
and `Lambda^*` is a lattice of covolume `1/N` containing `Z^d`. The index is `N`,
not `N p`, and the covolume that appears in Minkowski arguments is `1/N`, not
`1/(Np)`.

The quantity in the spectral law is the **coset minimum**

    mu_M(Lambda) = min { z^T M z : z in Lambda^* setminus Z^d },

that is, the minimum of the form over the nonzero cosets of `Z^d` in `Lambda^*`,
or equivalently the minimum over representatives. It is NOT the shortest vector
of the lattice `Lambda^*`: the shortest lattice vector can lie in `Z^d` (it
always can, `e_1` is in `Lambda^*`), so the only general relation is the
one-sided `mu_M(Lambda) >= lambda_1(Lambda^*, M)^2`. Consequently Minkowski and
Hermite bounds on the shortest lattice vector give a lower bound on `mu_M` and
can never give an upper bound. The correct upper bound is a packing argument on
the finite subgroup `Lambda^*/Z^d`, and the corrected statement is

    lambda_min(M)/N^2  <=  mu_M(Lambda)  <=  4 (N)^{-2/d} ((det M)^{1/2}/omega_d)^{2/d},

with `omega_d` the Euclidean volume of the unit ball. Both inequalities hold for
every `Lambda` of index `N`. Both orders occur:

* order `N^{-2}`: for `Lambda = U Lambda_0` with `U` unimodular and
  `Lambda_0 = <(N,0,...,0), e_2, ..., e_d>`, one has
  `mu_M(Lambda) <= m(M)/N^2`, with `m(M) = min { z^T M z : 0 != z in Z^d }`.
* order `N^{-2/d}`: for `Lambda = n Z^d` with `N = n^d`, one has
  `mu_M(Lambda) = m(M) N^{-2/d}` exactly.

So in the Cayley case with `q = |S|` generators the gap of an `N p`-vertex
abelian quotient ranges between `Theta(N^{-4/q})` and `Theta(N^{-2})`, and it is
not a function of the number of vertices. Hermite's constant enters at the low
endpoint, through `m(M) <= gamma_d (det M)^{1/d}`, and not at the high endpoint.
The exact supremum of `mu_M` over index-`N` sublattices is a packing problem for
finite subgroups of the torus, and I do not determine it. This corrects the
first version of this dossier, which wrongly identified `mu_M` with the shortest
full-lattice vector.

**(NUM)** `out/s12_coset_minimum.log`. Both inequalities are verified exactly, with
the dual points folded into the fundamental domain, for every sublattice of
`Z^2` of index `N <= 256` and for four forms `G` (square, triangular,
`[[6,6],[6,12]]`, golden `[[2,1],[1,1]]`). The observed maximum of `mu_M` over
sublattices stays below `0.907` of the packing bound in all four cases, and the
cubic sublattice attains exactly `pi/4` of that bound for the square lattice. At
`N = 256` the minimum of `mu_M` over the 511 sublattices equals `m(G)/N^2`
exactly in all four cases, so the achieved ratio to the lower bound
`lambda_min(M)/N^2` is `m(G)/lambda_min(G)`, namely `1`, `2`, `2.618` and `2.618`
for the four forms. In M-units the square lattice gives `min mu_M = 1.2047e-3`
and `lambda_min(M)/N^2 = 1.2047e-3`.

**(NUM)** `out/s01_abelian.log`. At `N = 256` the exact gaps over all 511
sublattices run from `6.0236e-4` to `1.6551e-1`, a ratio of 275.

**(NUM)** `out/s01b_d3.log`, dimension 3, the two orders in one table. Cubic
quotients of `Z^3/nZ^3` have `gap * n^2 -> 4 pi^2` with index `N = n^3`, so
`gap = Theta(N^{-2/3})`. The skewed quotients `<(N,0,0),(0,1,0),(0,0,1)>` have
`gap * N^2 -> 4 pi^2`, so `gap = Theta(N^{-2})`. The two exponents differ by
`N^{4/3}`.

**Explicit counterexample to "the gap is a function of N".** **(CALC)** Square
lattice, index `N = 6`, three sublattices and their exact gaps:

| `Lambda` | quotient | `lambda_2` | gap |
|---|---|---|---|
| `< (1,0),(0,6) >` | `Z/6` with two loops | `3` | `1` |
| `< (1,1),(0,6) >` | doubled `C_6` | `2` | `2` |
| `< (2,1),(0,3) >` | circulant `C_6(1,2)` | `0` | `4` |

Six vertices in each case and gaps `1, 2, 4`: a factor of four. The mechanism is
that the three dual groups have shortest vectors of length `1/6`, `sqrt 2/6` and
`sqrt 5/6` (`(1,0)`, `(1,1)` and `(2,1)` in units of `1/6`), and the leading
constant is proportional to the square of that length. At `N = 6` the
second-order law is of course not yet accurate (the ratios
`gap/(mu_M/2)` in the table are `0.46`, `0.05` and `0.23`), which is exactly the
point of the asymptotic statement.

### 3.5 Higher gaps and successive minima **(PROOF)**, **(NUM)**

For `Cay(Z^d/nZ^d,S)`, with `nu_1 <= nu_2 <= ...` the multiset
`{z^T G z : 0 != z in Z^d}` in increasing order,

    lambda_1 - lambda_j = (2 pi^2/n^2) nu_{j-1} + O(n^{-4})     for each fixed j.

`out/s08_higher_gaps.log`, `n = 24`. Square lattice: the first twelve gaps have
multiplicities `4,4,4` at the values proportional to `1,2,4`. Triangular
lattice: `6` gaps at the value proportional to `1`, then `6` at the value
proportional to `3`, matching `nu = 4` six times and `nu = 12` six times. This is
the lattice answer to the user's question about `d - lambda_3`, `d - lambda_4`:
for periodic lattices the whole beginning of the spectrum is the sequence of
successive minima of one quadratic form, with multiplicities.

### 3.6 The exact decomposition and the crossover **(PROOF)**

`lambda_2(G_Lambda) = max(Lambda_2(0), max_{kappa != 0} Lambda_1(kappa))` holds
as an identity, with no approximation. Hence `lambda_2` is pinned at the base
value `Lambda_2(0)` as long as the band edge has not descended below it, and
because `Lambda_1(0) - Lambda_1(kappa) = (1/2) mu + O(mu^2)` the crossover
happens at `n_* ~ sqrt(2 pi^2 C/(Lambda_1(0)-Lambda_2(0)))` for the cyclic
covers, where `C = M_1/(2 pi)^2`. **(NUM)** In every computed example the base gap
was at least `0.41` and the crossover therefore at `n_* <= 2.5`
(`out/s07_structure.log`), so plateaus are a genuinely small-quotient
phenomenon. A family of graphs exhibiting a long plateau would need
`Lambda_1(0)-Lambda_2(0) = O(n^{-2})`, that is an almost disconnected or almost
symmetric base.

### 3.7 The cyclic case has a closed form with a winding operator **(PROOF)**, **(NUM)**

For `d = 1` the constant is

    M_1 = (2 pi)^2 [ <psi, W_2 psi> - 2 < H psi, (lambda_1 - A(0))^+ H psi > ],
    W_2 = sum_w w^2 A_w,   H = sum_w w A_w (real antisymmetric),

and the gap of the `n`-fold cyclic cover is `(1/2) M_1/n^2 + O(n^{-4})`.
**(NUM)** four bases (K4, Petersen, Q3, K33) in `out/s05_cyclic.log`. The closed
form agrees with a finite difference of the band to `1e-7`, the explicit lifted
graph agrees with the Bloch spectrum to `1e-15`, and `n^2 gap/(2 pi^2)` converges
to the closed-form constant with ratio `1 - O(n^{-2})`. For K4 with windings
`(1,0,2,1,0,1)` on the six edges, `C = 1.25` exactly, and
`lambda_2(G_n) = 3 - 2 pi^2 (1.25)/n^2 + O(n^{-4})`.

-------------------------------------------------------------------------------

## 4. Falsification material

### 4.1 The Alon-Boppana and girth benchmarks are the wrong thresholds here

**(NUM)** `out/s06_girth.log`. Two families of `3`-regular graphs on the same
vertex sets `10 n`, basing everything on the Petersen graph which has girth 5.

* Cyclic covers with every winding 1: girth 5 to 8 for all `n`, and `lambda_2`
  rising to `2.9258` at `n = 23`, converging to the degree `3`.
* Uniform random `n`-lifts: girth exactly 5 for all `n` and `lambda_2` between
  `2.75` and `2.84`, converging to `2 sqrt 2 = 2.8284`.

Both families have the SAME girth profile, and `lambda_2` differs by a constant
which grows with nothing. So girth cannot be the mechanism. The mechanism is the
local limit: the cyclic cover converges to the amenable infinite cover whose top
of spectrum is `3`, the random lift converges to the tree whose radius is
`2 sqrt 2`. The Alon-Boppana inequality `lambda_2 >= 2 sqrt 2 - o(1)` holds in
both cases and is sharp in neither cyclic case.

A related exact point: every connected `Z^d`-periodic graph has bounded girth,
bounded by a function of `|V(B)|` alone, since a fundamental domain gives cycles
of bounded length. So the hypothesis "girth tends to infinity", which is what
makes the McKay and Alon-Boppana asymptotics tight, can never hold for periodic
lattices.

### 4.2 The tangle exponent formalism does not extend to amenable covers

**(PROOF)**, immediate from the definitions. A finite quotient `G_Lambda` has
`|E|-|V| = N(|E(B)|-p)`, so its order as a tangle is `Theta(N)`. The relativized
theory defines `eta_fund(B)` as the least order of a strict feasible tangle and
proves a failure probability `Theta(n^{-eta_fund})` for Ramanujan bases. Here the
failure event has probability 1 and the order of the only relevant tangle grows
with the graph. What replaces `eta_fund` is the geometric exponent `2/d`, or
`4/q` in terms of the number of generators. **(PROOF)** and **(NUM)**, Theorem B
and `out/s01_abelian.log`.

### 4.3 "The gap is a function of the number of vertices" is false

Section 3.4. **(CALC)** The factor is not a constant: at `N = 256` in `d = 2` it
is 275, and the two ends have different powers of `N` as soon as `d >= 2`.

### 4.4 The connectivity hypothesis cannot be weakened, and a naive check fails

**(NUM)** and **(PROOF)**, Section 2 remark in the proof file. The four-vertex
periodic graph with edges `(0,1,(1,0))`, `(1,2,(0,1))`, `(2,3,(-1,0))`,
`(3,0,(0,-1))`, `(0,2,(1,1))`, `(1,3,(0,0))` has edge shifts generating `Z^2`
and a connected fundamental graph `K_4`, yet the cycle windings generate only
`Z(1,-1)`, so the infinite graph is disconnected. Its top band reaches the value
`3 = Lambda_1(0)` at the nontrivial character `(1/2,1/2)`, with the signed
eigenvector `(1,-1,1,-1)`, its Hessian is singular with kernel the diagonal
direction, and the band is exactly flat along that direction
(`Lambda_1(t,t) = 3` to machine precision), while it takes the value `2.2361` at
`(0.4,0.1)`. Every abelian quotient is disconnected
(`out/s10_M_formula_2d.log`). A check based on the edge shifts, or on the
connectivity of `B`, gives the wrong answer. The correct test is that the cycle
windings generate `Z^d`, implemented in `code/s11_positivity_2d.py`.

### 4.5 A flat top band, exactly

**(PROOF)** and **(NUM)**. If all cycle windings vanish, the edge shifts are a
coboundary, `A(kappa)` is unitarily equivalent to `A(0)` for every `kappa`, the
top band is exactly constant, `M = 0`, and every quotient is disconnected. The
minimal example is two copies of `K_m` joined by a single wound edge, computed in
`out/s07_structure.log`: the band is constant to `1e-16`, `M = 0` to `1e-16`, and
the `n`-fold cover has the spectrum of `A(0)` repeated `n` times. This is the
degenerate boundary case of the law and it is a clean test of any proposed
implementation.

-------------------------------------------------------------------------------

## 5. Theorem target, with the hardest missing estimate named

### 5.1 Target T1 (Conjecture A): strict positivity of the band-edge Hessian **(CONJ)**

**Statement.** If `Gamma` is a connected `Z^d`-periodic graph then `M` is
positive definite.

**Why it matters.** By Theorem A this is exactly the statement that the rate
`Theta(N^{-2/d})` is always attained. A singular `M` would produce families of
quotients with defect `O(N^{-4/d})`, that is, dramatically better expansion than
the generic lattice rate. It is also the statement that the extension of `FMT`'s
exponent from Cayley graphs to general periodic graphs needs no flat-direction
exception.

**Evidence.** **(NUM)** 1398 connected one-dimensional cases
(`out/s07_structure.log`, smallest `C = 0.0957`) and 529 connected
two-dimensional cases (`out/s11_positivity_2d.log`, no case with
`lambda_min(M) <= 0`, smallest ratio `lambda_min/lambda_max = 0.0017`). The one
singular instance found is the disconnected example of Section 4.4.

**Hardest missing estimate.** Everything reduces to a quantitative stability
statement for the Perron vector. Write `M = B - 2C` with
`a^T B a = sum_g <a,g>^2 <psi,A_g psi>` and
`a^T C a = <H_a psi, (Lambda_1(0)-A(0))^+ H_a psi>`. `B` is positive definite
whenever the shifts span `R^d` (strict positivity of `<psi,A_g psi>` because
`psi > 0`), so the conjecture is the inequality `2C < B`, that is

    sum_i a_i H_i psi  must be small compared to sum_g <a,g>^2 <psi,A_g psi>.

The hard case is a graph whose top Perron vector is concentrated on a small part
of the fundamental domain while the winding is carried by edges elsewhere. The
single missing estimate is a bound of the form

    || (Lambda_1(0)-A(0))^{+1/2} H_a psi ||^2
        <= (1/2 - delta) sum_g <a,g>^2 <psi,A_g psi>       for some delta > 0,

which is a quantitative improvement of Perron-Frobenius domination for the pair
`(A(0), A(kappa))` in the direction `a`, and I do not know how to prove it in
general. A promising route is to use the eigenvector equation of the family
`A(ta)` analytically in `t` and to show that a flat direction forces
`A(kappa) = U(kappa)A(0)U(kappa)^*` (pure gauge), which by Lemma 7 forces
disconnection.

### 5.2 Target T2: the non-abelian amenable regime **(CONJ)**

**Statement.** For covers whose deck group is a finite nilpotent group of rank
`r` and `Z^d`-like growth, the defect should be `Theta(|G|^{-2/r})` with the
constant given by the same effective-mass tensor evaluated on the shortest
vectors of the character lattice. In particular the exponent should equal
`2/rank` and not `4/k`.

**Status.** Speculation. It is not even clear what the right substitute for the
dual lattice is when the deck group is non-abelian, and the analogue of Lemma 2
fails: the spectrum is no longer a union of Bloch eigenvalues at characters,
only the old spectrum is contained. The relativized paper shows that for free
deck groups the answer is governed by tangles instead, so a phase transition in
the exponent as the deck group becomes non-amenable is expected. This is the
sharpest formulation I can give of the "missing connection" between the abelian
sampling picture and the tangle picture.

### 5.3 Target T3: random sparse perturbations of a lattice **(CONJ)**

**Statement.** Let `G_Lambda` be a torus and let `P` be the `4`-regular graph
formed by replacing the `+-e_2` 2-factor by a random 2-factor. Then a fraction `c`
of random rewiring should give defect `Theta(c)` for small `c` and reach
`q - 2 sqrt(q-1) - o(1)` as `c -> 1`.

**Evidence.** **(NUM)** `out/s09_rewiring.log`. The defect grows roughly linearly
in `c` and reaches `0.44` to `0.47` at `c = 1`, against the maximum `0.536` for
`q = 4`. This is the amenable analogue of the relativized theorem: the
interpolation between a deterministic lattice defect and the tree threshold as
the local limit becomes random. I state it as a target and not a result.

-------------------------------------------------------------------------------

## 6. Unresolved steps and what evidence would decide them

1. **Conjecture A.** Deciding evidence would be either a proof of the
   quantitative domination inequality of Section 5.1, or a connected periodic
   graph with singular `M`. A search strategy: hunt in the class of periodic
   graphs whose Perron vector of `A(0)` is highly non-uniform, for instance a
   small clique attached to a large regular part through few edges, with the
   winding placed on the bridges. The scan in `code/s11_positivity_2d.py` covers
   random small cases only, and the smallest observed `lambda_min/lambda_max` is
   `0.0017`, which suggests that near-degenerate cases exist and are worth
   targeted construction.
2. **Sharp constants in the range theorem.** The upper bound of Section 3.4 is
   a packing constant for finite subgroups of the torus. In the four lattices of
   `out/s12_coset_minimum.log` the observed maximum of `mu_M` over index-`N`
   sublattices is between `0.52` and `0.91` of it, and between `0.85` and `0.91`
   at `N = 256`. The exact supremum over index-`N` sublattices, and its limit as
   `N` grows, is an open packing problem that I did not solve. What is proved is
   the two-sided bound and the fact that both orders `N^{-2}` and `N^{-2/d}`
   occur.
3. **The `O(mu^2)` remainder.** Making it explicit requires bounds on the fourth
   derivative of the top band and on `lambda_1(G_1)` gaps. The effective-mass
   estimates of Korotyaev and Saburova are exactly the right tool and I did not
   carry the constants through.
4. **Higher bands and `Lambda_2(0)`.** The case in which `Lambda_1(0)` is not
   simple (a repeated Perron value) is excluded by connectedness of `B` and I did
   not treat the reducible case, where `Gamma` is disconnected and the whole
   picture changes (Section 4.4).
5. **Non-abelian and random quotients.** Section 5.2 and 5.3. Both need new
   ideas, not just bookkeeping.

-------------------------------------------------------------------------------

## 7. Common ground with the four dossiers, the swarm menu, and the work list

### 7.1 Common ground with the sources

* **alon-second-eigenvalue (Friedman).** The failure exponent
  `tau_fund = ceil((sqrt(d-1)+1)/2)-1` and the lower bound `Pr[lambda_2 >
  2 sqrt(d-1)] >= c n^{-s}` are the polynomial shadow of a finite subgraph. For a
  `Z^d`-periodic lattice the corresponding statement is deterministic and goes
  the other way: `lambda_2 = q - Theta(N^{-2/d})` always, so the failure
  probability of any fixed `eps`-Ramanujan property is 1. The exponent `s`
  becomes the geometric exponent `2/d`. The tree threshold `2 sqrt(q-1)` is
  never the right threshold for a lattice, which is the sharpest way to say why
  the tree-local-limit hypothesis in Friedman's theorem cannot be dropped.
* **biregular-spectral-gap (Brito, Dumitriu, Decker Harris).** Their two edges
  `sqrt(d_1-1)+sqrt(d_2-1)` and `sqrt(d_1-1)-sqrt(d_2-1)` come from the two roots
  of the Ihara-Bass quadratic. The lattice analogue of the two-edge structure is
  the pair of spectral edges of the quotient, each governed by its own
  effective-mass tensor. For a bipartite periodic graph such as the honeycomb the
  two edges are `+-Lambda_1(kappa)`, so the lower edge of the `n`-torus is `-3`
  and the second smallest is `-sqrt(5+4 cos(2 pi/n))`, the same constant as the
  upper edge (`out/s03_honeycomb.log`). A genuine biregular lattice, for instance
  the subdivision of a regular lattice, would give two different Hessians and is
  a clean next computation.
* **friedman-second-eigenvalue-lifts (Bordenave).** Theorem 23 bounds the new
  non-backtracking eigenvalues of a random lift by `sqrt(rho_1)`. In the abelian
  case the exact answer for the new adjacency spectrum is `Lambda_1(0)` and the
  new non-backtracking threshold would be the Perron value of the infinite
  non-backtracking operator on the periodic graph, which is `q-1` for a
  `q`-regular lattice and again trivial. The `1/n` remainder discount of his
  Proposition 8, which is what converts a norm bound into a spectral bound,
  has no abelian analogue since the tangle-free event is not a rare event.
* **relativized-second-eigenvalue (Friedman, Kohler).** Their old and new
  spectra are exactly the `kappa = 0` component and the rest in Lemma 2, so the
  exact decomposition `lambda_2 = max(Lambda_2(0), max_{kappa != 0} Lambda_1)`
  is the exact version of their Chapter 1 splitting. Their `eta_fund` has no
  amenable analogue (Section 4.2). Their open irregular-base conjecture is about
  the tree threshold for irregular bases, which for lattices is the wrong
  threshold, so the lattice results here say nothing against it.

### 7.2 Relation to the swarm menu

* Item A (periodic lattices, Bloch decomposition) is my own direction and this
  dossier occupies the narrow subproblem "second eigenvalue of finite abelian
  quotients and its arithmetic constant".
* Item E (random Cayley graphs with explicit connection sets, character spectra)
  is the closest neighbour. The difference: E is about random `S` at fixed
  group, my results are about fixed `S` and varying lattice. The two meet at
  Theorem B, which is a statement about character spectra of abelian groups.
* Item F (general finite-group Cayley graphs, filtered trace methods) is the
  non-abelian extension, Target T2.
* Item G (irregular universal covers, quotient matrices, skew products) contains
  the natural next question: replace the abelian cover by a skew product over an
  irrational rotation, where the "sampling" is by a Kronecker sequence and the
  defect should be governed by the Diophantine type of the frequency. Everything
  in Section 3 goes through formally with `n^{-2}` replaced by the squared
  discrepancy of the orbit, and I regard this as the single most promising
  unexplored refinement of the present dossier.
* Item C and D (hypergraph gaps `d-lambda_3`, non-backtracking operators) are
  untouched here. The one transferable observation is Section 3.5: for lattices
  the higher gaps are successive minima of one form, and the analogous statement
  for a uniform hypergraph would be a successive-minima statement for the
  hypergraph's symbol, which is a well posed question and probably open.

### 7.3 Prioritised next experiments and proofs

1. **(PROOF)** Conjecture A, or a counterexample. Highest value, because it fixes
   the exponent `2/d` for all connected periodic graphs. Suggested attack: prove
   that a flat direction forces pure gauge, using the analytic curve
   `kappa = t a` and the equality analysis of Lemma 1.
2. **(NUM)** Targeted search for near-singular `M`: periodic graphs with a large
   clique attached by few edges, winding on the bridges, `p` up to 8. Also
   irrational geometries, for instance the Penrose-like periodic approximants.
3. **(NUM)** Biregular periodic lattices: the subdivision of the square lattice,
   the `4.8.8` tiling, and the `(3,4)`-biregular square-octagon lattice. Two
   Hessians, two constants, and a direct comparison with the biregular dossier.
4. **(NUM)** Higher dimensional and higher-genus lattices: the `p = 2` honeycomb
   in `d = 2` is done, next are the kagome lattice (flat band, singular `M`
   expected for the flat band, and `Lambda_1` still nondegenerate) and the
   diamond lattice in `d = 3`.
5. **(NUM)** Skew products over irrational rotations, Section 7.2 item G, to see
   whether the Diophantine type of the frequency is visible in the defect.
6. **(PROOF)** Explicit constants: combine the Korotyaev-Saburova effective-mass
   estimates with Lemma 3 to get an explicit `O(mu^2)` in Theorem A.
7. **(NUM)** Random rewiring, Section 5.3, with a sharper protocol (fixed defect
   versus `c`, several `n`) to test the linear law in `c`.

-------------------------------------------------------------------------------

## 8. File map

* `PROOF-band-edge-law.md`: complete proofs of Lemma 1, 2, 3, Theorem 4,
  Corollaries 5 and 6, Lemma 7, and the limits of what is proved.
* `code/lib.py`: periodic graphs, Bloch matrices, sublattices of `Z^2`, exact
  minima of binary forms.
* `code/s01_abelian.py`: exact law for abelian Cayley lattices, sublattice range,
  arithmetic versus analytic minimum. Output `out/s01_abelian.log`, `.json`.
* `code/s01b_d3.py`: dimension 3, the two extremes `N^{-2/3}` and `N^{-2}`.
* `code/s03_honeycomb.py`: exact `lambda_2` of the hexagonal tori, factor 2.
* `code/s04_bloch_vs_explicit.py`: Bloch spectrum versus explicit finite graph,
  13 cases.
* `code/s05_cyclic.py`: cyclic covers of K4, Petersen, Q3, K33, closed form for
  the constant, finite differences, explicit lifts.
* `code/s06_girth_vs_ramanujan.py`: same girth, different local limits.
* `code/s07_structure.py`: the pure-gauge flat band, the positivity scan in one
  dimension, the crossover data.
* `code/s08_higher_gaps.py`: successive minima and the higher gaps.
* `code/s09_random_rewiring.py`: rewired tori, defect versus fraction rewired.
* `code/s10_M_formula_2d.py`: the closed form for `M` in two dimensions, and the
  disconnected four-vertex warning example.
* `code/s11_positivity_2d.py`: the correct connectivity test and the two
  dimensional positivity scan.
* `code/s12_coset_minimum.py`: the geometry of cosets (not of lattice vectors),
  folding the dual points into the fundamental domain, and an exact check of both
  inequalities of Theorem C over all sublattices of index `N <= 256`.
* `lit/`: the downloaded sources and their extracted text. `cioaba.txt` (C. R.
  Acad. Sci. note with the FMT statement), `agarwal.txt`, `breuer.txt`,
  `ks2013.txt`, `ks2015.txt`.
* `run_all.sh`: reruns every script in order.

## 9. Honest boundaries

* No proof assistant was used, so nothing here is formally verified.
* FMT 2006 was read only through two secondary sources, the publisher site
  refused automated access with a bot check.
* The positivity of `M` is a conjecture supported by 1927 random cases and no
  proof.
* The exponent `2/d` is established here only conditionally on Conjecture A. What
  is unconditional is the two-sided range `[Theta(N^{-2}), Theta(N^{-2/d})]` of
  Theorem C and the exact law of Theorem A up to `O(mu^2)` with `M` semidefinite.
* All numerical claims are floating point unless stated as exact rational
  arithmetic. The exact parts are the rational computations of the dual lattices
  and of the quadratic forms, everything involving cosines is floating point.
