# Erratum: the rank-one resolvent expansion of batch 050 (displayed identity only)

**Affected files (left untouched).** `results/050-finite-defect.md` §2 and
`.ultramath/smwgwbyn9/m2/proof.md` Lemma 1(iii), Lemma 2, and the display in §3.
The frozen proofs are not edited and are not reinterpreted; this is a separate erratum.

## The error

Batch 050 and m2 state (their `A' = A - dP`, `P = 11^T/n`, `A` the adjacency of a simple
`d`-regular graph)
```
(A - lam I)^{-1} = P/(d-lam) - sum_{k>=0} (A')^k / lam^{k+1}        (*)
```
and consequently, for `T` with `|T| = D`,
```
1_T^T (A - lam I)^{-1} 1_T = D^2/(n(d-lam)) - sum_{k>=0} 1_T^T (A')^k 1_T / lam^{k+1}.   (**)
```
`(*)` is false. Its right-hand side kills the Perron direction: `A'^k 1 = 0` for `k >= 1`
but `(A')^0 1 = 1`, so the series contributes `-1/lam` on `span{1}`, whereas
`(A - lam I)^{-1} 1 = 1/(d-lam)`. The correct identity is
```
(A - lam I)^{-1} = P/(d-lam) + P/lam - sum_{k>=0} (A')^k / lam^{k+1},      (+) 
```
equivalently `(A-lam)^{-1} = P/(d-lam) + (I-P)(A'-lam)^{-1}(I-P)`, and consequently
```
1_T^T (A - lam I)^{-1} 1_T = D^2/(n(d-lam)) - sum_{k>=0} 1_T^T (A')^k 1_T / lam^{k+1}
                             + D^2/(n lam).                                (++ )
```
`(+)` is correct on `span{1}` (`1/(d-lam) + 1/lam - 1/lam`) and on `1^perp`
(`-sum_k (A'/lam)^k / lam = (A'-lam)^{-1}`), which is a complete proof.

## Exact refutation and confirmation (`check_rank_one_identity.py`, `out/rank_one_identity_check.txt`)

Petersen graph (`d=3, n=10`, spectrum `3,1^5,(-2)^4`, so `||A'|| = 2` exactly),
`lam = 5/2` (between host eigenvalues, so the sign is a genuine test), `T` an edge,
`D=2`, all arithmetic in `fractions.Fraction`, and the *rigorous* tail bound
`|sum_{k>=K} 1_T^T (A')^k 1_T lam^{-k-1}| <= D rho^K/(lam(1-rho))`, `rho = 4/5`,
which at `K = 60` is `6.1e-6`.
* `1_T^T (A-lam)^{-1} 1_T = -4/27 = -0.148148148148`.
* `S_60 = 1.108148057334`, so `4/(n(d-lam)) - S_60 = -0.308148`; the frozen `(**)` is
  wrong by `+0.160000` — exactly `D^2/(n lam) = 4/25`, i.e. 26 000 times the tail bound.
* `4/(n(d-lam)) - S_60 + D^2/(n lam) = -0.148148057`, and the residual is `9.1e-8`, inside
  the rigorous tail bound. `(++)` is confirmed.

## Consequence: no theorem-level conclusion changes

The repaired term is `D^2/(n lam) <= D^2/(n lam_min) = O(1/n)` on any compact window with
`lam >= lam_min > 0`. Every quantitative statement of batch 050 carries an explicit
`+O(1/n)` slack:
* Theorem A (resolvent limit) — bound already contains `+1/n`; the extra term is absorbed
  with a larger constant.
* Theorem B (limiting eigenvalues) — limit statement, unaffected.
* Theorem C (`n(d-lam_2) -> D^2/(D G_d(d) - d)`) — the extra term at `lam = d - s/n` is
  `D^2/(n lam) = O(1/n)`, negligible against the retained `D^2/s` and inside the stated
  `O(log n / n)` error. The constant `D^2/(D G_d(d)-d)` is unchanged.
* The separated-case erratum list (batch 050 §3) is unaffected.
So this is an error in an *exact displayed identity*, not in any limit theorem; but a proof
that leans on `(**)` as an identity is invalid as written and needs the one-term patch.
Batch 060's own Theorem A (m4 `NOTE.md`) uses `(++)`.

## What this erratum does not touch

The batch 050 conclusions about `-Delta G_d` for separated `T`, the Perron-removal idea,
`(A'^k)_{yy'} = (A^k)_{yy'} - d^k/n`, the finite-size constant, the interlacing analysis and
the `1 + 1_T^T(A-lam)^{-2}1_T > 0` monotonicity of `Sigma_n` are all correct as stated.
