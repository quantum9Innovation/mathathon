"""
Numerical corroboration for the m3 theorem (exterior resolvent limit, fixed d>=3).

 A. Exact symbolic Perron (Sherman-Morrison) identity, checked at rational lambda.
 B. Tree resolvent identity  ((lam-A_{Td})^{-1})_{xy} = G_d(lam) r(lam)^{dist(x,y)}
    on genuine d-regular trees (root has d children, others d-1).
 C. Main limit: 1_T^T (A-lam)^{-1} 1_T + Delta^2/(n(lam-d)) -> -Delta G_d(lam)
    for lam in (d,inf) and in (2 sqrt(d-1), d).  Graphs are drawn from the
    configuration model conditioned on simplicity (= uniform simple d-regular);
    the only approximation is the pseudo-random source (numpy PCG64, fixed seed).
 D. The deterministic form of (H) is FALSE: with T={0,1} adjacent,
    1_T^T G 1_T -> -G_d(2+2r+...)  not -2 G_d, and the added-vertex top
    eigenvalue moves above the bulk edge.

python3 check_theorem.py
"""
import numpy as np
import scipy.sparse as sp
import scipy.sparse.linalg as spla
import sympy as sy
import networkx as nx


def regular_tree(d, R):
    """Genuine d-regular tree truncated at depth R (root has d children)."""
    G = nx.Graph()
    G.add_node(0)
    frontier = [0]
    for level in range(R):
        nxt = []
        for v in frontier:
            nch = d if level == 0 else d - 1
            for _ in range(nch):
                u = G.number_of_nodes()
                G.add_node(u); G.add_edge(v, u); nxt.append(u)
        frontier = nxt
    return G


def uniform_regular(n, d, rng, max_try=10**7):
    """Uniform simple d-regular graph: configuration model + rejection."""
    assert n * d % 2 == 0
    m = n * d // 2
    for _ in range(max_try):
        stubs = np.repeat(np.arange(n), d)
        rng.shuffle(stubs)
        a, b = stubs[0::2], stubs[1::2]
        lo, hi = np.minimum(a, b), np.maximum(a, b)
        if np.any(lo == hi):
            continue
        if np.unique(lo.astype(np.int64) * n + hi).size != m:
            continue
        rows = np.concatenate([a, b]); cols = np.concatenate([b, a])
        return sp.csr_matrix((np.ones(2 * m), (rows, cols)), shape=(n, n))
    raise RuntimeError("sampler failed")


def km(d, lam):
    r = (lam - np.sqrt(lam * lam - 4 * (d - 1))) / (2 * (d - 1))
    return r / (1 - r * r), r


def checkA():
    print("== A. exact identity 1_T^T(A-lam)^{-1}1_T = 1_T^T(Ahat-lam)^{-1}1_T"
          " + Delta^2/(n lam) - Delta^2/(n(lam-d))   [Ahat = A-(d/n)J] ==", flush=True)
    graphs = [("K4", nx.complete_graph(4)), ("Q3", nx.hypercube_graph(3)),
              ("Petersen", nx.petersen_graph()), ("K5", nx.complete_graph(5)),
              ("C5xK2", nx.cartesian_product(nx.cycle_graph(5),
                                            nx.complete_graph(2)))]
    lams = [sy.Rational(7, 3), sy.Rational(11, 5), sy.Rational(-13, 4)]
    for name, G in graphs:
        G = nx.convert_node_labels_to_integers(G, 0)
        n = G.number_of_nodes()
        A = nx.to_numpy_array(G).astype(int)
        d = int(A.sum(1)[0])
        deg_ok = bool(np.all(A.sum(1) == d))
        Ahat = sy.Matrix(A) - sy.Rational(d, n) * sy.ones(n, n)
        ok = True
        for D in [1, 2, 3]:
            if D > n:
                continue
            e = np.zeros(n, dtype=int); e[list(range(D))] = 1
            for lam in lams:
                M1 = (sy.Matrix(A) - lam * sy.eye(n)).inv()
                M2 = (Ahat - lam * sy.eye(n)).inv()
                lhs = (sy.Matrix(e).T * M1 * sy.Matrix(e))[0, 0]
                rhs = ((sy.Matrix(e).T * M2 * sy.Matrix(e))[0, 0]
                       + sy.Rational(D * D, n) / lam
                       - sy.Rational(D * D, n) / (lam - d))
                ok = ok and sy.simplify(lhs - rhs) == 0
        print(f"  {name:9s} n={n:2d} d={d} regular={deg_ok}  identity exact for "
              f"Delta in {{1,2,3}}, lam in {{7/3,11/5,-13/4}}: {ok}", flush=True)


def checkB():
    print("== B. tree identity ((lam-A_{Td})^{-1})_{xy} = G_d(lam) r(lam)^{dist}"
          "   (d-regular trees, sparse solve) ==", flush=True)
    for d, lam, R in [(3, 3.3, 10), (3, 2.95, 12), (4, 4.4, 8), (5, 5.6, 7)]:
        T = regular_tree(d, R)
        n = T.number_of_nodes()
        A = nx.to_scipy_sparse_array(T, nodelist=list(range(n))).tocsr()
        lu = spla.splu((lam * sp.identity(n, format='csc') - A).tocsc())
        Gd, r = km(d, lam)
        dist = dict(nx.single_source_shortest_path_length(T, 0))
        ys = [y for y, k in dist.items() if k <= R - 2]
        e0 = np.zeros(n); e0[0] = 1.0
        col = lu.solve(e0)
        err = max(abs(col[y] - Gd * r ** dist[y]) for y in ys)
        print(f"  d={d} lam={lam:5.2f} R={R:2d} |V|={n:6d} r={r:.6f} G_d={Gd:.6f}"
              f"  max|G_xy-G_d r^dist| over {len(ys):6d} y = {err:.2e}", flush=True)


def checkC():
    print("== C. 1_T^T(A-lam)^{-1}1_T + Delta^2/(n(lam-d)) + Delta G_d(lam) -> 0 ==",
          flush=True)
    cases = [(3, 2, [3.30, 2.95], [1000, 4000, 16000]),
             (3, 6, [3.30, 2.95], [1000, 4000, 16000]),
             (4, 8, [4.40, 3.60], [1000, 4000, 16000]),
             (5, 9, [5.60, 4.20], [1000, 4000])]
    rng = np.random.default_rng(7)
    for d, D, lams, ns in cases:
        print(f"  -- d={d} Delta={D}   bulk edge 2sqrt(d-1)={2*np.sqrt(d-1):.4f}",
              flush=True)
        for lam in lams:
            Gd, r = km(d, lam)
            pred = -D * Gd
            row = []
            for n in ns:
                errs = []
                for rep in range(5):
                    A = uniform_regular(n, d, rng)
                    e = np.zeros(n); e[list(range(D))] = 1.0
                    lu = spla.splu((A - lam * sp.identity(n)).tocsc())
                    vals = e @ lu.solve(e) + D * D / (n * (lam - d))
                    errs.append(abs(vals - pred))
                row.append(f"n={n:6d} max {max(errs):.2e} mean {np.mean(errs):.2e}")
            print(f"     lam={lam:5.2f} (-Delta G_d={pred:+.6f})  " + " | ".join(row),
                  flush=True)


def relabel_edge_first(A):
    """Permute labels so that the first stored edge becomes (0,1)."""
    Ac = A.tocoo()
    i0, i1 = int(Ac.row[0]), int(Ac.col[0])
    n = A.shape[0]
    perm = np.arange(n)
    perm[[0, i0]] = perm[[i0, 0]]
    pos = int(np.where(perm == i1)[0][0])
    perm[[1, pos]] = perm[[pos, 1]]
    return A[perm][:, perm]


def checkD():
    print("== D. deterministic (H) fails when T has an internal edge ==", flush=True)
    print("   d=3, Delta=2, T={0,1} with 0~1: tree value -G_d(2+2r), false (H) -2G_d",
          flush=True)
    rng = np.random.default_rng(11)
    d = 3
    for lam in [3.3, 2.95]:
        Gd, r = km(d, lam)
        tree_val, flat_val = -Gd * (2 + 2 * r), -2 * Gd
        for n in [2000, 8000]:
            got = []
            for rep in range(20):
                A = uniform_regular(n, d, rng)
                A2 = relabel_edge_first(A)
                e = np.zeros(n); e[0] = 1.0; e[1] = 1.0
                lu = spla.splu((A2 - lam * sp.identity(n)).tocsc())
                got.append(e @ lu.solve(e) + 4.0 / (n * (lam - d)))
            print(f"     lam={lam:4.2f} n={n:5d} value={np.mean(got):+.6f} "
                  f"(sd {np.std(got):.1e})  tree -G_d(2+2r)={tree_val:+.6f}  "
                  f"(H) -2G_d={flat_val:+.6f}", flush=True)
    print("   consequence: top eigenvalue of the added-vertex graph G'", flush=True)
    for n in [2000, 8000]:
        tops_adj, tops_ind = [], []
        for rep in range(10):
            A = uniform_regular(n, d, rng)
            A2 = relabel_edge_first(A).toarray()
            for T, store in [([0, 1], tops_adj), ([0, 3], tops_ind)]:
                Abig = np.zeros((n + 1, n + 1))
                Abig[1:, 1:] = A2
                Abig[0, T] = 1; Abig[T, 0] = 1
                Asp = sp.csr_matrix(Abig)
                store.append(spla.eigsh(Asp, k=1, which='LA',
                                        return_eigenvectors=False)[0])
        print(f"     n={n:5d} max eig of G': T adjacent {np.mean(tops_adj):.5f} | "
              f"T 'independent' {np.mean(tops_ind):.5f} | 2sqrt(d-1)="
              f"{2*np.sqrt(d-1):.5f}", flush=True)


if __name__ == "__main__":
    checkA(); checkB(); checkC(); checkD()
