"""The signed Gram identity for 2-covers, and the resulting dichotomy.

Claim (T15).  Let H be (d,k)-regular, and let a Z_2-cover be given by voltages volt[v,e] in
{0,1} on the incidences.  The antisymmetric ('new') part of the cover is
    S_uv = sum_{e ni u,v} (-1)^(volt[u,e]+volt[v,e])   (u != v),   S_uu = 0,
and if Xtilde[v,e] = X[v,e] (-1)^(volt[v,e]) then  S + d I = Xtilde Xtilde^T, hence
lambda_min(S) >= -d for EVERY signing.  Consequences:
  d >= k  =>  the left-sided Ramanujan condition holds for every 2-cover (window bottom <= -d),
  d <  k  =>  it fails for every 2-cover (T12 forces -d into the new spectrum).
"""
import itertools
import numpy as np
from hyp import fengli, spec, window, degrees
from exp6_two_lifts import setup

rng = np.random.default_rng(2024)


def check(name, edges, n, nsample=40, seed=0):
    d = int(degrees(edges, n)[0])
    k = len(edges[0])
    A, X = fengli(edges, n)
    inc, index, tree, free = setup(edges, n, rng)
    rank = len(free)
    lo, hi = window(d, k)
    worst = np.inf
    minmult = 10 ** 9
    for _ in range(nsample):
        bits = [0] * rank
        free_bits = [int(x) for x in np.random.default_rng(seed + _).integers(0, 2, size=rank)]
        volt = {pe: 0 for pe in inc}
        for pe, b in zip(free, free_bits):
            volt[pe] = b
        S = np.zeros((n, n))
        Xt = np.zeros_like(X)
        for v in range(n):
            for e in range(len(edges)):
                if X[v, e]:
                    Xt[v, e] = (-1) ** volt[(v, e)]
        for j, e in enumerate(edges):
            for a in e:
                for b in e:
                    if a != b:
                        S[a, b] += (-1) ** (volt[(a, j)] + volt[(b, j)])
        # signed Gram identity
        assert np.abs(S + d * np.eye(n) - Xt @ Xt.T).max() < 1e-12, "signed Gram identity fails"
        w = np.linalg.eigvalsh(S)
        worst = min(worst, w[0])
        minmult = min(minmult, int(np.sum(np.abs(w + d) < 1e-8)))
    print(f"{name:34s} d={d} k={k} 2^rank={2**rank:>8d} window=({lo:8.4f},{hi:8.4f})  "
          f"min over signings of bottom = {worst:8.4f}  (-d = {-d})  "
          f"always >= -d: {worst >= -d - 1e-9}  left-sided always: {worst >= lo - 1e-9}  "
          f"min mult_S(-d)={minmult}")


print("=== signed Gram identity and the left-sided dichotomy ===")
for (d, k, n, s) in ((3, 3, 12, 6), (4, 3, 12, 8), (4, 4, 8, 21), (3, 4, 12, 9),
                     (2, 3, 12, 5), (2, 5, 20, 12), (5, 3, 15, 31), (2, 4, 16, 11)):
    from hyp import config_model_hypergraph
    E = config_model_hypergraph(n, d, k, np.random.default_rng(s))
    check(f"random ({d},{k})-regular", E, n, seed=100 + s)

from hyp import cyclic_interval_hypergraph
for (q, k) in ((6, 3), (8, 4), (9, 3)):
    check(f"cyclic interval H({q},{k})", *cyclic_interval_hypergraph(q, k), seed=q)
