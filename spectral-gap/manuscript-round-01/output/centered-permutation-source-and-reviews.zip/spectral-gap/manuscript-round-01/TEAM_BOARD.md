# Problem 21 coordinator board

| Task | Owner | Status | Output and acceptance |
| --- | --- | --- | --- |
| SG-M1 | Proof investigator | done | All three core proofs reconstructed. Exact factorial correction and optimal universal sqrt(e) prefactor proved in mixed revision 3, with independent integrator review |
| SG-M2 | Source investigator | done | Published question, source identities and version map verified. Bounded priority search and verified bibliography frozen |
| SG-M3 | Extension investigator | done | Relative hyperbolic window and square-root correction frozen and independently reviewed |
| SG-M4 | Integrator | done | A 19-page manuscript and five-page guide compiled, visually inspected and accepted. Claims SG-06 through SG-08 integrated. Source and evidence package prepared |
| SG-M5 | Independent referee | done | Fresh assembled-source audit and final-revision delta review complete. All five findings closed at frozen revision 4 |

Ownership is local to this round. Shared cross-topic coordinator records are not overwritten while another session owns them.
