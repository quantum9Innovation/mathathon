#!/bin/sh
# Reproduce every computation in this dossier. Run from this directory.
# exp2 and exp2b take about 9 and 4 minutes (dense eigensolves up to n = 3000).
set -e
cd "$(dirname "$0")/scripts"
python3 exp1_exact_structure.py   > ../outputs/exp1_exact_structure.txt   2>&1
python3 exp2_random_regular.py    > ../outputs/exp2_random_regular.txt    2>&1
python3 exp2b_random_regular.py   > ../outputs/exp2b_random_regular.txt   2>&1
python3 exp3_cyclic_interval.py   > ../outputs/exp3_cyclic_interval.txt   2>&1
python3 exp3b_fejer_and_gcd.py    > ../outputs/exp3b_fejer_and_gcd.txt    2>&1
python3 exp4_biregular_nb.py      > ../outputs/exp4_biregular_nb.txt      2>&1
python3 exp5_figures.py           > ../outputs/exp5_figures.txt           2>&1
python3 exp6_two_lifts.py         > ../outputs/exp6_two_lifts.txt         2>&1
python3 exp7_lift_obstruction.py  > ../outputs/exp7_lift_obstruction.txt  2>&1
python3 exp8_signed_gram.py       > ../outputs/exp8_signed_gram.txt       2>&1
echo "all outputs regenerated in ../outputs"
