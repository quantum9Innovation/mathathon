r"""Core library: periodic graphs, Bloch/Floquet spectra, abelian quotients.

Conventions
-----------
lambda_1 >= lambda_2 >= ... are adjacency eigenvalues, ordered by value (not by
absolute value).  The period group is Z^d acting freely and cofinitely on the
connected graph Gamma.  B = Gamma / Z^d is the collapsed graph, p = |V(B)|.
A(kappa), kappa in T^d = R^d/Z^d, is the p x p Bloch (fiber) matrix, and
Lambda_j(kappa) is its j-th eigenvalue.

For a finite-index subgroup Lambda <= Z^d of index N, with G_Lambda = Lambda \ Gamma,

    Spec(A_{G_Lambda}) = { Lambda_j(kappa) : kappa in Lambda^* / Z^d, j }.

Here Lambda^* = { x in R^d : <x,l> in Z for all l in Lambda } is the dual
lattice, and Lambda^*/Z^d is a finite group of order N.
"""
import numpy as np
import itertools, math
from fractions import Fraction


# --------------------------------------------------------------------------
# abelian Cayley graphs of Z^d
# --------------------------------------------------------------------------

def cayley_torus_eigs(S, nvec):
    """Spectrum of Cay(G,S), G = prod_i Z/nvec[i], S symmetric subset of Z^d."""
    ks = np.array(list(itertools.product(*[range(n) for n in nvec])), dtype=float)
    ks = ks / np.array(nvec, dtype=float)
    S = np.array(S, dtype=float)
    phases = 2*np.pi*(ks @ S.T)
    return np.sort(np.cos(phases).sum(axis=1))[::-1]


def all_chars(S, nvec):
    """Return (characters, eigenvalues) for the torus, characters as fractions."""
    ks = list(itertools.product(*[range(n) for n in nvec]))
    S = np.array(S, dtype=float)
    vals = []
    for k in ks:
        kk = np.array(k, dtype=float)/np.array(nvec, dtype=float)
        vals.append(np.cos(2*np.pi*(S @ kk)).sum())
    return ks, np.array(vals)


def gram_form(S):
    """M = 4*pi^2 * sum_{s in S} s s^T, so Lambda_1(k)=|S| - k^T M k/2 + O(|k|^4)."""
    S = np.array(S, dtype=float)
    return 4*np.pi**2*(S.T @ S)


# --------------------------------------------------------------------------
# explicit Z^d-periodic graphs
# --------------------------------------------------------------------------

class PeriodicGraph:
    """Z^d-periodic graph from a finite list of vertex types and oriented edges.

    edges: list of (u, v, g) with u, v in range(p) and g in Z^d.  Such a triple
    means: for every cell x, vertex (x,u) is joined to vertex (x+g, v).
    Each undirected edge is listed exactly once.  Multiple edges and loops
    (u == v, g == 0) are allowed.
    """

    def __init__(self, p, edges, d=None):
        self.p = p
        self.edges = [(u, v, tuple(int(t) for t in g)) for (u, v, g) in edges]
        self.d = len(self.edges[0][2]) if self.edges else (d or 0)

    def A(self, kappa):
        kappa = np.asarray(kappa, dtype=float)
        M = np.zeros((self.p, self.p), dtype=complex)
        for (u, v, g) in self.edges:
            ph = np.exp(2j*np.pi*float(np.dot(kappa, g)))
            M[u, v] += ph
            M[v, u] += np.conj(ph)
        return M

    def Lambda(self, kappa):
        return np.sort(np.linalg.eigvalsh(self.A(kappa)))[::-1]

    def decompactify(self, ks, nvec):
        """For ks[i] = z/nvec, hide the Bloch expansion."""
        return [self.A(np.array(k, dtype=float)/np.array(nvec, dtype=float))
                for k in ks]

    # ---- explicit finite quotient -------------------------------------
    def quotient(self, nvec, gen=None):
        """Explicit adjacency matrix of Z^d/nvec - quotient (nvec[i] copies)."""
        nvec = [int(t) for t in nvec]
        cells = list(itertools.product(*[range(n) for n in nvec]))
        idx = {c: i for i, c in enumerate(cells)}
        N = len(cells)*self.p
        Adj = np.zeros((N, N))
        for c in cells:
            for (u, v, g) in self.edges:
                t = tuple((c[i]+g[i]) % nvec[i] for i in range(self.d))
                i = idx[c]*self.p + u
                j = idx[t]*self.p + v
                Adj[i, j] += 1
                if i != j or True:
                    Adj[j, i] += 1 if (u, v, g) != (v, u, (-np.array(g)).tolist()) else 0
        return Adj

    def adjacency(self, nvec):
        """Finite quotient, built so that each listed edge contributes 1."""
        nvec = [int(t) for t in nvec]
        cells = list(itertools.product(*[range(n) for n in nvec]))
        idx = {c: i for i, c in enumerate(cells)}
        N = len(cells)*self.p
        Adj = np.zeros((N, N))
        for c in cells:
            for (u, v, g) in self.edges:
                t = tuple((c[i]+g[i]) % nvec[i] for i in range(self.d))
                i = idx[c]*self.p + u
                j = idx[t]*self.p + v
                if i == j:
                    Adj[i, i] += 2 if (u == v and all(x == 0 for x in g)) else 1
                else:
                    Adj[i, j] += 1
                    Adj[j, i] += 1
        return Adj


# --------------------------------------------------------------------------
# sublattices of Z^2 and dual points
# --------------------------------------------------------------------------

def sublattices_2d(N):
    """All index-N sublattices of Z^2, as HNF basis matrices [[a,b],[0,d]]."""
    out = []
    for a in range(1, N+1):
        if N % a:
            continue
        d = N//a
        for b in range(0, d):
            out.append((a, b, d))
    return out


def dual_points_2d(a, b, d):
    """Elements of Lambda^*/Z^2 for Lambda = <(a,b),(0,d)>, as exact Fractions
    in [0,1)^2."""
    pts = []
    for i in range(a):
        for j in range(d):
            # x.(a,b) = i, x.(0,d) = j
            x = Fraction(i, a) - Fraction(b*j, a*d)
            y = Fraction(j, d)
            pts.append((x % 1, y % 1))
    assert len(set(pts)) == a*d
    return pts


def frob_sq(z):
    return z[0]*z[0] + z[1]*z[1]


# --------------------------------------------------------------------------
# exact minimum of a positive definite binary quadratic form over Z^2 \ {0}
# --------------------------------------------------------------------------

def form_min_exact(Q):
    """Brute force with a rigorous radius.  Q given as ((a,b),(b,c)) exact."""
    a = Fraction(Q[0][0]); b = Fraction(Q[0][1]); c = Fraction(Q[1][1])
    lam = float(a+c)/2 - math.sqrt(float((a-c))**2/4 + float(b)**2)
    assert lam > 0
    # Q(z) >= lam*|z|^2
    best = None; bestz = None
    for x in range(-3, 4):
        for y in range(-3, 4):
            if x == 0 and y == 0:
                continue
            val = a*x*x + 2*b*x*y + c*y*y
            if best is None or val < best:
                best, bestz = val, (x, y)
    R = int(math.ceil(math.sqrt(float(best)/lam))) + 1
    for x in range(-R, R+1):
        for y in range(-R, R+1):
            if x == 0 and y == 0:
                continue
            val = a*x*x + 2*b*x*y + c*y*y
            if val < best:
                best, bestz = val, (x, y)
    return best, bestz


def gauss_reduce(Q):
    """Gauss reduction of a positive definite binary form; returns reduced
    (a,b,c) with a <= c and |b| <= a and the minimal value."""
    a = Fraction(Q[0][0]); b = Fraction(Q[0][1]); c = Fraction(Q[1][1])
    while True:
        if c < a:
            a, c = c, a
            b = -b
        m = int(math.floor(float(b)/(2*float(a)) + 0.5))
        b = b - 2*m*a
        c = c - 2*m*b + m*m*a if False else c
        # recompute c faithfully: c_new = a m^2 - 2 b_old m + c_old  -> use matrices
        break
    # fall back to the verified brute force
    return form_min_exact(Q)
