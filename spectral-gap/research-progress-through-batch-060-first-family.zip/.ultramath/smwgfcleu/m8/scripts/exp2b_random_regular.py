"""Second batch for the random regular hypergraph test: (d,k) with k | n*d constraints."""
import json
import numpy as np
from scipy.linalg import eigh
from hyp import config_model_hypergraph, fengli, components, window

rng = np.random.default_rng(777)
rows = []
configs = [((4, 3), [300, 600, 1200, 2400]),
           ((5, 3), [300, 600, 1200, 2400]),
           ((6, 4), [300, 600, 1200, 2400]),
           ((2, 5), [250, 500, 1000, 2000]),
           ((3, 3), [300, 1200])]
TRIALS = 3
for (d, k), ns in configs:
    for n in ns:
        if (n * d) % k:
            continue
        vals = []
        for _ in range(TRIALS):
            E = config_model_hypergraph(n, d, k, rng)
            A, X = fengli(E, n)
            w = eigh(A.astype(float), eigvals_only=True, driver="evr")[::-1]
            vals.append((w[1], w[-1], components(A)))
        lam2 = np.array([v[0] for v in vals])
        lammin = np.array([v[1] for v in vals])
        t_edge = k - 2 + 2 * np.sqrt((d - 1) * (k - 1))
        naive = 2 * np.sqrt((k - 1) * d - 1)
        rec = dict(d=d, k=k, n=n, lam2_mean=float(lam2.mean()), true_edge=float(t_edge),
                   naive=float(naive), edge_minus_lam2=float((t_edge - lam2).mean()),
                   lam2_minus_naive_min=float((lam2 - naive).min()),
                   lammin_mean=float(lammin.mean()), win_lo=float(window(d, k)[0]),
                   max_components=int(max(v[2] for v in vals)))
        rows.append(rec)
        print(f"d={d} k={k} n={n:5d} comps={rec['max_components']} lam2={lam2.mean():9.5f} "
              f"edge={t_edge:9.5f} naive={naive:9.5f} edge-lam2={t_edge-lam2.mean():7.5f} "
              f"lam2-naive(min)={rec['lam2_minus_naive_min']:7.5f} lammin={lammin.mean():9.5f} "
              f"winlo={window(d,k)[0]:9.5f}", flush=True)
json.dump(rows, open("../outputs/exp2b_random_regular.json", "w"), indent=1)
print("all runs have lam2 > naive:", all(r["lam2_minus_naive_min"] > 0 for r in rows))
