r"""The honeycomb lattice: exact lambda_2 of every hexagonal torus, and the
factor 2 between the arithmetic and the analytic minimum of the band Hessian.

Bloch matrix (2 vertices per cell, A at 0 and B at delta):
    A(kappa) = [[0, f], [conj f, 0]],  f = 1 + e^{2 pi i k_1} + e^{2 pi i k_2},
so Lambda_1(kappa) = |f(kappa)| and Lambda_2(kappa) = -|f(kappa)|.

Near kappa = 0:  |f| = 3 - (1/2) kappa^T M kappa + O(|kappa|^4) with
    M = (2 pi)^2 G,  G = (1/3) [[2,-1],[-1,2]],
so the arithmetic minimum m(G) = 2/3 while lambda_min(G) = 1/3.
"""
import sys, os, json, itertools
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
from fractions import Fraction
import lib

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "out")


def f(k):
    return 1 + np.exp(2j*np.pi*k[0]) + np.exp(2j*np.pi*k[1])


def bloch_top(k):
    return abs(f(k))


def main():
    log = []
    hon = lib.PeriodicGraph(2, [(0, 1, (0, 0)), (0, 1, (-1, 0)), (0, 1, (0, -1))])
    G = (1/3)*np.array([[2., -1.], [-1., 2.]])
    eig = np.linalg.eigvalsh(G)
    # exact arithmetic minimum of G over Z^2 \ 0
    mG = min(Fraction(2, 3)*(x*x - x*y + y*y) for x in range(-6, 7) for y in range(-6, 7)
             if (x, y) != (0, 0))
    log.append("honeycomb band Hessian  G = (1/3)[[2,-1],[-1,2]]")
    log.append(f"  lambda_min(G) = {eig[0]:.12f}   lambda_max(G) = {eig[1]:.12f}")
    log.append(f"  arithmetic minimum m(G) = {mG} (= {float(mG):.12f})")
    log.append(f"  m(G)/lambda_min(G) = {float(mG)/eig[0]:.12f}  (exactly 2)")
    log.append("")
    log.append("n x n hexagonal torus: 2 n^2 vertices, exact gap and its law")
    log.append("   n      N        lambda_2 (exact)      sqrt(5+4cos(2pi/n))"
               "     gap         gap*n^2      4pi^2/3")
    rows = []
    for n in [2, 3, 4, 5, 6, 8, 10, 12, 16, 20, 25, 30, 40, 60, 80]:
        pts = lib.dual_points_2d(n, 0, n)
        vals = sorted((bloch_top((float(a), float(b))) for (a, b) in pts))[::-1]
        gap = 3.0 - vals[1]
        exact = np.sqrt(5+4*np.cos(2*np.pi/n))
        rows.append(dict(n=n, N=2*n*n, gap=gap, exact=exact, scaled=gap*n*n))
        log.append(f"  {n:3d} {2*n*n:7d}  {vals[1]:.15f}   {exact:.15f}  "
                   f"{gap:.9e}  {gap*n*n:.9f}  {4*np.pi**2/3:.9f}")
    log.append("")
    log.append("naive prediction using lambda_min(G) instead of m(G) would give")
    log.append(f"  2 pi^2 lambda_min(G)/n^2 = {2*np.pi**2*eig[0]:.9f}/n^2  "
               f"vs the truth {2*np.pi**2*float(mG):.9f}/n^2 : factor "
               f"{float(mG)/eig[0]:.6f}")
    log.append("")
    log.append("skewed quotient Lambda = <(1,0),(0,N/'?)>:  use <(N,0),(0,1)>")
    log.append("   N       gap          gap*N^2")
    for N in [2, 5, 10, 20, 50, 100]:
        # Lambda = <(N,0),(0,1)>, dual points (j/N, 0)
        pts = [(Fraction(j, N), Fraction(0)) for j in range(1, N)]
        vals = sorted((bloch_top((float(a), float(b))) for (a, b) in pts))[::-1]
        gap = 3.0 - vals[0]
        log.append(f"  {N:4d}  {gap:.9e}  {gap*N*N:.9f}")

    # also: the full band max is at kappa=0 (Perron-Frobenius domination check)
    grid = np.linspace(0, 1, 401, endpoint=False)
    mx = max(bloch_top((a, b)) for a in grid for b in grid)
    log.append("")
    log.append(f"max over a 401x401 grid of the top band = {mx:.15f} "
               f"(value at 0 is 3), so the band edge is at kappa = 0")
    txt = "\n".join(log)
    open(os.path.join(OUT, "s03_honeycomb.log"), "w").write(txt)
    json.dump(rows, open(os.path.join(OUT, "s03_honeycomb.json"), "w"), indent=1)
    print(txt)


if __name__ == "__main__":
    main()
