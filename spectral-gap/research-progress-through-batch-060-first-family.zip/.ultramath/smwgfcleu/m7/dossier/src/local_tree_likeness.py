"""Check local tree-likeness by comparing closed-walk counts with the d-regular tree."""
import sys
sys.path.insert(0, 'dossier/src')
import numpy as np
from cayley import *
import builtins
def pp(*a, **k):
    k.setdefault('flush', True)
    builtins.print(*a, **k)


from tree_walks import tree_counts as tree_closed_walks


def closed_walks(G, S, L):
    A = G.adjacency(S)
    M = np.eye(G.n)
    out = [float(np.trace(M))]
    for _ in range(L):
        M = M @ A
        out.append(round(float(np.trace(M))))
    return [int(round(x)) for x in out]


if __name__ == '__main__':
    pp("d=3 tree closed walks (root):", tree_closed_walks(3, 10))
    pp("d=4 tree closed walks (root):", tree_closed_walks(4, 8))
    cases = []
    S4 = sym_group(4); A5 = alt_group(5); S5 = sym_group(5)
    # S4 cubic minimiser
    thr = 2 * np.sqrt(2)
    best = None
    for S in S4.symmetric_sets(3):
        if not S4.connected(S):
            continue
        lam = S4.lambda_two_sided(S)
        if best is None or lam < best[0]:
            best = (lam, S)
    cases.append(('S4 d=3 minimiser (girth 6)', S4, best[1]))
    best = None
    for S in A5.symmetric_sets(3):
        if not A5.connected(S):
            continue
        lam = A5.lambda_two_sided(S)
        if best is None or lam < best[0]:
            best = (lam, S)
    cases.append(('A5 d=3 minimiser (claimed girth 9)', A5, best[1]))
    best = None
    for S in S5.symmetric_sets(3):
        if not S5.connected(S):
            continue
        lam = S5.lambda_two_sided(S)
        if best is None or lam < best[0]:
            best = (lam, S)
    cases.append(('S5 d=3 minimiser (claimed girth 8)', S5, best[1]))
    for name, G, S in cases:
        L = 10
        cw = closed_walks(G, S, L)
        tv = tree_closed_walks(3, L)
        # per-vertex tree count = tv / n  is NOT right for totals; total closed walks
        # in a d-regular graph locally tree-like to radius r equal n * A_l for l <= 2r-1 approx
        pp("%s n=%d  closed walks %s" % (name, G.n, cw))
        pp("    tree*%d          %s" % (G.n, [G.n * x for x in tv]))
        div = [i for i in range(L + 1) if cw[i] != G.n * tv[i]]
        pp("    first length where counts differ from n*tree: %s (implies girth = %s)"
           % (div[0] if div else None, (div[0] if div else L + 1)))
    # prism check for m = 3
    G = dihedral_group(3)
    rot = G.pos[tuple((i + 1) % 3 for i in range(3)) + tuple(3 + (i + 1) % 3 for i in range(3))]
    ref = G.pos[tuple((3 - i) % 3 for i in range(3)) + tuple(3 + (3 - i) % 3 for i in range(3))]
    S = tuple(sorted({rot, int(G.inv[rot]), ref}))
    pp("m=3 prism: S size %d, spectrum %s" % (len(S), np.round(G.spectrum(S), 9)))
