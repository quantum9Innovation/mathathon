"""Readable digest of the raw numerics json (no recomputation)."""
import json
e=json.load(open('out/numerics_eig.json')); t=json.load(open('out/numerics_trend.json'))
r=json.load(open('out/numerics_resolvent2.json'))
out=[]
def p(s):
    out.append(str(s)); print(s)
p("DIGEST of out/numerics_*.json  (model: %s)" % e["model"])
p("%-3s %-6s %-4s %-13s %-13s %-13s %-9s %-12s %-9s"%("d","n","seed","lam_1(G')","lam_2(G')","secular zero","|diff|","pred lam_2","n(lam1-d)"))
for r_ in e["runs"]:
    p("%-3d %-6d %-4d %-13.9f %-13.9f %-13.9f %-9.1e %-12.6f %-9.4f"%(r_["d"],r_["n"],r_["seed"],
      r_["lam1"],r_["lam2"],r_["sec_zero"],r_["absdiff"],r_["pred_lam2"],r_["n_lam1_minus_d"]))
p(""); p("seed-averaged trends")
for q in t["lam2_trend"]:
    p("  d=%d n=%-5d mean lam_2=%.6f sd=%.6f (pred %.6f) ; mean n(lam_1-d)=%.4f"
      %(q["d"],q["n"],q["mean_lam2"],q["sd_lam2"],q["pred"],q["mean_nlam1md"]))
p(""); p("resolvent values F_n vs prediction")
for q in r["resolvent"]:
    p("  d=%d n=%-5d lam=%-4.2f F_adj=%.7f pred=%.7f | F_far=%.7f pred=%.7f (far distance %d)"
      %(q["d"],q["n"],q["lam"],q["F_adj"],q["pred_adj"],q["F_far"],q["pred_far"],q["dist_far"]))
open('out/numerics_digest.txt','w').write("\n".join(out)+"\n")
