"""
lift_scan_final.py -- produces outputs/lift_scan_final.txt and outputs/gap_test_final.txt

Random n-lifts of
  * (3,2)-biregular base = subdivision of K4
  * (4,2)-biregular base = subdivision of K5
  * Bordenave-Collins base  K_{2,3} + edge(0,1)   (degrees 4,4,2,2,2)
  * irregular base with degrees (3,3,3,3,2)
  * multigraph with degrees (3,3,2)
Reported: max |new eigenvalue|, most negative new eigenvalue, min |new|,
and the count of new eigenvalues strictly inside the open spectral gap.
"""
import numpy as np
from cover_tools import random_lift, new_spectrum, base_adjacency


def scan(r, edges, A, name, ns, reps=3, seed=7, gap=None, out=None):
    rng = np.random.default_rng(seed)
    eb = np.sort(np.linalg.eigvalsh(A))
    out.write(f"### {name}\n  base spectrum {np.round(eb,6)}\n")
    out.write("   n  verts   max|new| mean +- sd    most negative new   min|new|   #new in open gap\n")
    for n in ns:
        mx, mn, cnt = [], [], []
        for _ in range(reps):
            G = random_lift(r, edges, n, rng)
            new = new_spectrum(A, G, n)
            mx.append(np.max(np.abs(new)))
            mn.append(np.min(np.abs(new)))
            if gap is not None:
                cnt.append(int(np.sum((new > -gap) & (new < gap) & (np.abs(new) > 1e-7))))
        out.write(f"  {n:3d} {r*n:6d}   {np.mean(mx):.6f} +- {np.std(mx):.1e}   "
                  f"{np.min(new):.6f}   {np.mean(mn):.6f}   {cnt}\n")
    out.write("\n")


if __name__ == "__main__":
    import os
    os.makedirs("outputs", exist_ok=True)
    out = open("outputs/lift_scan_final.txt", "w")
    K4 = [(i, j) for i in range(4) for j in range(i+1, 4)]
    e32 = [(u, 4+v) for (u, v) in [(i, e) for e, (i, j) in enumerate(K4)] +
                             [(j, e) for e, (i, j) in enumerate(K4)]]
    A = base_adjacency(10, e32)
    scan(10, e32, A, "(3,2)-biregular, subdivision of K4: sqrt(a)+sqrt(b)=2.414214, "
                     "2sqrt(d1-1)=2.828427, sqrt3*rho=4.181541",
         [5, 10, 20, 40, 60], gap=np.sqrt(2)-1, out=out)
    K5 = [(i, j) for i in range(5) for j in range(i+1, 5)]
    e42 = [(u, 5+v) for (u, v) in [(i, e) for e, (i, j) in enumerate(K5)] +
                             [(j, e) for e, (i, j) in enumerate(K5)]]
    A42 = base_adjacency(15, e42)
    scan(15, e42, A42, "(4,2)-biregular, subdivision of K5: sqrt3+1=2.732051, 2sqrt3=3.464102",
         [5, 10, 20, 40, 60], gap=np.sqrt(3)-1, out=out)
    bc = [(0, 2), (0, 3), (0, 4), (1, 2), (1, 3), (1, 4), (0, 1)]
    scan(5, bc, base_adjacency(5, bc),
         "Bordenave-Collins base K_{2,3}+edge(0,1): 2sqrt(dmax-1)=3.464102",
         [5, 10, 20, 40, 60], out=out)
    irr = [(0, 1), (0, 2), (0, 3), (1, 2), (1, 3), (2, 4), (3, 4)]
    scan(5, irr, base_adjacency(5, irr),
         "irregular degrees (3,3,3,3,2): 2sqrt(dmax-1)=2.828427", [5, 10, 20, 40, 60], out=out)
    mg = [(0, 1), (0, 1), (1, 2), (0, 2)]
    scan(3, mg, base_adjacency(3, mg),
         "multigraph degrees (3,3,2): 2sqrt(dmax-1)=2.828427", [5, 10, 20, 40, 60], out=out)
    out.close()

    # gap test with a strict tolerance
    rng = np.random.default_rng(101)
    lo = np.sqrt(2) - 1
    g = open("outputs/gap_test_final.txt", "w")
    g.write("GAP TEST: new spectrum of random n-lifts of the (3,2)-biregular base (subdivision of K4)\n")
    g.write(f"universal-cover bands +-[{lo:.9f},{np.sqrt(2)+1:.9f}], open gap (-{lo:.9f},{lo:.9f})\n")
    g.write("the bipartition imbalance forces new eigenvalues exactly 0, counted separately\n")
    g.write("  n   #new   #zeros   #in gap with |lam|>1e-5   max|lam| in gap\n")
    for n in (5, 10, 20, 40, 60):
        rows = []
        for _ in range(3):
            G = random_lift(10, e32, n, rng)
            new = new_spectrum(A, G, n)
            z = np.sum(np.abs(new) < 1e-9)
            ing = new[(new > -lo) & (new < lo) & (np.abs(new) > 1e-5)]
            rows.append((len(new), z, len(ing), np.max(np.abs(ing)) if len(ing) else 0.0))
        g.write(f" {n:3d}  {rows[0][0]:5d}  {rows[0][1]:5d}   {[r_[2] for r_ in rows]}   "
                f"{max(r_[3] for r_ in rows):.3e}\n")
    g.close()
    print(open("outputs/lift_scan_final.txt").read()[:800])
