r"""Random rewiring of a periodic graph.

The n x n torus is the union of two 2-factors: the +-e1 cycles and the
+-e2 cycles.  Write the second 2-factor as the cycle structure of a permutation
sigma, sigma_0 = the shift (i,j) -> (i,j+1).  Random rewiring = composing sigma
with t random transpositions, t = c N / 2.  The graph stays 4-regular (as a
multigraph) for every c, c = 0 is the torus, c = 1 is a uniformly random
2-factor superimposed on the e1 cycles.
"""
import sys, os, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "out")


def build(n, sigma):
    N = n*n
    A = np.zeros((N, N))
    for i in range(n):
        for j in range(n):
            v = i*n+j
            w = i*n + (j+1) % n
            A[v, w] += 1
            A[w, v] += 1
    for v in range(N):
        w = sigma[v]
        if v != w:
            A[v, w] += 1
            A[w, v] += 1
        else:
            A[v, v] += 2
    return A


def main():
    log = []
    rng = np.random.default_rng(2026)
    log.append("4-regular rewired tori: c = fraction of random transpositions")
    log.append("    n   N     c     lambda_2 (3 samples)                defect 4-lambda_2")
    data = []
    for n in (8, 12, 16, 24):
        N = n*n
        sigma0 = np.array([((i+1) % n)*n + j for i in range(n) for j in range(n)])
        for c in (0.0, 0.05, 0.15, 0.3, 0.6, 1.0):
            vals = []
            for _ in range(3):
                sigma = sigma0.copy()
                t = int(c*N/2)
                for _ in range(t):
                    u, v = rng.choice(N, size=2, replace=False)
                    sigma[u], sigma[v] = sigma[v], sigma[u]
                A = build(n, sigma)
                ev = np.sort(np.linalg.eigvalsh(A))[::-1]
                vals.append(ev[1])
            data.append(dict(n=n, N=N, c=c, lam2=[float(x) for x in vals],
                             mean=float(np.mean(vals)),
                             defect=float(4-np.mean(vals))))
            log.append(f"  {n:3d} {N:5d} {c:5.2f}  {np.round(vals, 6).tolist()}  "
                       f"{4-np.mean(vals):.6f}")
    log.append("")
    log.append(f"degree 4 Alon-Boppana value 2 sqrt 3 = {2*np.sqrt(3):.6f}, "
               f"maximal defect {4-2*np.sqrt(3):.6f}")
    txt = "\n".join(log)
    open(os.path.join(OUT, "s09_rewiring.log"), "w").write(txt)
    json.dump(data, open(os.path.join(OUT, "s09_rewiring.json"), "w"), indent=1)
    print(txt)


if __name__ == "__main__":
    main()
