"""
Random-model numerics for direction d6.

Model A (one-sided): random k-regular digraph = sum of k independent uniform
permutation matrices.  Predictions:  rho = rho(A restricted to nontrivial part)
-> sqrt(k)  [Coste 2017, Thm 1],  sigma_2 -> 2 sqrt(k-1)  [double cover +
biregular Alon-Boppana / Brito-Dumitriu-Decker Harris], kappa = sigma_2/rho -> 2 sqrt(k-1)/sqrt(k).

Model B (normal control): random k-regular undirected graph viewed as a symmetric
digraph.  Predictions: rho = sigma_2 = lambda_2 -> 2 sqrt(k-1)  [Alon-Boppana,
Friedman], kappa -> 1.
"""
import json, time
import numpy as np
import scipy.sparse as sp
import scipy.sparse.linalg as spla

rng = np.random.default_rng(20261114)
out = []

def perm_digraph(k, n, rng):
    rows, cols = [], []
    for _ in range(k):
        p = rng.permutation(n)
        rows.append(np.arange(n)); cols.append(p)
    rows = np.concatenate(rows); cols = np.concatenate(cols)
    A = sp.coo_matrix((np.ones(len(rows)), (rows, cols)), shape=(n, n)).tocsr()
    A.sum_duplicates()
    return A

def config_undirected(k, n, rng):
    """random k-regular undirected multigraph by the configuration model."""
    stubs = np.repeat(np.arange(n), k)
    rng.shuffle(stubs)
    rows = stubs[0::2]; cols = stubs[1::2]
    A = sp.coo_matrix((np.ones(len(rows)), (rows, cols)), shape=(n, n)).tocsr()
    return (A + A.T).tocsr()

def nontrivial_rho_sigma(A, n, howmany=6):
    A = A.astype(float)
    w = spla.eigs(A, k=howmany, which='LM', return_eigenvectors=False, maxiter=20000, tol=1e-10)
    mods = np.sort(np.abs(w))[::-1]
    s = spla.svds(A, k=4, which='LM', return_singular_vectors=False, maxiter=40000, tol=1e-10)
    s = np.sort(s)[::-1]
    rho_all = mods[0]
    rho_nontriv = mods[1] if len(mods) > 1 else np.nan
    return rho_all, rho_nontriv, s

print("model,k,n,trial,rho_all,rho_nontriv,sqrt_k,sigma_1,sigma_2,2sqrt(k-1),kappa")
for model in ["directed", "symmetric"]:
    for k in [2, 3, 4, 5, 6]:
        if model == "symmetric" and k == 2:
            sizes = [500, 1000, 2000]
        else:
            sizes = [500, 1000, 2000, 4000]
        for n in sizes:
            for trial in range(2):
                A = perm_digraph(k, n, rng) if model == "directed" else config_undirected(k, n, rng)
                rho_all, rho_nontriv, s = nontrivial_rho_sigma(A, n)
                kappa = s[1] / rho_nontriv if rho_nontriv > 0 else np.inf
                row = dict(model=model, k=k, n=n, trial=trial, rho_all=float(rho_all),
                           rho_nontriv=float(rho_nontriv), sqrt_k=float(np.sqrt(k)),
                           sigma_1=float(s[0]), sigma_2=float(s[1]),
                           two_sqrt_k1=float(2 * np.sqrt(k - 1)), kappa=float(kappa))
                out.append(row)
                print(f"{model:9s},{k},{n},{trial},{rho_all:.4f},{rho_nontriv:.4f},{np.sqrt(k):.4f},"
                      f"{s[0]:.4f},{s[1]:.4f},{2*np.sqrt(k-1):.4f},{kappa:.4f}", flush=True)

with open("raw/random_numerics.json", "w") as f:
    json.dump(out, f, indent=1)
print("written raw/random_numerics.json")
