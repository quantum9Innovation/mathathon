#!/usr/bin/env python3
"""Check P(pairing is simple) against the classical limit exp(-(d^2-1)/4).
This both certifies the sampler's behaviour and verifies the constant used to
justify conditioning the pairing model on simplicity."""
import numpy as np, math, json
def attempt(n,d,rng):
    stubs=np.repeat(np.arange(n),d); s=stubs.copy(); rng.shuffle(s)
    a=s[0::2]; b=s[1::2]
    if np.any(a==b): return False
    u=np.minimum(a,b); v=np.maximum(a,b); key=u*n+v
    return np.unique(key).size==key.size
for d in (3,4,5):
    n=2000; rng=np.random.default_rng(1000+d); N=4000 if d<5 else 8000
    ok=sum(attempt(n,d,rng) for _ in range(N))/N
    print(json.dumps(dict(d=d,n=n,attempts=N,empirical=ok,
          predicted=math.exp(-(d*d-1)/4))))
