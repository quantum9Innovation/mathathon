"""Diagnose the exact secular equation lambda = -1_T^T (A_G-lambda)^{-1} 1_T."""
import numpy as np, networkx as nx
from scipy.linalg import eigvalsh

d, Delta, n = 3, 6, 4000
G = nx.random_regular_graph(d, n, seed=11)
A = nx.to_numpy_array(G)
T = np.random.default_rng(5).choice(n, size=Delta, replace=False)
w, U = np.linalg.eigh(A)
print("host top eigenvalues:", w[::-1][:5])
edge = 2*np.sqrt(d-1)

def secular(lam):
    return lam + np.sum(U[T, :]**2 / (lam - w[None, :]), axis=1).sum()

def g_closed(lam):
    a, b, c = d-1.0, -lam, 1.0
    disc = b*b-4*a*c
    if disc < 0: return np.nan
    r = min([(-b+np.sqrt(disc))/(2*a), (-b-np.sqrt(disc))/(2*a)], key=abs)
    return 1.0/(-lam + d*r)

def avg_stieltjes(lam):
    return np.sum(1.0/(lam - w))/n

print(f"{'lam':>8} {'S(lam)':>12} {'1_T^T..':>12} {'-lam':>9} {'g_closed':>10} {'avgStieltj':>11}")
for lam in [2.85, 2.9, 2.95, 2.98, 2.99, 2.995, 2.999, 3.001, 3.05, 3.1, 3.2]:
    s = secular(lam)
    q = s - lam
    print(f"{lam:8.4f} {s:12.6f} {q:12.6f} {-lam:9.4f} {g_closed(lam):10.6f} {avg_stieltjes(lam):11.6f}")

# where does the exact secular function vanish?
xs = np.linspace(max(w[-2]+1e-6, edge-1e-3), 3.15, 20000)
ss = np.array([secular(x) for x in xs])
sgn = np.sign(ss)
cross = xs[:-1][sgn[:-1]*sgn[1:] < 0]
print("\nzeros of exact secular function in window:", cross)

# full spectrum of G + spike
Gp = nx.convert_node_labels_to_integers(G); Gp.add_node(n)
for y in T: Gp.add_edge(n, int(y))
wp = eigvalsh(nx.to_numpy_array(Gp))
print("spiked graph top 5:", wp[::-1][:5])
print("spiked graph bottom 3:", wp[:3])
