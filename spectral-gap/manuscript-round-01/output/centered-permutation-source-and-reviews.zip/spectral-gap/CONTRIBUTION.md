# Audited contribution for problem 21

Problem 21 is selected for this conversation. The requested matching-product bottleneck has a direct proof with an optimal universal prefactor. The [manuscript round](manuscript-round-01/README.md) also proves the exact cubic criterion, a wider hyperbolic approximation window, and its square-root correction. Imported finite-defect research remains a separate track.

## Direct answer to the listed problem

The [strengthened mixed-product proof](manuscript-round-01/proof/permutation-proof-v3.md) handles arbitrary multiplicities and independent permutation colors. For a distinct cells, h consistent centered singletons, b inconsistent centered singletons, and 2<=a<=sqrt(n), it proves

$$
|\mathbb E P|\le \sqrt e\,2^b n^{-a}\beta^h,
\qquad
\beta=\frac{\sqrt{a-1}}{\sqrt n-\sqrt{a-1}}.
$$

The exact prefactor is F_n(a-h)=n^(a-h)/(n)_(a-h), valid for 2<=a<=n. The one-cell case is stated separately. Compatible uncentered matches with n=a^2 prove that sqrt(e) is the best universal constant for this arbitrary mixed-product class. A positive row-sum recurrence preserves cancellation before the remaining affine indicator expansion. The proof maps the uniform permutation of nd_1=md_2 half-edges into the use of preprint Lemma 7, published Lemma 5.6, in the biregular argument. It does not certify every subsequent trace estimate.

Two explicit counterexamples refute an intermediate conditional assertion in Bordenave's printed proof. They do not refute Proposition 28. The replacement proof avoids that assertion, and the [source note](audit-2026-11-14/source-findings-v2.md) preserves the exact scope of the correction.

## Further mathematical results

Let a_k(N) be the centered diagonal product moment, and let R_k be its ratio to the parity-dependent leading term defined in the proof. The [sharp scaling theorem](audit-2026-11-14/sharp-scaling-v2.md) proves

$$
R_k-1\ge\frac{2k^3}{27N}\quad(2\le k\le N),
\qquad
R_k\le\exp(3k^3/N)\quad(2k\le N).
$$

Consequently, R_k tends to one exactly when k^3/N tends to zero, and remains bounded exactly when k^3/N remains bounded. This resolves the optimal-scale question explicitly raised in [Collins and Nagatsu, published Remark 3.4](https://alco.centre-mersenne.org/item/10.5802/alco.480.pdf). Their base and normalized recurrences are prior results and remain attributed to them.

The [critical-scale theorem](audit-2026-11-14/critical-scale-v1.md) proves that if k^3/N tends to c, the even ratio tends to cosh(2 sqrt(c)/3) and the odd ratio tends to sinh(2 sqrt(c)/3)/(2 sqrt(c)/3). It supplies a uniform error bound on bounded critical scales and shows that 2/27 is the optimal global lower-bound constant.

## The wider window and its next correction

The [reviewed extension](manuscript-round-01/extensions/hyperbolic-window-v1.md) defines K=2 floor(k/2) and lambda=(2/3)sqrt(K^3/N). With H_k=cosh(lambda) for even k and sinh(lambda)/lambda for odd k, it proves R_k/H_k tends to one whenever k=o(sqrt N), with explicit finite relative bounds. If k^2/N tends to d>0, that ratio instead tends to exp(d/4). The corrected approximation exp(k^2/(4N))H_k is uniformly relatively accurate for k<=C sqrt N with fixed C.

The positive partition representation used in this argument is a classical Laguerre specialization. Pairs give the leading coefficients, triples give the parity-dependent hyperbolic functions, and four-blocks together with pair depletion give the square-root correction. The identity itself is not advertised as new.

## Evidence and limits

The authoritative [claim ledger](CLAIM_LEDGER.md) records SG-01 through SG-08, exact proof revisions, independent reviews and dependencies. Written arguments establish the uniform results. Exact finite checks and separate numerical corroboration support their implementation and examples.

The [primary-source audit](manuscript-round-01/priority/PRIORITY_AUDIT_V1.md) verifies the exact published question and checks neighboring permutation and special-function literature. It found no exact duplicate of the quantitative refinements in the inspected sources. No comprehensive priority certificate or end-to-end formal verification is claimed. The imported adjacent-defect family and its pending reports have not been promoted by this round.
