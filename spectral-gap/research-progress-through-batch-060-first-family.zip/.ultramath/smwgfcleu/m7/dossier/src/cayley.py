"""Exact small-scale study of Cayley graph spectra.

Conventions
-----------
* A group is represented by a list of elements plus a multiplication function.
  The identity must become elements[0] after sorting.
* Group.T[i][j] is the index of elements[i]*elements[j].
* A connection set S is symmetric: s in S implies s^-1 in S, and 1 not in S.
* Cay(G,S): x ~ x*s for s in S.  Adjacency A = sum_{s in S} P_s.
"""

import itertools
import numpy as np


def perm_mul(p, q):
    return tuple(p[q[i]] for i in range(len(q)))


def perm_inv(p):
    r = [0] * len(p)
    for i, pi in enumerate(p):
        r[pi] = i
    return tuple(r)


def sym(n):
    return [tuple(p) for p in itertools.permutations(range(n))]


def sign(p):
    n = len(p)
    seen = [False] * n
    s = 1
    for i in range(n):
        if not seen[i]:
            j = i
            L = 0
            while not seen[j]:
                seen[j] = True
                j = p[j]
                L += 1
            if L % 2 == 0:
                s = -s
    return s


def alt(n):
    return [p for p in sym(n) if sign(p) == 1]


def cycle_type(p):
    n = len(p)
    seen = [False] * n
    ct = []
    for i in range(n):
        if not seen[i]:
            j = i
            L = 0
            while not seen[j]:
                seen[j] = True
                j = p[j]
                L += 1
            ct.append(L)
    return tuple(sorted(ct, reverse=True))


class Group:
    def __init__(self, elements, mul, name=""):
        self.name = name
        self.els = sorted(elements)
        self.n = len(self.els)
        self.pos = {e: i for i, e in enumerate(self.els)}
        self.mul = mul
        T = np.empty((self.n, self.n), dtype=np.int32)
        for i, a in enumerate(self.els):
            for j, b in enumerate(self.els):
                T[i, j] = self.pos[mul(a, b)]
        self.T = T
        inv = np.empty(self.n, dtype=np.int32)
        for i in range(self.n):
            cand = np.nonzero(T[i] == 0)[0]
            assert len(cand) == 1
            inv[i] = cand[0]
        self.inv = inv
        order = np.zeros(self.n, dtype=np.int32)
        for i in range(self.n):
            k = 1
            x = i
            while x != 0:
                x = int(T[x, i])
                k += 1
            order[i] = k
        self.order = order
        self.classes = self._classes()
        self.class_of = np.empty(self.n, dtype=np.int32)
        for ci, C in enumerate(self.classes):
            for x in C:
                self.class_of[x] = ci

    def _classes(self):
        n, T, inv = self.n, self.T, self.inv
        seen = [False] * n
        out = []
        for x in range(n):
            if seen[x]:
                continue
            C = set()
            for g in range(n):
                C.add(int(T[int(T[g, x]), inv[g]]))
            for y in C:
                seen[y] = True
            out.append(sorted(C))
        out.sort(key=lambda C: C[0])
        return out

    def inverse_atoms(self):
        atoms = []
        seen = set()
        for i in range(1, self.n):
            if i in seen:
                continue
            j = int(self.inv[i])
            if i == j:
                atoms.append((i,))
                seen.add(i)
            else:
                atoms.append((i, j))
                seen.add(i)
                seen.add(j)
        atoms.sort()
        return atoms

    def symmetric_sets(self, d):
        """All symmetric S with |S| = d, identity excluded (indices sorted)."""
        atoms = self.inverse_atoms()
        out = []

        def rec(k, remaining, current):
            if remaining == 0:
                flat = []
                for a in current:
                    flat.extend(a)
                out.append(tuple(sorted(flat)))
                return
            if k >= len(atoms):
                return
            rec(k + 1, remaining, current)
            a = atoms[k]
            if len(a) <= remaining:
                current.append(a)
                rec(k + 1, remaining - len(a), current)
                current.pop()

        rec(0, d, [])
        return sorted(set(out))

    def adjacency(self, S):
        n, T = self.n, self.T
        A = np.zeros((n, n), dtype=np.float64)
        for s in S:
            A[np.arange(n), T[s]] += 1.0
        return A

    def connected(self, S):
        seen = {0}
        frontier = [0]
        T = self.T
        while frontier:
            nxt = []
            for x in frontier:
                for s in S:
                    y = int(T[s, x])
                    if y not in seen:
                        seen.add(y)
                        nxt.append(y)
            frontier = nxt
        return len(seen) == self.n

    def girth(self, S, cap=40):
        n, T = self.n, self.T
        best = cap + 1
        for r in range(n):
            dist = {r: 0}
            par = {r: -1}
            frontier = [r]
            while frontier and 2 * dist[frontier[0]] + 1 < best:
                nxt = []
                for x in frontier:
                    dx = dist[x]
                    for s in S:
                        y = int(T[s, x])
                        if y not in dist:
                            dist[y] = dx + 1
                            par[y] = x
                            nxt.append(y)
                        elif par[x] != y:
                            c = dx + dist[y] + 1
                            if c < best:
                                best = c
                frontier = nxt
        return best

    def spectrum(self, S):
        return np.linalg.eigvalsh(self.adjacency(S))

    def lambda_two_sided(self, S):
        ev = self.spectrum(S)
        d = float(len(S))
        idx = int(np.argmin(np.abs(ev - d)))
        rest = np.delete(ev, idx)
        return float(np.max(np.abs(rest)))


def sym_group(n):
    return Group(sym(n), perm_mul, name="S%d" % n)


def alt_group(n):
    return Group(alt(n), perm_mul, name="A%d" % n)


def cyclic_group(n):
    return Group(list(range(n)), lambda a, b: (a + b) % n, name="Z%d" % n)


def dihedral_group(m):
    rot = tuple((i + 1) % m for i in range(m)) + tuple(m + (i + 1) % m for i in range(m))
    ref = tuple((m - i) % m for i in range(m)) + tuple(m + (m - i) % m for i in range(m))
    els = set()
    cur = tuple(range(2 * m))
    for _ in range(m):
        els.add(cur)
        cur = perm_mul(rot, cur)
    cur = ref
    for _ in range(m):
        els.add(cur)
        cur = perm_mul(rot, cur)
    return Group(els, perm_mul, name="D%d" % m)
