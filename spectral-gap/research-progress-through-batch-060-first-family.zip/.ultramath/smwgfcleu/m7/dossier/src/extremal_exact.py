"""Exact extremal data: closed forms for lambda_min and lambda_max at small degree."""
import sys
sys.path.insert(0, 'dossier/src')
import numpy as np, sympy as sp
from cayley import *

import builtins
def pp(*a, **k):
    k.setdefault('flush', True)
    builtins.print(*a, **k)


def extremes(G, d):
    thr = 2 * np.sqrt(d - 1)
    rows = []
    for S in G.symmetric_sets(d):
        if not G.connected(S):
            continue
        ev = G.spectrum(S)
        idx = int(np.argmin(np.abs(ev - d)))
        rest = np.delete(ev, idx)
        lam = float(np.max(np.abs(rest)))
        which = 'neg' if abs(rest.min()) > abs(rest.max()) else 'pos'
        rows.append((lam, which, S, ev))
    rows.sort(key=lambda r: r[0])
    out = {}
    out['n_sets'] = len(rows)
    out['thr'] = thr
    out['n_ram'] = sum(1 for r in rows if r[0] <= thr + 1e-12)
    out['neg_extreme'] = sum(1 for r in rows if r[1] == 'neg')
    for tag, r in [('min', rows[0]), ('max', rows[-1])]:
        lam, which, S, ev = r
        cp = sp.factor(sp.Matrix(G.adjacency(S).astype(int).tolist()).charpoly('x').as_expr())
        out[tag] = dict(lam=lam, which=which, S=[cycle_type(G.els[s]) for s in S],
                        girth=G.girth(S), charpoly=str(cp), spec=np.round(ev, 9).tolist())
    return out


if __name__ == '__main__':
    cases = [(sym_group(4), d) for d in (3, 4, 5, 6)] + \
            [(alt_group(5), d) for d in (3, 4, 5)] + \
            [(sym_group(5), d) for d in (3, 4)]
    for G, d in cases:
        o = extremes(G, d)
        pp("### %s, d=%d : %d connected sets, threshold %.9f, Ramanujan %d, extremum at negative end %d"
           % (G.name, d, o['n_sets'], o['thr'], o['n_ram'], o['neg_extreme']))
        for tag in ('min', 'max'):
            r = o[tag]
            pp("   %s: lambda=%.12f (%s end) girth=%d S=%s" % (tag, r['lam'], r['which'], r['girth'], r['S']))
            pp("        charpoly = %s" % r['charpoly'])
