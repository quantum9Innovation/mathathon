r"""Check the closed-form second-derivative formula for M in two dimensions.

    M_ij = (2 pi)^2 [ sum_g g_i g_j <psi, A_g psi>
                      - 2 <H_i psi, (Lambda_1(0) - A(0))^+ H_j psi> ],
    H_i = sum_g g_i A_g   (real antisymmetric),

against a central-difference Hessian of Lambda_1 at kappa = 0, for the
honeycomb lattice and for a three-vertex non-Cayley periodic graph.
"""
import sys, os, itertools, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
import lib

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "out")


def closed_form(G):
    p = G.p
    A0 = G.A(np.zeros(G.d)).real
    lam, vec = np.linalg.eigh(A0)
    lam1 = lam[-1]
    psi = vec[:, -1]
    if psi.sum() < 0:
        psi = -psi
    W = np.zeros((p, p, G.d, G.d))
    H = np.zeros((p, p, G.d), dtype=float)
    for (u, v, g) in G.edges:
        for i in range(G.d):
            for j in range(G.d):
                W[u, v, i, j] += g[i]*g[j]
                W[v, u, i, j] += g[i]*g[j]
            H[u, v, i] += g[i]
            H[v, u, i] -= g[i]
    d = lam1-lam
    d[np.abs(d) < 1e-11] = np.inf
    M = np.zeros((G.d, G.d))
    for i in range(G.d):
        for j in range(G.d):
            t1 = psi @ (W[:, :, i, j] @ psi)
            Hi = H[:, :, i] @ psi
            t2 = 2*sum((vec[:, k] @ Hi)*(vec[:, k] @ (H[:, :, j] @ psi))/d[k]
                       for k in range(p))
            M[i, j] = (2*np.pi)**2*(t1-t2)
    return M


def fd_hessian(G, h=1e-4):
    f = lambda k: np.linalg.eigvalsh(G.A(k))[-1]
    d = G.d
    M = np.zeros((d, d))
    z = np.zeros(d)
    for i in range(d):
        for j in range(d):
            if i == j:
                ei = z.copy(); ei[i] = h
                M[i, i] = -(f(ei)-2*f(z)+f(-ei))/h**2
            else:
                ei = z.copy(); ei[i] = h
                ej = z.copy(); ej[j] = h
                M[i, j] = -(f(ei+ej)-f(ei-ej)-f(-ei+ej)+f(-ei-ej))/(4*h*h)
    return 0.5*(M+M.T)


def main():
    log = []
    hon = lib.PeriodicGraph(2, [(0, 1, (0, 0)), (0, 1, (-1, 0)), (0, 1, (0, -1))])
    tri = lib.PeriodicGraph(3, [(0, 1, (0, 0)), (1, 2, (0, 0)), (2, 0, (1, 0)),
                                (0, 0, (1, 0)), (1, 1, (0, 1))])
    four = lib.PeriodicGraph(4, [(0, 1, (1, 0)), (1, 2, (0, 1)), (2, 3, (-1, 0)),
                                 (3, 0, (0, -1)), (0, 2, (1, 1)), (1, 3, (0, 0))])
    for name, G in [("honeycomb", hon), ("three-vertex", tri), ("four-vertex", four)]:
        A0 = G.A(np.zeros(G.d)).real
        ev = np.linalg.eigvalsh(A0)
        cf = closed_form(G)
        fd = fd_hessian(G)
        log.append(f"\n{name}: p = {G.p}, degree of the periodic graph is not "
                   f"assumed; A(0) top eigenvalues {np.round(ev[-3:], 9).tolist()}")
        log.append(f"  closed form M = \n{np.round(cf, 9)}")
        log.append(f"  finite diff M = \n{np.round(fd, 9)}")
        log.append(f"  max |difference| = {np.max(np.abs(cf-fd)):.3e}, "
                   f"eigenvalues of M = {np.round(np.linalg.eigvalsh(cf), 9).tolist()}")
    txt = "\n".join(log)
    open(os.path.join(OUT, "s10_M_formula_2d.log"), "w").write(txt)
    print(txt)


if __name__ == "__main__":
    main()
