# 2. Literature, verified

Convention for this file: a statement is marked **[READ]** when I opened the source itself and
copied the wording, and **[SECONDARY]** when I only have it as a quotation inside a source I did
read. Nothing marked [SECONDARY] is used as a load-bearing hypothesis without an independent check.
Downloaded PDFs and extracted text are in `lit/`.

## 2.1 The five statements this dossier is built on

### L1. Feng-Li Alon-Boppana bound [SECONDARY, quoted verbatim in two independent sources]

> **Theorem 2 (Feng and Li).** Let `{H_m}` be a family of connected `(d,r)`-regular hypergraphs
> with `|V(H_m)| -> infinity` as `m -> infinity`. Then `lim inf lambda_2(H_m) >= r - 2 + 2 sqrt(q)`
> as `m -> infinity`, where `q = (d-1)(r-1) = d(r-1) - (r-1)`.

Verbatim from C. K. Storm, *The zeta function of a hypergraph*, Electron. J. Combin. **13** (2006),
#R84, Theorem 2, in `lit/storm.txt` line 110ff. Original: K. Feng and W.-C. W. Li, *Spectra of
hypergraphs and applications*, J. Number Theory **60** (1996) 1-22.

An equivalent form with the diameter dependence, quoted verbatim in a second source:

> "Feng and Li [24] (see also Li and Sole [33]) showed that if `H` is an `r`-regular `u`-uniform
> hypergraph whose diameter is at least `2 l + 2`, then `tau_2(H) >= u - 2 + 2 sqrt(q) - 2(sqrt(q)-1)/l`,
> where `q = (r-1)(u-1)`."

S. M. Cioaba, J. H. Koolen, M. Mimura, H. Nozaki, T. Okuda, *On the spectrum and linear
programming bound for hypergraphs*, arXiv:2009.03022v3, published European J. Combin. **104** (2022)
103535, equation (1.1) in `lit/ckmno.txt` line 71ff.

Two independent verbatim quotations agreeing on the constant `r - 2 + 2 sqrt((d-1)(r-1))` is my
verification of L1. I did not open Feng-Li itself.

### L2. The Li-Sole Ramanujan definition [SECONDARY, two versions that differ]

Version A, from Storm, Definition 3, `lit/storm.txt` line 160ff:

> "**Definition 3 (Li and Sole).** Let `H` be a finite, connected `(d,r)`-regular hypergraph. We say
> `H` is a Ramanujan hypergraph if `|lambda - r + 2| <= 2 sqrt((d-1)(r-1))`, for all **non-obvious**
> eigenvalues `lambda in Spec(H)` such that `lambda != d(r-1)`."

Version B, from Dumitriu-Zhu, equation (1.1), `lit/dz.txt` line 80ff:

> "the original paper [16] proved the Alon-Boppana lower bound for the adjacency matrix of regular
> hypergraphs, and then Li and Sole [26] defined a `(d,k)`-regular hypergraph to be Ramanujan if any
> eigenvalue `lambda != d(k-1)` satisfies `|lambda - k + 2| <= 2 sqrt((d-1)(k-1))`."

Version B has **no** "non-obvious" exclusion. Version A has one. They differ exactly when `-d` is
present. The original is W.-C. W. Li and P. Sole, *Spectra of regular graphs and hypergraphs and
orthogonal polynomials*, European J. Combin. **17** (1996) 461-477, which I did not obtain, so I do
not adjudicate between A and B. Instead, section 3 analyses both readings, and every theorem below
is stated so that it holds under either one.

### L3. "Obvious" eigenvalues are the rectangular ones [READ]

> "This gives a very explicit connection between the spectra of `H` and `H*`. When `d` and `r` are
> not equal, comparing the powers of `x` in both sides of Eq. (4) gives the **obvious eigenvalue `-d`**
> of `H` with multiplicity `|V(H)| - |E(H)|` or `-r` of `H*` with multiplicity `|E(H)| - |V(H)|`,
> depending on whether `d < r` or `r < d`."

Storm, `lit/storm.txt` line 155ff, with Eq. (4) being `x^{|V|} P*(x-r) = x^{|E|} P(x-d)`.

And the same paper's use of that, `lit/storm.txt` line 740ff:

> "We assume throughout that `H` is a `(d,r)`-regular hypergraph with `d >= r`. ... Then, we have
> that `n_2 >= n_1` since `d >= r`. By Eq. (4), `H` has no obvious eigenvalues `-d`. This will
> simplify our consideration of the Ramanujan condition on `H`."

So the literature's notion of "obvious" is precisely the rectangularity source, and the literature's
response to it is to assume `d >= r`. Song-Fan-Miao state the same fact in the same form
`[READ, lit/sfm.txt]`: "Note that if `d < r`, then `H` has an obvious eigenvalue `-d` with
multiplicity `|V(H)| - |E(H)|`, see Section 2.1."

### L4. The Gram identity [READ]

> "**Lemma 4.5.** Let `H` be a `(d,k)`-regular hypergraph, and let `G` be the corresponding
> bipartite biregular graph associated to `H`. ... Then `X X^T = A_H + d I`."

S. Dumitriu and Y. Zhu, *Spectra of random regular hypergraphs*, arXiv:1905.06487v5 (13 July 2021),
published Electron. J. Combin. **28**(3) (2021) P3-36, DOI 10.37236/8741, Lemma 4.5,
`lit/dz.txt` line 596ff. Also Storm Eqs. (1)-(3), `lit/storm.txt` line 125ff, in the form
`A(B_H)^2 = diag(A_H + d I_V, A_{H*} + r I_E)` and `Q(x) = P(x-d) P*(x-r)`.

### L5. The upper edge for random regular hypergraphs [READ]

> "**Theorem 4.3.** Let `A` be the adjacency matrix of a random `(d,k)`-regular hypergraph sampled
> uniformly from `H(n,d,k)` with `d >= k >= 3`, then any eigenvalue `lambda(A) != d(k-1)` satisfies
> `|lambda(A) - k + 2| <= 2 sqrt((k-1)(d-1)) + eps_n`, asymptotically almost surely with
> `eps_n -> 0` as `n -> infinity`."

Dumitriu-Zhu, Theorem 4.3, `lit/dz.txt` line 555ff. Their proof, in their words: "Our main
methodology is to translate the results from bipartite biregular graphs by using the bijection
between the spectra (Lemma 4.2). While this bijection has been known for a long time, the results on
bipartite biregular graphs [15, 9] (especially the spectral gap) are quite recent."

### L6. The bipartite biregular input, and the Godsil-Mohar measure [READ, from the paper's own LaTeX]

> "Previous work on bipartite, biregular graphs includes the work of Feng (1996) and Li (1996), who
> proved the analog of the Alon-Boppana bound. For every `eps > 0`, `eta >= sqrt(d_1-1) + sqrt(d_2-1) - eps`
> as the number of vertices goes to infinity. This bound also follows immediately from the fact that
> the second largest eigenvalue cannot be asymptotically smaller than the right limit of the
> asymptotic support for the eigenvalue distribution, which is `sqrt(d_1-1) + sqrt(d_2-1)` and was
> first computed by Godsil (1988). They found the spectral measure `mu(lambda)` has a point mass at
> `lambda = 0` of size `(1/2) |d_1-d_2|/(d_1+d_2)` and a continuous part ... supported on
> `|sqrt(d_1-1) - sqrt(d_2-1)| <= |lambda| <= sqrt(d_1-1) + sqrt(d_2-1)`."

G. Brito, I. Dumitriu, K. Decker Harris, *Spectral gap in random bipartite biregular graphs and
applications*, arXiv:1804.07808v6 (revised 2 June 2021), Combin. Probab. Comput. **31** (2022)
229-267, DOI 10.1017/S0963548321000249, Section 1 "Bipartite biregular model", equation
`\label{lower_bound}`. I read this in the paper's LaTeX source through the local dossier symlink
`.paper-mastery/biregular-spectral-gap/source/source/introduction.tex`, lines 140-175.

Their upper bound, which is the input to L5, is their Theorem 4, quoted verbatim by Dumitriu-Zhu as
Lemma 4.6 (`lit/dz.txt` line 587ff): for a uniform simple `(d_1,d_2)`-biregular bipartite graph with
`d_1 >= d_2` fixed, `lambda_2 <= sqrt(d_1-1) + sqrt(d_2-1) + o(1)` and
`lambda^+_min >= sqrt(d_1-1) - sqrt(d_2-1) - o(1)` almost surely. Two independent readings agree
(Dumitriu-Zhu's quotation, and the paper's own LaTeX for the lower side). I did not re-derive the
trace-moment proof.

### L7. Hypergraph coverings [READ]

> "**Definition 1.2.** Let `H` be a connected `(d,r)`-regular hypergraph. We call `H` a Ramanujan
> hypergraph if any non-trivial non-obvious eigenvalue `lambda` of `H` satisfies
> `|lambda - (r-2)| <= 2 sqrt((d-1)(r-1))`, `H` a **right-sided** Ramanujan hypergraph if any
> non-trivial eigenvalue `lambda` satisfies `lambda <= r-2+2 sqrt((d-1)(r-1))`, and `H` a
> **left-sided** Ramanujan hypergraph if any non-obvious eigenvalue `lambda` satisfies
> `lambda >= r-2-2 sqrt((d-1)(r-1))`."

> "**Theorem 1.3.** Let `H` be a connected hypergraph and let `H_bar` be a `k`-cover of `H`. Then,
> as multi-sets, the spectrum of `H_bar` contains that of `H`."

> "**Theorem 1.5.** Let `H` be a `d`-regular hypergraph, and let `T_H` be the universal cover of `H`.
> Then `lambda_2(H) >= rho(T_H) - o_n(1)`." with, for `(d,r)`-regular `H`,
> `rho(D_{d,r}) = r-2+2 sqrt((d-1)(r-1))`.

> "**Theorem 1.6.** Every connected `(d,r)`-regular hypergraph has a right-sided Ramanujan 2-covering."

> "**Theorem 1.7.** There exists an infinite family of `(d,d)`-regular (respectively, `(d+1,d)`-regular)
> right-sided Ramanujan hypergraphs for every `d >= 3` (respectively, for every prime power `d`)."

Yi-Min Song, Yi-Zheng Fan, Zhengke Miao, *Hypergraph coverings and Ramanujan hypergraphs*,
arXiv:2310.01771v2 (4 March 2024), `lit/sfm.txt` lines 30-70, 100-200.

### L8. Covers, duality, and the universal cover [READ]

> "There are obvious eigenvalues `0` of `B` with multiplicity `||V| - |E||`. Hence, the spectrum of
> one of the three graphs `B`, `H` and `H*` yields that of the other two."

> "An `r`-regular `u`-uniform hypergraph `H` is called Ramanujan if `|tau_2(H) - (u-2)| <= 2 sqrt(q)`,
> where ... `q = (r-1)(u-1)`."

Cioaba-Koolen-Mimura-Nozaki-Okuda, arXiv:2009.03022v3, Section 2 around their equation (2.1), and
Section 1 around their equation (1.1), `lit/ckmno.txt` lines 71, 190.

## 2.2 What I searched for and did not find

Searches were run on 2026-11-14 against the public arXiv API with general mathematical terms.
Recorded here so that the novelty claims in this dossier are calibrated.

* `search_query=abs:"random lift" AND abs:hypergraph` returns **0 results**. The random-lift
  (Broder-Shamir, Friedman-Kohler, Bordenave) theory of hypergraph covers, as opposed to 2-covers,
  therefore appears not to be in the literature. This is the basis of open target O1 in file 04.
* `search_query=all:"Ramanujan hypergraph"` returns 3 results: Song-Fan-Miao (L7), and two 2026
  preprints by J. M. Courtney on permutation routing in neutral-atom architectures
  (arXiv:2605.02498, arXiv:2605.05036) which quote the standard definition and which I did not use
  for any mathematical statement.
* `search_query=ti:"random regular hypergraphs"` returns 5 results, of which Dumitriu-Zhu (L5) is
  the spectral one.
* No source was found that states, or uses, the fact that a strong `k`-colouring forces `-d` with
  multiplicity at least `k-1` when `d >= k`, nor the rank criterion `mult(-d) = n - rank(X)`.
  This is the basis of the novelty claim for T2, T5, T9. It is a small statement with a three-line
  proof, so I would not be surprised if it is folklore. It is not in Storm, not in
  Dumitriu-Zhu, not in Song-Fan-Miao, not in Cioaba et al., and not in the two 2026 preprints.
* No source was found that compares the Li-Sole window with the naive tree quantity
  `2 sqrt((k-1)d - 1)`. This is the basis of T7.

## 2.3 Use of the four local dossiers, and the errors in them that I avoided

The four dossiers under `.paper-mastery/` are reading notes, not certified proofs. I read the
executive maps, the main-results files and the assumptions-and-weak-points files of all four, and
for each statement I actually use I went to the primary source.

* `alon-second-eigenvalue` (Friedman, arXiv:cs/0405020v1, 118 pp). Used only as the statement of
  Alon's conjecture and of the constant `2 sqrt(d-1)` in the `k = 2` case. Nothing from this paper is
  load-bearing. The dossier's W1 (`q_k(d) = d(d-1)^{k-1}`, not `(d-1)^k`) and W3 (reversed inclusion
  in Lemma 9.2) are local defects in the source, and neither touches anything used here.
* `biregular-spectral-gap` (Brito-Dumitriu-Decker Harris, arXiv:1804.07808v6). I use their Theorem 4
  (upper edge `sqrt(d_1-1)+sqrt(d_2-1)`) and their `lower_bound` equation. Their dossier lists a
  serious audit objection to Corollary 12 of that paper (the packaged half-edge bound does not
  follow from Lemma 11) and a one-sidedness issue in Lemma 13. Those concern the trace-moment
  proof. I do not reproduce or rely on the moment proof, I take the theorem as a published result,
  and I flag in file 04 that the moment proof's status is a separate question.
* `friedman-second-eigenvalue-lifts` (Bordenave, arXiv:1502.04482v4). I use only the description of
  Theorem 23 (new non-backtracking eigenvalues bounded by `sqrt(rho_1)`) and the Ihara-Bass
  quartic. **Caution:** I did not re-check Theorem 23 against Bordenave's PDF in this run, so it is
  marked [SECONDARY] and used only in file 04 as part of a strategy, never as a proved input.
* `relativized-second-eigenvalue` (Friedman-Kohler, arXiv:1403.3462v1). I use the shape of the
  relativized conjecture and the notion of fundamental order. The dossier's warning that the paper's
  own inequality `eta_fund(B) > sqrt(d-1)` (Theorem 3.3.4) contradicts its definitions is noted. I
  do not use that inequality anywhere.

## 2.4 Two literature statements that I use with a correction

* Dumitriu-Zhu Theorem 4.3 is stated for `d >= k >= 3`. The proof uses the biregular theorem with
  `(d_1,d_2) = (d,k)`, and it is valid for all `d,k >= 2` once the pair is ordered as
  `(max, min)`, because the Gram identity is exact. It is *not* valid as a two-sided statement for
  `d < k`: see T9 and T12, where every `(d,k)`-regular hypergraph with `d < k` carries `-d` with
  multiplicity at least `n - m`, which lies below the window bottom. So for `d < k` the only valid
  conclusion is the upper one, `lambda_2 <= k-2+2t`. This is consistent with the literature's
  treatment of `-d` as "obvious" and excluded, but it means that the `d >= k` restriction in
  Dumitriu-Zhu is not cosmetic: it is the hypothesis that makes the two-sided statement meaningful.
* Storm's remark "with `d >= r` we have that `n_2 >= n_1` ... `H` has no obvious eigenvalues `-d`.
  This will simplify our consideration of the Ramanujan condition" is correct for the rectangular
  source. It is not correct for the colouring source (T5, T9): a `k`-partite `(d,k)`-regular
  hypergraph with `d > k` has `n_2 > n_1` and still has `-d` with multiplicity at least `k-1`.
