#!/usr/bin/env python3
"""Exact numerical check (NOT a proof) of the finite-root law for the spiked
d-regular host, using a CERTIFIED-UNIFORM sampler.

Sampler: configuration model (uniform random perfect matching of d*n stubs)
conditioned on simplicity, by rejection.  Conditioned on simplicity this is
exactly the uniform distribution on simple d-regular graphs on n labelled
vertices (Bollobas 1980; Janson-Luczak-Rucinski 2000, Prop. 7.13 / Rem. 7.14).
Acceptance probability tends to exp(-(d^2-1)/4), which is why d <= 4 is used.
networkx.random_regular_graph is NOT certified uniform and is not used.

Prediction (proof/reduction.md, Theorem 3): with
    lambda_f = sqrt( ( (d^2-(d-2)D) + sqrt((d^2-(d-2)D)^2 + 4(d-1)D^2) ) / 2 )
and lambda_f := 2 sqrt(d-1) when D <= 2(d-2),
    lambda_1(G') -> max(d, lambda_f),   lambda_2(G') -> min(d, lambda_f).

Fixed seeds.  Run: python3 scripts/finite_root_test.py
"""
import numpy as np, scipy.sparse as sps
from scipy.sparse.linalg import eigsh

def cfg_simple(n, d, rng, max_try=4000):
    """Uniform simple d-regular graph via conditioned configuration model."""
    for _ in range(max_try):
        stubs = np.repeat(np.arange(n), d)
        rng.shuffle(stubs)
        a, b = stubs[0::2], stubs[1::2]
        if np.any(a == b):
            continue
        e = np.minimum(a, b) * n + np.maximum(a, b)
        if np.unique(e).size != e.size:
            continue
        return a, b
    raise RuntimeError("rejection sampler failed")

def adj(n, a, b):
    A = sps.coo_matrix((np.ones(len(a)), (a, b)), shape=(n, n))
    return (A + A.T).tocsr()

def lamf(d, D):
    if D <= 2*(d-2):
        return 2*np.sqrt(d-1)
    a = d*d - (d-2)*D
    return np.sqrt((a + np.sqrt(a*a + 4*(d-1)*D*D))/2)

def gd(x, d):
    """Kesten-McKay Stieltjes transform at real x > 2 sqrt(d-1)."""
    sq = np.sqrt(x*x - 4*(d-1))
    return (-(d-2)*x + d*sq)/(2*(x*x - d*d))

def run(d, D, n, seed):
    rng = np.random.default_rng(seed)
    a, b = cfg_simple(n, d, rng)
    A = adj(n, a, b)
    T = np.arange(D)                       # fixed vertex set {0,...,D-1}
    # spiked graph: n+1 vertices, new vertex n adjacent to T
    rows = np.concatenate([a, np.full(D, n)])
    cols = np.concatenate([b, T])
    Ap = sps.coo_matrix((np.ones(rows.size), (rows, cols)), shape=(n+1, n+1))
    Ap = (Ap + Ap.T).tocsr()          # symmetrise exactly once
    ev = np.sort(eigsh(Ap.tocsc(), k=5, which='LA', return_eigenvectors=False,
                       tol=1e-11))[::-1]
    evh = np.sort(eigsh(A.tocsc(), k=3, which='LA', return_eigenvectors=False,
                        tol=1e-11))[::-1]
    return ev, evh

def main():
    print("d  D      n     lam1        lam2      pred_max    pred_min"
          "    lam2_host   2sqrt(d-1)")
    lf = {}
    for (d, D) in [(3, 1), (3, 2), (3, 3), (3, 4), (3, 6), (4, 5), (4, 7)]:
        lf[(d, D)] = lamf(d, D)
        for n in (1000, 2000, 4000, 8000):
            seed = 10**6*d + 10**3*D + n
            ev, evh = run(d, D, n, seed)
            pm, pn = max(d, lf[(d, D)]), min(d, lf[(d, D)])
            print(f"{d}  {D:2d}  {n:6d}  {ev[0]:.7f}  {ev[1]:.7f}   "
                  f"{pm:.7f}   {pn:.7f}   {evh[1]:.7f}   {2*np.sqrt(d-1):.7f}")
    print("\nReference values of lambda_f (exact closed form):")
    for k, v in lf.items():
        print(f"  (d,Delta)={k}: lambda_f={v:.10f}"
              + ("   [= 2 sqrt(d-1) edge convention]" if k[1] <= 2*(k[0]-2) else ""))
    print("\nResidual check of the exact secular identity: Sigma(lambda_2)=0.")
    from scipy.sparse.linalg import spsolve
    for (d, D) in [(3, 3), (3, 6)]:
        n = 4000
        seed = 10**6*d + 10**3*D + n
        rng = np.random.default_rng(seed)
        a, b = cfg_simple(n, d, rng)
        A = adj(n, a, b)
        one = np.zeros(n); one[:D] = 1.0
        # exact finite-graph value of 1_T^T (A-lam)^{-1} 1_T at the computed
        # eigenvalues of the spiked graph, and the tree value -D*G_d(lam).
        rows = np.concatenate([a, np.full(D, n)])
        cols = np.concatenate([b, np.arange(D)])
        Ap = sps.coo_matrix((np.ones(rows.size), (rows, cols)), shape=(n+1, n+1))
        Ap = (Ap + Ap.T).tocsr()
        ev = np.sort(eigsh(Ap.tocsc(), k=5, which='LA', return_eigenvectors=False,
                           tol=1e-12))[::-1]
        for lam in ev[:2]:
            if lam > 2*np.sqrt(d-1) - 1e-9:   # only exterior energies are legal
                x = spsolve((A - lam*sps.identity(n)).tocsc(), one)
                sig = lam + one @ x
                tr = lam - D*gd(lam, d)
                print(f"  (d,Delta)=({d},{D}) n={n} lam={lam:.8f}: "
                      f"Sigma(lam)={sig:+.3e}   lam-D*G_d(lam)={tr:+.3e}")

if __name__ == "__main__":
    main()
