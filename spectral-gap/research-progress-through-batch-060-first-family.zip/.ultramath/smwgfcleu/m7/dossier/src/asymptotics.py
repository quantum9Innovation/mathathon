"""Contrast experiments: abelian and dihedral families vs non-abelian groups of larger order."""
import sys
sys.path.insert(0, 'dossier/src')
import numpy as np
from cayley import *
from scipy.sparse import csr_matrix
from scipy.sparse.linalg import eigsh

import builtins
def pp(*a, **k):
    k.setdefault('flush', True)
    builtins.print(*a, **k)


def sparse_A(G, S):
    n, T = G.n, G.T
    rows = np.concatenate([np.arange(n) for _ in S])
    cols = np.concatenate([T[s] for s in S])
    dat = np.ones(len(rows))
    return csr_matrix((dat, (rows, cols)), shape=(n, n))


def lam_sparse(G, S, k=3, seed=0):
    A = sparse_A(G, S).astype(float)
    n = G.n
    d = len(S)
    rng = np.random.default_rng(seed)
    v0 = rng.standard_normal(n)
    vals_hi = eigsh(A, k=k, which='LA', return_eigenvectors=False, tol=1e-8, v0=v0)
    vals_lo = eigsh(A, k=k, which='SA', return_eigenvectors=False, tol=1e-8, v0=v0)
    hi = sorted(vals_hi, reverse=True)
    lo = sorted(vals_lo)
    lam2p = hi[1]
    lammin = lo[0]
    return max(abs(lam2p), abs(lammin)), lam2p, lammin


def abelian_contrast():
    pp("### abelian contrast: Cayley graphs of Z_n, d fixed")
    for d in [3, 4, 6]:
        pp("  d = %d, threshold 2 sqrt(d-1) = %.6f" % (d, 2 * np.sqrt(d - 1)))
        for n in [20, 50, 100, 200, 500, 1000]:
            G = cyclic_group(n)
            # S = {+-1, ...} plus an involution if d odd
            if d % 2 == 0:
                S = set()
                k = d // 2
                for j in range(1, k + 1):
                    S.add(j % n)
                    S.add((-j) % n)
            else:
                S = set()
                k = (d - 1) // 2
                for j in range(1, k + 1):
                    S.add(j % n)
                    S.add((-j) % n)
                S.add(n // 2 if n % 2 == 0 else 0)  # involution (or identity -> fix)
                S.discard(0)
            S = tuple(sorted(S))
            if len(S) != d or not G.connected(S):
                pp("     n=%4d : skipped (S not usable)" % n)
                continue
            lam = G.lambda_two_sided(S)
            pp("     n=%4d : lambda = %.9f   gap d-lambda = %.3e" % (n, lam, d - lam))


def dihedral_contrast():
    pp("### dihedral contrast: cubic Cayley graphs of D_m (prisms)")
    for m in [5, 8, 13, 25, 50, 101, 200]:
        G = dihedral_group(m)
        # S = {r, r^-1, t}
        rot = G.pos[tuple((i + 1) % m for i in range(m)) + tuple(m + (i + 1) % m for i in range(m))]
        ref = G.pos[tuple((m - i) % m for i in range(m)) + tuple(m + (m - i) % m for i in range(m))]
        S = tuple(sorted({rot, int(G.inv[rot]), ref}))
        if len(S) != 3 or not G.connected(S):
            pp("   m=%d skipped" % m); continue
        lam = G.lambda_two_sided(S)
        pred = 1 + 2 * np.cos(2 * np.pi / m)
        pp("   m=%4d : lambda = %.9f   prediction 1+2cos(2pi/m) = %.9f   2sqrt2 = %.6f"
           % (m, lam, pred, 2 * np.sqrt(2)))


def random_nonabelian():
    pp("### typical random symmetric S in larger non-abelian groups")
    for n, name in [(4, 'S4'), (5, 'A5'), (5, 'S5'), (6, 'A6'), (6, 'S6')]:
        G = alt_group(n) if name[0] == 'A' else sym_group(n)
        for d in [3, 4]:
            rng = np.random.default_rng(12345 + 10 * n + d)
            vals = []
            tries = 0
            while len(vals) < 60 and tries < 200000:
                tries += 1
                # random symmetric S of size d: random d/2 or (d-1)/2 pairs plus maybe an involution
                if d % 2 == 0:
                    cand = set()
                    while len(cand) < d:
                        x = int(rng.integers(1, G.n))
                        cand.add(x); cand.add(int(G.inv[x]))
                    S = tuple(sorted(cand))
                else:
                    cand = set()
                    while len(cand) < d - 1:
                        x = int(rng.integers(1, G.n))
                        if G.order[x] == 2:
                            continue
                        cand.add(x); cand.add(int(G.inv[x]))
                    invol = [i for i in range(1, G.n) if G.order[i] == 2]
                    if not invol:
                        break
                    cand.add(int(rng.choice(invol)))
                    S = tuple(sorted(cand))
                if len(S) != d:
                    continue
                if not G.connected(S):
                    continue
                if G.n <= 60:
                    lam = G.lambda_two_sided(S)
                else:
                    lam, a, b = lam_sparse(G, S, k=3, seed=tries)
                vals.append(lam)
            if vals:
                vals = np.array(vals)
                thr = 2 * np.sqrt(d - 1)
                pp("   %s (order %d), d=%d: %d samples  mean %.6f  min %.6f  max %.6f  threshold %.6f  frac>thr %.3f"
                   % (name, G.n, d, len(vals), vals.mean(), vals.min(), vals.max(), thr, np.mean(vals > thr + 1e-9)))


if __name__ == '__main__':
    abelian_contrast(); pp()
    dihedral_contrast(); pp()
    random_nonabelian()
