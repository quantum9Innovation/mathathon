# Dossier index, member m2, direction d6 (one-sided spectra and the two Alon-Boppana constants)

Read in this order.

1. `main.md` the research dossier. Model, results, exact examples, numerics, theorem targets, open
   problems, common ground with the four source dossiers and with the other swarm directions,
   epistemic ledger, file manifest.
2. `proofs.md` complete proofs of the double cover lemma, the trivial-spectrum proposition,
   Theorems A, B, C, and Propositions 3, 4, 5, each with its external inputs named.
3. `literature.md` verified literature, with the version read, the exact statement used, and an
   explicit note on which items are second-hand through a survey.
4. `experiments.md` script by script description, commands, raw output locations, and the
   limitations of each experiment.
5. Section 12 of `main.md` records the five corrections made after the first review, each with the
   counterexample that forced it and the repaired statement. Read it before relying on any claim
   about arbitrary period coverings.
5. `../experiments/` runnable scripts, `../raw/` raw outputs, `../papers/` the downloaded primary
   source (Parzanchevski arXiv:1804.08028v4) and its text extract.

Headline results.

* **Theorem A.** Every strongly connected $k$-regular digraph satisfies
  $\sigma_2\ge2\sqrt{k-1}-o(1)$, with no symmetry hypothesis, because the bipartite double cover is
  $(k,k)$-biregular and the biregular Alon-Boppana bound of the second source dossier applies.
* **Theorem B.** On the normal locus (period one) the eigenvalue threshold is the same
  $2\sqrt{k-1}$, sharp by Friedman's theorem. This is strictly stronger than the published
  $\sqrt{k}$ bound for almost-normal families.
* **Theorem C.** Inside $2$-normal families the sharp constant drops to exactly $\sqrt{k}$, for every
  period, because the Ihara-Bass image of the Ramanujan interval is the circle of radius $\sqrt{k}$.
  The period bookkeeping requires an aperiodic base, which is the repair of review point 1.
* **Proposition D.** A $k$-regular digraph of period $m$ has exactly $m$ eigenvalues of modulus $k$,
  namely $k\zeta_m^j$. Hence $k-\lambda_2=0$ for $m\ge2$ and the first informative gap is
  $k-\lambda_{m+1}$. For $m=2$ that is the user's $d-\lambda_3$, for $m=3$ the user's
  $d-\lambda_4$.
* **Proposition E.** The map $\lambda=2\sqrt{k}\cos\theta\mapsto\mu=\sqrt{k}e^{i\theta}$ is the
  Ihara-Bass substitution, so $\sqrt{k}$ and $2\sqrt{k-1}$ are the same threshold in two coordinates.
