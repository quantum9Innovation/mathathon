"""
experiments_final.py -- (1) certified lower bounds for rho(A_T) of irregular bases,
(2) new spectra of random lifts vs the universal-cover prediction,
(3) gap test for biregular bases.
"""
import numpy as np
from cover_tools import (universal_cover_ball, base_adjacency, random_lift,
                         new_spectrum, top_eigs)

def cover_growth(r, edges, out, name, depths):
    out.write(f"### {name}: base {r} vertices, {len(edges)} edges, degrees "
              f"{sorted(np.bincount(np.array(edges).ravel()).tolist())}\n")
    prev = None
    for D in depths:
        T = universal_cover_ball(r, edges, 0, D)
        t, b = top_eigs(T, 2)
        n = T.shape[0]
        out.write(f"  depth={D:2d} verts={n:7d} top={t[0]:.10f} bottom={b[0]:.10f}\n")
        if n > 400000: break
    out.write("\n")

def lift_scan(r, edges, A, out, name, ns, reps=3, seed=7, extra=None):
    rng = np.random.default_rng(seed)
    out.write(f"### {name}\n")
    eb = np.sort(np.linalg.eigvalsh(A))
    out.write(f"  base spectrum: {np.round(eb,6)}\n")
    if extra: out.write("  " + extra + "\n")
    out.write("   n  verts  max|new| mean +- sd   min nonzero |new|   #new in gap\n")
    for n in ns:
        mxs, mns, counts = [], [], []
        for _ in range(reps):
            G = random_lift(r, edges, n, rng)
            new = new_spectrum(A, G, n)
            mxs.append(np.max(np.abs(new)))
            nz = np.abs(new)[np.abs(new) > 1e-7]
            mns.append(np.min(nz) if nz.size else np.nan)
            if extra is not None and 'gap' in globals().get('GAP', {}):
                pass
        out.write(f"  {n:3d} {r*n:6d}   {np.mean(mxs):.6f} +- {np.std(mxs):.1e}    {np.mean(mns):.6f}\n")
    out.write("\n")
    return

def bireg_edges(nL, pairs):
    return [(u, nL+v) for (u,v) in pairs]

if __name__ == "__main__":
    import os
    os.makedirs("outputs", exist_ok=True)
    out = open("outputs/experiments_final.txt","w")
    out.write("UNIVERSAL COVERS AND RANDOM LIFTS: FINAL EXPERIMENTS\n" + "="*74 + "\n\n")

    # ---- biregular (3,2): subdivision of K4
    K4 = [(i,j) for i in range(4) for j in range(i+1,4)]
    e32 = bireg_edges(4, [(i,e) for e,(i,j) in enumerate(K4)] + [(j,e) for e,(i,j) in enumerate(K4)])
    cover_growth(10, e32, out, "(3,2)-biregular = subdivision of K4", [4,8,12,16,20])
    A32 = base_adjacency(10, e32)
    lift_scan(10, e32, A32, out, "(3,2) lifts;  sqrt(a)+sqrt(b)=%.6f, 2 sqrt(d1-1)=%.6f, sqrt3 rho=%.6f"
              % (np.sqrt(2)+1, 2*np.sqrt(2), np.sqrt(3)*(np.sqrt(2)+1)), [5,10,20,40,60], reps=3)

    # ---- gap test: count new eigenvalues strictly inside (-(sqrt a - sqrt b), +(sqrt a - sqrt b))
    rng = np.random.default_rng(11)
    lo = np.sqrt(2)-1
    out.write(f"GAP TEST (3,2): open interval (-{lo:.6f},{lo:.6f}); zeros are forced (unequal bipartition)\n")
    for n in (10, 20, 40, 60):
        vals = []
        for _ in range(3):
            G = random_lift(10, e32, n, rng)
            new = new_spectrum(A32, G, n)
            inside = new[(new > -lo) & (new < lo)]
            vals.append(np.max(np.abs(inside)) if inside.size else 0.0)
        out.write(f"  n={n:3d}: #new inside gap (per rep) = {[int(np.sum((new>-lo)&(new<lo))) for _ in range(1)]}, "
                  f"max |new inside gap| = {np.mean(vals):.6f}  (all zeros? {np.mean(vals) < 1e-6})\n")
    out.write("\n")

    # ---- Bordenave-Collins base: K_{2,3} plus the edge joining the two degree-4 vertices
    bc = [(0,2),(0,3),(0,4),(1,2),(1,3),(1,4),(0,1)]
    Abc = base_adjacency(5, bc)
    out.write("BORDENAVE-COLLINS BASE (their Figure caption: sigma(A_star) = [-2.866,-0.283] u {0} u [0.283,2.866])\n")
    out.write(f"  base degrees {np.round(np.asarray(Abc.sum(1)).ravel(),1)}, base spectrum {np.round(np.sort(np.linalg.eigvalsh(Abc)),6)}\n")
    cover_growth(5, bc, out, "K_{2,3} + edge(0,1)", [6,9,12,15,18,21])
    lift_scan(5, bc, Abc, out, "lifts of the BC base; 2 sqrt(dmax-1)=%.6f" % (2*np.sqrt(3)), [5,10,20,40,60], reps=3)

    # ---- irregular simple base with degrees (3,3,3,3,2)
    irr = [(0,1),(0,2),(0,3),(1,2),(1,3),(2,4),(3,4)]
    Airr = base_adjacency(5, irr)
    out.write("IRREGULAR BASE with degrees (3,3,3,3,2): edges %s\n" % (irr,))
    out.write(f"  base degrees {np.round(np.asarray(Airr.sum(1)).ravel(),1)}, spectrum {np.round(np.sort(np.linalg.eigvalsh(Airr)),6)}\n")
    cover_growth(5, irr, out, "degrees (3,3,3,3,2)", [6,9,12,15,18])
    lift_scan(5, irr, Airr, out, "lifts; 2 sqrt(dmax-1)=%.6f" % (2*np.sqrt(2)), [5,10,20,40,60], reps=3)

    # ---- multigraph base: 2 parallel 0-1 edges, 1-2, 0-2  (degrees 3,3,2)
    mg = [(0,1),(0,1),(1,2),(0,2)]
    Amg = base_adjacency(3, mg)
    out.write("MULTIGRAPH BASE: two parallel 0-1 edges, edges 1-2 and 0-2; degrees (3,3,2)\n")
    out.write(f"  base spectrum {np.round(np.sort(np.linalg.eigvalsh(Amg)),6)}\n")
    cover_growth(3, mg, out, "degrees (3,3,2) multigraph", [6,9,12,15,18])
    lift_scan(3, mg, Amg, out, "lifts; 2 sqrt(dmax-1)=%.6f" % (2*np.sqrt(2)), [5,10,20,40,60], reps=3)
    out.close()
    print(open("outputs/experiments_final.txt").read())
