"""Key table for the dossier: MRRW-derived lower bound versus explicit constructions.

For a connected Cayley graph on F_2^rho with |S| = d we have exactly
    lambda_2 = d - 2 d_min(C),   C = rowspace of the rho x d column matrix of S.
The MRRW-1 asymptotic bound gives (derivation in theorem-05.md)
    lambda_2 >= sqrt( 2 rho d / (2 log2 d + C0) ),   C0 = 1 + 2 log2(e) = 2.4427.
The script checks the inequality on every computed example and reports, for each d,
the critical rho at which the bound overtakes 2 sqrt(d-1).
"""
import json
import math

C0 = 1 + 2 * math.log2(math.e)


def popcount(v):
    return bin(v).count('1')


def code_of(rho, S):
    d = len(S)
    rows = []
    for i in range(rho):
        m = 0
        for j, s in enumerate(S):
            if (s >> i) & 1:
                m |= 1 << j
        rows.append(m)
    basis = []
    for v in rows:
        for b in basis:
            v = min(v, v ^ b)
        if v:
            basis.append(v)
            basis.sort(reverse=True)
    code = {0}
    for b in basis:
        code |= {c ^ b for c in code}
    we = {}
    for c in code:
        w = popcount(c)
        we[w] = we.get(w, 0) + 1
    return we, len(basis)


def lam2(d, we, rho, rank):
    nz = sorted(w for w in we if w > 0)
    if not nz:
        return None, None
    return d - 2 * nz[0], we[nz[0]] * (1 << (rho - rank))


def lower_bound(rho, d):
    return math.sqrt(2 * rho * d / (2 * math.log2(d) + C0)) if d > 1 else 0.0


def cubic_family(k):
    q = 1 << k
    polys = {2: 0b111, 3: 0b1011, 4: 0b10011, 5: 0b100101, 6: 0b1000011,
             7: 0b10001001, 8: 0b100011101, 9: 0b1000001001}
    mod = polys[k]

    def mul(a, b):
        r = 0
        while b:
            if b & 1:
                r ^= a
            b >>= 1
            a <<= 1
            if a >> k:
                a ^= mod
        return r

    return [x | (mul(mul(x, x), x) << k) for x in range(1, q)]


def main():
    import itertools
    import random
    rng = random.Random(11)
    rows = []
    # exhaustive small rho (connected only)
    for rho in (3, 4):
        for d in range(rho, (1 << rho)):
            best = None
            for S in itertools.combinations(range(1, 1 << rho), d):
                we, rank = code_of(rho, list(S))
                if rank < rho:
                    continue
                lam, mult = lam2(d, we, rho, rank)
                if best is None or lam < best[0]:
                    best = (lam, mult, list(S))
            if best:
                rows.append({'source': 'exhaustive', 'rho': rho, 'd': d,
                             'lambda_2': best[0], 'mult': best[1],
                             'S': best[2], 'bound': round(lower_bound(rho, d), 3),
                             'bench': round(2 * math.sqrt(d - 1), 3),
                             'bound_ok': best[0] >= lower_bound(rho, d) - 1e-9})
    # random examples at larger rho (single random S each, not optimised)
    for rho, d in [(6, 6), (8, 9), (10, 12), (12, 14), (12, 48), (16, 20), (16, 90),
                   (20, 21), (20, 60), (20, 200)]:
        S = rng.sample(range(1, 1 << rho), d)
        we, rank = code_of(rho, S)
        lam, mult = lam2(d, we, rho, rank)
        rows.append({'source': 'random', 'rho': rho, 'd': d, 'lambda_2': lam,
                     'mult': mult, 'rank': rank,
                     'bound': round(lower_bound(rho, d), 3),
                     'bench': round(2 * math.sqrt(d - 1), 3),
                     'bound_ok': lam >= lower_bound(rho, d) - 1e-9})
    # cubic moment-curve family in F_{2^k}^2 = F_2^{2k}
    cub = []
    for k in range(3, 9):
        S = cubic_family(k)
        rho, d = 2 * k, len(S)
        we, rank = code_of(rho, S)
        lam, mult = lam2(d, we, rho, rank)
        nz = sorted(w for w in we if w > 0)
        cub.append({'k': k, 'rho': rho, 'd': d, 'rank': rank,
                    'lambda_2': lam, 'lambda_min': d - 2 * nz[-1],
                    'd_min': nz[0], 'd_max': nz[-1],
                    'ratio_lambda2_over_d': round(lam / d, 4),
                    'bound': round(lower_bound(rho, d), 3),
                    'bench': round(2 * math.sqrt(d - 1), 3),
                    'beats_bench': lam < 2 * math.sqrt(d - 1)})
    # for each d, smallest rho with bound > benchmark
    crit = []
    for d in (16, 32, 64, 128, 256, 1024):
        r = 1
        while lower_bound(r, d) <= 2 * math.sqrt(d - 1):
            r += 1
            if r > 10 * d:
                break
        crit.append({'d': d, 'critical_rho': r,
                     'log2_d': round(math.log2(d), 2),
                     'critical_rho_over_log2_d': round(r / math.log2(d), 2),
                     'log2_G_at_critical': r})
    allok = all(row['bound_ok'] for row in rows)
    print(json.dumps({'C0': C0, 'rows': rows, 'cubic': cub, 'critical': crit,
                      'all_bound_checks_ok': allok}, indent=1))


if __name__ == '__main__':
    main()
