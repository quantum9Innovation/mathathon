# Model, normalisation, regime, and why it matters

## The object

Let $G$ be a finite group, $n = |G|$, and $S \subseteq G\setminus\{1\}$ with
$S = S^{-1}$, $|S| = d$. The Cayley graph $X = \mathrm{Cay}(G,S)$ is
$d$-regular and vertex transitive. Restrict to the case where $S$ generates
$G$, so that $X$ is connected and $(G,S)$ is a "symmetric generating set of
size $d$".

The family of all such graphs for varying $(G,S)$ with $d$ fixed is exactly the
subfamily of $d$-regular graphs that are finite quotients of the $d$-regular
tree $T_d$ with a vertex-transitive deck group acting with one orbit on
vertices. In the language of Mohanty and O'Donnell (arXiv:1904.03500) it is the
subfamily of $\mathrm{FinQuo}(T_d)$ obtained from the one-vertex base graph
with $d$ loops.

## The three spectral parameters

1. $\lambda(X) = \max_{2\le i \le n}|\lambda_i|$, with
   $\lambda_1 = d > \lambda_2 \ge \dots \ge \lambda_n$ and $\lambda_1$ counted
   once. This is the quantity compared with the Ramanujan threshold and it is
   the one used by Alon-Boppana, Friedman, Bordenave and Mohanty-O'Donnell
   (their "two-sided" convention).
2. $\lambda_2^+(X) = \lambda_2$ (the one-sided second eigenvalue).
3. $N(\theta,X) = \#\{i\ge 2 : |\lambda_i| > \theta\}$, the quasi-index. This is
   the index in the $k$-quasi-$X$-Ramanujan definition of Mohanty-O'Donnell
   (Definition 2.16): $X$ is $k$-quasi-Ramanujan if infinitely many finite
   quotients satisfy $\lambda_{k+1} \le \rho(X)$.

## The threshold and the comparison class

$\rho(T_d) = 2\sqrt{d-1}$ is the spectral radius of the infinite $d$-regular
tree, which is the universal cover of every $d$-regular graph. By
Alon-Boppana, every family of $d$-regular graphs with $n \to \infty$ has
$\liminf \lambda \ge 2\sqrt{d-1}$. By Greenberg's theorem (stated and cited as
Theorem 2.9 in Mohanty-O'Donnell) the stronger statement holds: for every
$\varepsilon>0$ there is $c>0$ such that every $n$-vertex $G \in
\mathrm{FinQuo}(T_d)$ has at least $cn$ eigenvalues $\ge 2\sqrt{d-1}-\varepsilon$.
So the threshold is a genuine lower limit for the whole class, not a
convention.

A Cayley graph is called *Ramanujan* here if $\lambda(X) \le 2\sqrt{d-1}$, that
is two-sided Ramanujan in the sense of Definition 2.10 of Mohanty-O'Donnell.
Because of Proposition 4 of `03-theory.md` (bipartite Cayley graphs have
$\lambda = d$), the two-sided convention is the only one that makes the
question non-vacuous for groups with an index two subgroup.

## The limiting regime studied, and its two halves

The asymptotic question is: fix $d \ge 3$ and $\varepsilon>0$, take groups
$G_m$ with $|G_m| \to \infty$ and symmetric generating sets
$S_m$ with $|S_m| = d$, and ask whether
$\lambda(\mathrm{Cay}(G_m,S_m)) \le 2\sqrt{d-1}+\varepsilon$ for all large $m$.

Two natural readings, and they are different problems:

(A) *Typical*: $S_m$ uniformly random among symmetric generating sets of size
$d$. This is the Cayley analogue of Alon's conjecture, and it is open, see
`02-literature.md`.
(B) *Extremal*: the minimum of $\lambda$ over all $S$ of size $d$, that is the
best expander that the group $G$ admits at degree $d$. For fixed $G$ this is a
finite problem, and this dossier solves it exhaustively for small groups.

The dossier's primary contribution is on side (B) and on the exact structural
laws that constrain both sides.

## Why it matters

1. *It is the boundary case of the relativized theory.* A Cayley graph is a
   finite quotient of $T_d$ with a one-vertex base. That base has
   $|E| = |V| = 1$, Euler characteristic zero, so Bordenave's lift theorem
   (which assumes $|E|>|V|$) and the Friedman-Kohler relativized theorem
   (which assumes negative Euler characteristic in its core) both exclude
   exactly this case. What is left out of the relativistic picture is the
   vertex-transitive case, and the Cayley question is the cleanest instance.
2. *It separates the two mechanisms in the dossiers.* The four source dossiers
   attribute the threshold $2\sqrt{d-1}$ to a local limit (the tree) plus rare
   defect (tangle) control. For Cayley graphs the "defects" are visible
   combinatorially: they are short relations and subgroups of small index. The
   exact data here identify when the subgroup mechanism is responsible and when
   it is not.
3. *It is a hard open problem in a small compass.* Whether random Cayley graphs
   of $S_N$ have a spectral gap at all, for fixed degree, is reported as open
   (see `02-literature.md`). Any progress needs exactly the uniformity over
   irreducible blocks that Proposition 1 isolates.
4. *"Beyond $\lambda_2$" becomes a representation theoretic question.* By
   Corollary 2 the multiplicities and the quasi-index are sums of irreducible
   degrees, so the questions "$d-\lambda_2$, $d-\lambda_3$, $d-\lambda_4$" have
   answers that are forced by the block structure, not by geometry.

## Independence from the source dossiers' errors

The four source dossiers carry documented local defects (for example the sign
error in the tree Euler characteristic and the inconsistent Theorem 3.3.4 of
the relativized paper, recorded in
`.paper-mastery/relativized-second-eigenvalue/09-assumptions-and-weak-points.md`).
Nothing in this dossier depends on those defective statements. The only
external inputs used are the thresholds and the meta-theorems (Alon-Boppana,
Greenberg, Friedman, Feng-Li, and the block decomposition), each of which is
either quoted verbatim in `02-literature.md` or proved in `03-theory.md`.
