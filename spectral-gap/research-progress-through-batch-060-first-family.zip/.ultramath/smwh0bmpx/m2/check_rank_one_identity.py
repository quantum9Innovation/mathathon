#!/usr/bin/env python3
"""Independent exact-rational check of the rank-one Perron resolvent identity.

Claim under test (batch 050, Lemma 1(iii) / Lemma 2 / 050-finite-defect §2):
   (A - L)^{-1}  =  P/(d-L) - sum_{k>=0} (A')^k / L^{k+1} ,   A' = A - dP, P = 11^T/n.
Board finding d1/f9 (m4) says this is FALSE and the correct identity is
   (A - L)^{-1}  =  P/(d-L) + P/L - sum_{k>=0} (A')^k / L^{k+1} .
Consequently, for a set T of size D,
   1_T^T (A-L)^{-1} 1_T = D^2/(n(d-L)) + D^2/(n L) - sum_{k>=0} 1_T^T (A')^k 1_T / L^{k+1} .
Everything below is exact rational arithmetic (fractions.Fraction), with a rigorous
geometric tail bound D^2 rho^K/(L(1-rho)), rho = ||A'||/L < 1.
"""
from fractions import Fraction as F
import json

import numpy as np


def petersen():
    # standard Petersen graph: outer 5-cycle, inner pentagram, spokes
    E = [(0, 1), (1, 2), (2, 3), (3, 4), (4, 0),
         (0, 5), (1, 6), (2, 7), (3, 8), (4, 9),
         (5, 7), (7, 9), (9, 6), (6, 8), (8, 5)]
    n = 10
    A = [[F(0)] * n for _ in range(n)]
    for a, b in E:
        A[a][b] = F(1)
        A[b][a] = F(1)
    return A, n


def matmul(X, Y, n):
    return [[sum(X[i][k] * Y[k][j] for k in range(n)) for j in range(n)] for i in range(n)]


def solve(A, b, n):
    """Exact Gaussian elimination for a rational n x n system."""
    M = [[A[i][j] for j in range(n)] + [b[i]] for i in range(n)]
    for c in range(n):
        p = next(r for r in range(c, n) if M[r][c] != 0)
        M[c], M[p] = M[p], M[c]
        piv = M[c][c]
        M[c] = [v / piv for v in M[c]]
        for r in range(n):
            if r != c and M[r][c] != 0:
                f = M[r][c]
                M[r] = [M[r][j] - f * M[c][j] for j in range(n + 1)]
    return [M[i][n] for i in range(n)]


def main():
    out = []
    A, n = petersen()
    d = 3
    # Perron projector
    P = [[F(1, n)] * n for _ in range(n)]
    Ap = [[A[i][j] - d * P[i][j] for j in range(n)] for i in range(n)]
    # ||A'|| : integer roundoff-free check via numpy eigenvalues (bound only)
    ev = np.linalg.eigvalsh(np.array([[float(A[i][j]) for j in range(n)] for i in range(n)]))
    lam2 = max(abs(sorted(ev)[-2]), abs(sorted(ev)[0]))
    rho_check = lam2 / 2.5
    assert rho_check < 1, rho_check

    for (T, name) in (([0, 1], "edge T={0,1}, D=2"),):
        D = len(T)
        L = F(5, 2)
        # left-hand side: 1_T^T (A - L I)^{-1} 1_T
        M = [[A[i][j] - (L if i == j else 0) for j in range(n)] for i in range(n)]
        b = [F(1) if i in T else F(0) for i in range(n)]
        x = solve(M, b, n)
        lhs = sum(x[i] for i in T)
        # right-hand sides: truncated series
        K = 80
        Pow = [[F(1) if i == j else F(0) for j in range(n)] for i in range(n)]   # (A')^0 = I
        s_v = F(0)                                          # 1_T^T (A')^k 1_T / L^{k+1}
        for k in range(K):
            q = sum(Pow[i][j] for i in T for j in T)
            s_v += q / L ** (k + 1)
            Pow = matmul(Pow, Ap, n)
        tail = F(D * D) * F(rho_check) ** K / (L * (1 - F(rho_check)))
        # careful: use a rational upper bound for rho
        rho = F(str(round(rho_check + 1e-3, 6)))
        tail = F(D * D) * rho ** K / (L * (1 - rho))
        frozen = F(D * D, n) / (d - L) - s_v
        repaired = F(D * D, n) / (d - L) + F(D * D, n) / L - s_v
        rec = {"graph": "Petersen (d=3,n=10)", "T": name, "lambda": str(L),
               "lhs_exact": str(lhs), "lhs_float": float(lhs),
               "frozen_formula": str(frozen), "frozen_float": float(frozen),
               "frozen_error": float(lhs - frozen),
               "repaired_formula": str(repaired), "repaired_float": float(repaired),
               "repaired_error": float(lhs - repaired),
               "missing_term_D2_over_n_lambda": str(F(D * D, n) / L),
               "tail_bound": float(tail), "K": K,
               "repaired_error_within_tail_bound": abs(float(lhs - repaired)) <= float(tail)}
        out.append(rec)
        print(json.dumps(rec, indent=1))
        assert rec["repaired_error_within_tail_bound"]
        assert abs(rec["frozen_error"] - float(F(D * D, n) / L)) < 1e-6

    # the same for the pole-free (projected) quadratic form
    for (T, name) in (([0, 1], "edge T={0,1}"),):
        D = len(T)
        L = F(5, 2)
        M = [[A[i][j] - (L if i == j else 0) for j in range(n)] for i in range(n)]
        b = [F(1) - F(D, n) if i in T else (F(-D, n)) for i in range(n)]  # Q1_T = 1_T-(D/n)1
        x = solve(M, b, n)
        lhs = sum(x[i] for i in T) - F(D, n) * sum(x)
        K = 80
        Pow = [[F(1) if i == j else F(0) for j in range(n)] for i in range(n)]
        s_v = F(0)
        for k in range(K):
            s_v += sum(Pow[i][j] for i in T for j in T) / L ** (k + 1)
            Pow = matmul(Pow, Ap, n)
        rec = {"checked": "pole-free quadratic form 1_T^T (A-L)^{-1} Q 1_T",
               "lhs_exact": str(lhs), "lhs_float": float(lhs),
               "minus_series": str(-s_v), "minus_series_float": float(-s_v),
               "difference": float(lhs + s_v),
               "predicted_difference_D2_over_n_lambda": float(F(D * D, n) / L)}
        out.append(rec)
        print(json.dumps(rec, indent=1))

    with open("out/rank_one_identity_check.json", "w") as f:
        json.dump(out, f, indent=1)


if __name__ == "__main__":
    main()
