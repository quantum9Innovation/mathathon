import numpy as np, json
from scipy.sparse import csr_matrix, identity
from scipy.sparse.linalg import eigsh, spsolve
import importlib.util
spec = importlib.util.spec_from_file_location("ng", "checks/numeric_gprime.py")
ng = importlib.util.module_from_spec(spec); spec.loader.exec_module(ng)
d, n, seed = 5, 800, 13
rng = np.random.default_rng(seed)
lo, hi, tries = ng.pairing_graph(n, d, rng)
A = csr_matrix((np.ones(2*lo.size), (np.concatenate([lo,hi]), np.concatenate([hi,lo]))), shape=(n,n))
T = np.where(A[0].toarray().ravel() > 0)[0]
rows = np.concatenate([lo, hi, T, np.full(T.size, n)])
cols = np.concatenate([hi, lo, np.full(T.size, n), T])
Ap = csr_matrix((np.ones(rows.size), (rows, cols)), shape=(n+1, n+1))
ev_g = np.sort(eigsh(Ap.astype(float), k=4, which='LA', tol=0)[0])[::-1]
ev_h = np.sort(eigsh(A.astype(float), k=6, which='LA', tol=0)[0])[::-1]
print("host top6:", ev_h)
print("G' top4:", ev_g)
oneT = np.zeros(n); oneT[T] = 1.0
Ad = A.toarray()
ev_dense = np.linalg.eigvalsh(Ad)[::-1][:6]
print("host top6 dense:", ev_dense)
def Sig(lam):
    x = np.linalg.solve(Ad - lam*np.eye(n), oneT)
    return lam + x[T].sum()
for lam in [4.02, 4.05, 4.0636, 4.0637, 4.064, 4.5, 4.9999]:
    print(f"  Sigma({lam}) = {Sig(lam):+.6f}")
