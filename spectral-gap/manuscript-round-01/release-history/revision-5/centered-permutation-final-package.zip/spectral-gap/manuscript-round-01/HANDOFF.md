# Problem 21 continuation packet

Task: SG-M1 through SG-M5. Sender: the problem 21 integrator. Intended recipient: the next project owner or manuscript reader. Date: November 14, 2026 Pacific.

## Result and scope

Problem 21 is selected in this conversation. The manuscript gives a direct quantitative proof of Bordenave's Proposition 28, explains its identification with the biregular matching input, and proves two asymptotic transitions for distinct centered diagonal entries. The reading guide supplies the cancellation example, proof mechanism, six-factor partition count, boundary example and graph-level map.

The accepted mathematical additions are SG-06, the exact mixed-product factorial correction and optimal universal sqrt(e) prefactor, SG-07, relative hyperbolic accuracy throughout k=o(sqrt N), and SG-08, the exp(d/4) correction at k^2/N tending to d and the uniform corrected formula on bounded square-root ranges. Their dependency statements and review limits are in the [authoritative ledger](../CLAIM_LEDGER.md).

SG-01 through SG-05 remain supported at their original revisions. No imported finite-defect claim was promoted. The main graph spectral theorems were not re-proved or strengthened by this round.

## Exact outputs

- [19-page manuscript](output/pdf/centered-permutation-products.pdf).
- [Five-page illustrated guide](output/pdf/reading-guide.pdf).
- [Final frozen document revision](frozen-manuscript-v5/MANIFEST.json).
- [Core reconstruction](proof/core-audit-v1.md) and [mixed proof v3](proof/permutation-proof-v3.md).
- [Mixed-proof integration review](reviews/mixed-v3-integrator-review.md).
- [Extension proof v1](extensions/hyperbolic-window-v1.md) and [independent review](reviews/extension-review-v1.md).
- [Updated priority audit](presubmission-01/PRIORITY_AUDIT_V2.md), [journal comparison](presubmission-01/BORDENAVE_JOURNAL_CHECK.md), and [additional search log](presubmission-01/SEARCH_LOG.md).
- [Submission-readiness note](presubmission-01/SUBMISSION_READINESS.md).
- [Verification record](VERIFICATION.md).

The original input packet is [inputs/MANIFEST.json](inputs/MANIFEST.json). Earlier frozen manuscript revisions remain available to reconstruct the later corrections. The maintained source files match final frozen revision 5. The [revision-4 acceptance](reviews/manuscript-referee-v4.md) closes the five earlier findings. The [revision-5 delta review](reviews/manuscript-referee-v5.md) accepts the source and attribution corrections with no new blocking finding.

## Findings and limits

The first proof revision already survived fresh reconstruction. The round strengthened its mixed constant and factorial correction. The wider-window theorem and square-root boundary passed a separate independent review. A fresh assembled-document review identified explanatory issues concerning odd partitions, pair depletion and parallel-edge non-backtracking walks. They were corrected without changing the main theorem chain. Full-depletion and regular-graph boundary wording was also made explicit. The issue registry preserves these findings as SG-MAN-I1 through SG-MAN-I6.

The priority search verified the published optimal-scale question and the known recurrences, leading terms and special-function identity. It found no exact duplicate of the quantitative refinements in the inspected sources. Historical priority is still provisional. Preprint Lemma 7 in the biregular paper is published Lemma 5.6.

The pre-submission pass retrieved the full Bordenave journal article and verified equation (62) on printed page 1428. Both counterexamples apply. It also found Bordenave and Zhu's prior raw factorial inequality in equation (2.3), which is now cited explicitly. The sharper complete mixed estimate and diagonal transition statements remain distinct from the inspected results. The full Dai and Wong article remained unavailable, while its announced finite-ratio regime and the positive-parameter theorem of Dai, Ismail and Wang were checked at the recorded access levels.

No end-to-end formal verification is claimed. Exact checks certify their finite domains only. High-precision calculations and figures are corroboration. The proof at bounded square-root scales gives a uniform limit without an explicit rate. No formula for unbounded k/sqrt N is asserted.

## Continuation

The original round ended at revision 4. The user then authorized this pre-submission pass, recorded in [its run contract](presubmission-01/RUN_CONTRACT.md). Revision 5 contains the resulting source and attribution changes. The original cutoff remains November 15, 2026 at 12:21 AM America/Los_Angeles. No unattended continuation or deadline extension is active.

The final archive is `output/centered-permutation-final-package.zip`. Its portable index fixes the omitted-import link defect in the earlier archive. Run `checks/verify_release.py` with that archive to verify file identity, local links, finite-check reports and a complete content-identical rebuild from a temporary directory. Its exact archive hash and acceptance result are written to `checks/release-verification.json` outside the archive.

The most useful next mathematical task is to derive an explicit uniform error rate for the corrected approximation on k<=C sqrt N, starting from the Poisson availability proof. A graph application would instead require an independent audit of circuit enumeration and tangle terms. Neither is a missing premise of the delivered theorems.

Before external submission, add the team's chosen author information and check the destination's format. No publication, registration, submission or external communication was performed here. The problem 138 manuscript remains separately owned.
