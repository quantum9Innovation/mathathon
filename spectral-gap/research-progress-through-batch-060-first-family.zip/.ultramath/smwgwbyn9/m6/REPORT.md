# m6 report (revised after judge rejection) — swarm smwgwbyn9, direction d4

**What was rejected and what is now different.**
1. *Lemma 3 (the Vitali/Montel step).* The first version asserted that replacing `F_n` on
   its tightness-exceptional events yields a family with a deterministic common bound on
   every compact. That does not follow from tightness. **Repaired**: Lemma 3 is now stated
   with a *pointwise, `n`-independent* boundedness hypothesis (α2) — there is a continuous
   `h : Ω → [0,∞)`, independent of `n`, with `|F_n(z)| ≤ h(z)` **for every** `z ∈ Ω` and
   every `n` on the event `E_n` — which is exactly the form the resolvent estimate supplies
   (`h(z) = Δ/dist(z,[-b,b])` on `{spec(A_n)∖{d} ⊆ [-b,b]}`). The modified family
   `G_n = F_n 1_{E_n} + L 1_{E_n^c}` is then bounded *pathwise* and *uniformly in n* by the
   continuous function `max(h,|L|)`; normality is genuine; the subsequential limit is
   identified as `L` by diagonal extraction of a.s. convergence on a countable dense subset
   of the **open** set `U = (d+1,∞)` plus the identity theorem on the connected domain
   `Ω = ℂ∖[-b,b]`. No step assumes anything about a chosen compact at a chosen `n`.
2. *The `P(simple) ≥ c_d` input.* Withdrawn as "quoted from memory". **Replaced by a source
   read this run**: O. Angel, R. van der Hofstad, C. Holmgren, arXiv:1603.07172v2, Cor. 1.2
   eq. (1.15): `N_n(r) = e^{-(r-1)/2-(r-1)²/4+O(1/n)}(rn-1)!!/(r!)^n`; combined with their
   eq. (1.16) `P(CM simple) = N_n(d)∏d_i!/(ℓ_n-1)!!` — which is the same counting identity
   proved in Lemma 1(i) — this gives `P(S_n) = e^{-(d²-1)/4+O(1/n)}`. PDF and extracted text
   kept at `papers/avhh.pdf`, `papers/avhh.txt` (statement at text lines 194-220).

**Result unchanged.** Hypothesis (H) is proved: for fixed `d ≥ 3` and a fixed label set `T`,
`sup_{λ∈K}|1_T^T(A_{G_n}-λI)^{-1}1_T + ΔG_d(λ)| → 0` in probability for compact
`K ⊂ (2√(d-1),d)∪(d,∞)`; on `Ω = ℂ∖[-b,b]` the convergent object is the pole-subtracted
`F_n^⊥ = F_n - Δ²/(n(z-d))` (the Perron pole at `z=d` is what blocks naive continuation).
Second result unchanged: the batch value `-ΔG_d` is right only for asymptotically separated
`T`; in general the limit is `-G_d Σ_{s,t} r^{dist(s,t)}` (adjacent pair `G_d(2+2r)`;
`T=N(c)`: `dλr/(λ-dr)`), so `Δ>2(d-2)` and the "degree census" fail for clustered `T`.

**Residual issues, explicit.** Friedman's second-eigenvalue theorem is used once (to get
`P(E_n) → 1`) and is cited as in the m5 dossier (arXiv:cs/0405020v1) without a fresh
page-by-page read this run. Everything else in the argument is proved in `THEOREM.md`:
Lemma 1(i), Lemma 2 and its corollary, Lemma 3, Step 1, Step 3, Theorems A and B. Not done:
the transfer from (H) to the `λ_1/λ_2` limit, rates, the edge `λ=2√(d-1)`, growing `Δ`.

**Files** (`.ultramath/smwgwbyn9/m6/`): `THEOREM.md`, `REPORT.md`, `resolvent_patterns.py`,
`accept_check.py`, `out_8000.txt`, `out_small.txt`, `out_accept.txt`, `papers/avhh.pdf`,
`papers/avhh.txt`, and the first submission kept as `REPORT_v1_superseded.md`.
