"""
Period bookkeeping for the cyclic-cover construction A -> P_m (x) A_0, after review.

Claims to test.
(C1) Peripheral spectrum of a strongly connected k-regular digraph D equals the period:
     the number of eigenvalues of modulus k equals the period (Perron-Frobenius).
(C2) If D_0 has period m_0 and A = P_m (x) A_0, then the eigenvalues of modulus k are
     k times the lcm(m, m_0)-th roots of unity, with multiplicity gcd(m, m_0) each, and A is
     strongly connected if and only if gcd(m, m_0) = 1.
(C3) If D_0 is APERIODIC (m_0 = 1) and strongly connected, then P_m (x) A_0 is strongly
     connected with period exactly m, for every m >= 1.
"""
import json
import numpy as np
from itertools import combinations

rng = np.random.default_rng(4)
out = {}

def hashimoto(edges):
    nb = {}
    for (u, v) in edges:
        nb.setdefault(u, []).append(v); nb.setdefault(v, []).append(u)
    arcs = []
    for u in sorted(nb):
        for v in nb[u]:
            arcs.append((u, v))
    idx = {a: i for i, a in enumerate(arcs)}
    B = np.zeros((len(arcs), len(arcs)))
    for (u, v) in arcs:
        for w in nb[v]:
            if w != u:
                B[idx[(u, v)], idx[(v, w)]] += 1
    return B

def sym_adj(edges, n):
    A = np.zeros((n, n))
    for (u, v) in edges:
        A[u, v] = 1; A[v, u] = 1
    return A

def kron_cover(A0, m):
    """A = P_m (x) A0, i.e. arcs (v,j) -> (w, (j+1) mod m) for each arc v -> w."""
    N = A0.shape[0]
    A = np.zeros((N * m, N * m))
    idx = np.arange(N)
    for j in range(m):
        rows = j * N + idx
        cols = ((j + 1) % m) * N + idx
        A[np.ix_(rows, cols)] = A0
    return A

def peripheral_count(A, k, tol=1e-6):
    w = np.linalg.eigvals(A)
    return int(np.sum(np.abs(np.abs(w) - k) < tol)), w

def strongly_connected(A):
    n = A.shape[0]
    reach = (A > 0).astype(int)
    M = reach.copy()
    np.fill_diagonal(M, 1)
    for _ in range(int(np.ceil(np.log2(n))) + 2):
        M = ((M @ M) > 0).astype(int)
    return bool(M.min() > 0)

print("case, base period m0, m, lcm, ||A0||_F, peripheral count, strongly connected")
rows = []
k33 = [(i, 3 + j) for i in range(3) for j in range(3)]
K4 = list(combinations(range(4), 2))
cases = []
for name, edges, n, k in [("DL(K_{3,3})", k33, 6, 2), ("DL(K_4)", K4, 4, 2)]:
    A0 = hashimoto(edges)
    c0, _ = peripheral_count(A0, k)
    for m in [1, 2, 3, 4]:
        A = kron_cover(A0, m)
        c, _ = peripheral_count(A, k)
        rows.append(dict(base=name, m0=c0, m=m, lcm=int(np.lcm(c0, m)),
                         peripheral=c, sc=strongly_connected(A), size=A.shape[0]))
        print(f"{name:12s} m0={c0} m={m} lcm={np.lcm(c0,m)} peripheral={c} "
              f"strongly_connected={strongly_connected(A)} size={A.shape[0]}")
out["cyclic_cover"] = rows

print()
print("aperiodic bases (random regular graph as symmetric digraph, and DL of a non-bipartite graph)")
def random_regular(d, n, rng):
    for _ in range(500):
        stubs = np.repeat(np.arange(n), d); rng.shuffle(stubs)
        E = []; seen = set(); ok = True
        for i in range(0, len(stubs), 2):
            u, v = stubs[i], stubs[i + 1]
            key = (min(u, v), max(u, v))
            if u == v or key in seen:
                ok = False; break
            seen.add(key); E.append((u, v))
        if ok:
            return E
    raise RuntimeError

rows = []
for m in [1, 2, 3, 4, 5]:
    E = random_regular(3, 300, rng)          # random cubic graph, aperiodic a.s.
    A0 = sym_adj(E, 300)
    c0, w0 = peripheral_count(A0, 3)
    A = kron_cover(A0, m)
    c, w = peripheral_count(A, 3)
    nontriv = [abs(z) for z in w if abs(abs(z) - 3) > 1e-6]
    rows.append(dict(base="sym 3-regular", m0=c0, m=m, peripheral=c,
                     sc=strongly_connected(A), rho=float(max(nontriv)),
                     lambda2_two_sided=float(max(sorted(np.abs(w0))[::-1][1], 1e-12))))
    print(f"sym 3-regular m0={c0} m={m} peripheral={c} sc={strongly_connected(A)} "
          f"rho={max(nontriv):.5f} (2 sqrt(k-1) = {2*np.sqrt(2):.5f})")
for m in [1, 2, 3]:
    A0 = hashimoto(K4)                        # K_4 is non-bipartite, so DL(K_4) is aperiodic
    c0, w0 = peripheral_count(A0, 2)
    A = kron_cover(A0, m)
    c, w = peripheral_count(A, 2)
    nontriv = [abs(z) for z in w if abs(abs(z) - 2) > 1e-6]
    rows.append(dict(base="DL(K_4)", m0=c0, m=m, peripheral=c, sc=strongly_connected(A),
                     rho=float(max(nontriv))))
    print(f"DL(K_4)      m0={c0} m={m} peripheral={c} sc={strongly_connected(A)} "
          f"rho={max(nontriv):.5f} (sqrt(k) = {np.sqrt(2):.5f})")
out["aperiodic_bases"] = rows
json.dump(out, open("raw/period_check.json", "w"), indent=1)
print("written raw/period_check.json")
