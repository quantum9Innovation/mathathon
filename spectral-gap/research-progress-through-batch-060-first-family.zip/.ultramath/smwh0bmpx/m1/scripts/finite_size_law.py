#!/usr/bin/env python3
"""Direction 4 (m1): the pattern-level finite-size law at the Perron pole.

Claim.  With Sigma_n(lambda) = Phi_T(lambda) - |T|^2/(n(lambda-d)) + o(1) and
Phi_T(lambda) = lambda - G_d(lambda) sigma_T(lambda), sigma_T = sum_{s,t} r^{rho(s,t)}:

  if Phi_T(d) != 0, then on the side of d where the new eigenvalue sits between d and
  the pattern-law root,        n |lambda_i - d|  ->  |T|^2 / |Phi_T(d)|
  = |T|^2 d(d-2) / | d^2(d-2) - (d-1) sigma_T(d) | ,

and the 050 separated law is the special case sigma_T = |T| = Delta.

  if Phi_T(d) = 0 (critical), the scale is n^{-1/2} with constant |T|/sqrt(Phi_T'(d)).

This script computes all constants exactly and compares with the measured rows.
"""
import json
import sympy as sp

out = []
r = sp.symbols('r', positive=True)
d = sp.symbols('d', positive=True)


def sigma(pattern, dd, rr):
    if pattern == 'adj':
        return 2 + 2 * rr
    if pattern == 'N':
        return dd + dd * (dd - 1) * rr ** 2
    if pattern == 'C':
        return (dd + 1) + 2 * dd * rr + dd * (dd - 1) * rr ** 2
    raise ValueError


def Phi(pattern, dd, lam):
    """exact Phi, expressed through r by substituting lambda=(d-1)r+1/r"""
    rr = sp.symbols('rr', positive=True)
    lam_r = (dd - 1) * rr + 1 / rr
    Gd = rr / (1 - rr ** 2)
    return sp.simplify(lam_r - Gd * sigma(pattern, dd, rr)), rr


out.append("Phi_T(d) exactly, with r(d)=1/(d-1), G_d(d)=(d-1)/(d(d-2)):")
rows = []
for dd in (3, 4):
    for pat in ('adj', 'N', 'C'):
        rr = sp.symbols('rr', positive=True)
        lam_r = (dd - 1) * rr + 1 / rr
        Gd = rr / (1 - rr ** 2)
        Phid = sp.simplify((lam_r - Gd * sigma(pat, dd, rr)).subs(rr, sp.Rational(1, dd - 1)))
        size = {'adj': 2, 'N': dd, 'C': dd + 1}[pat]
        const = sp.nsimplify(size ** 2 / Phid) if Phid != 0 else None
        rows.append((dd, pat, Phid, const))
        out.append(f"  d={dd} T={pat:3s} |T|={size}: Phi_T(d) = {Phid}"
                   + (f"  =>  n|lam-d| -> |T|^2/|Phi_T(d)| = {sp.simplify(abs(const))}"
                      if const is not None else "  =>  CRITICAL (n^{-1/2} law)"))
out.append("")

out.append("Critical constant: |T|/sqrt(Phi_T'(d)) for the vanishing case:")
rr = sp.symbols('rr', positive=True)
lam_r = 2 * rr + 1 / rr
Gd = rr / (1 - rr ** 2)
PhiN = lam_r - Gd * (3 + 6 * rr ** 2)
dPhi = sp.simplify(sp.diff(PhiN, rr) / sp.diff(lam_r, rr))
val = sp.simplify(dPhi.subs(rr, sp.Rational(1, 2)))
out.append(f"  d=3, T=N(c): Phi_N'(3) = {val};  |T|/sqrt(Phi') = 3/sqrt({val}) = {sp.N(3/sp.sqrt(val), 12)}")
out.append("")

out.append("Separated special case (sigma_T = |T| = Delta) reproduces 050 sec.2.5:")
Dl = sp.symbols('Delta', positive=True)
lam_rD = (d - 1) * rr + 1 / rr
GdD = rr / (1 - rr ** 2)
Phi_sep_d = sp.simplify((lam_rD - Dl * GdD).subs(rr, 1 / (d - 1)))
const_sep = sp.simplify(Dl ** 2 / Phi_sep_d)
out.append(f"  Phi_sep(d) = {sp.factor(Phi_sep_d)}")
out.append(f"  constant = {sp.factor(const_sep)}")
claim = sp.simplify(const_sep - Dl ** 2 * d * (d - 2) / (Dl * (d - 1) - d ** 2 * (d - 2)))
out.append(f"  equals Delta^2 d(d-2)/(Delta(d-1)-d^2(d-2)) (050): "
           f"{'OK' if claim == 0 else 'FAIL ' + str(claim)}")
out.append("")

out.append("Measured rows (out/numerics_raw.json) against the exact constants:")
raw = json.load(open("out/numerics_raw.json"))
meas = {}
for rec in raw['runs']:
    meas.setdefault((rec['d'], rec['pattern']), []).append((rec['n'], rec['lambda_1'], rec['lambda_2']))
for (dd, pat, Phid, const) in rows:
    out.append(f"  d={dd} T={pat}: Phi_T(d)={Phid}, target constant "
               f"{'critical' if const is None else sp.simplify(abs(const))}")
    for (n, l1, l2) in sorted(meas[(dd, pat)]):
        if const is not None:
            c = abs(const)
            if Phid < 0:      # gap zero runs at d - c/n : measure n(d-lam2)
                out.append(f"     n={n:5d}  n(d-lam2) = {float(n)*(dd-l2):.4f}"
                           f"   [target {float(c):.4f}]")
            else:             # top zero runs at d + c/n : measure n(lam1-d)
                out.append(f"     n={n:5d}  n(lam1-d) = {float(n)*(l1-dd):.4f}"
                           f"   [target {float(c):.4f}]")
        else:
            s = float(sp.sqrt(dd + 1))  # |T|=d
            out.append(f"     n={n:5d}  sqrt(n)(d-lam2) = {float(n)**0.5*(dd-l2):.4f}"
                       f"   sqrt(n)(lam1-d) = {float(n)**0.5*(l1-dd):.4f}"
                       f"   [target {float(3/sp.sqrt(8)):.4f}]")
    out.append("")

txt = "\n".join(out)
print(txt)
open("out/finite_size_law.txt", "w").write(txt + "\n")
