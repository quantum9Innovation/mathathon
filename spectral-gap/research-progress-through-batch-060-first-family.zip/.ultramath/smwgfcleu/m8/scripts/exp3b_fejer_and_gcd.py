"""Exact symbol of the cyclic interval hypergraph, and the exact -d multiplicity.

Claim (T11): for q >= 2k+1 the Feng-Li operator of C(q,k) is the circulant with symbol
    p(theta) = |sum_{r=0}^{k-1} e^{i r theta}|^2 - k,
its spectrum is {p(2 pi m/q)}, and the multiplicity of -k in it is exactly gcd(k,q) - 1.
"""
import math
import numpy as np
from hyp import cyclic_interval_hypergraph, fengli, spec


def fejer(k, q):
    th = 2 * np.pi * np.arange(q) / q
    out = np.empty(q)
    for i, t in enumerate(th):
        out[i] = k * k - k if abs(t) < 1e-15 else (np.sin(k * t / 2) / np.sin(t / 2)) ** 2 - k
    return out


print("=== Fejer identity: spec(A_H(C(q,k))) = { |D_k(2 pi m/q)|^2 - k } ===")
for k in (2, 3, 4, 5, 6):
    for q in (2 * k + 1, 17, 23, 60):
        E, n = cyclic_interval_hypergraph(q, k)
        A, _ = fengli(E, n)
        err = np.abs(np.sort(spec(A)) - np.sort(fejer(k, q))).max()
        assert err < 1e-11, (k, q, err)
        print(f"k={k} q={q:3d}  max|spec - Fejer| = {err:.2e}")

print("\n=== multiplicity of -k equals gcd(k,q) - 1 ===")
bad = 0
for k in (3, 4, 5, 6):
    for q in range(2 * k + 1, 2 * k + 40):
        E, n = cyclic_interval_hypergraph(q, k)
        A, _ = fengli(E, n)
        w = spec(A)
        m = int(np.sum(np.abs(w + k) < 1e-9))
        if m != math.gcd(k, q) - 1:
            bad += 1
            print("MISMATCH", k, q, m, math.gcd(k, q) - 1)
print("mismatches:", bad, " (0 means the claim holds on the whole tested grid)")

print("\n=== -k appears for every m = j q / k with k | j q, j = 1..k-1 ===")
for (k, q) in ((4, 10), (6, 9), (4, 8), (3, 9)):
    E, n = cyclic_interval_hypergraph(q, k)
    A, _ = fengli(E, n)
    w = spec(A)
    print(f"k={k} q={q:2d}: gcd={math.gcd(k,q)} mult(-k) = {int(np.sum(np.abs(w+k)<1e-9))}, "
          f"predicted {math.gcd(k,q)-1}")
