# Erratum 1 (batch 060, m1/direction 4): the adjacent-pair bulk-edge value in the target

**Affected file:** `results/060-clustered-attachment-target.md`, section "Adjacent pair".
Not edited: this file records the defect and its reviewed replacement.

## What is stated

> At the bulk edge $b=2\sqrt{d-1}$, $K_{\rm adj}(b)=\frac{2}{1-1/\sqrt{d-1}}$.
> This already distinguishes $d=3,4$ from larger-degree cases [...]

## What is true

With $\lambda=(d-1)r+1/r$, $r(b)=1/\sqrt{d-1}=:r_b$, $G_d=r/(1-r^2)$:

$$K_{\rm adj}(\lambda)=G_d(\lambda)\,(2+2r(\lambda))=\frac{2r}{1-r},$$

(the identity $G_d(2+2r)=2r/(1-r)$ is verified symbolically), so

$$K_{\rm adj}(b)=\frac{2r_b}{1-r_b}=\frac{2}{\sqrt{d-1}-1},$$

**not** $2/(1-r_b)$. The ratio is exactly $\sqrt{d-1}=1/r_b$: at $r=r_b$ the factor
$2r(1+r)/(1-r^2)$ is $2r/(1-r)$, not $2/(1-r)$. Numerically ($d=4$):
correct $2.7320508$, stated $4.7320508$ ($=\sqrt3\cdot$ correct).

## Consequence — this changes a conclusion

$$\Phi_{\rm adj}(b)=b-K_{\rm adj}(b)=\frac{2\big(d-2-\sqrt{d-1}\big)}{\sqrt{d-1}-1}
=\frac{2(s^2-s-1)}{s-1},\qquad s=\sqrt{d-1}.$$

$\Phi_{\rm adj}$ is strictly increasing on $(b,\infty)$ ($K_{\rm adj}$ increasing in $r$,
$\lambda$ decreasing in $r$, so $\Phi_{\rm adj}'>1$), hence a root exists **iff** it is
negative at the edge:

$$s^2-s-1<0\iff s<\frac{1+\sqrt5}{2}\iff d<\frac{5+\sqrt5}{2}=3.618\ldots$$

For integer $d\ge3$ this holds **only for $d=3$** (exactly: $s^2-s-1=(d-2)-\sqrt{d-1}$
and $(d-2)^2-(d-1)=d^2-5d+5>0$ for $d\ge4$). The stated value would instead have made
$d=3,4$ have exterior roots and $d=5$ exactly critical. The correct branch is

$$d=3:\ r_*=\text{root of }2r^3+r-1,\ \lambda_*=\frac{2r_*}{1-r_*}=2.8751297942\ldots
\ (\lambda_*^3-\lambda_*^2-4\lambda_*-4=0),$$
$$d\ge4:\ \text{no exterior root};\ \lambda_2(G_n')\to 2\sqrt{d-1},\ \lambda_1(G_n')\to d .$$

**Also worth recording** (independent of this erratum): the elimination of $r$ gives
$\lambda^3-(d-2)\lambda^2-4\lambda-4=0$, whose positive root (`d=4: 3.4798157`) is
spurious for $d\ge4$ — it lies on the other branch $r=\lambda/(\lambda+2)=0.6350>1/\sqrt3$.

## Provenance

Found independently by m1 (this file; `scripts/verify_symbolic.py` §C–D,
`out/verify_symbolic.txt`) and by m4/d1 (board finding on d1), with identical numbers.
Reviewed replacement: correct the edge value and the $d$-range conclusion as above.
