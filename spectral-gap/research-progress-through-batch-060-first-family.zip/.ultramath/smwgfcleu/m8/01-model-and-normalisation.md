# 1. Model, conventions, normalisation, and the index dictionary

## 1.1 The object

`H = (V, E)` is a finite hypergraph with `|V| = n` and `|E| = m`. It is `k`-uniform
(`|e| = k` for every `e in E`, `k >= 2`) and `d`-regular (every vertex lies in exactly `d` edges).
Hyperedges are counted with multiplicity: the edge list is a multiset and two distinct edges may
have the same vertex set. A single edge never contains a vertex twice. The count gives
`n d = m k`, which is the only arithmetic constraint. `H` is *simple* when no vertex set is
repeated. Everything below holds for the multiset model, and the simple model is the special case
in which every multiplicty is one.

`X` is the `n x m` incidence matrix, `X[v, e] = 1` if `v in e` and `0` otherwise. Then
`X 1 = d 1` and `X^T 1 = k 1`.

**Definition 1.1 (Feng-Li operator [LIT]).** Following Feng and Li (1996) as used by Dumitriu and
Zhu, the adjacency operator `A_H` is the `n x n` symmetric matrix

```
(A_H)[u, v] = #{e in E : {u, v} subset e}   for u != v,      (A_H)[u, u] = 0.
```

This is a weighted graph adjacency matrix, not a tensor. `A_H` is the adjacency matrix of the
multigraph `G_H` on `V` in which each edge `e` contributes one copy of every pair inside `e`.
`G_H` has `(k choose 2) m` edges counted with multiplicity, it is `(k-1)d`-regular, and each
hyperedge contributes a `k`-clique. For `k >= 3`, `G_H` therefore contains a triangle through every
vertex, so `G_H` is never bipartite and never locally a tree. This single observation is the source
of every threshold correction in this dossier.

## 1.2 The Gram identity

Write `I` for the `n x n` identity.

**Proposition 1.2 [PROOF, T1 in file 03].** `A_H + d I = X X^T`.

*Consequence.* `A_H + d I` is positive semidefinite, so `spec(A_H) subset [-d, d(k-1)]`,
`d(k-1)` occurs with eigenvector `1`, and `-d` occurs with multiplicity exactly `n - rank(X)`.

The identity is not new. It is Lemma 4.5 of Dumitriu-Zhu [LIT], and equation (2) of Storm [LIT] in
the form `A(B_H)^2 = diag(A_H + d I, A_{H*} + k I)`. What this dossier does with it is extract the
trivial spectrum exactly, which needs the rank of `X` rather than only the shape of `X`.

## 1.3 Ordering

`lambda_1(A_H) >= lambda_2(A_H) >= ... >= lambda_n(A_H)` is the decreasing order of the eigenvalues
of `A_H`. Following Dumitriu-Zhu I also write

```
lambda_tilde(H) = max{ lambda_2(A_H), -lambda_n(A_H) } = max{ lambda_2(A_H), |lambda_n(A_H)| }.
```

Note that `lambda_tilde` removes **one** eigenvalue, the Perron value. It does not remove `-d`.
The two-sided quantity `max{lambda_2, |lambda_n|}` is the right one for a non-bipartite graph and
the wrong one whenever `-d` is a structurally forced value, which is exactly the situation studied
here.

For the incidence graph `B_H = Inc(H)` (bipartite, `n + m` vertices, degrees `d` on one side and
`k` on the other) the adjacency matrix is `[[0, X], [X^T, 0]]`, its eigenvalues are `+sigma_i` and
`-sigma_i` for the singular values `sigma_i` of `X`, plus `|n - m|` zeros, and the Perron pair is
`+sqrt(dk), -sqrt(dk)`.

For the Hashimoto (non-backtracking) operator `Hash` of `B_H`, the states are the `2 n d` directed
edges, `Hash[(u->e), (e->v)] = 1` for `v != u` and `Hash[(e->u), (u->f)] = 1` for `f != e`.

## 1.4 The five normalisations, and the exact dictionary between them

The same spectral information is quoted in at least five different scales in the literature. The
conversion is exact and worth writing once. Put

```
a = d - 1,    b = k - 1,    t = sqrt(a b) = sqrt((d-1)(k-1)).
```

| quantity | operator | top trivial value | Ramanujan window | bulk edge |
| --- | --- | --- | --- | --- |
| Feng-Li, absolute | `A_H` | `d(k-1)` | `[k-2-2t, k-2+2t]` | `k-2+2t` |
| random walk | `P = A_H/(d(k-1))` | `1` | `[(k-2-2t)/(d(k-1)), (k-2+2t)/(d(k-1))]` | `(k-2+2t)/(d(k-1))` |
| squared singular value | `X X^T = A_H + d I` | `dk` | `[(sqrt(a)-sqrt(b))^2, (sqrt(a)+sqrt(b))^2]` | `(sqrt(a)+sqrt(b))^2` |
| singular value | `X` | `sqrt(dk)` | `[|sqrt(a)-sqrt(b)|, sqrt(a)+sqrt(b)]` | `sqrt(a)+sqrt(b)` |
| incidence adjacency | `A_{B_H}` | `±sqrt(dk)` | `±[|sqrt(a)-sqrt(b)|, sqrt(a)+sqrt(b)]` | as stated |
| Hashimoto | `Hash` | `±sqrt(ab) = ±t` | `|mu| <= (ab)^(1/4)` | `(ab)^(1/4)` |

**Proposition 1.3 [CALC].** The Feng-Li window is exactly the preimage of the Godsil-Mohar
singular-value support interval under `lambda |-> sqrt(d + lambda)`. That is,
`lambda = k-2 ± 2t` if and only if `d + lambda = (sqrt(a) ± sqrt(b))^2`.

*Proof.* `(sqrt(a) ± sqrt(b))^2 = a + b ± 2 sqrt(ab) = d + k - 2 ± 2t`, and `d + (k-2 ± 2t)` is the
same number. Verified symbolically in `scripts/exp1_exact_structure.py`, section B, which asserts
the two identities `d(k-1) - (k-2+2t) = (t-1)^2` and `(k-2-2t) + d = (sqrt(a)-sqrt(b))^2`.

So "Ramanujan" in the Feng-Li sense means exactly "the whole nontrivial singular spectrum lies in
the support of the limiting spectral measure computed by Godsil and Mohar". That is the
normalisation-free content, and it is the reason the centre of the window is `k-2` rather than `0`,
`d`, or `d(k-1)`. The `-2` is the `-d` of the Gram identity after the change of variable.

## 1.5 The index dictionary, which is the answer to "`d - lambda_3`" and "`d - lambda_4`"

For a connected `(d,k)`-regular hypergraph with `k >= 2`, `d >= 2`:

| operator | structurally forced eigenvalues ("trivial spectrum") | multiplicity | index of the first genuinely nontrivial eigenvalue | correct comparison constant |
| --- | --- | --- | --- | --- |
| `A_H` | `d(k-1)` at the top, `-d` at the bottom | `1` at the top, `n - rank(X)` at the bottom, with `n - rank(X) >= k-1` if `k`-partite and `>= n - m` if `d < k` | `2` | `d(k-1)` |
| `A_{B_H}` | `+sqrt(dk)` and `-sqrt(dk)`, plus `|n-m|` zeros | `1`, `1`, `|n-m|` | `3` in the absolute-value order, since two values are separated | `sqrt(dk)` |
| `Hash` | `+t` and `-t`, plus eigenvalues of modulus `1` | `1` and `1` for `±t`, and at least `n(ab-1)/k` for each of `+1` and `-1` when `ab > 1` | position 3, counting the Perron pair as positions 1 and 2 | `t = sqrt(ab)` |

Reading of the table:

* There is exactly **one** trivial value at the top of `spec(A_H)`. So `lambda_2` is already the
  first nontrivial eigenvalue, and the only meaningful top gap is `d(k-1) - lambda_2`. A quantity
  written `d - lambda_2` is not a gap at all: `d - lambda_2` can be negative, and it is
  `1/(k-1)` of the normalised gap.
* There are **two** trivial values only for the bipartite-type operators `A_{B_H}` and `Hash`. That
  is where an index `3` legitimately appears, counting the Perron pair as positions 1 and 2. In those
  two rows the correct comparison constant is `sqrt(dk)`, respectively `t`, and never `d`.
* For `Hash` the values `±1` deserve a warning: they are present (multiplicity at least `n(ab-1)/k`
  each by the standard `(lam^2-1)^(|E|-|V|)` factor, and in fact more, because the Laplacian of the
  incidence graph is singular, so `det(D - Hash + 1)` always vanishes at `lam = ±1`). Their modulus is
  `1`, which is below the bulk edge `(ab)^(1/4)` whenever `ab > 1`, so they are not separated from
  the bulk and they do not shift the index. The measured counts are 18, 32, 42, 22, 38, 44 against
  predicted lower bounds 8, 30, 40, 20, 18, 42 in the six instances of `exp4`.
* Indices `3` and `4` counted from the **bottom** of `spec(A_H)` do have a structural meaning: the
  bottom `n - rank(X)` eigenvalues all equal `-d`. So whenever `rank(X) <= n - 3` one has
  `lambda_{n-2} = lambda_{n-1} = lambda_n = -d`, and the quantities `d - lambda_{n-2}`,
  `d - lambda_{n-1}`, `d - lambda_n` are all identically `2d`. For a `2`-regular `k`-uniform
  hypergraph this happens with `n - m = n(1 - 2/k)`, which is at least a third of the spectrum for
  every `k >= 3` [NUM, `outputs/exp1_exact_structure.txt` rows "random (2,3)-regular" and
  "random (2,5)-regular"].

Hence the precise answer to the question "what are the gaps `d - lambda_3`, `d - lambda_4` and so
forth": for the Feng-Li operator they are the wrong index at the top and the wrong constant at the
bottom. The correct pair of objects is `d(k-1) - lambda_2` at the top and the exact plateau at the
bottom, whose size is `n - rank(X)`.

## 1.6 Why this matters

Three independent reasons.

1. **Expansion.** `A_H` governs the hyperedge and vertex expansion of `H` (Dumitriu-Zhu Theorems 3.1
   and 3.3), and the simple random walk on a `(d,k)`-regular hypergraph has transition matrix
   `P = A_H/(d(k-1))`. So `d(k-1) - lambda_2` is a real expansion parameter and `d - lambda_2` is a
   rescaled one.
2. **The definition of Ramanujan.** The Li-Sole definition (see `02-literature.md`) is stated in
   terms of the window `|lambda - (k-2)| <= 2t` and "non-obvious" eigenvalues. Which eigenvalues
   count as obvious is therefore part of the definition and not a technicality. Section 3 shows
   that the literature's criterion (rectangularity, `d < r`) is not the whole answer.
3. **Covers.** The whole relative-expander programme (Bilu-Linial, Marcus-Spielman-Srivastava,
   Hall-Puder-Sawin, Friedman-Kohler) is built on the statement "old spectrum equals the base
   spectrum". The Feng-Li operator of a hypergraph cover has an inherited part equal to the base
   spectrum [LIT, Song-Fan-Miao Theorem 1.3], and the `-d` plateau behaves differently from the
   Perron value under lifting. That is the content of T12.

## 1.7 The limiting regime, and the two regimes `d >= k` and `d < k`

The asymptotic statements are: `d` and `k` fixed, `n -> infinity`, `n d` divisible by `k`.

Because `m = nd/k`, the two cases `d > k`, `d = k`, `d < k` correspond to `m < n`, `m = n`,
`m > n`. The incidence matrix `X` is then "tall", "square", or "wide". This is the single structural
parameter that controls the trivial spectrum:

* `d <= k`: `rank(X) <= m <= n`, and the rectangular source of `-d` gives `n - rank >= n - m >= 0`.
* `d >= k`: `rank(X) <= n <= m`, the rectangular source gives nothing, and `-d` can only come from
  a rank deficiency of a different kind, namely from vectors `x` with `X^T x = 0`. A strong
  `k`-colouring supplies `k - 1` of those.

Most of the existing literature restricts to `d >= r` (Storm explicitly, Dumitriu-Zhu by
`d >= k >= 3`) and this removes the rectangular source. It does not remove the colouring source.
