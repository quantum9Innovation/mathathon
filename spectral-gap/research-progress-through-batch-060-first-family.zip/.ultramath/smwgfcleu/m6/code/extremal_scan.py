"""Numerical study of lambda_2 for Cayley graphs on F_2^rho.

All eigenvalues are exact integers of the form d - 2w (see exact_dictionary.py).
Contents
  1. exhaustive minimisation of lambda_2 over connected S for rho <= 4;
  2. random search for the best (largest d_min) code for rho = 5..12;
  3. the cubic "moment curve" family S = {(x,x^3) : x in F_q^*} in F_2^{2k};
  4. checks of the benchmark 2 sqrt(d-1) and of the MRRW-derived lower bound
     lambda_2 >= sqrt( 2 rho d / (2 log2 d + 2.45) ).
"""
import itertools
import json
import math


def popcount(v):
    return bin(v).count('1')


def code_of(rho, S):
    """Weight enumerator of the column code C <= F_2^{|S|}, plus rank(S)."""
    d = len(S)
    rows = []
    for i in range(rho):
        m = 0
        for j, s in enumerate(S):
            if (s >> i) & 1:
                m |= 1 << j
        rows.append(m)
    basis = []
    for v in rows:
        for b in basis:
            v = min(v, v ^ b)
        if v:
            basis.append(v)
            basis.sort(reverse=True)
    code = {0}
    for b in basis:
        code |= {c ^ b for c in code}
    we = {}
    for c in code:
        w = popcount(c)
        we[w] = we.get(w, 0) + 1
    return we, len(basis)


def lam2_from_we(d, we, rho, rank):
    """lambda_2 = d - 2 * (smallest nonzero weight), plus its multiplicity."""
    nz = sorted(w for w in we if w > 0)
    if not nz:
        return None, None, None
    w1 = nz[0]
    return d - 2 * w1, we[w1] * (1 << (rho - rank)), nz


def exhaustive_min(rho):
    N = 1 << rho
    elems = list(range(1, N))
    out = {}
    for d in range(1, N):
        best = None
        for S in itertools.combinations(elems, d):
            we, rank = code_of(rho, list(S))
            if rank < rho:
                continue
            lam, mult, nz = lam2_from_we(d, we, rho, rank)
            if best is None or lam < best[0]:
                best = (lam, list(S), mult, nz)
        if best is not None:
            out[d] = best
    return out


def random_search(rho, d, trials, rng):
    N = 1 << rho
    best = None
    for _ in range(trials):
        S = rng.sample(range(1, N), d)
        we, rank = code_of(rho, S)
        if rank < rho:
            continue
        lam, mult, nz = lam2_from_we(d, we, rho, rank)
        if best is None or lam < best[0]:
            best = (lam, S, mult, nz)
    return best


def cubic_family(k):
    """S = {(x,x^3) : x in F_{2^k}^*} inside F_{2^k}^2 = F_2^{2k}, as 2k-bit ints."""
    q = 1 << k
    # multiplication in F_2[x]/(p) for a primitive-like irreducible p of degree k
    polys = {2: 0b111, 3: 0b1011, 4: 0b10011, 5: 0b100101, 6: 0b1000011,
             7: 0b10001001, 8: 0b100011101}
    mod = polys[k]

    def mul(a, b):
        r = 0
        while b:
            if b & 1:
                r ^= a
            b >>= 1
            a <<= 1
            if a >> k:
                a ^= mod
        return r

    S = []
    for x in range(1, q):
        S.append(x | (mul(mul(x, x), x) << k))
    return S


def main():
    rng = __import__('random').Random(7)
    out = {}
    out['exhaustive'] = {}
    for rho in (2, 3, 4):
        res = exhaustive_min(rho)
        out['exhaustive'][rho] = {str(d): {'lambda_2': v[0], 'S': v[1],
                                          'mult': v[2], 'weights': v[3]}
                                  for d, v in res.items()}
    out['random_search'] = []
    for rho in (5, 6, 8, 10, 12):
        for d in sorted({rho, rho + 1, rho + 2, int(1.5 * rho), 2 * rho,
                         min(4 * rho, (1 << rho) - 1)}):
            if d > (1 << rho) - 1:
                continue
            trials = 200 if d <= 40 else 60
            best = random_search(rho, d, trials, rng)
            if best is None:
                continue
            lam, S, mult, nz = best
            out['random_search'].append({
                'rho': rho, 'd': d, 'best_lambda_2': lam, 'mult_lambda_2': mult,
                'distinct_weights': nz[:4],
                'bench_2sqrt_d_minus_1': 2 * math.sqrt(d - 1),
                'mrrw_lower_bound': math.sqrt(2 * rho * d / (2 * math.log2(d) + 2.45))
                if d > 1 else 0.0,
                'S': S if d <= 20 else 'omitted'})
    out['cubic'] = []
    for k in range(2, 8):
        S = cubic_family(k)
        rho = 2 * k
        d = len(S)
        we, rank = code_of(rho, S)
        lam, mult, nz = lam2_from_we(d, we, rho, rank)
        out['cubic'].append({'k': k, 'rho': rho, 'd': d, 'rank': rank,
                             'lambda_2': lam, 'd_minus_lambda_2': d - lam,
                             '2sqrt(d-1)': 2 * math.sqrt(d - 1),
                             'sqrt(2 rho d ln2)': math.sqrt(2 * rho * d * math.log(2)),
                             'weights': nz[:5]})
    out['random_independent_check'] = []
    for rho in (8, 10, 12):
        for d in (2, 3, rho // 2, rho - 1):
            vals = []
            for _ in range(20):
                S = rng.sample(range(1, 1 << rho), d)
                we, rank = code_of(rho, S)
                vals.append(rank)
            out['random_independent_check'].append(
                {'rho': rho, 'd': d, 'ranks': sorted(set(vals))})
    print(json.dumps(out, indent=1))


if __name__ == '__main__':
    main()
