# Spectral gaps of Cayley graphs on elementary abelian 2-groups are code distances

Research dossier, swarm `smwgfcleu`, member m6, direction d5 (menu item E).
Written 2026-11-14. Files needed to check every claim are listed in Section 13.

Claim labels used throughout.
[L] checked literature statement, with the source read directly.
[L*] literature statement taken from a secondary source or from a local dossier, not re-read at the primary source.
[C] exact computation, reproducible from the scripts in this directory.
[P] mathematical proof supplied here, written out in full.
[N] numerical experiment, no asymptotic claim inferred from it.
[K] conjecture or speculation.

---

## 1. Model, normalization, regime, and why the question is worth asking

Let $r \ge 1$, $G = \mathbb F_2^r$ with XOR written additively, and let
$S \subseteq G \setminus \{0\}$ with $|S| = d$. Because every element of $G$ is its own
inverse, $S$ is symmetric automatically, and $0 \notin S$ excludes loops, so
$X = \mathrm{Cay}(G,S)$ is a simple $d$-regular graph on

$$N \,=\, |G| \,=\, 2^r$$

vertices, with $g \sim g + s$ for $s \in S$. Let $A$ be its adjacency matrix and order
the eigenvalues $\lambda_1 = d \ge \lambda_2 \ge \cdots \ge \lambda_N$. Write
$\lambda^{\mathrm{abs}}_2 = \max_{i \ge 2} |\lambda_i|$ for the two sided second
eigenvalue (the bias) and $1 - \lambda_2/d$ for the normalized gap. Characters are
$\chi_a(g) = (-1)^{a \cdot g}$ for $a \in G$, where $a \cdot g$ is the mod 2 dot product.

The benchmark in all four source dossiers is the following. For a sequence of
$d$-regular graphs with $d$ fixed and $N \to \infty$, one has
$\lambda_2^{\mathrm{abs}} \ge 2\sqrt{d-1} - o(1)$ (Alon and Boppana), and
$\lambda_2^{\mathrm{abs}} \le 2\sqrt{d-1} + \varepsilon$ with probability tending to one
for random regular graphs and their random lifts (Friedman, Bordenave, Friedman and
Kohler). The constant $2\sqrt{d-1}$ is the spectral radius of the adjacency operator of
the infinite $d$-regular tree, so the statement is that random finite quotients of the
tree have new spectrum as small as the tree allows, while rare tangles are the only
obstruction. The question taken up here is the same question for the most rigid
algebraic family of $d$-regular graphs in existence, namely Cayley graphs of
elementary abelian 2-groups:

$$\textbf{For which } (d, N) \textbf{ can a } d\textbf{-regular Cayley graph on }
\mathbb F_2^r \textbf{ have } \lambda_2 \le 2\sqrt{d-1}\,?$$

The answer turns out to have nothing to do with tangles. It is a question about binary
linear codes, and Section 3 shows that the spectral gap is exactly twice a code distance.
Section 4 shows that the regime $d$ fixed and $N \to \infty$ is empty for this family, so
the benchmark cannot be an asymptotic sharp threshold here at all. Sections 5 and 6 give
the replacement, which is a tradeoff between $d$ and $\log_2 N$ with a certified window in
which the answer is known and an explicit open window in which it is not.

Why it matters beyond bookkeeping. The four source dossiers share one mechanism, a sharp
infinite local limit threshold combined with control of rare defects. The present family
shows that this mechanism is not a property of sparse regular graphs but of a metric
notion of local convergence. Once the local structure is chosen adversarially and
algebraically, a global algebraic constraint replaces tangle control, and the threshold
moves by a factor that grows without bound. That is the missing connection this dossier
pursues: a spectral question in graph theory whose exact answer is a coding theoretic
quantity, and whose benchmark constant is unattainable except in a bounded window.

---

## 2. Results at a glance

**R1 [P] Degree barrier.** A connected Cayley graph on $\mathbb F_2^r$ with $|S| = d$
satisfies $r \le d$ and hence $N \le 2^d$. Consequently there is no infinite family of
connected $d$-regular Cayley graphs on elementary abelian 2-groups with $d$ fixed.

**R2 [L,C] Exact dictionary.** For $a \in G$ let $\varphi(a) = (a\cdot s)_{s \in S}
\in \mathbb F_2^d$, let $M$ be the $r \times d$ matrix whose columns are the elements of
$S$, and let $C = \mathrm{rowspace}(M)$. Then the spectrum of $A$ is the multiset
$\{d - 2\,\mathrm{wt}(c) : c \in C\}$ with multiplicities as in Theorem 1. Hence
$\lambda_2 = d - 2 d_{\min}(C)$ and $\lambda_{\min} = d - 2 d_{\max}(C)$. The spectrum has
at most $d+1$ distinct values, and the multiplicity of the eigenvalue $d - 2w$ is the
weight enumerator coefficient $A_w(C)$. The identity is classical in coding theory under
the name syndrome graph or coset graph of a code. The specialization to $q = 2$ was
verified here in exact integer arithmetic on 208 configurations.

**R3 [P] Rigidity of the negative end.** $\lambda_2 < 0$ if and only if $\lambda_2 = -1$
if and only if $S = G \setminus \{0\}$, that is, the graph is the complete graph
$K_{2^r}$. Verified exhaustively for $r \le 4$ [C].

**R4 [P] Shortening bound.** If $S \ne G \setminus \{0\}$ then
$\lambda_2 \ge r - 1 - \log_2 d = \log_2(N/d) - 1$. Consequently $\lambda_2 > 2\sqrt{d-1}$
whenever $\log_2 N > 2\sqrt{d-1} + \log_2 d + 1$, so the benchmark fails provably for
$N \gtrsim d \cdot 4^{\sqrt d}$.

**R5 [P] Flatness bound.** $\max(\lambda_2, -\lambda_{\min}) \ge
\sqrt{(Nd - d^2)/(N-1)}$. The bound is an identity for complete graphs. Every Cayley graph
on $\mathbb F_2^r$ therefore has two sided bias at least $\sqrt d\,(1-o(1))$, whereas a
random $d$-regular graph has bias $2\sqrt{d-1}\,(1+o(1))$. The factor two is forced by
integrality and cannot be removed.

**R6 [N] The benchmark is attained at group size $d^2$.** For $k \le 10$ let
$S_k = \{(x,x^3) : x \in \mathbb F_{2^k}^\times\} \subset \mathbb F_{2^k}^2$. Then
$d = 2^k - 1$, $N = d^2(1+o(1))$, and $\lambda_2(S_k) < 2\sqrt{d-1}$ for every computed
$k$, with $\lambda_2/\sqrt{d-1} = 1.970$ at $d = 1023$. So the tree constant $2$ is
attained up to lower order at $N \approx d^2$, exponentially below the range where R4
forbids it.

**R7 [K] Where the crossover sits.** The proved window of ignorance is
$d^2 \lesssim N \lesssim d\,4^{\sqrt d}$. Conjecture: the crossover is at $N = d^{\Theta(1)}$,
and the single missing estimate is the classical gap between the Gilbert Varshamov and the
linear programming bound for binary codes at relative distance near $1/2$. Section 9 states
this precisely.

**R8 [P,C] The higher gaps $d - \lambda_3$ and $d - \lambda_4$ are not independent
invariants here.** Let $0 < w_1 < w_2 < \cdots$ be the distinct nonzero weights of $C$ and
$A_{w}$ the weight enumerator. Then

$$\lambda_2 = \lambda_3 = \cdots = \lambda_{1 + A_{w_1}} = d - 2w_1,
\qquad d - \lambda_{2 + A_{w_1}} = 2w_2,$$

so $d-\lambda_3$ and $d-\lambda_4$ coincide with $d-\lambda_2$ whenever $A_{w_1} \ge 3$.
In the computed examples $A_{w_1}$ is large (for the family of R6 at $d = 1023$ it is
$46376$). The meaningful higher-order sequence is twice the weight hierarchy
$w_1, w_2, w_3, \ldots$ of the code, not the index based sequence $d - \lambda_j$.

---

## 3. The exact dictionary

**Theorem 1 (character formula and code dictionary).** Let $S \subseteq \mathbb F_2^r
\setminus \{0\}$ be finite with $|S| = d$, let $\rho = \dim \mathrm{span}(S)$, let $M$ be
the $r \times d$ matrix over $\mathbb F_2$ whose columns are the elements of $S$ in some
order, and let $C = \{aM : a \in \mathbb F_2^r\} \subseteq \mathbb F_2^d$ be the row space
of $M$. Then for every $a \in \mathbb F_2^r$,

$$\lambda_a \,=\, \sum_{s \in S} (-1)^{a \cdot s} \,=\, d - 2\,\mathrm{wt}(aM),$$

and the multiset of eigenvalues of $A$ equals the multiset that contains
$d - 2\,\mathrm{wt}(c)$ with multiplicity $|\ker \varphi| = 2^{r - \rho}$ for each
$c \in C$. In particular, if $S$ spans $\mathbb F_2^r$ (the graph is connected) then

$$\lambda_2 = d - 2 d_{\min}(C), \qquad \lambda_{\min} = d - 2 d_{\max}(C), \qquad
\#\{i : \lambda_i = d - 2w\} = A_w(C).$$

*Proof.* Let $P_s$ be the permutation matrix of translation by $s$, so
$(P_s)_{g,g+s} = 1$ and $A = \sum_{s \in S} P_s$. All $P_s$ are simultaneously
diagonalized by the characters, since $P_s \chi_a = \chi_a(s) \chi_a$. Hence
$\lambda_a = \sum_{s} \chi_a(s) = d - 2 \#\{s : a \cdot s = 1\}$, and
$\#\{s : a\cdot s = 1\} = \mathrm{wt}(aM)$ because the $j$-th coordinate of $aM$ is
$a \cdot s_j$. The map $\varphi : a \mapsto aM$ is $\mathbb F_2$-linear with image $C$ and
kernel $( \mathrm{span}\,S )^{\perp}$, of size $2^{r-\rho}$. If $\rho = r$ then
$\varphi$ is injective, so each codeword occurs exactly once and the multiplicities are the
weight enumerator coefficients. $\square$

Theorem 1 is classical. In the coding theory literature the graph $\mathrm{Cay}(\mathbb
F_2^r, S)$ with $S$ the set of columns of a parity check matrix is called the syndrome
graph of the code $\ker M$, and it is isomorphic to the coset graph of
$C = \mathrm{rowspace}(M)$ [L*]. The general alphabet version of the eigenvalue formula
appears as "the eigenvalues of the syndrome graph are $n(q-1)q^{r-1} - q w_i$ with
multiplicity $A_i$", which for $q = 2$ is Theorem 1. The classical source is Delsarte's
theory of the coset graph of the dual code, whose two-weight special case is the standard
dictionary between two-weight codes and strongly regular graphs.

Verification [C]. `code/exact_dictionary.py` compares, for 208 configurations with
$r \le 5$ and $d \le 12$ including 66 disconnected ones, the characteristic polynomial of
the explicit $0/1$ adjacency matrix (computed with exact integer arithmetic) with the
polynomial reconstructed from the code weight enumerator. All 208 agree. Output in
`out/exact_dictionary.json`.

Immediate consequences, stated because they are used below.

(i) The spectrum is integral, lies in $\{d, d-2, \ldots, -d\}$, and is determined by the
weight enumerator of a binary linear code of length $d$ and dimension $\rho \le r$.

(ii) $d - \lambda_2 = 2 d_{\min}(C)$ is an even nonnegative integer, and
$\lambda_2 = d - 2$ (the largest possible value of $\lambda_2$ for a connected graph)
holds exactly when $C$ contains a word of weight one, that is, exactly when the columns of
$M$ are linearly independent.

(iii) $\lambda_2 = d$ (disconnected) holds exactly when $\rho < r$, consistent with
$\langle S \rangle \ne G$.

(iv) The number of distinct eigenvalues is at most $d+1$, and since there are $N$
eigenvalues distributed over at most $d+1$ values, the multiplicity of $\lambda_2$ alone
is at least $(N-1)/(d+1)$ in the connected case. For connected graphs in the natural
regime $r \asymp d$ this is exponential in $d$, matching the tight $2^{\Theta(d)}$ bound on
the multiplicity of $\lambda_2$ for connected degree $d$ abelian Cayley graphs obtained by
d'Orsi, Jones, Ruotolo, Vadhan and Zhang [L].

(v) The whole dictionary is exactly the small-bias set dictionary of pseudorandomness. A
set $S \subseteq \mathbb F_2^r$ is $\varepsilon$-biased in the sense of Naor and Naor when
$|\mathbb E_{s \in S}\chi_a(s)| \le \varepsilon$ for every nontrivial character $a$, which
by Theorem 1 says precisely $\max(\lambda_2, -\lambda_{\min}) \le \varepsilon d$. So a
Cayley graph on $\mathbb F_2^r$ is an $\varepsilon$-expander in the two sided sense exactly
when its connection set is an $\varepsilon$-biased set, and the "expanding generating set"
of Alon and Roichman and of the small-bias literature is exactly the spectral object
studied in the four source dossiers [L].

---

## 4. Four structural theorems

### 4.1 The degree barrier empties the benchmark regime [P]

**Theorem 2.** Let $S \subseteq \mathbb F_2^r \setminus \{0\}$ with $|S| = d$ and
$\langle S \rangle = \mathbb F_2^r$. Then $r \le d$ and $N = 2^r \le 2^d$.

*Proof.* Every generating set contains a basis of the $\mathbb F_2$-span, so
$r = \dim \mathrm{span}(S) \le |S| = d$. $\square$

The content is that the whole group is an $\mathbb F_2$-span of the connection set, and a
span of $d$ vectors has at most $2^d$ elements. There is no such constraint for cyclic
groups: $\mathrm{Cay}(\mathbb Z_n, \{\pm 1\})$ is a cycle for every $n$, of degree $2$, so
$\mathbb Z_n$ has infinite connected families of fixed degree while $\mathbb F_2^r$ has
none. In the language of the four dossiers, the local weak limit of a connected Cayley
graph on $\mathbb F_2^r$ is the $d$-regular tree only while $r$ is large compared to
$\log d$, and $r \le d$ caps how tree like a fixed degree family can be. Formally:

**Corollary 2.1.** Every sequence of connected $d$-regular Cayley graphs on elementary
abelian 2-groups with $N \to \infty$ has $d \to \infty$ at rate at least $d \ge \log_2 N$.
Hence the statement "$\lambda_2^{\mathrm{abs}} \le 2\sqrt{d-1} + \varepsilon$ with
probability tending to one" cannot be an asymptotic theorem about this family, since no
such family exists with $d$ fixed. What replaces it is the two variable question studied in
Sections 5 and 6.

This is the first precise sense in which the benchmark $2\sqrt{d-1}$ is the wrong object
here. It is not that the constant is slightly off. The regime in which the constant is
defined is empty, and the only available scaling is $d \ge \log_2 N$, in which the tree
threshold $2\sqrt{d-1}$ grows like $\sqrt d$ while the graph itself has only $N \le 2^d$
vertices.

### 4.2 Rigidity of the negative end [P]

**Theorem 3.** Let $S \subseteq \mathbb F_2^r \setminus \{0\}$ span $\mathbb F_2^r$ and let
$d = |S|$. Then $\lambda_2 < 0$ if and only if $\lambda_2 = -1$, and this holds if and only
if $S = \mathbb F_2^r \setminus \{0\}$.

*Proof.* By Theorem 1, $\lambda_2 = d - 2 d_{\min}(C)$ with $C$ of length $d$, dimension
$r$ and all columns of the generator matrix distinct and nonzero. If $\lambda_2 < 0$ then
$d_{\min}(C) > d/2$. Apply the Plotkin bound to $C$: a binary code of length $d$ whose
minimum distance exceeds $d/2$ has at most $2d_{\min}/(2d_{\min} - d)$ words. Hence

$$2^r \,\le\, \frac{2d_{\min}}{2d_{\min} - d}
\quad \Longrightarrow \quad
2d_{\min}\,(2^r - 1) \,\le\, 2^r d
\quad \Longrightarrow \quad
2d_{\min} \,\le\, d + \frac{d}{2^r - 1} \,\le\, d + 1,$$

using $d \le 2^r - 1$. Since $2d_{\min} \ge d+1$ by $\lambda_2 < 0$, both are equal, so
$d = 2^r - 1$ and $2d_{\min} = d+1$. The average pairwise distance of $C$ equals

$$\frac{1}{2^r(2^r-1)}\sum_{c \ne c'} \mathrm{wt}(c + c')
= \frac{d \cdot 2^{r-1}}{2^r - 1} = 2^{r-1} = d_{\min},$$

where the first equality uses that every coordinate of $C$ is balanced, which holds
because no column of $M$ is zero. So every nonzero codeword has weight exactly
$d_{\min}$, $C$ is a one-weight code of length $2^r - 1$ and dimension $r$, hence the
simplex code, and its generator matrix has all $2^r - 1$ nonzero vectors of
$\mathbb F_2^r$ as columns. Therefore $S = \mathbb F_2^r \setminus \{0\}$ and
$\lambda_2 = (2^r - 1) - 2^r = -1$. $\square$

Verified exhaustively [C] for $r \le 4$: the minimum of $\lambda_2$ over connected
connection sets equals $-1$ exactly at $d = 2^r - 1$ and equals $0$ or a positive integer
otherwise. The table is in Section 5.

Theorem 3 is the exact statement that would have to be wrong for the negative end of the
spectrum of a 2-group Cayley graph to behave like a random regular graph. It cannot: below
$0$ the spectrum is a single possible integer, and it occurs only for the complete graph.

### 4.3 The flatness bound, and why the factor two is unavoidable [P]

**Theorem 4.** For every $S \subseteq \mathbb F_2^r \setminus \{0\}$ with $|S| = d$ and
$N = 2^r$,

$$\max(\lambda_2, -\lambda_{\min}) \,\ge\, \sqrt{\frac{Nd - d^2}{N-1}}.$$

If in addition $S$ spans $\mathbb F_2^r$ then the left side equals
$\max_{a \ne 0} |\lambda_a|$.

*Proof.* Since $A$ is a $0/1$ matrix with all row sums $d$, $\mathrm{tr}(A^2) = Nd$. On
the other hand $\mathrm{tr}(A^2) = \sum_{a} \lambda_a^2$ and $\lambda_1 = d$. So
$\sum_{a \ne 0}\lambda_a^2 = Nd - d^2$, and the maximum of $|\lambda_a|^2$ over the
$N-1$ terms is at least the average. $\square$

Consequences. First, $\max(\lambda_2,-\lambda_{\min}) \ge \sqrt{d}(1 - d/N)^{1/2}(1+o(1))$,
so every Cayley graph on $\mathbb F_2^r$ has a nontrivial eigenvalue of absolute value at
least $\sqrt d$ no matter how the connection set is chosen. The tree benchmark is
$2\sqrt{d-1} \approx 2\sqrt d$, twice as large, so Theorem 4 never certifies the benchmark
and never contradicts it. Second, equality holds for the complete graph: with
$d = N-1$, the right side is $\sqrt{((N(N-1) - (N-1)^2)/(N-1))} = 1$, and
$\lambda_2 = \lambda_{\min} = -1$. The bound is therefore sharp and it explains the
rigidity of Theorem 3.

Comparison with the source dossiers. For random $d$-regular graphs the same trace identity
gives the same lower bound $\sqrt{d}(1-o(1))$, which is weaker than Alon and Boppana by a
factor two, and the Alon and Boppana argument is what upgrades $\sqrt d$ to
$2\sqrt{d-1}$. In the 2-group case the upgrade is impossible in general, because
independent columns give $\lambda_2 = d-2$ which is far above $2\sqrt d$, and the complete
graph gives $-1$ which is far below $-\sqrt d$. So the Alon and Boppana constant is an
upper envelope for some members of the family and not a law for the family.

### 4.4 The shortening bound [P]

This is the one elementary estimate that does certify failure of the benchmark, and it uses
the code dictionary in an essential way.

**Theorem 5.** Let $S \subseteq \mathbb F_2^r \setminus \{0\}$ span $\mathbb F_2^r$, let
$d = |S|$, $N = 2^r$, and suppose $S \ne \mathbb F_2^r \setminus \{0\}$. Then

$$\lambda_2 \,\ge\, r - 1 - \log_2 d \,=\, \log_2\!\left(\frac{N}{d}\right) - 1 .$$

*Proof.* By Theorem 1, $\lambda_2 = d - 2d_{\min}(C)$ with $C$ a binary linear code of
length $d$ and dimension $r$. Put $\Delta = d/2 - d_{\min}(C)$, so $\lambda_2 = 2\Delta$.
By Theorem 3 we may assume $\Delta \ge 0$, and $\Delta$ is a half integer. If
$2\Delta + 1 > r$ then $\lambda_2 > r - 1 \ge r - 1 - \log_2 d$ and there is nothing to
prove. Otherwise let $t = 2\Delta + 1$, an integer with $1 \le t \le r$, and shorten $C$ in
$t$ coordinates, that is, keep the codewords that vanish on a fixed set $T$ of $t$
coordinates. The shortened code $C_T$ has dimension at least $r - t$ by rank nullity for
the projection $C \to \mathbb F_2^T$, has length $d - t$, and every nonzero word of $C_T$
is a nonzero word of $C$, so

$$\mathrm{wt}(c) \,\ge\, d_{\min}(C) \,=\, \frac{d - 2\Delta}{2} \,=\, \frac{d - t + 1}{2}
\,>\, \frac{d-t}{2}.$$

The Plotkin bound for a binary code of length $n$ with minimum distance $\delta > n/2$
gives size at most $2\delta/(2\delta - n)$. With $n = d-t$ and $\delta = (d-t+1)/2$ the
bound is $(d-t+1)/1 = d-t+1$, so

$$2^{r-t} \,\le\, |C_T| \,\le\, d - t + 1 \,\le\, d .$$

Taking logarithms, $r - t \le \log_2 d$, that is $\lambda_2 = t - 1 \ge r - 1 - \log_2 d$.
$\square$

**Corollary 5.1 (explicit benchmark failure).** If $S$ spans $\mathbb F_2^r$, is not the
full nonzero set, and

$$\log_2 N \,>\, 2\sqrt{d-1} + \log_2 d + 1,$$

then $\lambda_2 > 2\sqrt{d-1}$. In terms of the size of the group, $\lambda_2 > 2\sqrt{d-1}$
whenever $N > d \cdot 2^{\,2\sqrt{d-1}+1}$, that is $N \gtrsim d \cdot 4^{\sqrt d}$.

*Remark on tightness.* Theorem 5 is an equality for some small cases. For
$r = 4$, $d = 8$ the extended Hamming code gives $d_{\min} = 4$, $\lambda_2 = 0$, and
$r - 1 - \log_2 d = 4 - 1 - 3 = 0$. For $r = 2$, $d = 2$ one gets $\lambda_2 = 0$ and
$r - 1 - \log_2 d = 0$. For the complete graph with $d = 2^r - 1$ the exceptional case
excluded in the statement gives $\lambda_2 = -1 < r - 1 - \log_2 d \approx -1$, so the
exclusion is sharp and not cosmetic.

The mechanism of the proof is worth isolating, because it is the only place where the
global algebra enters. Shortening a code whose words are all slightly heavier than half the
length produces a code whose words are heavier than half of its own (shorter) length, and
such codes are tiny by Plotkin. In spectral language, a Cayley graph on $\mathbb F_2^r$
whose second eigenvalue is small must have a code whose symmetry is broken by shortening,
and shortening corresponds to passing to an induced subgraph of the dual picture.

---

## 5. The finite picture: exhaustive data for $r \le 4$

For $r \le 4$ the minimum of $\lambda_2$ over connected connection sets was computed
exhaustively by enumerating all $\binom{2^r-1}{d}$ sets, keeping the connected ones, and
minimising $d - 2d_{\min}(C)$ [C]. Source `code/final_numerics.py`, output
`out/final_numerics.json`. There are 31328 connected configurations in the sweep.

| $r$ | $d$ | $\min \lambda_2$ | multiplicity of $\lambda_2$ | distinct nonzero code weights |
|---|---|---|---|---|
| 2 | 2 | 0 | 2 | 1, 2 |
| 2 | 3 | $-1$ | 3 | 2 |
| 3 | 3 | 1 | 3 | 1, 2, 3 |
| 3 | 4 | 0 | 6 | 2, 4 |
| 3 | 5 | 1 | 2 | 2, 3, 4 |
| 3 | 6 | 0 | 4 | 3, 4 |
| 3 | 7 | $-1$ | 7 | 4 |
| 4 | 4 | 2 | 4 | 1, 2, 3, 4 |
| 4 | 5 | 1 | 10 | 2, 4 |
| 4 | 6 | 2 | 6 | 2, 4 |
| 4 | 7 | 1 | 7 | 3, 4, 7 |
| 4 | 8 | 0 | 14 | 4, 8 |
| 4 | 9 | 1 | 6 | 4, 5, 8 |
| 4 | 10 | 2 | 5 | 4, 6 |
| 4 | 11 | 1 | 6 | 5, 6, 7, 8 |
| 4 | 12 | 0 | 12 | 6, 8 |
| 4 | 13 | 1 | 4 | 6, 7, 8 |
| 4 | 14 | 0 | 8 | 7, 8 |
| 4 | 15 | $-1$ | 15 | 8 |

Three features deserve comment.

The negative value $-1$ occurs only at $d = 2^r - 1$, in agreement with Theorem 3. The
achievable minima are otherwise $0$, $1$ or $2$, never large negative, so in small groups
the second eigenvalue cannot be pushed below the trivial barrier at all.

The values $0$ are attained by famous codes: at $(r,d) = (4,8)$ the extended Hamming code
$[8,4,4]$ gives $d_{\min} = 4 = d/2$, at $(4,12)$ a Hadamard type $[12,4,6]$ code gives
$d_{\min} = 6$, at $(4,15)$ the simplex code gives $d_{\min} = 8$. All three have
$\lambda_2 \le 0$, that is, a spectrum beginning $d, 0, 0, \ldots$ or $d, -1, \ldots$. These
are the exact analogues of strongly regular graphs with three eigenvalues, and they are
exactly the two-weight codes of Delsarte's dictionary.

The multiplicities of $\lambda_2$ in the table are already comparable to $N$, for instance
$14$ out of $16$ at $(4,8)$. That is the finite shadow of point (iv) of Section 3.

---

## 6. The benchmark is attained at group size $d^2$

Theorem 5 forbids the benchmark only for $N \gtrsim d\,4^{\sqrt d}$. It does not forbid it
at $N \approx d^2$. The next computation shows that the benchmark is in fact attained
there, so the obstruction is genuinely about how fast $N$ grows, not about being abelian.

Take $k \ge 3$, $q = 2^k$, and

$$S_k \,=\, \{(x, x^3) : x \in \mathbb F_q^\times\} \,\subset\, \mathbb F_q^2 = \mathbb F_2^{2k},
\qquad d = q - 1, \quad N = q^2 = (d+1)^2 .$$

This is the cubic moment curve. Over $\mathbb F_2$ the map $x \mapsto x^2$ is linear, which
is why the quadratic moment curve degenerates into a subspace, but $x \mapsto x^3$ is not
linear, and $S_k$ spans $\mathbb F_q^2$ (verified: rank $2k$ in every computed case). For
$(a_1,a_2) \ne 0$ the character sum is
$\sum_{x \in \mathbb F_q^\times} (-1)^{\mathrm{Tr}(a_1x + a_2x^3)}$, and the Weil bound for
additive characters of a cubic polynomial gives absolute value at most $1 + 2\sqrt q$, so
a priori $\lambda_2^{\mathrm{abs}} \le 2\sqrt q + 1 = 2\sqrt{d+1} + 1$. The exact values
[C] are much smaller.

| $k$ | $r = 2k$ | $d$ | $\lambda_2$ | $\lambda_{\min}$ | $d_{\min}$ | $2\sqrt{d-1}$ | $\lambda_2/\sqrt{d-1}$ | mult of $\lambda_2$ |
|---|---|---|---|---|---|---|---|---|
| 3 | 6 | 7 | 3 | $-5$ | 2 | 4.899 | 1.134 | 21 |
| 4 | 8 | 15 | 7 | $-9$ | 4 | 7.483 | 1.871 | 15 |
| 5 | 10 | 31 | 7 | $-9$ | 12 | 10.954 | 1.304 | 310 |
| 6 | 12 | 63 | 15 | $-17$ | 24 | 15.748 | 1.949 | 210 |
| 7 | 14 | 127 | 15 | $-17$ | 56 | 22.450 | 1.355 | 4572 |
| 8 | 16 | 255 | 31 | $-33$ | 112 | 31.875 | 1.964 | 3060 |
| 9 | 18 | 511 | 31 | $-33$ | 240 | 45.166 | 1.383 | 69496 |
| 10 | 20 | 1023 | 63 | $-65$ | 480 | 63.937 | 1.970 | 46376 |

Two readings. First, along even $k$ the ratio $\lambda_2/\sqrt{d-1}$ approaches $2$ from
below, so this family attains the Alon and Boppana constant at $N = d^2(1+o(1))$, which is
exponential in $d$ and dwarfs the complete graph case $N = d+1$. Second, along odd $k$ the
ratio is $\sqrt 2$ instead of $2$, which is an artefact of the small parameter, the values
$\lambda_2 = 7, 15, 31, 63$ being exactly $2^{j}-1$ along a subsequence. The pattern
suggests $\lambda_2 \approx 2\sqrt{d}$ for all large $k$ with period two effects in the
exponent, and the even rows support the constant $2$.

A second reading of the same table matters for Section 9. The flatness bound of Theorem 4
predicts $\lambda_2^{\mathrm{abs}} \ge \sqrt d(1-o(1))$. At $d = 1023$ that floor is
$31.97$ and the actual two sided value is $65$, so the moment curve is a factor $2$ above
the flatness floor, exactly as the Alon and Boppana constant is a factor $2$ above it for
random regular graphs. So at group size $d^2$ the 2-group Cayley graphs behave, in this
one respect, exactly like random regular graphs. The resemblance stops at larger $N$.

For contrast, here are single random connection sets at larger $r$ [N].

| $r$ | $d$ | $\lambda_2$ | $\lambda_{\min}$ | $\lambda_2 / 2\sqrt{d-1}$ | flatness floor |
|---|---|---|---|---|---|
| 12 | 20 | 14 | $-14$ | 1.61 | 4.46 |
| 16 | 30 | 24 | $-22$ | 2.23 | 5.48 |
| 16 | 150 | 50 | $-54$ | 2.05 | 12.23 |
| 20 | 100 | 48 | $-50$ | 2.41 | 10.00 |
| 20 | 400 | 94 | $-92$ | 2.35 | 20.00 |
| 24 | 300 | 90 | $-92$ | 2.60 | 17.32 |

Every entry violates the benchmark by a factor between $1.6$ and $2.6$, and none of them is
a designed counterexample. Random connection sets in the regime $d \gtrsim r$ are bad
expanders essentially always, in sharp contrast with random regular graphs, whose
$\lambda_2^{\mathrm{abs}}$ is at most $2\sqrt{d-1} + \varepsilon$ with probability tending
to one. The reason is Theorem 1: a random connection set gives a random code, whose
relative distance is the Gilbert Varshamov distance $H_2^{-1}(1 - r/d)$, and
$\lambda_2 \approx d(1 - 2H_2^{-1}(1-r/d))$, which is $\Theta(d)$ whenever $r/d$ is
bounded away from zero.

---

## 7. The open window and the right scale

Collecting the two sides. Let $S \subseteq \mathbb F_2^r \setminus \{0\}$ span
$\mathbb F_2^r$, $d = |S|$, $N = 2^r$. Then $\log_2(d+1) \le r \le d$ by Theorems 1 and 2,
and

$$\lambda_2 \,\ge\, \log_2(N/d) - 1 \quad (\text{Theorem 5, except } S = G \setminus \{0\}),$$

while for $N \approx d^2$ the moment curve achieves $\lambda_2 = (2-o(1))\sqrt d$, which is
below $2\sqrt{d-1}$ in every computed case, so the benchmark is attainable there. The proved window of ignorance is

$$d^2 \,\lesssim\, N \,\lesssim\, d\cdot 4^{\sqrt d}.$$

Two natural guesses for the true crossover are worth separating, because they are
different theorems.

Guess A (coding theoretic). The tradeoff is governed by the best relative distance $\delta$
of a binary code of length $d$ and rate $R = r/d$, through
$\lambda_2 = d(1 - 2\delta)$. The benchmark $\lambda_2 \le 2\sqrt{d-1}$ asks for
$\delta \ge 1/2 - 1/\sqrt d + o(1/\sqrt d)$, so the answer depends on which bound on
$\delta$ is the truth. Under the Gilbert Varshamov bound $\delta = H_2^{-1}(1-R)$ one has
$H_2(1/2 - \eta) = 1 - (2/\ln 2)\eta^2 + O(\eta^4)$, so with $\eta = 1/\sqrt d$ the
benchmark is attainable exactly for $R \le (2/\ln 2)/d + o(1/d)$, that is
$r \le 2.885 + o(1)$, and $N \le d^{2.885+o(1)}$ [K, heuristic, puts the crossover at a
constant slightly below $3$]. Under the linear programming bound the same computation gives
the opposite extreme, since the linear programming bound controls $\delta$ from above and
hence $\lambda_2$ from below with $\lambda_2 \gtrsim c\sqrt{rd/\log_2(2d/r)}$. That bound
becomes larger than $2\sqrt d$ precisely when $r \gtrsim (4/c^2)\log_2 d$, so the crossover
is at $N \approx d^{4/c^2}$ [K]. Both guesses are polynomial in $d$ and they differ only in
the constant. The moment curve of Section 6 attains the constant $2$ at
$r = 2\log_2(d+1)$ and its values satisfy $\lambda_2 \approx \sqrt 2\,\sqrt{rd/\log_2(2d/r)}$,
that is $c \approx \sqrt 2$ and $4/c^2 = 2$ [C,N]. So the computed family sits exactly at
the linear programming crossover, which is evidence that the linear programming side is the
relevant one near the transition and that the constant is small.

Guess B (against the small constant). The moment curve at $m$ coordinates,
$S = \{(x, x^3, x^5, \ldots, x^{2m-1})\} \subset \mathbb F_q^m$ with $N = d^m$, has
character sums bounded by $(2m-2)\sqrt q$ by the Weil bound, so its $\lambda_2$ is at most
$(2m-2)\sqrt d$. That reaches the benchmark constant $2$ only at $m = 2$, and Section 11.3
shows that no coordinate-wise Weil argument can do better, because all nonzero linear
combinations of the $m$ coordinate functions would have degree at most $2$, which forces
$m \le 3$ and in fact $m \le 2$ for the constant. If every construction at $N = d^m$ with
$m \ge 3$ pays a constant that grows with $m$, then the crossover constant $c_2$ in
Conjecture 7.1 is larger than $2$ and the truth sits at the upper end of the linear
programming window, that is $c_2$ close to $4/c^2$ for the best available $c$.

The dossier takes Guess A as the working conjecture, because it is the only one with a
mechanism that predicts a numerical constant, and because the linear programming side of
Guess A is what Theorem 5 approximates poorly and what a sharper estimate would fix.

**Conjecture 7.1 [K].** There are absolute constants $2 \le c_1 < c_2$ such that for all
large $d$ and all $r$,

$$r \,\le\, c_1 \log_2 d \,\Longrightarrow\, \exists S,\ |S| = d,\ \langle S\rangle =
\mathbb F_2^r,\ \lambda_2(S) \le 2\sqrt{d-1},$$

$$r \,\ge\, c_2 \log_2 d \,\Longrightarrow\, \forall S,\ |S| = d,\ \langle S\rangle =
\mathbb F_2^r,\ \lambda_2(S) > 2\sqrt{d-1}.$$

The lower end $c_1 \ge 2$ is certified by the moment curve computation of Section 6 up to
$d = 1023$ [N] and by the Weil bound in general [P]. The upper end is open. The proved
statement is only the much weaker $r \le 2\sqrt d + \log_2 d + 1$ of Corollary 5.1.

If Conjecture 7.1 holds then the four source dossiers have the following exact
counterpart. For random regular graphs and their random lifts the threshold $2\sqrt{d-1}$
holds in the whole regime $d$ fixed, $N \to \infty$, with failure probability controlled by
tangle orders. For Cayley graphs of $\mathbb F_2^r$ the threshold holds exactly in the
regime $N = d^{\Theta(1)}$ and fails, by a factor tending to infinity, once
$N = d^{\omega(1)}$. The correct global parameter is not the tangle order but the ratio
$\log_2 N / d$, which is the rate of a binary code.

---

## 8. The user's question about $d - \lambda_3$ and $d - \lambda_4$, answered for this family

The prompt asks about hypergraphs with gaps $d - \lambda_3$ and $d - \lambda_4$, and more
generally about which higher gaps are the right invariants. For 2-group Cayley graphs the
answer is exact and it is not the index based one.

By Theorem 1 the spectrum is $\{d - 2w : w \text{ a nonzero weight of } C\}$ with the
weight enumerator as multiplicity function. Let the distinct nonzero weights be
$0 < w_1 < w_2 < \cdots < w_m \le d$. Then, in decreasing order,

$$\underbrace{d}_{w=0},\ \underbrace{d - 2w_1, \ldots, d-2w_1}_{A_{w_1} \text{ copies}},\
\underbrace{d - 2w_2, \ldots}_{A_{w_2} \text{ copies}},\ \ldots$$

so

$$d - \lambda_2 = d - \lambda_3 = \cdots = d - \lambda_{1 + A_{w_1}} = 2w_1,
\qquad d - \lambda_{2 + A_{w_1}} = 2w_2 .$$

Consequences.

(a) $d - \lambda_3$ and $d - \lambda_4$ are equal to $d - \lambda_2$ unless the code has
fewer than three minimum weight words. In every computed example $A_{w_1}$ is large, so
the first genuinely new gap appears at an index that grows with $N$. At $(r,d) = (4,8)$ the
multiplicity is $14$ out of $16$, so $\lambda_2 = \lambda_3 = \cdots = \lambda_{15}$ and the
only other nontrivial eigenvalue is $\lambda_{16} = -8$.

(b) The correct higher order gap sequence is $2w_1, 2w_2, 2w_3, \ldots$, twice the weight
hierarchy of the code. This is the exact analogue of the "generalized Hamming weights" of
Wei, which for a code $C$ are the smallest supports of $j$-dimensional subcodes, and which
determine the weight hierarchy by Wei duality applied to the dual code.

(c) Therefore any research programme phrased as "prove a gap $d - \lambda_3$ for
hypergraphs or Cayley graphs" must first say which of two things it means, an index based
gap or a distinct-value gap. For 2-group Cayley graphs the index based gap $d-\lambda_3$
carries no information beyond $d - \lambda_2$, while the distinct-value gap is a code
invariant. The same dichotomy is the substance of direction d1 of this swarm, which reaches
it for $k$-uniform hypergraphs through the Perron eigenvalue of the clique expansion. The
present dossier reaches it through integrality of the character spectrum, which is a
stronger and simpler mechanism but applies to a much narrower family.

(d) The multiplicity statement is exactly the phenomenon behind the tight $2^{\Theta(d)}$
bound on the multiplicity of $\lambda_2$ for connected degree $d$ abelian Cayley graphs
[L]. In that literature the multiplicity bound is proved as a statement about abelian group
algebras. Here it is a one line consequence of the dictionary, and the computed
multiplicities ($46376$ at $d = 1023$ for the moment curve) show the bound is the truth in
the exponential regime.

---

## 9. Literature, what was verified, and what could not be verified

All statements below were checked against the object named. Where a statement was taken
from a local dossier rather than from the primary source, it is marked [L*] and the
statement is quoted as the dossier gives it.

**L1 [L*] Friedman, A proof of Alon's second eigenvalue conjecture, arXiv cs/0405020v1.**
For fixed even $d \ge 4$ and $\varepsilon > 0$, the model $\mathcal G_{n,d}$ of $d/2$
independent uniform permutations satisfies
$\Pr[\max_{2 \le i \le n}|\lambda_i| \le 2\sqrt{d-1} + \varepsilon] \ge
1 - c n^{-\tau_{\mathrm{fund}}}$ with $\tau_{\mathrm{fund}} =
\lceil(\sqrt{d-1}+1)/2\rceil - 1$, and there is a matching polynomial lower bound for
$\lambda_2 > 2\sqrt{d-1}$. Taken from the local dossier `.paper-mastery/alon-second-eigenvalue`
(Sections R1, R5, R6). This dossier did not re-read the primary PDF.
URL https://arxiv.org/abs/cs/0405020, version v1 (2004), SHA256 of the supplied PDF
recorded in the local SOURCE.md.

**L2 [L*] Bordenave, A new proof of Friedman's second eigenvalue theorem and its extension
to random lifts, arXiv 1502.04482v4.** Theorem 1 (Friedman) and Theorem 23 (new
non-backtracking spectrum of a random lift of a connected base with $|E| > |V|$ bounded by
$\sqrt{\rho_1} + o(1)$) and Corollary 24 ($2\sqrt{d-1}+o(1)$ for regular bases). Taken from
`.paper-mastery/friedman-second-eigenvalue-lifts` (05-main-results).
URL https://arxiv.org/abs/1502.04482v4.

**L3 [L*] Friedman and Kohler, The relativized second eigenvalue conjecture of Alon, arXiv
1403.3462v1.** Theorem 0.1.1: for $d$-regular $B$ and $\varepsilon > 0$,
$\Pr[\rho_B^{\mathrm{new}}(A_G) \ge 2\sqrt{d-1}+\varepsilon] \le C_{B,\varepsilon} n^{-1}$.
Theorem 0.1.3: for Ramanujan $B$ the exceptional probability is
$\Theta(n^{-\eta_{\mathrm{fund}}(B)})$ for small $\varepsilon$. Taken from
`.paper-mastery/relativized-second-eigenvalue` (05-main-results). The local dossier
documents that the printed Proposition 3.3.1 and Theorem 3.3.2 use $\rho(H_G)$ where the
new radius is required, and that the printed inequality $\eta_{\mathrm{fund}}(B) >
\sqrt{d-1}$ of Theorem 3.3.4 conflicts with the paper's own bouquet example. Those printed
claims are not used here.
URL https://arxiv.org/abs/1403.3462v1.

**L4 [L*] Brito, Dumitriu, Decker Harris, Spectral gap in random bipartite biregular graphs
and applications, arXiv 1804.07808v6, CPC 31 (2022) 229-267.** Theorem 4:
$\lambda_2(A) \le \sqrt{d_1-1}+\sqrt{d_2-1}+o(1)$, lower positive edge
$\ge \sqrt{d_1-1}-\sqrt{d_2-1}-o(1)$, and full row rank of the biadjacency. Theorem 3 gives
$|\lambda_2(B)| \le ((d_1-1)(d_2-1))^{1/4}+\varepsilon_n$ for the non-backtracking matrix.
Taken from `.paper-mastery/biregular-spectral-gap`. The local dossier records that printed
Lemma 2 swaps the imaginary eigenvalue multiplicities and that printed Corollary 12 does not
follow from Lemma 11. Those printed statements are not used here.
URL https://arxiv.org/abs/1804.07808v6.

**L5 [L] Alon and Roichman, Random Cayley graphs and expanders, Random Structures and
Algorithms 5 (1994) 271-284, DOI 10.1002/rsa.3240050203.** For every $1 > \delta > 0$ there
is $c(\delta) > 0$ such that for every group $G$ of order $n$, a set $S$ of $c(\delta)\log n$
random elements gives expected second largest eigenvalue of the normalized adjacency matrix
at most $1-\delta$. The published abstract adds "for abelian groups this is essentially
tight". Verified from two independent renderings of the publisher abstract.

**L6 [L] Naor and Naor, Small-bias probability spaces: efficient constructions and
applications, SIAM J. Comput. 22 (1993) 838-856 (STOC 1990).** Defines
$\varepsilon$-biased sets $S \subseteq \mathbb F_2^n$, meaning
$|\mathbb E_{x \in S}(-1)^{a \cdot x}| \le \varepsilon$ for all $a \ne 0$. This is exactly
the condition $\max(\lambda_2,-\lambda_{\min}) \le \varepsilon d$ by Theorem 1, verified
here from the definition as quoted in L7.

**L7 [L] Jalan and Moshkovitz, Near-Optimal Cayley Expanders for Abelian Groups,
arXiv:2105.01149v1 (3 May 2021).** Theorem 1.1: there is a deterministic polynomial time
algorithm which, given a generating set of an abelian group $G$, an integer $n \ge 1$ and
$\varepsilon > 0$, outputs $S \subset G^n$ of size
$O(n \log|G| / \varepsilon^{2+o(1)})$ such that $\mathrm{Cay}(G^n,S)$ has spectral gap
$1-\varepsilon$. Verified by reading the PDF text (extracted to `lit/jm.txt`). For
$G = \mathbb F_2$ this is $S \subseteq \mathbb F_2^n$ of size $O(n/\varepsilon^{2+o(1)})$.
The introduction of the same paper states a lower bound of
$\Omega((n\log|G|/\varepsilon^2)^{1-o(1)})$ for abelian $G$ and
$\Omega(\log(1/\varepsilon)/\varepsilon^2)$ for $\mathbb F_2^n$, citing Alon, Goldreich,
Håstad and Peralta (1992). **This lower bound could not be reconciled with the explicit
moment curve computation of Section 6.** At $k = 10$ the moment curve has $n = r = 20$,
$d = 1023$ and two sided bias $\varepsilon = 65/1023 = 0.0635$, so
$n/\varepsilon^2 = 4962$, and the literal reading $|S| \ge (n/\varepsilon^2)^{1-o(1)}$
would require $|S| \gtrsim 2000$ if the $o(1)$ in the exponent were negligible, and would
need an exponent of about $0.81$ to be consistent with $|S| = 1023$. The computation gives
$\lambda_2 = 63$ and $\lambda_{\min} = -65$, verified in exact integer arithmetic. Since
the $o(1)$ is not specified in the secondary quotation this is not a disproof of the quoted
bound. It is a reason not to use it, and consequently this dossier does not use that lower
bound. The only lower bounds used are Theorems 4 and 5, both proved here.

**L8 [L] d'Orsi, Jones, Ruotolo, Vadhan and Zhang, Sparsest cut and eigenvalue
multiplicities on low degree Abelian Cayley graphs, arXiv:2412.17115v3 (30 September 2025),
APPROX/RANDOM 2025, LIPIcs 353, 16:1-16:20.** Abstract verified. Two statements matter
here: low degree abelian Cayley graphs are described as canonical examples of graphs with
poor expansion, and the multiplicity of $\lambda_2$ for connected degree $d$ abelian Cayley
graphs is bounded by $2^{O(d)}$, tight, improving $2^{O(d^2)}$ of Lee and Makarychev.
DOI 10.4230/LIPIcs.APPROX/RANDOM.2025.16.

**L9 [L*] Syndrome graph and coset graph of a code.** The dictionary of Theorem 1 is
classical. The statement read in a secondary source is: with $H$ a parity check matrix of a
linear code, the Cayley graph of the syndrome space with connection set the columns of $H$
is the syndrome graph of the code, isomorphic to its coset graph, and for $q$-ary codes its
eigenvalues are $n(q-1)q^{r-1} - qw_i$ with multiplicity $A_i$ (weight enumerator of the
dual code). Source read: the HTML rendering of arXiv:1912.03892, "Three-weight codes over
rings and strongly walk regular graphs", Section 2. For $q = 2$ this is Theorem 1. This
dossier verified the $q=2$ case independently by exact characteristic polynomial
computation on 208 configurations rather than by re-deriving the general $q$ statement from
the primary coding theory literature (Delsarte).

**L10 [L] McEliece, Rodemich, Rumsey, Welch, New upper bounds on the rate of a code via the
Delsarte-MacWilliams inequalities, IEEE Trans. Inform. Theory 23 (1977) 157-166,
DOI 10.1109/TIT.1977.1055688.** The MRRW first asymptotic bound
$R(\delta) \le H_2(1/2 - \sqrt{\delta(1-\delta)})$ for binary codes. The formula was
verified against several independent renderings. **It was not used as a load bearing input
in this dossier.** An earlier draft of Theorem 5 was derived from it and had to be
withdrawn, because the MRRW bound is asymptotic in $n$ with $\delta$ fixed, while the
regime of interest has $\delta = 1/2 - O(1/\sqrt d)$ moving with $n$. The numerical check
in `out/final_numerics.json` (exhaustive sweep, $r \le 4$) shows the asymptotic formula
fails at small parameters: at $(r,d) = (3,3)$ one has $\lambda_2 = 1$ while the formula
predicts at least $1.6$. The elementary Theorem 5 replaced it and passes all 31328
exhaustive checks exactly. This is recorded because the withdrawn route is the natural one
and a reader will try it.

**L11 [L] Alon and Boppana.** $\lambda_2 \ge 2\sqrt{d-1} - o(1)$ for $d$-regular graphs with
$N \to \infty$, as stated and used in L1 to L4.

**L12 [L] Weil bounds for additive character sums over $\mathbb F_q$.**
$|\sum_{x \in \mathbb F_q}\psi(f(x))| \le (\deg f - 1)\sqrt q$ for a polynomial $f$ of
degree coprime to the characteristic whose derivative does not vanish identically. Used in
Section 6 only to explain why the moment curve is expected to have small bias, and all
numerical claims about it are exact computations, not consequences of the Weil bound.

---

## 10. Closest known work and an honest novelty statement

**Not new.** The dictionary of Theorem 1 is classical coding theory [L9]. The flatness
identity of Theorem 4 is the standard second moment for Cayley graph spectra and for
$\varepsilon$-biased sets [L6]. The small-bias dictionary, that expanding generating sets of
abelian groups are small-bias sets, is stated explicitly in L7 and is folklore. The
multiplicity of $\lambda_2$ for abelian Cayley graphs being exponential in $d$ is the main
result of L8, which is stronger in its generality than anything here. The observation that
low degree abelian Cayley graphs expand poorly is also in L8.

**What this dossier adds, in decreasing order of confidence.**

(1) [P] Theorem 5, the shortening bound $\lambda_2 \ge \log_2(N/d) - 1$, and its corollary
that the benchmark $2\sqrt{d-1}$ fails provably for $N \gtrsim d\,4^{\sqrt d}$. To the
author's knowledge this exact statement, obtained by shortening a code with all weights just
above $d/2$ and applying Plotkin, is not in the literature in this form. It is elementary
and the ingredients are classical, so it should be regarded as a folklore-grade lemma that
happens not to be written down in the spectral literature.

(2) [P] Theorem 3, the rigidity of the negative end: $\lambda_2 < 0$ forces the complete
graph. This is a small exact result with a clean proof, and it is the cheapest available
proof that 2-group Cayley graphs cannot mimic random regular graphs at the bottom of the
spectrum.

(3) [P,N] The framing of the benchmark question as a two parameter question in $(d, \log_2 N)$
with a certified window and an explicit open window, together with Conjecture 7.1. The
framing is what makes the missing estimate visible. It also identifies the exact place where
the four source dossiers' mechanism breaks, namely Theorem 2: the local limit exists only
while $d \ge \log_2 N$, and there the tree threshold is not the natural scale.

(4) [C] The exhaustive data for $r \le 4$ and the moment curve table up to $d = 1023$,
which exhibit the constant $2$ being attained at $N = d^2$ and the crossover behaviour.

**What this dossier does not claim.** It does not claim that Conjecture 7.1 is true. It does
not claim that $\lambda_2 \ge c\sqrt{d\log N}$ or any similar law. It does not claim that
the moment curve family is optimal, only that it certifies attainability at $N = d^2$ for
$d \le 1023$ and, via Weil, for all $d$ up to the stated constant. It does not claim any
formal verification, and no proof assistant was run.

---

## 11. Theorem targets, proof strategies, and the single hardest missing estimate

### 11.1 Target T1, the two variable spectral law

**Target statement.** There are absolute constants $c > 0$ and $C$ such that for every
$r \ge 1$ and every $d$ with $\log_2(d+1) \le r \le d$ the following two assertions hold.
Every $S \subseteq \mathbb F_2^r$ with $|S| = d$ and $\langle S \rangle = \mathbb F_2^r$
satisfies $\lambda_2(S) \ge c\,\sqrt{r\,d/\log_2(2d/r)}$. And there exists at least one such
$S$ with $\lambda_2(S) \le C\,\sqrt{r\,d/\log_2(2d/r)}$.

*Status.* The upper inequality in the regime $r \ge 4\log_2 d$ follows from the union bound
plus Chernoff, which is the Alon and Roichman argument: choosing $S$ uniformly of size $d$
with $\varepsilon^2 d \ge 2(r+1)\ln 2$ makes the probability that some character sum
exceeds $\varepsilon d$ less than one. With $\varepsilon = \sqrt{2(r+1)\ln 2/d}$ this gives
$\lambda_2^{\mathrm{abs}} \le \sqrt{2\ln 2}\,\sqrt{(r+1)d}$, which is at most
$1.18\sqrt{2rd}$ for large $d$, so an upper bound of order $\sqrt{rd}$ holds for such $S$
[P, routine] with an unoptimised constant. The
explicit constructions of L7 give the same order with polylogarithmic losses [L]. The lower
inequality is open. Theorem 5 gives $\lambda_2 \ge \log_2(N/d) - 1 = r - \log_2 d - 1$,
which is linear in $r$ rather than $\sqrt r$ and is the wrong order for large $r$ but the
right order for $r$ close to $d$.

### 11.2 The missing estimate (M), stated exactly

**(M).** There is a constant $c > 0$ such that for every binary linear code $C$ of length
$d$, dimension $r$, with dual distance at least $3$, and with every nonzero word of weight
at least $d/2 - \Delta$,

$$\Delta \,\ge\, c\,\sqrt{\frac{r\,d}{\log_2(2d/r)}} .$$

Equivalently, in spectral language, $\lambda_2 \ge 2c\sqrt{rd/\log_2(2d/r)}$.

*Why this is the hardest step and the only one.* By Theorem 1, (M) is exactly Target T1's
lower inequality. Everything else in this dossier is either elementary (Theorems 2, 3, 4, 5)
or already in the literature. (M) is a statement about binary codes, and it is precisely the
question of how large the rate of a binary code can be when its relative distance is
$1/2 - \eta$: (M) says rate at most $O(\eta^2 \log(1/\eta))$, which is the Gilbert
Varshamov order and is what the linear programming bound also gives asymptotically. So (M)
sits exactly in the classical gap between the Gilbert Varshamov bound (existence at rate
$1 - H_2(\delta)$, which near $\delta = 1/2 - \eta$ is $2\eta^2/\ln 2$) and the linear
programming bound (which gives $H_2(\eta^2)$ up to constants). Both bounds have the order
$\eta^2\log(1/\eta)$, so (M) is *not* the full open problem of determining the binary
rate function. It only needs the order, not the constant.

**Why the obvious argument fails, precisely.** The shortening argument of Theorem 5 is
saturated. Averaging the Plotkin bound over all shortening sets $T$ of size $t$, one
obtains

$$\frac{\binom{d/2 - \Delta}{t}}{\binom{d}{t}}\,2^{r} \,\le\, \frac{d}{t - 2\Delta}
\qquad \text{for every } t > 2\Delta,$$

because the average size of the shortened code is
$\binom{d}{t}^{-1}\sum_{c}\binom{d - \mathrm{wt}(c)}{t} \ge 2^r \binom{d/2-\Delta}{t} /
\binom{d}{t}$. With $t = 2\Delta + 1$ this becomes

$$2\Delta\left(1 + \frac{2\Delta}{d\ln 2}\right) \,\ge\, r - \log_2 d - 1 + o(1).$$

In the benchmark critical regime $r = O(\log_2 d)$ one has $\Delta = O(\sqrt d)$, so the
factor $(1 + 2\Delta/(d\ln 2))$ is $1 + O(1/\sqrt d)$ and the bound is Theorem 5 up to lower
order. Improving the shortening estimate by any fixed factor in that regime is therefore
impossible. In the opposite regime $r = \Theta(d)$ the same factor is at most
$1 + 2/\ln 2 \approx 3.9$, so all that shortening can ever give is a bounded constant
improvement. **Conclusion: (M) cannot be proved by any refinement of shortening. It needs a
genuinely different inequality, and the only known family that reaches the required order
is the Delsarte linear programming bound evaluated near relative distance $1/2$.** This is
the precise obstacle.

**Strategy for (M), with the critical sublemma isolated.** The uniform-in-$\delta$ version
of the MRRW computation. Concretely, the Delsarte linear programming bound is a finite-$d$
statement: for the weight enumerator $(A_i)$ of $C$ and Krawtchouk polynomials $K_j$,
$\sum_i A_i K_j(i) \ge 0$ for all $j \ge 0$, with $A_0 = 1$, $A_i = 0$ for
$0 < i < d/2 - \Delta$, and $\sum_i A_i = 2^r$. One needs a single dual feasible function
$f = \sum_j c_j K_j$ with $c_j \ge 0$ such that $f(0) > 0$ and $f(i) \le -1$ for
$i \ge d/2-\Delta$, with
$\log_2(\text{ratio}) \le -\Omega(\Delta^2/d)$, uniformly for $\Delta/d \le 1/4$. The MRRW
second bound exhibits such an $f$ asymptotically with $\Delta/d$ fixed. The sublemma to
prove is that the same $f$ works with the explicit error term needed when
$\Delta/d \to 0$ at rate $d^{-1/2}$. This is a single, concrete, finite dimensional
estimate: it is an inequality between explicit polynomials, so it is in principle checkable
by symbolic computation. That is the one place where this dossier expects the next serious
work to go.

**Fallback if (M) is false.** If (M) fails then there are binary codes with relative
distance $1/2 - o(1/\sqrt d)$ and rate $\omega(\log d/d)$, which would give $\varepsilon$-biased
sets of size $d$ in $\mathbb F_2^{r}$ with $r = \omega(\log d)$ and bias $2/\sqrt d$. That
would refute Guess A of Section 7 and would be a striking coding theory result, since it
would beat the Gilbert Varshamov bound near $\delta = 1/2$ by a superlogarithmic factor in
the rate. Either outcome settles Conjecture 7.1's upper end. This is why the question is
well posed: it has a definite answer and both answers are interesting.

### 11.3 Target T2, explicit constructions beyond the moment curve

**Target.** For every fixed integer $m \ge 2$ and all large $q = 2^k$, exhibit
$S \subseteq \mathbb F_q^m$ of size $q - 1$ with two sided bias at most $2/\sqrt q$, that is,
with $N = d^m$ and the optimal constant. The moment curve achieves this only at $m = 2$,
because the Weil bound for a polynomial of degree $2m-1$ pays $2m-2$. A construction that
avoids the degree penalty would move the certified attainability from $N \approx d^2$ to
$N \approx d^m$ for arbitrary fixed $m$ and would put Guess A's constant at least at $m$.

*Strategy.* Replace the polynomial graph $\{(x, f(x))\}$ by a graph of a function whose
exponential sums are governed by a curve of low degree in a higher dimensional projective
space, for instance a rational normal curve of degree $m$ evaluated so that all coordinate
functions have degree at most $2$. Concretely, one wants $m$ functions
$f_1, \ldots, f_m : \mathbb F_q \to \mathbb F_q$ such that every nonzero linear combination
$\sum a_i f_i$ has degree at most $3$ after cancellation, since a combination of degree $D$
contributes at most $(D-1)\sqrt q$ to the bias. The polynomials of degree at most $3$ form a
space of dimension $4$ over $\mathbb F_q$, so $m \le 3$. Over $\mathbb F_2$ there is a
second, sharper obstruction, the Frobenius map $x \mapsto x^2$ is $\mathbb F_2$-linear, so a
quadratic coordinate is a linear combination of the $k$ bit coordinates of $x$ and cannot
raise the rank of $S$. What is left at degree at most $3$ is the single cubic coordinate
$x^3$, which is why the moment curve has $m = 2$. The obstruction is worth recording: **a
coordinate wise Weil argument cannot give $m \ge 3$ with constant $2$ over $\mathbb F_2$.** Any
improvement must use a genuinely non-polynomial source of cancellation, for instance
algebraic geometry codes or Katz's bounds for character sums along varieties of higher
dimension.

---

## 12. Unresolved steps and the evidence that would decide them

**U1. The order of $\lambda_2$ in the regime $r = \Theta(d)$.** Theorem 5 gives
$\lambda_2 \ge r - \log_2 d - 1 \asymp d$ and the flatness bound gives only
$\sqrt d$. The moment curve at $N = d^2$ gives $2\sqrt d$. Is $\lambda_2 = \Theta(d)$ for
$r = \Theta(d)$? Evidence for: Gilbert Varshamov codes with rate $\Theta(1)$ have relative
distance bounded away from $1/2$, so $\lambda_2 = d(1 - 2\delta)$ is linear. Evidence
against: none known. Decisive evidence: an explicit code of rate $1/2$ and relative
distance $1/2 - o(1)$, which would be a major coding result and is not expected.

**U2. The crossover constant of Conjecture 7.1.** Decisive evidence: an explicit family with
$r = c\log_2 d$ for $c$ as large as possible, or a proof of (M). A computational study of
the best known $\varepsilon$-biased sets at $d \in [10^2, 10^4]$ with $n = r$ in
$[2\log_2 d, 20\log_2 d]$ would locate the empirical crossover, but by Section 1 the
regime requires exact rank computations in $\mathbb F_2^r$ with $r$ up to a few hundred,
which is feasible with linear algebra over $\mathbb F_2$ and a spectral computation through
the code, not through the graph.

**U3. Is the moment curve optimal among algebraic families?** The obstruction recorded in
Target T2 says the coordinate wise Weil route is capped at $m = 2$. Whether a different
algebraic route exists is open to the author.

**U4. The exponent two assumption.** Theorem 2 uses that $S$ generates a subgroup of size at
most $2^{|S|}$. For $\mathbb Z_m^r$ with $m \ge 3$ the same rank argument gives
$|\langle S\rangle| \le m^{|S|}$, hence $r \le d$. For $\mathbb Z_n$ with $n$ not a prime
power the span is not a subgroup and fixed degree families exist. So the barrier is really
about groups of bounded exponent, not about 2-groups. This is worth recording because it
tells direction E where the general theorem lives: **for any finite abelian group of exponent
$m$, a connected $d$-regular Cayley graph has $|G| \le m^d$.**

**U5. Higher gaps beyond the weight enumerator.** Section 8 gives the exact answer for
2-group Cayley graphs. The analogue for hypergraphs (direction d1) and for general groups
(directions E and F) is not settled by this work.

---

## 13. Common ground with the four source dossiers and with other swarm directions

**With `alon-second-eigenvalue` (Friedman).** The shared object is the tree norm
$2\sqrt{d-1}$ and the shared question is whether finite quotients can reach it. Friedman's
mechanism is that rare tangles, at order $s$, occur with probability $n^{-s}$ and force
$\lambda_2$ above the threshold. In the 2-group case the role of a tangle is played by a code
with small minimum weight, and Theorem 1 makes the correspondence exact: the weight
enumerator of the relation code is the abelian replacement for the tangle generating
function, and the "order" of a tangle is replaced by $d - 2w$. This is the missing
connection the prompt asks about, in its cleanest available form. Theorem 2 explains why the
tangle based mechanism has no asymptotic content here.

**With `friedman-second-eigenvalue-lifts` (Bordenave) and
`relativized-second-eigenvalue` (Friedman and Kohler).** A Cayley graph $\mathrm{Cay}(G,S)$
of a group of order $N$ is a covering of the bouquet $B_d$ with one vertex and $d$ loops, and
for abelian $G$ it is an abelian cover. The base $B_d$ is Ramanujan, its only adjacency
eigenvalue being $d$, so the relativized setting applies with $\rho_B^{\mathrm{new}}$ equal
to $\max_{i \ge 2}|\lambda_i|$. Theorem 0.1.1 of the relativized dossier says that for
random degree $n$ covers the new spectrum is at most $2\sqrt{d-1} + \varepsilon$ with
probability $1 - O(n^{-1})$. The present family shows that this cannot be upgraded to all
abelian covers: for every $d$ and every $N$ in the range $d \ll N \ll 2^d$ there are abelian
covers of degree $N$ whose new spectrum is $\Omega(\log_2(N/d))$ by Theorem 5, and the
moment curve shows the bound is reached in order at $N = d^2$ with the constant $2$. So the
relativized threshold is a probabilistic statement about random fibres in the strongest
possible sense, it is not a statement about abelian covers.

**With `biregular-spectral-gap` (Brito, Dumitriu, Decker Harris).** The transfer mechanism is
the same in form: the biregular dossier transfers adjacency eigenvalues of a bipartite graph
to singular values of its biadjacency matrix through the Ihara Bass formula, and Theorem 1
here transfers adjacency eigenvalues to weights through the character formula. Both are
instances of the same principle, that a spectral quantity on one side of an incidence
structure is a combinatorial quantity on the other. The biregular threshold
$\sqrt{d_1-1}+\sqrt{d_2-1}$ is the tree value for the $(d_1,d_2)$-biregular tree, and it
suggests the following question that this dossier does not settle: for the bipartite double
of $\mathrm{Cay}(\mathbb F_2^r,S)$, which is again a Cayley graph, of the group
$\mathbb F_2^{r+1}$ with connection set $\{(s,1) : s \in S\}$, is the biregular threshold
attained at group size $d^2$ as well? The computed moment curve suggests yes, since both
sides of the double see the same code.

**With direction d1 (hypergraph gap normalization).** Section 8(c) records the shared
conclusion: index based gaps $d - \lambda_3$, $d - \lambda_4$ are not independent invariants
in the presence of a large trivial eigenspace or a large multiplicity. The two mechanisms are
different (a forced $-d$ eigenspace from the incidence rank in the hypergraph case, versus
integrality and multiplicity in the 2-group case) but the remedy is the same, namely to index
gaps by distinct values and to identify the combinatorial sequence behind them.

**With direction d2 (band edge sampling for abelian covers of periodic graphs).** The two
directions are the two halves of the abelian obstruction story. For $\mathbb Z^b$ periodic
graphs and cyclic quotients, fixed $S$ gives $\lambda_2 \to d$ because the quotient spectrum
samples the top band at a lattice point, which is d2's defect. For exponent 2 there is no
fixed degree family at all (Theorem 2), and the available scaling forces $d \ge \log_2 N$.
Both say the same thing in different coordinates: a local limit alone does not determine the
asymptotic spectral gap of abelian quotients, and the true parameter is arithmetic.

---

## 14. Reproducibility

All files below live in this directory, `.ultramath/smwgfcleu/m6/`.

| file | what it does |
|---|---|
| `code/exact_dictionary.py` | Theorem 1 verification. Builds $0/1$ adjacency matrices, computes characteristic polynomials with exact integer arithmetic, compares with the polynomial rebuilt from the code weight enumerator. 208 configurations, includes disconnected ones. |
| `code/extremal_scan.py` | Exhaustive minimisation of $\lambda_2$ over connected $S$ for $r \le 4$, random search for $r \le 12$, and a first version of the cubic family table. |
| `code/bounds_check.py` | Earlier version of the bound checks. Superseded by `final_numerics.py`. Kept because its output is quoted nowhere. |
| `code/key_table.py` | Table of the asymptotic MRRW based bound. **Superseded and not used as evidence.** It records the failed route described in L10. |
| `code/final_numerics.py` | The final sweep. Exhaustive over all connected $S$ for $r \le 4$ (31328 configurations), checking Theorems 3, 4, 5 in exact integer arithmetic, plus the random table, the cubic family for $k \le 10$ and the crossover table. |
| `out/exact_dictionary.json` | Output of `exact_dictionary.py`. 208 checks, 0 failures. |
| `out/extremal_scan.json` | Output of `extremal_scan.py`. Contains the minimum $\lambda_2$ table and the witness sets. |
| `out/final_numerics.json` | Output of `final_numerics.py`. 0 failures, minimum table, random table, cubic table, crossover table. |
| `out/key_table.json` | Output of `key_table.py`. Contains the failing MRRW checks discussed in L10. |
| `lit/jm.txt` | Text extracted from arXiv:2105.01149v1 with `pdftotext`. The exact wording of Theorem 1.1 and of the lower bound quoted in the introduction is in this file. |
| `lit/jm.pdf` | The downloaded arXiv PDF (SHA not recorded, downloaded 2026-11-14 from `https://arxiv.org/pdf/2105.01149v1`). |

Reproduce with

```bash
cd .ultramath/smwgfcleu/m6
python3 code/exact_dictionary.py      > out/exact_dictionary.json
python3 code/final_numerics.py        > out/final_numerics.json
python3 code/extremal_scan.py         > out/extremal_scan.json
python3 code/key_table.py             > out/key_table.json
```

`final_numerics.py` needs `sympy` (used only to pick irreducible polynomials for the finite
fields $\mathbb F_{2^k}$) and takes about two minutes. The other scripts are pure Python 3
and run in seconds. No floating point value is used in any verification, only in printed
tables.

---

## 15. Claim ledger

| claim | label | where checked |
|---|---|---|
| Theorem 1, the code dictionary | [L] for the general $q$ syndrome graph statement, [P] for the proof of the $q=2$ case, [C] exact verification | Section 3, `out/exact_dictionary.json` |
| Theorem 2, the degree barrier | [P] | Section 4.1 |
| Theorem 3, rigidity of the negative end | [P], [C] for $r \le 4$ | Section 4.2, `out/final_numerics.json` |
| Theorem 4, the flatness bound | [P], [C] exhaustive and exact | Section 4.3, `out/final_numerics.json` |
| Theorem 5, the shortening bound and Corollary 5.1 | [P], [C] exhaustive and exact | Section 4.4, `out/final_numerics.json` |
| minimum $\lambda_2$ table for $r \le 4$ | [C] | Section 5, `out/final_numerics.json` |
| moment curve values up to $d = 1023$ | [C] | Section 6, `out/final_numerics.json` |
| moment curve attains $\lambda_2 < 2\sqrt{d-1}$ for all computed $k \le 10$ | [N] | Section 6 |
| the constant $2$ is attained as $k \to \infty$ along even $k$ | [K] | Section 6, conjecture, the table only supports it for $k \le 10$ |
| crossover window $d^2 \lesssim N \lesssim d\,4^{\sqrt d}$ | [P] for both ends | Sections 4.4 and 6 |
| Conjecture 7.1 | [K] | Section 7 |
| the missing estimate (M) and the saturation of shortening | [P] for the saturation, [K] for (M) | Section 11 |
| the literature statements L1 to L12 | [L] or [L*] as marked | Section 9 |
| the lower bound quoted in L7 is not used because it conflicts with the moment curve | [C] for the conflict | Section 9, L7 |
| the MRRW route is withdrawn | [C] for the failure at small parameters | Section 9, L10, `out/key_table.json` |

No formal verifier was run. No proof assistant was used. No claim in this dossier depends on
a numerical experiment for an asymptotic statement, and the two asymptotic statements that
are asserted (Theorem 5's corollary and Target T1's upper bound) are proved, not measured.
