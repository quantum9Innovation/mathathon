#!/usr/bin/env python3
"""Fluctuation study for hypothesis (H_pt) at FIXED exterior energy.

(H_pt): for fixed lambda > 2 sqrt(d-1) and fixed finite T,
        Sigma_n(lambda) - h(lambda) = o_P(1),  h(lambda) = lambda - Delta G_d(lambda).

The heuristic variance computation (proof/reduction.md, Sec. 7) predicts
        sd( 1_T^T (A-lambda)^{-1} 1_T )  ~  C(d,Delta,lambda) n^{-1/2},
with C blowing up like (lambda-2 sqrt(d-1))^{-1/4} near the bulk edge, because
nontrivial (cyclic) nonbacktracking patterns contribute variance ~
sum_l ((d-1) r(lambda)^2)^l / l  <  infinity  iff  lambda > 2 sqrt(d-1).

Certified-uniform sampler (configuration model conditioned on simplicity).
Fixed seeds.  This is EVIDENCE, not a proof.

Run: python3 scripts/fluct_scaling.py
"""
import numpy as np, scipy.sparse as sps
from scipy.sparse.linalg import spsolve

def cfg_simple(n, d, rng, max_try=6000):
    for _ in range(max_try):
        stubs = np.repeat(np.arange(n), d)
        rng.shuffle(stubs)
        a, b = stubs[0::2], stubs[1::2]
        if np.any(a == b):
            continue
        e = np.minimum(a, b) * n + np.maximum(a, b)
        if np.unique(e).size != e.size:
            continue
        return a, b
    raise RuntimeError("sampler failed")

def adj(n, a, b):
    A = sps.coo_matrix((np.ones(len(a)), (a, b)), shape=(n, n))
    return (A + A.T).tocsr()

def gd(x, d):
    sq = np.sqrt(x*x - 4*(d-1))
    return (-(d-2)*x + d*sq)/(2*(x*x - d*d))

def main():
    d, D = 3, 3
    print("d=%d  Delta=%d   2sqrt(d-1)=%.6f" % (d, D, 2*np.sqrt(d-1)))
    for lam in (2.86, 2.95, 3.3, 4.0):
        h = lam - D*gd(lam, d)
        print(f"\nlambda={lam}   h(lambda)=lambda-Delta*G_d(lambda)={h:+.8f}")
        print("   n     ns   mean(Sigma_n)   sd(Sigma_n)   sd*sqrt(n)   mean-h")
        for n in (1000, 2000, 4000, 8000):
            vals = []
            for s in range(8):
                rng = np.random.default_rng(7_000_000 + 1000*n + s)
                a, b = cfg_simple(n, d, rng)
                A = adj(n, a, b)
                one = np.zeros(n); one[:D] = 1.0
                x = spsolve((A - lam*sps.identity(n)).tocsc(), one)
                vals.append(lam + one @ x)
            v = np.array(vals)
            print(f"  {n:5d}   {len(v):2d}   {v.mean():+.8f}   {v.std(ddof=1):.3e}"
                  f"   {v.std(ddof=1)*np.sqrt(n):.4f}      {v.mean()-h:+.3e}")

if __name__ == "__main__":
    main()
