# Theorem target, obstructions, unresolved steps, next experiments

## 1. The target

**Conjecture T (Cayley-Friedman, block-uniform form).** Fix $d \ge 3$,
$\varepsilon>0$ and $B \ge 1$. Let $(G_m)$ be finite groups with
$|G_m| \to \infty$ such that

(H1) for every subgroup $H \le G_m$ with $[G_m:H] \le B$, the abelianization
$H/H'$ has order at most $B$,

and let $S_m$ be a uniformly random symmetric generating set of size $d$. Then
with probability tending to one,
$$\lambda(\mathrm{Cay}(G_m,S_m)) \le 2\sqrt{d-1} + \varepsilon .$$

Equivalently, by Proposition 1: every nontrivial irreducible block satisfies
$\|M_\rho\| \le 2\sqrt{d-1}+\varepsilon$.

(H1) is a "quasirandomness plus no monomial trap" hypothesis. It is satisfied
by $S_N$ and $A_N$ (bounded-index subgroups are point stabilisers of bounded
index only when the index is bounded, which happens only for $N$ bounded, and
the abelianization has order $2$ or $1$), and by finite simple groups of Lie
type with bounded abelianization. It is violated by abelian groups, by
dihedral groups and more generally by any group with a large cyclic section of
bounded index.

A weaker, more accessible target, which would already be new for any sequence
of groups:

**Conjecture T' (bounded gap).** There is a sequence of finite groups $G_m$
with $|G_m| \to \infty$ and, for each $d \ge 3$, symmetric generating sets $S_m$
with $|S_m| = d$ and $\lambda(\mathrm{Cay}(G_m,S_m)) \le C_d$ for a constant
$C_d < d$ depending only on $d$.

T' is weaker than the Ramanujan bound and is still open: the aggregator
passage quoted in `02-literature.md` says that for random Cayley graphs of
$S_N$ "it has not even been shown that the maximum nontrivial eigenvalue is
bounded away from the trivial eigenvalue". Note that T' with the *minimum* over
$S$ instead of a random $S$ is a different and easier-looking question, and the
exhaustive data below do not settle it either.

## 2. Why each hypothesis is there (verified obstructions)

**Obstruction A: characters of the group (abelian quotients).** Proposition 6:
for abelian $G$ of order $n$, $\lambda \ge d - O(d n^{-2/k})$ with $k \approx
d/2$. So no hypothesis that allows large abelian quotients can give an upper
bound at $2\sqrt{d-1}$. This is confirmed exactly for $\mathbb{Z}_n$ and
matches the sharp order $|G|^{-2/k}$ proved by Hermon and Olesker-Taylor for
random abelian Cayley graphs, and the abelianization theorem of Hermon and
Huang for nilpotent groups.

**Obstruction B: monomial blocks from bounded-index subgroups.** Proposition
7: the dihedral family $\mathrm{Cay}(D_m,\{r,r^{-1},t\})$ has
$\lambda = 3$ for even $m$ and $1+2\cos(\pi/m)$ for odd $m$, so it is
Ramanujan only for $m \in \{5,7\}$, even though $D_m/D_m'$ has order $2$ for odd
$m$. The block that fails is a two-dimensional representation *induced* from a
character of the index two subgroup $\langle r\rangle$, and the failure
survives for all $m$. So (H1) is essential in the form "subgroups of bounded
index", not merely "the group's own abelianization".

**Obstruction C: bipartiteness.** Proposition 4: if $S$ avoids an index two
subgroup then $\lambda = d$. For $S_n$ such sets always exist (all generators
odd), so the *maximum* of $\lambda$ over $S$ is exactly $d$ for every $n$ and
every $d$, and the extremal problem's upper end is trivial while its lower end
is not. This is the same remark as the parenthetical in Definition 2.10 of
Mohanty-O'Donnell.

**Obstruction D: short relations.** Exact data at degree 3 (`04-computations.md`
sections 5 and 6): in $A_5$ all 240 non-Ramanujan sets fail with girth 3, 4 or
6 and none is detected by any subgroup coset. So the tangent space of failure
is strictly larger than the subgroup directions. This is the Cayley shadow of
the "feasible tangle" notion of Friedman-Kohler.

## 3. The single hardest missing estimate

By Proposition 1 the whole conjecture reduces to a max over irreducible blocks.
The global spectral information available is the trace, or more precisely the
expected number of closed walks:
$$\mathbb{E}\,\mathrm{tr}(A^{2k}) = |G| \cdot \mathbb{E}\,\#\{\text{closed
walks of length } 2k \text{ at the identity}\}.$$
For random $S$ this is computable from the relation structure of $G$: the
leading term is the count in the free group $F_{d/2}$, which equals the count in
$T_d$, and the corrections are indexed by words in the free group of length at
most $2k$ that evaluate to the identity, each contributing a factor of order
$|G|^{-1}$.

**The missing estimate.** A bound, uniform over $\rho \in \mathrm{Irr}(G)$ and
over $k \le \kappa \log|G|$, of the form
$$\bigl|\,\mathbb{E}\,\mathrm{tr}(M_\rho^{2k}) - T_d(2k)\,\bigr| \le
|G|^{-\alpha}\,\bigl(2\sqrt{d-1}+\delta\bigr)^{2k}$$
for some $\alpha>0$ and $\delta<\varepsilon$, where $T_d(2k)$ is the number of
closed walks of length $2k$ from the root in $T_d$.

Two features make this genuinely harder than the corresponding step in
Friedman, Bordenave, or Friedman-Kohler.

(a) *The trace only controls the average over blocks.* Summing the missing
estimate over $\rho$ with weights $f_\rho$ and using $\sum_\rho f_\rho
\mathrm{tr}(M_\rho^{2k}) = \mathrm{tr}(A^{2k})$ recovers the global estimates,
so the global method is strictly weaker. A single block can carry all the
excess, and in the abelian case it does.

(b) *The trace method is blind to the dangerous eigenvectors.* Take
$G = \mathbb{Z}_n$, $d$ fixed, and let $\chi$ be the character produced by
Proposition 6, with $\chi(S) = d - O(d n^{-2/k})$. The corresponding
eigenvector is the character vector, which is perfectly delocalised: it
contributes exactly $\chi(S)^{2k} \approx d^{2k}$ to $\mathrm{tr}(A^{2k})$
while the bulk contributes about $n\,(2\sqrt{d-1})^{2k}$. The ratio is
$$\frac{d^{2k}}{n\,(2\sqrt{d-1})^{2k}} =
\frac{1}{n}\left(\frac{d^2}{4(d-1)}\right)^{k},$$
which is smaller than one as soon as $k \gtrsim \log n /
\log\!\bigl(d^2/(4(d-1))\bigr)$. Since the trace method works with
$k \asymp \log n$, the outlier is invisible at the only scales where the trace
can be computed. This is a *fatal* obstruction for any proof of Conjecture T
that uses only global moment information, and it explains why the existing
random-regular-graph technology does not transfer automatically: in the
$d$-regular graph model such outliers do not exist, and here they do.

The way around (b) in the existing technology is the *side-stepping* and
*spreading* machinery of Friedman-Kohler: convert coefficient information into
per-eigenvalue information by finite differences, and remove the known
delocalised directions separately. Both steps need the block structure: the
finite-difference step must be applied to the per-block traces, and the known
directions must be removed block by block. That translation is not in the
literature.

## 4. Two smaller targets that are within reach

**Target S1 (exact landscape for $A_6$ and $S_6$ at $d=3$).** Exhaustive
enumeration: about $92{,}000$ symmetric $3$-subsets for $S_6$ and about
$11{,}000$ for $A_6$. Using the sparse Lanczos extraction in
`src/asymptotics.py` this is a few hours of compute. It would decide whether
the exact minimum of $\lambda$ over $S$ stays below $2\sqrt2$ at $|G| = 360$
and $720$. The sampled minima already do ($2.8142 < 2.8284$ for $A_6$,
$2.8214$ for $S_6$), so the exhaustive answer is very likely positive, and the
interesting output is the *shape* of the distribution near the threshold.

**Target S2 (structural characterisation of non-Ramanujan sets at $d=3$).**
From the exact data, every non-Ramanujan set at degree 3 falls into one of:
(i) $S$ inside a coset of an index two subgroup, (ii) $S$ such that two
generators multiply into a small subgroup, producing a low-dimensional block
with a large eigenvalue. Test: for each of the 720 non-Ramanujan sets of $S_5$,
compute all blocks and check whether the extremal block is monomial or is the
"flat" (fully non-monomial) block. This is a finite computation with the tools
already in `src/blocks.py` and would turn the qualitative picture of
`04-computations.md` section 6 into a theorem at $d = 3$.

## 5. Unresolved steps and the evidence that would decide them

| step | status | evidence that would decide it |
| --- | --- | --- |
| block law and quasi-index | proved here (Propositions 1, 2) | nothing further needed |
| coset certificate | proved here (Proposition 5), verified on 2196 sets | nothing further needed |
| abelian pigeonhole bound | proved here (Proposition 6, sharp exponent) | compare constants with Hermon-Olesker-Taylor |
| prism spectrum and Ramanujan set | proved here (Proposition 7), verified for $m \le 13$ | extend the check to $m \le 40$ |
| monomial obstruction for general bounded-index subgroups | conjecture | compute the induced blocks for a family with a bounded-index abelian subgroup of growing order, for example $G = \mathbb{Z}_q \rtimes \mathbb{Z}_3$ |
| Conjecture T for a specific group family | open | first settle T' for $S_N$ at $d = 3$, then sharpen to $2\sqrt2$ |
| the missing per-block trace estimate | open | a proof for abelian $G$ recovered independently of Proposition 6 would be a test case: the estimate must reproduce the exact gap order $|G|^{-2/k}$ |

## 6. Prioritised next steps

1. Run the exhaustive landscape for $A_6, S_6$ at $d=3$ (a few hours of CPU).
2. Decide the monomial-or-not question for the extremal block of every
   non-Ramanujan degree 3 set in $S_5$ (Target S2).
3. Test the semidirect family $\mathbb{Z}_q \rtimes \mathbb{Z}_3$ with a fixed
   3-element connection set: does the induced block from the abelian normal
   subgroup produce $\lambda \to d$, as the monomial mechanism predicts? This
   is a cheap falsification test of the "monomial trap" picture and it is the
   natural next family after the prisms.
4. Compute the exact $\lambda_{\min}$ over $S$ for $A_7$ and $A_8$ at $d = 3,4$
   by a branch and bound using the block decomposition (the blocks have degree
   at most 35, so each candidate can be screened cheaply).
5. Only after 1 to 4, attempt the per-block trace estimate of section 3, in
   the model case of a group with a unique nontrivial block of large degree.
