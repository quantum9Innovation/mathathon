"""Character tables: Murnaghan-Nakayama for S_n, hardcoded table for A_5."""
import functools


def partitions(n, maxpart=None):
    if maxpart is None:
        maxpart = n
    if n == 0:
        yield ()
        return
    for k in range(min(n, maxpart), 0, -1):
        for rest in partitions(n - k, k):
            yield (k,) + rest


def border_strips(lam, r):
    """All ways to remove a border strip of size r from lam. Returns (new, height)."""
    lam = list(lam)
    out = []
    # try removing a horizontal-ish border strip: choose a starting row i and end row j
    L = len(lam)
    for i in range(L):          # top row of the strip
        for j in range(i, L):   # bottom row of the strip
            # rows i..j must each lose >=1 cell, with lengths strictly decreasing
            # strip occupies rows i..j; row i loses lam[i]-lam[i+1] ... standard algorithm:
            pass
    # standard recursive removal
    def strip_rows(k):
        return lam[k] if k < len(lam) else 0
    for i in range(L):
        for j in range(i, L):
            a = strip_rows(i - 1)
            b = strip_rows(j + 1)
            # strip: row i keeps a-? we need lam[i] > ... and lam[j] > b
            if a <= strip_rows(i):
                pass
            # conditions: lam[i] > a (i.e. row i has a cell in the strip) etc.
            # rows i..j lose cells; resulting lengths must satisfy:
            #   new[i] = a-? ... use the standard: after removal, rows i..j have lengths
            #   a-1?? We use: new_i = lam[i]-1 - (extra)
            pass
    # use a robust brute force: find all partitions mu of |lam|-r with lam/mu a border strip
    total = sum(lam)
    res = []
    for mu in partitions(total - r):
        if len(mu) > len(lam):
            continue
        # check mu subset lam and lam/mu connected with no 2x2
        ok = True
        cells = []
        for i in range(len(lam)):
            mi = mu[i] if i < len(mu) else 0
            if mi > lam[i]:
                ok = False
                break
            for j in range(mi, lam[i]):
                cells.append((i, j))
            # check for rows beyond len(lam)
        if not ok:
            continue
        m = len(mu)
        for i in range(m, len(lam)):
            pass
        if len(cells) != r:
            continue
        # connected?
        cs = set(cells)
        if not cs:
            continue
        start = cells[0]
        stack = [start]
        seen = {start}
        while stack:
            (i, j) = stack.pop()
            for nb in ((i - 1, j), (i + 1, j), (i, j - 1), (i, j + 1)):
                if nb in cs and nb not in seen:
                    seen.add(nb)
                    stack.append(nb)
        if len(seen) != len(cs):
            continue
        # no 2x2 square
        has_square = False
        for (i, j) in cs:
            if (i + 1, j) in cs and (i, j + 1) in cs and (i + 1, j + 1) in cs:
                has_square = True
        if has_square:
            continue
        height = len({i for (i, j) in cs}) - 1
        res.append((mu, height))
    return res


@functools.lru_cache(maxsize=None)
def chi(lam, mu):
    """Murnaghan-Nakayama: irreducible character of S_n at cycle type mu."""
    if sum(lam) == 0:
        return 1
    if not mu:
        return 1 if sum(lam) == 0 else 0
    r = mu[0]
    rest = tuple(mu[1:])
    tot = 0
    for new, h in border_strips(lam, r):
        tot += (-1) ** h * chi(new, rest)
    return tot


def sn_character_table(n):
    parts = list(partitions(n))
    types = list(partitions(n))
    return parts, types, {(l, m): chi(l, m) for l in parts for m in types}


# A5: classes ordered [1, (2,2), (3), (5)A, (5)B]
A5_CLASSES = [1, 15, 20, 12, 12]
_GOLD = (1 + 5 ** 0.5) / 2


def a5_character_table():
    """Return (degrees, characters) with characters indexed [irrep][class]."""
    from fractions import Fraction
    import math
    s5 = math.sqrt(5.0)
    x = (1 + s5) / 2
    y = (1 - s5) / 2
    chars = [
        [1, 1, 1, 1, 1],
        [3, -1, 0, x, y],
        [3, -1, 0, y, x],
        [4, 0, 1, -1, -1],
        [5, 1, -1, 0, 0],
    ]
    return [1, 3, 3, 4, 5], chars


def check_orthogonality(degrees, chars, class_sizes, n):
    ok = True
    msgs = []
    for a in range(len(degrees)):
        for b in range(len(degrees)):
            s = sum(class_sizes[c] * chars[a][c] * chars[b][c] for c in range(len(class_sizes)))
            want = n if a == b else 0
            if abs(complex(s) - want) > 1e-8:
                ok = False
                msgs.append((a, b, s, want))
    return ok, msgs
