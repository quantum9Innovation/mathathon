"""Graph-side multiplicity bound from the Seidel moment inequality, plus
the exact stability identity and two-eigenvalue equality family."""
import numpy as np, json
import networkx as nx
import sympy as sp

def seidel(A):
    n=A.shape[0]
    return np.ones((n,n),dtype=np.int64)-np.eye(n,dtype=np.int64)-2*A

def spec_mult(M,tol=1e-7):
    ev=np.linalg.eigvalsh(np.array(M,dtype=float)); out=[]
    for x in ev:
        if out and abs(x-out[-1][0])<tol: out[-1][1]+=1
        else: out.append([x,1])
    return [[round(a,7),k] for a,k in out]

def mult_bound(n,theta):
    return sp.Rational(n*(n-1),1)/(sp.Integer(n-1)+sp.nsimplify(theta)**2)

def rep(name,G):
    A=nx.to_numpy_array(G,dtype=np.int64); n=A.shape[0]
    assert set(np.unique(A)).issubset({0,1}), (name, np.unique(A))
    assert np.array_equal(A,A.T) and np.all(np.diag(A)==0)
    sa=spec_mult(A); S=seidel(A); ss=spec_mult(S)
    checks=[]
    for lam,k in sa:
        if k>1:
            b=mult_bound(n,sp.nsimplify(round(lam,9)))
            checks.append([lam,k,str(b),bool(sp.Integer(k)<=b)])
    # stability identity on the largest Seidel multiplicity
    ev=np.linalg.eigvalsh(S.astype(float))
    vals,counts=np.unique(np.round(ev,9),return_counts=True)
    i=int(np.argmax(counts)); theta=vals[i]; kk=int(counts[i])
    rest=np.delete(ev,np.where(np.round(ev,9)==theta)[0])
    slack=n*(n-1)-kk*theta**2-(kk*theta)**2/(n-kk)
    var=float(np.sum((rest-rest.mean())**2))
    return dict(name=name,n=n,deg=sorted(set(dict(G.degree()).values())),m=G.number_of_edges(),
                adj=sa,seidel=ss,boundcheck=checks,
                stability=dict(k=kk,theta=round(float(theta),8),slack=round(float(slack),10),
                               variance=round(var,10),match=abs(float(slack)-var)<1e-6))

def shrikhande():
    # Shrikhande graph = Cayley graph of Z4 x Z4 with S = {+-1,0),(0,+-1)}
    G=nx.Graph(); G.add_nodes_from([(i,j) for i in range(4) for j in range(4)])
    for i in range(4):
        for j in range(4):
            for di,dj in [(1,0),(-1,0),(0,1),(0,-1)]:
                G.add_edge((i,j),((i+di)%4,(j+dj)%4))
    return G
def rook44():
    # 4x4 rook graph = Z4 x Z4 with S = (+-1,0),(0,+-1) replaced by rows/cols -> K4 x K4
    G=nx.Graph(); G.add_nodes_from([(i,j) for i in range(4) for j in range(4)])
    for i in range(4):
        for j in range(4):
            for k in range(4):
                if k!=j: G.add_edge((i,j),(i,k))
                if k!=i: G.add_edge((i,j),(k,j))
    return G

out=[]
for name,G in [("K4",nx.complete_graph(4)),("K5",nx.complete_graph(5)),("K6",nx.complete_graph(6)),
               ("K33",nx.complete_bipartite_graph(3,3)),("K44",nx.complete_bipartite_graph(4,4)),
               ("Petersen",nx.petersen_graph()),("Heawood",nx.heawood_graph()),
               ("Q4",nx.convert_node_labels_to_integers(nx.hypercube_graph(4))),
               ("C5xC5",nx.convert_node_labels_to_integers(nx.cartesian_product(nx.cycle_graph(5),nx.cycle_graph(5)))),
               ("Shrikhande",shrikhande()),("Rook44",rook44())]:
    out.append(rep(name,G))
for (d,n,sd) in [(4,30,7),(3,40,11),(5,50,3)]:
    out.append(rep(f"rand{d}reg{n}",nx.random_regular_graph(d,n,seed=sd)))
json.dump(out,open("out/mult_bound.json","w"),indent=1)
for r in out:
    print(r["name"], "n=",r["n"],"deg=",r["deg"],"adj=",r["adj"],"seidel=",r["seidel"])
    print("   checks:",r["boundcheck"],"stability:",r["stability"])
