"""
(E) m-periodic k-regular digraphs: the trivial eigenvalues are the m-th roots of unity
    times k, so lambda_2 is trivial for m >= 2 and the first informative gap is
    k - lambda_{m+1}  ("d - lambda_3" for m = 2, "d - lambda_4" for m = 3).
(F) line digraphs DL(G) of random d-regular graphs (2-normal, k = d-1 regular):
    prediction rho(DL(G)) -> sqrt(d-1) = sqrt(k) and sigma_2 = k with high multiplicity.
"""
import json
import numpy as np
import scipy.sparse as sp
import scipy.sparse.linalg as spla

rng = np.random.default_rng(7)
out = {}

def perm_sum(k, n, rng):
    rows, cols = [], []
    for _ in range(k):
        rows.append(np.arange(n)); cols.append(rng.permutation(n))
    return sp.coo_matrix((np.ones(k * n), (np.concatenate(rows), np.concatenate(cols))),
                         shape=(n, n)).tocsr()

def m_periodic(k, m, n, rng):
    """block matrix with blocks X_j (k-regular biadjacency) in cyclic position."""
    blocks = [perm_sum(k, n, rng) for _ in range(m)]
    return sp.bmat([[blocks[(j - i) % m] if (i + 1) % m == j % m or True else None
                     for j in range(m)] for i in range(m)], format='csr')

def m_periodic2(k, m, n, rng):
    """explicit construction: edge from block i to block i+1."""
    blocks = [perm_sum(k, n, rng) for _ in range(m)]
    rows = []
    for i in range(m):
        row = [None] * m
        row[(i + 1) % m] = blocks[i]
        rows.append(row)
    # replace None by zero blocks
    N = n * m
    data = sp.lil_matrix((N, N))
    mats = []
    for i in range(m):
        r = sp.lil_matrix((N, N))
        blk = blocks[i].tocoo()
        for (a, b, v) in zip(blk.row, blk.col, blk.data):
            r[i * n + a, ((i + 1) % m) * n + b] = v
        mats.append(r.tocsr())
    A = sum(mats)
    return A

print("=== (E) m-periodic k-regular digraphs ===")
print("model,k,m,n | top moduli (7 largest) | trivial count with |lam|=k | first nontrivial")
rows = []
for (k, m, n) in [(2, 2, 500), (2, 3, 500), (3, 2, 500), (3, 3, 500), (3, 4, 400), (4, 2, 400), (4, 3, 300)]:
    A = m_periodic2(k, m, n, rng)
    w = spla.eigs(A.astype(float), k=12, which='LM', return_eigenvectors=False, maxiter=20000, tol=1e-10)
    mods = np.sort(np.abs(w))[::-1]
    triv = int(np.sum(np.abs(mods - k) < 1e-6))
    first_nontriv = mods[triv] if triv < len(mods) else float('nan')
    rows.append(dict(k=k, m=m, n=A.shape[0], mods=[float(x) for x in mods],
                     trivial_count=triv, first_nontriv=float(first_nontriv)))
    print(f"rand,{k},{m},{A.shape[0]} | {np.round(mods[:2*m+2],5)} | {triv} (=m={m}) | {first_nontriv:.5f}"
          f"   [sqrt(k)={np.sqrt(k):.4f}, 2sqrt(k-1)={2*np.sqrt(k-1):.4f}]")
out["periodic"] = rows

# Part (F) was superseded by experiments/line_digraph_transfer.py (ARPACK non-convergence on
# Hashimoto matrices with a large bulk of modulus-sqrt(k-1) eigenvalues).

json.dump(out, open("raw/periodic_and_line.json", "w"), indent=1)
print("written raw/periodic_and_line.json")
