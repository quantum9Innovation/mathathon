"""Pass 3: real cube roots for the d=3 root; contact constant via u=sqrt(eps) series."""
import sympy as sp
LOG=[]
def rep(s=""):
    LOG.append(str(s)); print(s)
d, r, lam, eps, u = sp.symbols('d r lam eps u', positive=True)

rep("="*78); rep("L'. exact exterior root for d=3 (real cube roots)")
A = sp.Rational(1,4); B2 = sp.Rational(29,432)
def rcuberoot(x):
    x = sp.nsimplify(x)
    return sp.sign(x)*sp.Abs(x)**sp.Rational(1,3)
rstar = rcuberoot(A+sp.sqrt(B2)) + rcuberoot(A-sp.sqrt(B2))
rep("  r* = (1/4+sqrt(29/432))^(1/3) + (1/4-sqrt(29/432))^(1/3)   [real cube roots]")
rep("  P(r*) = 2r*^3+r*-1 = %s" % sp.simplify(sp.expand(2*rstar**3+rstar-1)))
rep("  r* = %s ; 1/sqrt2 = %s ; r* < 1/sqrt2 ? %s"
    % (sp.N(rstar,22), sp.N(1/sp.sqrt(2),22), bool(sp.N(rstar) < sp.N(1/sp.sqrt(2)))))
lamstar = sp.simplify(2*rstar + 1/rstar)
rep("  lam* = 2r*+1/r* = %s" % sp.N(lamstar,22))
rep("  lam*^3-lam*^2-4lam*-4 = %s" % sp.N(sp.expand(lamstar**3-lamstar**2-4*lamstar-4),22))
rep("  sqrt2*2 = b = %s ; lam*-b = %s ; 3-lam* = %s"
    % (sp.N(2*sp.sqrt(2),22), sp.N(lamstar-2*sp.sqrt(2),15), sp.N(3-lamstar,15)))
rep("  K_adj(lam*) - lam* = %s" % sp.N(2*rstar/(1-rstar)-lamstar, 20))
rep("  Phi'(lam*) = 1+2r*^2/((1-r*)^2(1-2r*^2)) = %s"
    % sp.N(1+2*rstar**2/((1-rstar)**2*(1-2*rstar**2)), 15))
rep("  nroots cross-check: %s"
    % [sp.N(t,15) for t in sp.nroots(lam**3-lam**2-4*lam-4)])

rep(); rep("="*78); rep("M'. contact order at the critical real degree d_c=(5+sqrt5)/2")
Ks   = lambda dd: 2/(sp.sqrt(dd-1)-1)
Phis = lambda dd: 2*sp.sqrt(dd-1) - Ks(dd)
dc = (5+sp.sqrt(5))/2
rep("  Phi(b(d);d) = %s" % sp.simplify(Phis(d)))
rep("  Phi(b(d_c);d_c)=0 with d_c = %s" % sp.N(dc,15))
dPhi = sp.simplify(sp.diff(Phis(d),d))
rep("  Phi'(b(d);d) (total d-derivative at the edge) at d_c = %s" % sp.N(dPhi.subs(d,dc),15))
# K(b+u^2) series in u
b_ = 2*sp.sqrt(d-1); rbb=1/sp.sqrt(d-1)
sols = sp.solve(sp.Eq((d-1)*r**2 - (b_+u**2)*r + 1, 0), r)
small = [s for s in sols if sp.simplify(sp.limit(s,u,0)-rbb)==0][0]
Kser = sp.series(2*small/(1-small), u, 0, 2).removeO()
C0 = sp.simplify(Kser.coeff(u,1))
rep("  K_adj(b+u^2) = K_adj(b) + (%s) u + O(u^2)" % sp.simplify(C0))
rep("  so K(b+eps) = K(b) - C sqrt(eps),  C = %s" % sp.simplify(-C0))
Cval = sp.N((-C0).subs(d,dc),15); dP = sp.N(dPhi.subs(d,dc),15)
rep("  at d_c:  C = %s ,  dPhib/dd = %s" % (Cval, dP))
rep("  => root displacement delta(d) ~ (dPhib/C)^2 (d-d_c)^2, coeff = %s"
    % sp.N((dP/Cval)**2,12))
rep("  numeric confirmation: solve Phi_adj(lam)=0 on the exterior branch for real d")
for dd in [3.40,3.50,3.55,3.60,3.617,3.62,3.64,3.70,3.80,4.0]:
    ddd = sp.Rational(str(dd))
    bb = 2*sp.sqrt(ddd-1); rr_ = 1/sp.sqrt(ddd-1)
    # Phi is strictly increasing; root exists iff Phi(b)<0
    phib = sp.N(Phis(sp.nsimplify(ddd, rational=True)), 15)
    if phib < 0:
        fv = lambda x: float((x - 2*(((x-sp.sqrt(x**2-4*(ddd-1)))/(2*(ddd-1))))/(1-((x-sp.sqrt(x**2-4*(ddd-1)))/(2*(ddd-1))))))
        lo, hi = float(bb), 50.0
        for _ in range(200):
            mid = (lo+hi)/2
            if fv(mid) < 0: lo = mid
            else: hi = mid
        rep("    d=%s : Phi(b)=%s <0, root lam*=%s, lam*-b=%s, (d_c-d)^2=%s, ratio=%s"
            % (dd, round(float(phib),6), round(lo,8), round(lo-float(bb),9),
               round((float(dc)-dd)**2,9), round((lo-float(bb))/(float(dc)-dd)**2,4)))
    else:
        rep("    d=%s : Phi(b)=%s >0  -> no exterior root" % (dd, round(float(phib),6)))

rep(); rep("="*78); rep("P. integer-degree table (exact forms)")
for dd in range(3,11):
    rep("  d=%2d: b=2sqrt(%d) = %s ; K_adj(b)=2/(sqrt(%d)-1) = %s ; Phi_adj(b) = %s"
        % (dd, dd-1, sp.N(2*sp.sqrt(dd-1),10), dd-1, sp.N(2/(sp.sqrt(dd-1)-1),10),
           sp.N(Phis(dd),10)))
rep("  K_adj(d) = 2/(d-2): d=3 -> %s (=2r/(1-r) at r=1/2)" % sp.Rational(2,1))
rep("  cubic lam^3-(d-2)lam^2-4lam-4 = 0 ; unique real root per d (checked numerically below):")
for dd in range(3,11):
    rt = [t for t in sp.nroots(lam**3-(dd-2)*lam**2-4*lam-4) if abs(sp.im(t))<1e-20]
    rep("   d=%2d: real roots = %s ;  b=%s ;  on exterior branch? %s"
        % (dd, [sp.N(sp.re(t),10) for t in rt], sp.N(2*sp.sqrt(dd-1),8),
           [bool(sp.N(sp.re(t)) > 2*sp.sqrt(dd-1)) for t in rt]))
with open('out/exact_checks3.txt','w') as f: f.write("\n".join(LOG)+"\n")
