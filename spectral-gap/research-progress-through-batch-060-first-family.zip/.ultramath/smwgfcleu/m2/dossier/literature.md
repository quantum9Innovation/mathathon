# Verified literature

Each entry gives the source, the version actually read, the exact statement used, and a note on what
I verified myself versus what I take second-hand. Quotes are from the text I read, transcribed
without editorial repair. Where a source is a survey, that is stated, because several results used
here are reported there rather than proved there.

## L1. Parzanchevski, Ramanujan Graphs and Digraphs

* arXiv:1804.08028v4, submitted 21 April 2018, this version 25 May 2020. Published as a chapter in
  *Analysis and Geometry on Graphs and Manifolds*, LMS Lecture Note Series 461, DOI
  10.1017/9781108615259.014. Abstract page: https://arxiv.org/abs/1804.08028
* PDF read: https://arxiv.org/pdf/1804.08028v4 (downloaded to `papers/parzanchevski.pdf`, text
  extract `papers/parzanchevski.txt`).

**Verified statements.** A **survey with new results**. The following are its own formulations.

1. Definition 2.2 (page 3): a $k$-regular digraph is a *Ramanujan digraph* if
   $\rho(D):=\rho(A_D|_{L_0^2})\le\sqrt{k}$, where (page 3, immediately above) "If $D$ is
   $m$-periodic ... then $e^{2\pi ti/m}k$ are also eigenvalues ... By Perron-Frobenius theory, all
   eigenvalues of absolute value $k$ arise in this manner. We call these eigenvalues (including $k$)
   trivial, and denote by $L_0^2$ the orthogonal complement of their eigenfunctions".
2. Page 3: "The bound $\|A\|_{L_0^2}\le\sqrt{k}$ does not have to hold anymore. Indeed, we will see
   that there are Ramanujan digraphs for which $\|A\|_{L_0^2}=k$". This is the operator-norm versus
   spectral-radius distinction that Theorem A of this dossier quantifies as $\kappa$.
3. Definition 2.3 (page 3): $r$-normal means unitarily equivalent to block diagonal with blocks of
   size at most $r$, and a family is almost-normal if it is $r$-normal for one fixed $r<\infty$.
4. Section 3.3 (page 4): for $p\equiv3\pmod4$ the Paley digraph is "$k=\frac{p-1}{2}$-regular normal
   digraph, with nontrivial eigenvalues $\frac{-1\pm i\sqrt p}{2}$ ... These are of absolute value
   $\sqrt{\frac{k+1}{2}}$, so $PD(p)$ is a normal Ramanujan digraph." I re-derived and checked this
   exactly, see `raw/exact_examples.json`.
5. Section 3.4 and Remark 3.2 (page 4): De Bruijn digraphs are $k$-regular, aperiodic, with
   nontrivial spectrum "entirely of zeros", "not diagonalizable", "Jordan blocks of size $s$", and
   "De Bruijn graphs show that a direct analogue of the Alon-Boppana theorem (with respect to any
   positive $\varepsilon$) does not hold for digraphs in general. In Section 4 we will see that in
   the settings of almost-normal digraphs, an Alon-Boppana theorem does hold, with the bound
   $\sqrt{k}$."
6. Proposition 3.1 (page 4): "For any fixed $k\ge2$ and $m\ge1$ there are only finitely many
   $k$-regular $m$-periodic normal (and in particular, self-adjoint) Ramanujan digraphs." Its proof
   uses the symmetrization $A+A^{\mathsf T}$ and Nilli's Theorem 3.4
   ($\lambda_2\ge2\sqrt{k_G-1}\cos(2\pi/\operatorname{diam}G)$), quoted from Nilli 2004.
7. Section 3.5 (page 5), line digraphs: $\mathrm{Spec}(DL(G))$ is given by eq. (3.1),
   $$\mathrm{Spec}(DL(G))=\Big\{\tfrac{\lambda\pm\sqrt{\lambda^2-4k}}{2}:\lambda\in\mathrm{Spec}(G)\Big\}\cup\{\pm1\}^{|E_G|-|V_G|},$$
   and eq. (3.2) "$|\lambda|\le2\sqrt{(k+1)-1}\iff|\tfrac12(\lambda\pm\sqrt{\lambda^2-4k})|=\sqrt k$,
   so that $G$ is a Ramanujan graph if and only if $DL(G)$ is a Ramanujan digraph." Also: "The
   digraph $DL(G)$ is not normal ... the trivial singular value $k$ repeats $|V_G|$ times", and "The
   breakthrough in [LP16] is the understanding that $A$ is always $2$-normal."
8. Theorem 4.3 (page 9): "Let $k\ge2$ and $m\ge1$. For any $\varepsilon>0$, there is no infinite
   almost-normal family of $k$-regular $m$-periodic digraphs $D$ with $\rho(D)\le\sqrt k-\varepsilon$."
   The proof is written for the aperiodic case and ends "This concludes the aperiodic case, and we
   leave the general one to the reader." **Scope caveat carried into Theorem C(i) of this dossier.**
9. Eq. (5.1) (page 10): "$\mathrm{Spec}(T_k)=\{z\in\mathbb C:|z|\le\sqrt k\}$", where $T_k$ is the
   $k$-regular directed tree, credited to [dlHRV93]. Theorem 5.2 (page 11, from [dlHRV93]): if $S$
   generates a free subsemigroup of a group $G$ then $\rho(A_{\mathrm{Cay}(G,S)})=\sqrt k$.
10. Section 5.3 (page 11): "For any $k$, [MSS15] shows the existence of infinitely many $k$-regular
    bipartite Ramanujan graphs, and thus there exist infinitely many $k$-regular, $2$-periodic,
    $2$-normal Ramanujan digraphs, namely their line-digraphs defined in Section 3.5."
11. Section 5.5 (page 13), Alon's conjecture for digraphs, eq. (5.4): "$\mathrm{Prob}[\rho(D)\le\sqrt
    k+\varepsilon]\to1$ where $D$ is a random $k$-regular digraph on $n$ vertices", and Theorem 5.3:
    "Statement (5.4) is true", attributed to "[Cos17, Thm. 1 with $\delta=\Delta=k$]".
12. Section 6, Question (5): "Is there an almost-normal family of $k$-regular digraphs with
    $n\to\infty$ whose nontrivial spectrum is contained in the circle $\{z:|z|=\sqrt k\}$?" This
    dossier's Theorem C(ii) shows that the *quantitative* content of that question has a positive
    answer, since line digraphs of Ramanujan graphs have all nontrivial eigenvalues on the circle
    except the $\pm1$ values, which sit strictly inside. The strict form of Question (5), requiring
    no eigenvalues inside the circle, is not addressed.

**Novelty adjustment (review point 5).** Item 10 above is exactly the line-digraph construction of
Ramanujan digraphs, and it is already recorded in the source. Revision 1 of this dossier overstated
the novelty of "line digraphs attain $\sqrt{k}$". What remains new is the sharp constant
classification (the normal locus has constant $2\sqrt{k-1}$, the $2$-normal class has constant
exactly $\sqrt{k}$, and the jump sits between $r=1$ and $r=2$), the period bookkeeping of
Proposition 6, and the gap index rule of Proposition 2. Theorem C is stated as a consequence of
item 10 plus Friedman's bound, not as a new construction.

**Second-hand items.** The survey attributes the $2$-normality of line digraphs to Lubetzky-Peres
(GAFA 2016) and the existence of Ramanujan graphs of all degrees to Marcus-Spielman-Srivastava. I did
not open those two papers. Everything that depends on them is marked (1) in the ledger of the main
dossier, and the dependence is isolated in Theorem C.

## L2. Coste, The Spectral Gap of Sparse Random Digraphs

* arXiv:1708.00530v2, submitted 1 August 2017, this version 26 July 2018.
  Abstract: https://arxiv.org/abs/1708.00530
* Abstract quoted: "we give an asymptotic upper bound for the second eigenvalue when $P$ is the
  transition matrix of the simple random walk over a random directed graph with given degree
  sequence ... An immediate consequence of our result is a proof of the Alon conjecture for directed
  regular graphs. Our result is based on a variation of the trace method introduced by Bordenave
  (2015)."
* The specific form I use is the specialization recorded as Theorem 5.3 of L1, namely the regular
  case with in-degree and out-degree both $k$, giving $\rho\le\sqrt k+\varepsilon$ with probability
  tending to one. I did not open the Coste PDF. **Second-hand through L1.**

## L3. Brito, Dumitriu, Decker Harris, Spectral gap in random bipartite biregular graphs

* arXiv:1804.07808v6, last revised 2 June 2021. CPC 31 (2022) 229-267, DOI 10.1017/S0963548321000249.
  Abstract: https://arxiv.org/abs/1804.07808. TeX source read from the local reading library
  `/workspace/nucleus/work/home/research/reading/biregular-spectral-gap/source`.
* Eq. (2) in the introduction (verified in `introduction.tex`): "For every $\epsilon>0$,
  $\eta\ge\sqrt{d_1-1}+\sqrt{d_2-1}-\epsilon$ as the number of vertices goes to infinity", attributed
  in the text to "the work of [feng1996] and [li1996], who proved the analog of the Alon-Boppana
  bound", and noted to also follow from the Godsil-Mohar asymptotic support
  $|\sqrt{d_1-1}-\sqrt{d_2-1}|\le|\lambda|\le\sqrt{d_1-1}+\sqrt{d_2-1}$.
* Their Theorem 4 gives the matching upper bound $\eta\le\sqrt{d_1-1}+\sqrt{d_2-1}+\varepsilon'_n$
  for uniform simple random biregular graphs, plus $\eta^+_{\min}\ge\sqrt{d_1-1}-\sqrt{d_2-1}-o(1)$
  and full row rank when $d_1>d_2$.
* Their introduction also notes (verified): "similar techniques have been employed by [coste2017] to
  study the spectral gap of the Markov matrix of a random directed multigraph", and that "the
  non-backtracking operator of a bipartite biregular graph could be seen as the adjacency matrix of a
  directed multigraph".
* **This is the key input for Theorem A.** I use only eq. (2), with $d_1=d_2=k$, applied to the
  bipartite double cover.

## L4. Feng 1996 and Li 1996 (biregular and hypergraph Alon-Boppana)

* W.-C. W. Li, *Spectra of Regular Graphs and Hypergraphs and Orthogonal Polynomials*, European J.
  Combinatorics 17 (1996) 461-477, DOI 10.1006/eujc.1996.0040. Abstract (from the biregular paper's
  bibliography, verified): studies eigenvalue distributions of "regular graphs, regular hypergraphs,
  and biregular bipartite graphs of given girth" via "polynomials orthogonal with respect to the
  measures attached to the spectra of such graphs and to the continuous spectra of their universal
  covers", and mentions Hecke operators on weight 2 cusp forms.
* K. Feng, *Spectra of Hypergraphs and Applications*, J. Number Theory 60 (1996) 1-22, DOI
  10.1006/jnth.1996.0109. Abstract (verified): "To a regular hypergraph we attach an operator, called
  its adjacency matrix, and study the second largest eigenvalue as well as the overall distribution
  of the spectrum of this operator. Our definition and results extend naturally what is known for
  graphs, including the analogous threshold bound for $k$-regular graphs."
* **Relevance outside this dossier.** Feng's abstract indicates that a hypergraph Alon-Boppana
  threshold for a codegree-type operator was already treated in 1996. That is directly relevant to
  direction `d1` of this swarm, whose question about the correct normalization of hypergraph gaps
  should be checked against Feng's "analogous threshold bound" before any novelty claim.
* I did not open either paper. Both are second-hand through L3's introduction and the biregular
  reading library bibliography.

## L5. Godsil and Mohar, Walk generating functions and spectral measures of infinite graphs

* Linear Algebra Appl. 107 (1988) 191-220, DOI 10.1016/0024-3795(88)90245-5. Abstract (verified from
  the bibliography): spectral measures of infinite locally finite graphs, a pairing theorem for
  infinite bipartite graphs, "the calculation of the expected eigenvalue distribution of a large
  finite random regular or bipartite semiregular graph". The support formula used in L3 is
  attributed to this paper. Second-hand.

## L6. Marcus, Spielman, Srivastava, Interlacing families I

* Annals of Mathematics 182 (2015) 307-325, "Bipartite Ramanujan graphs of all degrees". Used only
  as the existence statement quoted in L1 item 10. Second-hand.

## L7. Lubetzky and Peres, Cutoff on all Ramanujan graphs

* Geometric and Functional Analysis 26 (2016) 1190-1216. Source of the $2$-normality of line
  digraphs, quoted in L1 item 7. Second-hand.

## L8. de la Harpe, Robertson, Valette, On the spectrum of the sum of generators

* Colloquium Mathematicum 65 (1993) 87-102, part II. Source of $\mathrm{Spec}(T_k)=\{|z|\le\sqrt k\}$
  and of the free-subsemigroup criterion, quoted in L1 items 9. Second-hand.

## L9. The four local dossiers (inputs to the common-ground section)

* Friedman, *A proof of Alon's second eigenvalue conjecture and related problems*,
  arXiv:cs/0405020v1 (2004), per `.paper-mastery/alon-second-eigenvalue/SOURCE.md`. Main theorem
  used: random $d$-regular graphs have all nontrivial $|\lambda_i|\le2\sqrt{d-1}+\varepsilon$ with
  probability $1-O(n^{-\tau_{\mathrm{fund}}})$.
* Brito-Dumitriu-Decker Harris, as in L3, per `.paper-mastery/biregular-spectral-gap/SOURCE.md`.
* Bordenave, *A new proof of Friedman's second eigenvalue theorem and its extension to random
  lifts*, arXiv:1502.04482v4 (2019), per `.paper-mastery/friedman-second-eigenvalue-lifts/SOURCE.md`.
  Main theorem used: new non-backtracking eigenvalues of a random lift are at most
  $\sqrt{\rho_1}+o(1)$.
* Friedman and Kohler, *The relativized second eigenvalue conjecture of Alon*, arXiv:1403.3462v1
  (2014), per `.paper-mastery/relativized-second-eigenvalue/SOURCE.md`. Main theorem used:
  $\Pr[\rho_B^{\mathrm{new}}(A_G)\ge2\sqrt{d-1}+\varepsilon]\le C_{B,\varepsilon}n^{-1}$.
* These four are used only for the common-ground discussion and for the sharpness side of Theorem B
  (Friedman's upper bound is what makes $2\sqrt{k-1}$ optimal on the normal locus).

## L10. Not consulted, flagged as a gap

* No search of the *full text* of Lubetzky-Peres, Lubetzky-Lubotzky-Parzanchevski, or
  Parzanchevski-Sarnak for a statement of $2\sqrt{k-1}$ as the normal-locus constant. The closest
  verified statement is Theorem 4.3 of L1 with constant $\sqrt k$. A full-text search is item 2 of
  the prioritized next steps in the main dossier.
