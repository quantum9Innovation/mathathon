# Finite-defect resolvent and the finite-root law: minimal-hypothesis reduction

Member m5, direction d5 (Role 5: rigorous eigenvalue reduction from the weakest
adequate resolvent input).  Working directory `.ultramath/smwgwbyn9/m5/`.

**Scope.** Fixed degree `d >= 3`, `Delta >= 1` fixed, `G_n` uniform random simple
`d`-regular on `[n]`, `T_n = {1,...,Delta}` a **fixed** set, `G_n' = G_n` plus one new
vertex adjacent exactly to `T_n`.  No growing degree, no random `T`, no expectation in
place of in-probability.

**What this file proves outright (no unproved input):** Theorem A (exact reduction),
Lemma B (multiplicities at host eigenvalues), Lemma C (Perron/interlacing), Lemma D
(root counting and monotonicity), Lemma E (uniformity in `lambda` is automatic), the
exact algebra of the Kesten-McKay transform (Sec. 5: thresholds `2(d-2)` and
`d^2(d-2)/(d-1)`, closed-form biquartic root, branch selection), and the exact
separation of the fixed-`T`, random-`T` and vertex-averaged targets (Sec. 7).

**What is proved conditionally (Theorem F):** the full finite-root law, from the single
scalar hypothesis (H_pt) below, which requires *only pointwise convergence at each
fixed real exterior energy* - no uniformity, no complex energy, no rate.

**What is not proved:** (H_pt) itself.  Sec. 9 states it as the exact missing estimate,
with the variance heuristic and the numerical fluctuation study that support it, and
with the honest statement that near the bulk edge the convergence is slow and no
uniform-in-`lambda` rate should be claimed.

--------------------------------------------------------------------------
## 1. Notation and the exact transform

For `d >= 3` let `bulk_d = [-2 sqrt(d-1), 2 sqrt(d-1)]`.  For `lambda > 2 sqrt(d-1)`
let `r(lambda)` be the root of `(d-1) r + 1/r = lambda` with `0 < r < 1/sqrt(d-1)`
(exists and is unique, `r` strictly decreasing), and

    G_d(lambda) := r/(1-r^2) = 1/(lambda - d r(lambda))   (Kesten-McKay transform).

`G_d(lambda) = int d mu_{KM,d}(x)/(lambda - x)`; it is the **full** transform, not the
one-sided branch `r`.

## 2. Theorem A (exact secular identity; deterministic, all graphs)

Let `G` be any graph, `T` a vertex set, `G' = G + (one vertex adjacent exactly to T)`,
`1_T` the indicator of `T`, `p_H(x) = det(xI - A_H)`.  Then

    p_{G'}(lambda) = p_G(lambda) * Sigma(lambda),    Sigma(lambda) = lambda + 1_T^T (A_G - lambda I)^{-1} 1_T

as an identity of polynomials after clearing denominators.

*Proof.* Order the new vertex first.  `lambda I - A_{G'}` has `(1,1)` entry `lambda`,
first row `(-1_T^T)` and first column `(-1_T)`; its Schur complement with respect to
the `(1,1)` block is the scalar `Sigma(lambda)` whenever `lambda` is not an eigenvalue
of `A_G`, and `det = lambda * Sigma * ... ` gives `det(lambda I - A_{G'}) =
det(lambda I - A_G) Sigma(lambda)`.  Both sides are rational functions agreeing on the
complement of a finite set, hence identical; after multiplying by `p_G` they are
polynomials.  (Verified in exact integer arithmetic on `K_{3,3}+`spike, `Q_3+`spike,
`K_5+`spike, residual 0; `scripts/exact_algebra.py`, Sec. 7.)  `[]`

This identity is accepted in the established scope and is not claimed as new here.

## 3. Lemma B (what happens at host eigenvalues; deterministic)

Let `mu` be an eigenvalue of `A_G` of multiplicity `m`, `P_mu` the orthogonal projector
onto `ker(A_G - mu)`, `(A_G - mu)^+` the Moore-Penrose inverse.  Then

    mult_{G'}(mu) = m - 1   if P_mu 1_T != 0,
                  = m + 1   if P_mu 1_T = 0 and 1_T^T (A_G - mu)^+ 1_T = -mu,
                  = m       otherwise.

*Proof.*  An eigenvector of `A_{G'}` at `mu` is a pair `(y,c)`, `y in R^n`, `c in R`,
with (i) `A_G y + c 1_T = mu y` and (ii) `1_T^T y = mu c`.
If `c = 0`: (i) `<=> y in ker(A_G - mu)`; (ii) cuts the kernel by the hyperplane
`1_T^T y = 0`, which is automatic exactly when `P_mu 1_T = 0` (i.e. `1_T` is
orthogonal to the kernel) and otherwise removes exactly one dimension.
If `c != 0`: (i) is solvable iff `P_mu 1_T = 0`; then `y = -c (A_G-mu)^+ 1_T + k`,
`k in ker`, and (ii) becomes `-c 1_T^T (A_G-mu)^+ 1_T = mu c`, independent of `c`, so
either the whole `(m+1)`-dimensional space `{(y,c)}` is available or nothing.
Adding the two branches gives the three cases.  `[]`

*Exact checks.*  `K_{3,3}` (`spec = lambda^4(lambda-3)(lambda+3)`) plus a spike onto one
side has `spec = lambda^5 (lambda^2-12)`: the two simple eigenvalues `+-3` drop to `0`
(first case), `mu = 0` with `m = 4` rises to `m+1 = 5` (second case, since
`1_T = 1_A in range(A)`).  `K_2` plus a spike onto both vertices is `K_3`: `mu = 1`
drops to 0, `mu = -1` rises to 2.  `C_4` plus a spike onto two opposite vertices:
`mu = 0` has `m = 2` and rises to 3, in the second case.  All three cases are
non-vacuous; an exhaustive float-arithmetic check over **all** graphs on `<= 5`
vertices and **all** `T` matched **149009 instances with 0 mismatches**
(`out/exact_algebra.txt`).

The batch dossier's Corollary 2 said "`m_i` if `1_T perp ker`, at least `m_i - 1`
otherwise".  Both halves are correct but not sharp: the first can be `m_i + 1`, the
second is exactly `m_i - 1`.  Lemma B replaces it.

## 4. Lemma C (Perron, interlacing; deterministic)

(i) `1` is an eigenvector of `A_n` with eigenvalue `d`, so `lambda_1(A_n) = d`.
(ii) `A_n` is a principal submatrix of `A_n'`, so Cauchy interlacing gives
`lambda_k(A_n') >= lambda_k(A_n) >= lambda_{k+1}(A_n')` for all `k`; in particular
`lambda_2(A_n') <= lambda_1(A_n) = d`.
(iii) `lambda_1(A_n') > d` strictly, for every `Delta >= 1`.

*Proof of (iii).*  Suppose `lambda_1(A_{n'}) = d` and let `u > 0` be an eigenvector
(Perron).  Its restriction `y = u|_G` is nonzero, `y >= 0`, `u(x) > 0`, and
`A_n y = d y - u(x) 1_T`.  Taking the inner product with `1` and using
`1^T A_n = d 1^T` gives `0 = d 1^T y - u(x) Delta`, i.e. `u(x) Delta = 0`,
contradiction.  `[]`

Consequently the ordering of the two largest eigenvalues is **unconditional**:
`lambda_1(G_n') > d >= lambda_2(G_n')`.  No hypothesis is needed for the "two possible
orderings" question; only the *limits* need one.

## 5. Lemma D (root structure of `Sigma_n`)

Write the spectral decomposition of `A_n` as `(mu_i, u_i)_{i=1..n}` and put
`a_i = (1_T^T u_i)^2 >= 0`.  Then on every component `J` of `R \ sigma(A_n)`,

    Sigma_n(lambda) = lambda + sum_i a_i/(mu_i - lambda),   Sigma_n'(lambda) = 1 + sum_i a_i/(mu_i - lambda)^2 > 1.

Hence `Sigma_n` is real analytic and *strictly* increasing with slope `> 1` on `J`, and
for `mu in sigma(A_n)`: `Sigma_n -> -inf` as `lambda downarrow mu` and `-> +inf` as
`lambda uparrow mu` whenever `a_{mu} := (1_T^T P_mu 1_T) > 0`, in particular at
`mu = d` where `a_d = Delta^2/n > 0` exactly (`u_d = n^{-1/2} 1`).  Also
`Sigma_n(lambda) ~ lambda` as `|lambda| -> inf`.  `[]`

Consequently, on `(d, inf)`: `Sigma_n downarrow d = -inf`, `Sigma_n -> +inf`, strictly
increasing, so **`Sigma_n` has exactly one root in `(d, inf)`**, and it is
`lambda_1(G_n')`; and on `(lambda_2(A_n), d)` it has at most one root, which when it
exists is `lambda_2(G_n')`.  Combined with Theorem A and `sigma(A_n) subset [-d, d]`
this is a complete deterministic count of the exterior roots.

## 6. The scalar limits: exact algebra (deterministic)

Let `h(lambda) = lambda - Delta G_d(lambda)`, the limiting secular function.

**(Q)** `(lambda^2 - d^2) G_d^2 + (d-2) lambda G_d - (d-1) = 0` on `(2 sqrt(d-1), inf)`,
   `lambda != d`; verified symbolically, and with the cleaner substitution
   `lambda = (d-1) r + 1/r`, `G = r/(1-r^2)` the residual is identically `0`
   (`out/exact_algebra.txt` Sec. 1).
   Equivalently `G_d(lambda) = (-(d-2) lambda + d sqrt(lambda^2-4(d-1)))/(2(lambda^2-d^2))`,
   the branch that is continuous at `lambda = d`; the other branch of the algebraic
   curve has a simple pole at `lambda = d` and is **not** a Stieltjes transform of a
   positive measure (it is negative on `(d, inf)`).
   `G_d' < 0` on `(2 sqrt(d-1), inf)`: from `dG/dr = (1+r^2)/(1-r^2)^2 > 0` and
   `d lambda/dr = (d-1) - 1/r^2 < 0` (because `r^2 < 1/(d-1)` on that branch).
   Hence **`h' = 1 - Delta G_d' > 1 > 0`**: `h` is strictly increasing.
   `G_d(d) = (d-1)/(d(d-2))`, `G_d(2 sqrt(d-1)) = sqrt(d-1)/(d-2)`; the second value is
   a limit from inside the open interval.

**Thresholds.**  `h(2 sqrt(d-1)+) = sqrt(d-1)(2 - Delta/(d-2))`, so

    h has a zero in (2 sqrt(d-1), inf)   <=>   Delta > 2(d-2)        [tree/bulk edge is 2 sqrt(d-1)]

and `h(d) = d - Delta (d-1)/(d(d-2))`, so

    that zero lies in (2 sqrt(d-1), d)  <=>  2(d-2) < Delta < d^2(d-2)/(d-1)
    that zero lies in (d, inf)          <=>  Delta > d^2(d-2)/(d-1).

Because `h` is strictly increasing and `~ lambda` at infinity, the zero, when it
exists, is unique.  Call it `lambda_f`; set `lambda_f := 2 sqrt(d-1)` when
`Delta <= 2(d-2)` (the convention of the dossier).

**Closed form.**  `lambda = Delta G_d(lambda)` together with (Q) gives the biquartic

    lambda^4 - (d^2 - (d-2) Delta) lambda^2 - (d-1) Delta^2 = 0,

so `lambda_f^2 = [ (d^2 - (d-2)Delta) + sqrt( (d^2-(d-2)Delta)^2 + 4(d-1)Delta^2 ) ] / 2`
(the other root in `lambda^2` is negative).  Values: `(d,Delta)=(3,6): 3.1806986606`,
`(3,4): 2.9469744550`, `(3,3): 2.8628923177`, `(4,7): 3.6284328657`.  The `(3,6)` value
reproduces the dossier's independent numerical `3.1807`.

**Branch trap, made a theorem.**  If one replaces `G_d` by the one-sided branch `r`,
the equation `lambda = Delta r(lambda)` has a root above the bulk exactly when
`Delta > 2 sqrt(d-1) r(2 sqrt(d-1)) = 2(d-1)`.  So substituting `r` for `G_d` shifts
the threshold from `2(d-2)` to `2(d-1)` - the classical tree threshold.  This is a
rigorous statement about the two functions, and it is why the warning in the batch
README is not cosmetic.

## 7. Why fixed `T`, random `T` and the vertex average are three different objects

Exact identities, for any symmetric `M` and `T` a uniform random `Delta`-subset
independent of `M`:

    E_T[ 1_T^T M 1_T ] = (Delta/n) tr M + (Delta(Delta-1)/(n(n-1))) (1^T M 1 - tr M),

and for `M = (A_n - lambda I)^{-1}`, `1^T M 1 = sum_i (1^T u_i)^2/(mu_i - lambda)`
contains the Perron contribution `n/(d - lambda)`.  Hence:
- the **vertex average** `(Delta/n) tr M -> -Delta G_d(lambda)` is a statement about the
  empirical spectral measure only;
- the **random-`T`** target equals the vertex average *plus*
  `(Delta(Delta-1)/(n(n-1))) (1^T M 1 - tr M)`, which is `o(1)` for fixed `lambda != d`
  but is `O(1)` when `lambda = d - c/n`; it is therefore not the same statement in the
  near-`d` regime that produces the `O(1/n)` finite-size law;
- the **fixed-`T`** target is strictly stronger than both, and is what Theorem F needs.

This is the exact content of Gate A's "do not average over `T` while claiming a theorem
for fixed `T`".

## 8. Lemma E (uniformity in `lambda` is automatic, not an extra hypothesis)

Let `I` be an open interval, `f_n, f : I -> R` with `f_n, f` increasing, `f` continuous,
and `f_n -> f` pointwise on a dense `D subset I`.  Then `f_n -> f` locally uniformly on
`I`.

*Proof.*  Given `[a,b] subset I` and `eps > 0`, choose grid points
`a = x_0 < ... < x_m = b` in `D` with `f(x_{j+1}) - f(x_j) < eps/2` (possible since `f`
is uniformly continuous on `[a,b]`).  For `lambda in [x_j, x_{j+1}]` and `n` large
enough that `|f_n(x_j) - f(x_j)| < eps/2` for all `j`,

    f_n(lambda) - f(lambda) <= f_n(x_{j+1}) - f(x_j) <= f(x_{j+1}) + eps/2 - f(x_j) < eps,
    f(lambda) - f_n(lambda) <= f(x_{j+1}) - f_n(x_j) <= f(x_{j+1}) - f(x_j) + eps/2 < eps.  []

Applied with `f_n = Sigma_n`, `f = h` (both increasing: Lemma D and Sec. 6), pointwise
convergence at the rationals of a window upgrades to
`sup_{lambda in K} |Sigma_n - h| -> 0` for every compact `K` inside the window.  So the
dossier's hypothesis (H) (*uniform* on compacts) is **equivalent** to the pointwise
hypothesis at a countable dense set, and the uniformity demanded by role 5 needs no
separate argument.  What the upgrade does **not** give is any rate.

## 9. Theorem F (conditional finite-root law; the main conditional result)

**Hypothesis (H_pt).**  For every fixed `lambda in W := (2 sqrt(d-1), d) union (d, inf)`,

    1_{T_n}^T (A_n - lambda I)^{-1} 1_{T_n}  ->  -Delta G_d(lambda)   in probability,

equivalently `Sigma_n(lambda) -> h(lambda)` in probability.

**Conclusion.**  With `lambda_f` as in Sec. 6,

    lambda_1(G_n') -> max(d, lambda_f),      lambda_2(G_n') -> min(d, lambda_f)   in probability.

*Proof.*  Throughout, `eps > 0`, and `c = c(d)` denotes the import F1 below.

*Step 1 (window emptiness).*  By import F1 (Bordenave / Friedman), for each `eps > 0`,
`P(lambda_2(A_n) <= 2 sqrt(d-1) + eps) -> 1`.  Let `E_n` be that event.  On `E_n`,
`sigma(A_n) cap (2 sqrt(d-1)+eps, d) = empty`, so by Lemma D `Sigma_n` is real analytic
and strictly increasing with slope `> 1` on `W_eps := (2 sqrt(d-1)+eps, d) union (d,inf)`.
(By Lemma C/Perron, `sigma(A_n)` never meets `(d, inf)`.)

*Step 2 (`lambda_1` is the unique root above `d`).*  Deterministic, Lemma D: on
`(d, inf)`, `Sigma_n downarrow d = -inf`, `Sigma_n -> +inf`, strictly increasing, so
exactly one root `rho_n`; by Theorem A and `sigma(A_n) subset [-d,d]` the roots of
`Sigma_n` in `(d,inf)` are exactly the eigenvalues of `A_n'` in `(d,inf)`, and by
Lemma C(iii) there is exactly one of those.  So `rho_n = lambda_1(G_n')`.

*Step 3 (root sandwich).*  Fix `lambda in (d, inf)`.
   If `h(lambda) > 0`, then `P(Sigma_n(lambda) <= 0) -> 0`, and on
   `{Sigma_n(lambda) > 0} = {Sigma_n(lambda) > Sigma_n(rho_n)}` monotonicity gives
   `rho_n < lambda`.  If `h(lambda) < 0` then similarly `rho_n > lambda`.  Hence for
   every such `lambda`,
       `P(rho_n >= lambda) -> 0` if `h(lambda) > 0`,  `P(rho_n <= lambda) -> 0` if `h(lambda) < 0`.
   Therefore
       `limsup rho_n <= inf{lambda > d : h(lambda) > 0}` and
       `liminf rho_n >= sup{lambda > d : h(lambda) < 0}`   in probability,
   and because `h` is continuous and strictly increasing both bounds equal
   `max(d, lambda_f)`: indeed `inf{lambda > d : h(lambda) > 0} = d` if `h(d) >= 0` and
   `= lambda_f` if `h(d) < 0`; and `sup{lambda > d : h(lambda) < 0} = d` if
   `h(d) >= 0`, `= lambda_f` if `h(d) < 0`.  (At `h(d) = 0`, i.e.
   `Delta = d^2(d-2)/(d-1)`, both are `d = lambda_f`.)  This is `lambda_1 -> max(d,lambda_f)`.

*Step 4 (`lambda_2`, case `lambda_f < d`, i.e. `2(d-2) < Delta < d^2(d-2)/(d-1)`).*
   Let `2 sqrt(d-1) < a < lambda_f < b < d` with `a, b` in `W_eps` and `h(a) < 0 < h(b)`
   (possible since `h` is increasing with `h(lambda_f) = 0`).  On `E_n` intersected with
   `{Sigma_n(a) < 0 < Sigma_n(b)}` (probability `-> 1` by (H_pt)), monotonicity on
   `(lambda_2(A_n), d)` gives a root in `(a,b)` - hence an eigenvalue of `A_n'` in
   `(a,b)` - and gives no root in `(b,d)`; no eigenvalue of `A_n` lies in `(a,d)`
   either.  So `lambda_2(G_n') in (a,b)` with probability `-> 1`.  Letting
   `a uparrow lambda_f`, `b downarrow lambda_f` along rationals gives
   `lambda_2(G_n') -> lambda_f = min(d, lambda_f)`.

*Step 5 (`lambda_2`, case `lambda_f > d`, i.e. `Delta > d^2(d-2)/(d-1)`).*
   Upper: `lambda_2(G_n') <= d` by Lemma C(ii), deterministically.
   Lower: by Lemma C(iii) `lambda_1(G_n') -> lambda_f > d`, and the elementary
   Rayleigh-quotient bound (dossier Lemma C, unconditional) gives an eigenvalue of
   `A_n'` within `|Delta - d|/sqrt(n+1)` of `d`.  For large `n` that eigenvalue is
   `< lambda_1(G_n')`, hence it is `<= lambda_2(G_n')`, so
   `lambda_2(G_n') >= d - |Delta-d|/sqrt(n+1) -> d`.  Hence `lambda_2 -> d = min(d,lambda_f)`.

*Step 6 (`lambda_f` at the edge, `Delta <= 2(d-2)`).*  Then `min(d,lambda_f) = 2 sqrt(d-1)`
   and `max(d,lambda_f) = d`.  Step 3 already gives `lambda_1 -> d`.  For `lambda_2`:
   `h > 0` on all of `(2 sqrt(d-1), d)` (strictly increasing, `h(edge) >= 0`), so by the
   sign sandwich `Sigma_n > 0` on `(2 sqrt(d-1)+eps, d)` with probability `-> 1`; by
   Theorem A there is then no eigenvalue of `A_n'` in `(2 sqrt(d-1)+eps, d)`.
   With Lemma C(ii) (`<= d`) and interlacing `lambda_2(G_n') >= lambda_2(G_n)` this gives
   `lambda_2(G_n') in [lambda_2(G_n), 2 sqrt(d-1)+eps]`, and the known two-sided limit
   `lambda_2(G_n) -> 2 sqrt(d-1)` (import F1 + Alon-Boppana; see Sec. 10) yields
   `lambda_2 -> 2 sqrt(d-1)`.  `[]`

**Corollary F' (two-point localisation; no uniformity, no rate, no subsequences).**
Let `a < b` be rationals in `W_eps` with `h(a) < 0 < h(b)`.  Then

    P( lambda_2(G_n') not in (a,b) ) <= P( Sigma_n(a) >= 0 ) + P( Sigma_n(b) <= 0 ) + P( E_n^c ).

So, for each target accuracy, **two** scalar convergence statements at two fixed real
energies suffice.  The same holds for `lambda_1` with a pair in `(d, inf)`.  Nothing is
required about correlation between different `lambda`, and no statement about complex
energies is used anywhere in this file.

--------------------------------------------------------------------------
## 10. Imported inputs, with version, statement and hypotheses checked

**F1.**  C. Bordenave, *A new proof of Friedman's second eigenvalue theorem and its
extension to random lifts*, arXiv:1502.04482v4 (5 Mar 2019), Ann. Sci. ENS (to appear).
Statement quoted verbatim from the abstract: "a random `d`-regular graph has nearly the
largest possible spectral gap, more precisely, the largest absolute value of the
non-trivial eigenvalues of its adjacency matrix is at most `2 sqrt(d-1) + o(1)` with
probability tending to one as the size of the graph tends to infinity"; the paper says
it gives a new proof of Friedman's theorem.
Hypotheses checked: fixed `d`, uniform random `d`-regular **simple** graph, `n -> inf`,
no condition on `Delta` or on `T` - all satisfied here.  Used only for the *upper* bound
`lambda_2(A_n) <= 2 sqrt(d-1) + eps` (and, in Step 6, for `|lambda_n| <= 2 sqrt(d-1)+eps`
together with Alon-Boppana).
Original: J. Friedman, *A proof of Alon's second eigenvalue conjecture and related
problems*, Memoirs AMS 195 (2008), no. 910 - same statement.  **Caveat:** I did not
open the PDFs in this run, so the theorem *number* inside F1 is not certified here; the
statement is the one in the arXiv abstract, which is what the proof uses.  A reviewer
should record the internal number.

**F2.**  R. Bauerschmidt, J. Huang, H.-T. Yau, *Local Kesten-McKay law for random
regular graphs*, arXiv:1609.09052v3, Comm. Math. Phys. 369 (2019) 523-636.
**Not used.**  Its abstract restricts to the bulk `[-2 sqrt(d-1)+eps, 2 sqrt(d-1)-eps]`
("in the bulk of the spectrum ... down to the optimal spectral scale"), so it does not
supply (H_pt) at real exterior energies; the batch source-baseline already flags the
mismatch of the domain `D` (complex `z`, `Im z >= (log N)^{48 alpha+1}/N`).  Recording
this as the precise reason the target is still open, not as an import.

**Dossier Lemma C** (Rayleigh quotient at `1`): elementary, reproved in the dossier,
`|lambda - mean degree| <= ||(A - dI) 1/sqrt(N)|| = |Delta - d|/sqrt(n+1)`; no import.

## 11. The remaining estimate, stated exactly

**(H_pt)** (missing).  `d >= 3` fixed, `T_n` fixed with `|T_n| = Delta` fixed, `G_n`
uniform random simple `d`-regular.  For each fixed `lambda > 2 sqrt(d-1)`,

    1_{T_n}^T (A_n - lambda I)^{-1} 1_{T_n}  ->  -Delta G_d(lambda)  in probability.

By Lemma E this is *equivalent* to the dossier's uniform-on-compacts (H).  By
Corollary F' it is needed only at finitely many points per accuracy target.  It is not
weakened further by anything in this file; in particular the vertex-average statement
`(1/n) tr (A_n - lambda I)^{-1} -> -G_d(lambda)` (which does follow from moment
convergence plus F1) does **not** imply it (Sec. 7).

**Heuristic for (H_pt) and its testable predictions.**  Expand the resolvent over
nonbacktracking paths of the host.  A path of length `k` carries weight `O(r(lambda)^k)`
with `r(lambda) < 1/sqrt(d-1)`, and the tree contributes exactly `-Delta G_d(lambda)`.
Nontrivial (cyclic) patterns give a correction with mean of order `1/n` and variance of
order

    (1/n) * sum_{l >= 3} ((d-1) r(lambda)^2)^l / l,

which is finite **iff** `(d-1) r(lambda)^2 < 1`, i.e. **iff** `lambda > 2 sqrt(d-1)`.
So the heuristic predicts `sd = Theta(n^{-1/2})` with a constant blowing up like
`(lambda - 2 sqrt(d-1))^{-1/4}` as the edge is approached - and it also predicts that
(H) *must* fail at the edge itself, which is consistent with the fact that the bulk
local law is a genuinely harder statement.  This is a proposed route, not a proof: the
centring of the cyclic-pattern sum (the "factor `n^{-1}`" issue flagged in the dossier's
Sec. 4, item 3(c)) is exactly the unproved step, and it is direction d1's/d4's terrain.

**Numerical test of the prediction** (`out/fluct_scaling.txt`, certified-uniform
sampler, 8 seeds, `d = 3`, `Delta = 3`): `sd(Sigma_n(lambda))` at
`lambda = 4.0`: `6.2e-3, 4.6e-4, 1.3e-4, 1.4e-4` for `n = 1000, 2000, 4000, 8000`, i.e.
`sd * sqrt(n) ~ 0.2, 0.02, 0.009, 0.012` (consistent with `n^{-1/2}` and tiny bias
`-2.9e-3 -> -7.3e-5`); at `lambda = 3.3`: `sd*sqrt(n) ~ 0.84, 0.13, 0.08, 0.11`; at
`lambda = 2.95`: `sd*sqrt(n) ~ 3.8, 0.87, 0.75, 0.96`, bias `0.20, 0.12, 0.057, 0.029`
(decaying only like `n^{-1/2}`, i.e. no rate is uniform near the edge); at
`lambda = 2.86` (distance `0.03` from the edge) the standard deviation is still `0.045`
at `n = 8000` and the bias decays slowly.  Conclusion: (H_pt) is numerically supported
away from the edge, the fluctuations are `n^{-1/2}`, and **no uniform-in-`lambda`
statement on a window closing on `2 sqrt(d-1)` should be claimed** - which is consistent
with Lemma E being a compact-subset statement only.

## 12. Numerical corroboration of the law (evidence, not proof)

`out/finite_root_test.txt`: certified-uniform sampler (configuration model conditioned
on simplicity, rejection; acceptance `-> exp(-(d^2-1)/4)`, hence `d <= 4`; fixed seeds;
`networkx.random_regular_graph` is **not** used because it is not a certified uniform
sampler).  Residual check of Theorem A at the computed eigenvalues of `G_n'`:
`|Sigma_n(lambda_i(G_n'))| <= 2e-12` for `(d,Delta) = (3,3), (3,6)`, `n = 4000`.

    (d,Delta)=(3,4), lambda_f = 2.94697, bulk edge 2.82843:
        lambda_2 = 2.9266, 2.9281, 2.9367, 2.9461   (n = 1000, 2000, 4000, 8000)
    (d,Delta)=(3,6), lambda_f = 3.18070 > d = 3:
        lambda_1 = 3.2001, 3.2101, 3.1876, 3.1830 ; lambda_2 = 2.9667, 2.9852, 2.9913, 2.9955
    (d,Delta)=(3,1),(3,2) (Delta <= 2(d-2)):  lambda_2 = 2.825..2.827 ~ 2 sqrt(d-1), lambda_1 ~ 3.000
    (d,Delta)=(4,5), lambda_f = 3.48786:       lambda_2 = 3.4867, 3.4865, 3.4790, 3.4823
    (d,Delta)=(3,3), lambda_f = 2.86289:       lambda_2 = 2.8470, 2.8607, 2.8905, 2.8614

The `(3,4)` and `(3,6)` rows discriminate the finite-root law from the tree law (which
predicts no exterior eigenvalue, i.e. `lambda_2 -> 2 sqrt(d-1)` and `lambda_1 -> d`):
the observed gaps are `0.12` and `0.18`, far above the observed `n^{-1/2}` noise.
The `(3,3)` row is **not** decisive at these sizes: `lambda_f` is only `0.035` above the
bulk edge, comparable to the fluctuation scale measured in Sec. 11.  Sampler limits
stated: `d <= 4`, `n <= 8000`, 8 seeds, rejection sampling, no confidence intervals
claimed.

## 13. What this file does not claim

- (H_pt) is not proved, so Theorem F is a conditional theorem (Tier 2 of the batch
  README: "a complete conditional root theorem with one precisely stated resolvent
  lemma whose proof is still missing"), not a Tier 1 fixed-degree limit theorem.
- No rate, no `1/sqrt(n)` law, no uniformity in `lambda` near `2 sqrt(d-1)`.
- No claim about eigenvalues inside the bulk of `G_n'`, and no claim about complex
  energies for `G_n`.  The `O(1/n)` finite-size law `d - lambda_2 ~ Delta^2/(n(Delta
  G_d(d) - d))` of the dossier is *not* reproved here: Theorem F gives only the limit;
  the finite-size law needs derivative-level control of `Sigma_n` uniformly at scale
  `1/n` around `d`, which (H_pt) does not provide.
- Nothing here is formalised in Lean; no statement in this file is machine checked.
