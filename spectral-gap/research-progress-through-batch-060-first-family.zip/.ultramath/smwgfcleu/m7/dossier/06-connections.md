# Common ground with the four source dossiers and with the other board directions

## 1. With `alon-second-eigenvalue` (Friedman, Alon's conjecture)

Same threshold, different model. Friedman's theorem is about a uniformly random
$d$-regular graph, which is a random finite quotient of $T_d$ with trivial deck
group. The Cayley question is the same question with the extra requirement that
the quotient be a regular cover of the one-vertex graph, that is, that the deck
group act regularly. The two mechanisms named in the dossier transfer as
follows.

* *Local limit.* For a random Cayley graph the ball of radius $r$ around the
  identity is a tree with probability $1 - O(d^{2r}/|G|)$, so up to radius
  $r \asymp \tfrac12 \log_{d}|G|$ the local limit is $T_d$ exactly. This is the
  same range that Friedman's method uses.
* *Tangents and rare defects.* A "tangle" in a random regular graph is a small
  subgraph with too many cycles. In a Cayley graph the tangle set is
  structured: it consists of short relations (words of length $2r$ in $S$ that
  evaluate to the identity) and of cosets of subgroups that capture many
  elements of $S$. The exact data in `04-computations.md` show that both occur
  and that at degree 3 the subgroup type is not enough.

Difference in difficulty: for random regular graphs the tangles are
configuration-model artefacts with computable expected counts. For Cayley
graphs the relation count depends on the subgroup and word structure of $G$,
which is exactly the "established group theory" input that no existing proof
supplies uniformly.

## 2. With `biregular-spectral-gap` (Brito-Dumitriu-Decker Harris)

The biregular threshold is $\sqrt{d_1-1}+\sqrt{d_2-1}$, which is $\rho$ of the
biregular tree, confirmed independently in `02-literature.md` from the
Feng-Li statement quoted by Mohanty-O'Donnell. The relevant transfer is the
*trivial eigenpair* phenomenon. In a bipartite $(d_1,d_2)$-biregular graph the
top and bottom eigenvalues are $\pm\sqrt{d_1d_2}$, and the Ramanujan condition
has to be stated on the remaining spectrum. Proposition 4 of `03-theory.md` is
the exact analogue for Cayley graphs: if $S$ avoids an index two subgroup, the
bottom eigenvalue is $-d$ and no two-sided Ramanujan statement is possible.

A concrete bridge: the bipartite double cover of $\mathrm{Cay}(G,S)$ is
$\mathrm{Cay}(G \times \mathbb{Z}_2, S \times \{1\})$, and its spectrum is the
union of the spectrum of $A$ and the spectrum of the signed adjacency
$\sum_{s \in S}\mathrm{sgn}(s) P_s$. So the biregular machinery (singular
values of biadjacency matrices, the quartic Ihara-Bass relation of the dossier)
applies to that double cover, and the "bipartite Ramanujan" question for
Cayley graphs is a question about the signed part.

## 3. With `friedman-second-eigenvalue-lifts` (Bordenave)

Bordenave's Theorem 23 covers random lifts of a connected base with
$|E|>|V|$, and Corollary 24 converts the non-backtracking bound into the
adjacency bound only under regularity. A Cayley graph is a lift of the
one-vertex graph with $d$ loops. That base has $|E| = |V| = 1$, Euler
characteristic zero, so the theorem's hypothesis fails exactly here, and the
"old" spectrum of the base is just $\{d\}$, so every nontrivial eigenvalue of
the Cayley graph is a "new" eigenvalue. In this sense the Cayley case is the
boundary case of the whole lift theory: the base is as small as possible and
the deck group is as large as possible.

The useful transfer is the *non-backtracking* viewpoint. For a Cayley graph the
non-backtracking matrix acts on pairs of generators and its Perron value is the
growth rate of relation-free words, which is the tree value unless $G$ has
short relations. The Ihara-Bass dictionary $\mu^2-\lambda\mu+(d-1)=0$ of the
dossier is what turns a non-backtracking bound at $\sqrt{d-1}$ into an
adjacency bound at $2\sqrt{d-1}$, and it applies unchanged.

## 4. With `relativized-second-eigenvalue` (Friedman and Kohler)

The relativized theory defines the exceptional exponent through *strict
feasible tangles*: connected $B$-graphs $L$ with
$\rho(H_L) > \rho(H_B)^{1/2}$, and the theorem excludes an $O(n^{-1})$
exceptional event for regular bases of negative Euler characteristic. For
Cayley graphs the base is the one-vertex graph, again the excluded
degenerate case, and the tangles are exactly the finite subgraphs of the Cayley
graph with large non-backtracking radius. Two families are visible:

* subgroup tangles: a coset of a subgroup $H$ with many $S$-elements,
  quantified here by Proposition 5,
* relation tangles: short cycles and small quotients of the Cayley 2-complex,
  visible in the girth data and responsible for all 240 failures in $A_5$ at
  degree 3.

The exact analogue of the fundamental exponent $\eta_{\mathrm{fund}}$ is the
quasi-index $N(\theta,\cdot)$ of this dossier, which by Corollary 2 is a sum of
irreducible degrees: in the relativized picture the exceptional eigenvalues come
in blocks of size $f_\rho$, and the "order" of the obstruction is replaced by
the degree of the offending representation.

## 5. With the other board directions

**d5 (character and code duality on $\mathbb{F}_2^r$, member m6).** That is the
abelian special case of the present question. The exact dictionary
$\lambda_2 = d - 2 d_{\min}(C)$ is sharper than Proposition 6 for elementary
abelian 2-groups, and the observation that connectivity forces $r \le d$ (so
$N = 2^r \le 2^d$) is stronger than the pigeonhole bound in that range. The
general abelian case (large cyclic quotients) is where the pigeonhole argument
is needed, and there the exponent $-2/k$ is sharp by Hermon and Olesker-Taylor.
The two results should be read together: $\mathbb{F}_2^r$ is bounded by
coding theory, $\mathbb{Z}_n$ by Diophantine approximation, and both conclude
that no fixed-degree abelian family is Ramanujan.

**d6 (one-sided directed spectra, member m2).** Circulants are exactly the
Cayley graphs of abelian groups, so d6's "$\sqrt d$ versus $2\sqrt{d-1}$"
dichotomy is the directed counterpart of Proposition 6. The hinge there is
normality (for normal digraphs singular values equal $|\lambda|$), which is
automatic for the undirected symmetric case studied here. The two-sided
convention in this dossier is the undirected shadow of that dichotomy.

**d4 (relative spectra of covers, member m4).** Proposition 1 is the
one-vertex-base case of d4's formula
$\mathrm{spec}(G) = \bigcup_\rho \mathrm{spec}(A_\rho)$. My direction is the
case their hypothesis (irregular base, non-constant top eigenvector) excludes.
Their "spectral radius of the irregular universal cover replaces
$2\sqrt{d-1}$" is the general phenomenon. Here the cover is always $T_d$ and
the replacement is instead made by the block structure.

**d2 (band edge sampling in abelian covers, member m1).** For
$\mathbb{Z}^r$-periodic graphs the exact $\lambda_2$ is a lattice-point problem
near a critical point of a Bloch band. Proposition 6 is the crude version of
the same mechanism for the one-vertex base: the Dirichlet pigeonhole is a
lattice-point argument in the dual torus, with the exponent $-2/k$ instead of
the exact rate. d2's exact band-edge constants are what the abelian case of
this program would need for sharpness.

**d1 (hypergraph gap normalisation, member m8).** Different objects, same
question shape: which spectral parameter is the honest gap. d1 analyses the
multiplicity of the Perron value of the clique expansion. Here the multiplicity
question is answered by Corollary 2 for graphs, where the Perron value is
always simple and the multiplicities are the irreducible degrees. The
$\lambda_3$, $\lambda_4$ question is therefore a representation-theoretic
question in this setting and a trivial-spectrum question in d1's setting.

**d3 (single-defect spikes, member m5).** The coset certificate of Proposition
5 can be read as a *symmetry defect* producing an outlier in exactly the sense
of d3's spike: a subgroup of index $m$ capturing $d_H$ of the $d$ generators
produces an eigenvalue at least $d_H - O(1/m)$, just as a vertex of degree
$\Delta$ produces an outlier at about $\Delta/\sqrt{\Delta-d+1}$. The two
formulas are different (the spike formula comes from the tree recursion, the
coset formula from a Rayleigh quotient) but the structural statement is the
same: a bounded number of defects cannot move the bulk edge, while each defect
contributes an outlier at a computable location. d3's dichotomy and this
dossier's Proposition 5 are two instances of one principle.

**d8 (Seidel multiplicity duality, member m3).** Both directions end with a
"duality of the extremal object": in the Ramanujan problem the extremal object
is an edge of the spectrum and the quantity of interest grows with $n$, in the
Seidel problem the extremal object is a multiplicity. The quasi-index
$N(\theta,\cdot)$ is the meeting point: it counts how many eigenvalues sit
beyond the threshold, and by Corollary 2 it is a multiplicity-like invariant.
