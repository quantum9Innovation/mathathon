# Fixed-set exterior resolvent limits for random regular graphs: proof of (H), and the finite-pattern correction

m6, swarm `smwgwbyn9`, direction d4 (role 1: bounded-local-cycle concentration and
finite-pattern resolvent corrections).

Status legend: **(P)** proved below in full; **(C)** exact computation; **(N)** numerics,
reproducible, not a proof; **(L)** literature import with version and hypotheses;
**(S)** conjecture / not proved here.

---

## 0. Executive summary

1. **(P) Theorem A.** For fixed `d >= 3`, a fixed finite set `T` of *vertex labels*, and
   `G_n` uniform random simple `d`-regular on `[n]`, the batch hypothesis **(H)** is TRUE,
   in the strong form demanded by the brief: for every compact
   `K ⊂ (2√(d-1), d) ∪ (d, ∞)`,
   ```
   sup_{λ∈K} | 1_T^T (A_{G_n} - λ I)^{-1} 1_T  +  Δ G_d(λ) |  →  0   in probability,
   ```
   and more strongly `sup_{z∈K}|1_T^T(z-A)^{-1}1_T - ΔG_d(z) - Δ²/(n(z-d))| → 0` on
   compacts of `ℂ∖[-2√(d-1)-η, 2√(d-1)+η]`.
   The proof is elementary and does not use any local law: absolutely convergent walk
   expansion at `|z| > d` (where `||A|| ≤ d` makes the series converge uniformly in `n`),
   fixed-radius tree-likeness of the neighbourhood of a fixed label set with an explicit
   `O(1/n)` failure probability, and a stochastic Vitali theorem (Lemma 3) which
   propagates the limit off `|z| > d` using only analyticity and the deterministic bound
   `spec A_n ⊆ [-d,d]`. The only place a spectral input is used is the event
   `spec(A_n)∖{d} ⊆ [-2√(d-1)-η, 2√(d-1)+η]`, which holds with probability `→ 1` by
   Friedman's theorem. **The analytic-continuation step is Lemma 3, and its hypothesis is a
   *pointwise, `n`-independent* boundedness condition (α2), not a tightness condition**:
   the first version of this note used tightness ("for each compact `K` there is `M_K` with
   `P(sup_K|F_n| > M_K) → 0`"), from which no pathwise bound on the family follows, so
   Montel had nothing to apply to; that formulation is withdrawn and replaced by (α2) plus
   a diagonal-extraction/identity-theorem identification of the limit (§3.2).
   **The one structural subtlety**, treated in §3.3, is that
   `z ↦ 1_T^T(z-A)^{-1}1_T` has a *Perron pole at `z = d`* for every `n`, so the window
   `(2√(d-1), d)` cannot be reached by analytic continuation without first removing that
   pole; the rank-one term removed is exactly `Δ²/(n(z-d))`, which is the `O(1/n)`
   correction of the dossier's §2.5 finite-size law.

2. **(P) Theorem B, the finite-pattern correction.** The batch statement `-ΔG_d(λ)` is the
   limit only for *asymptotically separated* attachment sets. For a bounded-diameter
   pattern the limit is the resolvent of the **local limit gadget**:
   ```
   1_T^T (z - A_{G_n})^{-1} 1_T  →  1_T^T (z - A_{G_∞})^{-1} 1_T
                                  =  G_d(z) Σ_{s,t∈T} r(z)^{dist(s,t)} ,
   ```
   which for adjacent attachment vertices or for `T = N(c)` differs from `Δ G_d` by a
   factor of order 1. Two closed forms are derived exactly:
   * `T = {adjacent s,t}`, `Δ = 2`: limit `G_d(λ)(2 + 2 r)`.
   * `T = N(c)`, `Δ = d`: limit `d λ r/(λ - d r)`.
   At `d=3, λ=3.2` the second is `2.1264` against the batch value `1.5605` (36%);
   measured `2.1273` (N).

3. **(P) Lemma 1** supplies a *certified* uniform sampler: the pairing model conditioned
   on simplicity is exactly uniform (each simple `d`-regular graph has exactly `(d!)^n`
   realizations), and `P(simple) = e^{-(d²-1)/4+O(1/n)}`. The latter is now taken from a
   source read directly (Angel–van der Hofstad–Holmgren, arXiv:1603.07172v2, Cor. 1.2
   eq. (1.15) with eq. (1.16); PDF kept locally), replacing a citation in the first
   version that was quoted from memory and is withdrawn. This removes the
   `networkx.random_regular_graph` caveat from the batch's numerics.

4. What is **not** done here: the passage from the resolvent limit to the limiting
   eigenvalue law (root bookkeeping, host-pole exclusion, ordering) is not re-proved
   (§5). Theorem A discharges exactly hypothesis (H); the remaining content of the
   dossier's Proposition D is separate.

---

## 1. Setting and conventions

Fix `d ≥ 3`. `A = A_{G_n}` is the adjacency matrix of a simple graph on `[n] = {1,…,n}`,
all degrees `d`; hence `spec(A) ⊆ [-d,d]` and `||A|| ≤ d`. `1_T` is the indicator of
`T ⊆ [n]`.

**Kesten–McKay data.** For `z ∉ [-2√(d-1), 2√(d-1)]` let `r(z)` be the root of
```
(d-1) r + 1/r = z ,     |r(z)| < 1/√(d-1)
```
(for `z > 2√(d-1)` real, `0 < r(z) < 1/√(d-1)` and `r` is strictly decreasing). Put
```
G_d(z) := ∫ dμ_{KM,d}(x)/(z - x) = r(z)/(1 - r(z)²) = 1/(z - d r(z)).
```
Both are analytic and nonvanishing on `ℂ ∖ [-2√(d-1), 2√(d-1)]`, and for `z > 2√(d-1)`,
`G_d(z) > 0`.

**Tree resolvent (C).** Let `T_d` be the infinite `d`-regular tree. For `z` in the above
domain and vertices `u,v`,
```
(z - A_{T_d})^{-1}_{uv} = G_d(z) r(z)^{dist(u,v)} .
```
*Proof.* Schur complement at `u`: each of the `d` neighbours roots a one-sided tree whose
root self-energy `s := -(A_{D}-z)^{-1}_{oo}` equals `r(z)` (the one-sided rooted
resolvent is `-r`, [m5 dossier, Lemma 1]); hence
`(z-A)^{-1}_{uu} = (z - d s)^{-1} = 1/(z - d r) = G_d`, and
`(z-A)^{-1}_{u,v} = -G_d · (-s)·(neighbour-to-v pass) `, giving the factor `r` per edge of
the geodesic. ∎

**Model.** (Uniform simple `d`-regular graphs.) The **pairing model** `P_n`: attach `d`
labelled stubs to each vertex `i ∈ [n]` and pick a uniformly random perfect matching of the
`nd` labelled stubs; let `Γ` be the resulting multigraph. Write `S_n` for the event that
`Γ` is simple.

**Lemma 1 (P) (exact uniformity; conditioning is harmless).**
(i) Each simple `d`-regular graph on `[n]` arises from exactly `(d!)^n` pairings. Hence
`Γ | S_n` is exactly uniform on simple `d`-regular graphs.
(ii) **(L) verified in the source** With `d ≥ 3` fixed and `nd` even,
`P(S_n) = exp(-(d²-1)/4 + O(1/n))`. In particular `P(S_n) ≥ c_d > 0` for all `n ≥ n_0(d)`.

*Proof.* (i) Given a simple `d`-regular `G` and a pairing realizing it, for every vertex
`v` the pairing induces a bijection from `v`'s `d` labelled stubs onto its `d` neighbours;
conversely any choice of one such bijection for every `v` determines the pairing. So the
number of pairings realizing `G` is `∏_v d! = (d!)^n`, independent of `G`.

(ii) *Source, read directly (PDF downloaded and converted to text; copy kept at
`papers/avhh.pdf`, `papers/avhh.txt`).* O. Angel, R. van der Hofstad and C. Holmgren,
*Limit laws for self-loops and multiple edges in the configuration model*,
arXiv:1603.07172v2 (2 Feb 2017); Electron. Commun. Probab. 22 (2017), paper no. 27.
**Corollary 1.2, eq. (1.15)** (text line 213 of `papers/avhh.txt`) states, verbatim in the
extracted text: the number `N_n(r)` of `r`-regular graphs with `n` vertices satisfies, when
`rn` is even,
`N_n(r) = e^{-(r-1)/2-(r-1)²/4+O(1/n)} (rn-1)!!/(r!)^n`.
**Eq. (1.16)** of the same paper states `P(CM_n(d)` simple`) = N_n(d) ∏_i d_i!/(ℓ_n-1)!!`,
which is *identical* to the counting identity proved in (i) above (`ℓ_n = nd`), so combining
them with `d_i = d` gives
`P(S_n) = e^{-(d-1)/2-(d-1)²/4+O(1/n)} = e^{-(d²-1)/4+O(1/n)}`,
using `(d-1)/2 + (d-1)²/4 = (d-1)(d+1)/4 = (d²-1)/4`. *Hypotheses checked:* fixed `r = d`,
`rn` even (our `n` is chosen so that `nd` is even), the degree sequence is exactly regular
(`d_i = d`), and the error term is `O(1/n)` in exactly this fixed-degree regime. The same
paper's Theorem 1.1, eq. (1.13), independently gives
`P(S_n = M_n = 0) = e^{-λ^S_n-λ^M_n} + r_n` with `λ^S_n → (d-1)/2`, `λ^M_n → (d-1)²/4`,
`r_n → 0`, which is the same limit. This replaces an earlier citation of mine that was
quoted from memory and is withdrawn. ∎

**Corollary 1.1.** `P_{P_n}(B | S_n) ≤ P_{P_n}(B)/P_{P_n}(S_n) ≤ 2 e^{(d²-1)/4} P_{P_n}(B)`
for all `n ≥ n_0(d)`. Any event of `P_n`-probability `O(1/n)` therefore has
`P_n(·|S_n)`-probability `O(1/n)`.

---

## 2. Lemma 2 (P): fixed-radius tree-likeness at a fixed label set

Let `Δ ≥ 1`, `K ≥ 1`, and let `T = {1,…,Δ}` be a fixed set of labels. Write
`B_K(T) = ∪_{t∈T} B_K(t)` for the induced subgraph on vertices at distance `≤ K` from `T`,
rooted at `T`. Let `F_K` be the disjoint union of `Δ` copies of the radius-`K` ball of the
`d`-regular tree rooted at a vertex (a labelled rooted forest; "the tree answer").

**Lemma 2.** There is `C = C(Δ,K,d)` with
```
P( B_K(T) ≅ F_K as rooted graphs )  ≥  1 - C/n
```
both under `P_n` and under `P_n(·|S_n)`.

*Proof.* Work under `P_n` and reveal `B_K(T)` by successive revelation of partners of open
stubs, starting from the `Δ` roots, processing stubs in order of the depth of their vertex,
and stopping when every stub of every vertex at depth `< K` has been matched. Let `R` be
the total number of pairs revealed; `R ≤ Δ(1 + d + … + d^{K}) ≤ Δ d^{K+1} =: R_0`.

Conditionally on the history, the partner of a chosen open stub is uniform among the
remaining unmatched stubs, of which there are at least `nd - 2R_0`. The ball fails to be
`F_K` only if some revealed partner is a stub of an already explored vertex (this creates a
cycle or identifies two roots, or a multi-edge/loop) or two revealed pairs share an
endpoint. At each revelation the number of such forbidden stubs is at most `2R_0 + Δd`.
Hence, for `n` with `nd ≥ 4R_0`,
```
P(failure)  ≤  R_0 · (2R_0 + Δd)/(nd - 2R_0)  ≤  C_1/n .
```
For the conditional statement use Lemma 1(ii). ∎

**Corollary 2.1.** On the event of Lemma 2, for every `k ≤ K` the number of walks of
length `k` with both endpoints in `T` equals the tree answer. Indeed a walk of length `k`
starting in `T` remains in `B_k(T) ⊆ B_K(T)`, and distinct tree components cannot be joined
by a walk of length `k ≤ K` because their distance exceeds `2K`. Also, no walk leaves
`B_k(T)`. Hence
```
(A^k)_{T,T} := 1_T^T A^k 1_T = Δ c_k   on that event,
```
where `c_k` is the number of closed walks of length `k` from the root of `T_d`, and
`c_k ≤ d^k`.

---

## 3. Theorem A (P): proof of hypothesis (H) for a fixed label set

**Theorem A.** Fix `d ≥ 3`, `Δ ≥ 1`, the label set `T = {1,…,Δ}`, and `η > 0`. Put
`b_η := 2√(d-1) + η`, `Ω_η := ℂ ∖ [-b_η, b_η]`, and for connected `G_n` let `P_n = 11^T/n`
be the Perron projector, so that
```
F_n(z) := 1_T^T (z - A_{G_n})^{-1} 1_T ,      F_n^⊥(z) := 1_T^T (z - A_{G_n})^{-1}(1 - P_n)1_T
        = F_n(z) - Δ²/(n (z - d)) .
```
Then:
**(a)** for every compact `K ⊂ Ω_η`,
`sup_{z∈K} |F_n^⊥(z) - Δ G_d(z)| → 0` in probability;
**(b)** hence, for every compact `K ⊂ (2√(d-1), d) ∪ (d, ∞)`,
```
sup_{λ∈K} | 1_T^T (A_{G_n} - λ I)^{-1} 1_T + Δ G_d(λ) |  ⟶ 0   in probability,
```
because `|F_n(λ) - F_n^⊥(λ)| = Δ²/(n|λ - d|) ≤ Δ²/(n dist(K,d)) → 0` uniformly on `K`, and
`(A-λ)^{-1} = -(λ-A)^{-1}`.

This is exactly hypothesis (H) of the dossier, uniformly on compact subsets of the required
window, in probability, for deterministic fixed `T`.

### 3.1 Step 1 (P): pointwise convergence for `|z| > d`

Fix `z` with `|z| > d`, `t := 1/z`. Because `||A|| ≤ d` the Neumann series converges
absolutely, uniformly in `n` and in the graph:
```
F_n(z) := 1_T^T (z - A)^{-1} 1_T = Σ_{k≥0} t^{k+1} (A^k)_{T,T},   |(A^k)_{T,T}| ≤ Δ² d^k .
```
By Corollary 2.1 and the same absolute convergence in the tree,
`Δ G_d(z) = Δ Σ_{k≥0} t^{k+1} c_k`.

Fix `K` and let `E_K(n)` be the good event of Lemma 2. On `E_K(n)`,
`Σ_{k≤K} t^{k+1}(A^k)_{T,T} = Δ Σ_{k≤K} t^{k+1} c_k`. Both remainders are bounded by
```
Σ_{k>K} |t|^{k+1} Δ² d^k  =  Δ² |t| (|t| d)^{K} /(1 - |t| d)  =:  ρ_K → 0  (K→∞),
```
using `|t|d < 1`. Hence
```
P( |F_n(z) - ΔG_d(z)| > 2ρ_K )  ≤  C_K/n ,
```
and letting `n→∞` then `K→∞` gives `F_n(z) → ΔG_d(z)` in probability. ∎

### 3.2 Step 2 (P): a stochastic Vitali lemma, with the boundedness hypothesis repaired

The version used in the first submission asserted that modifying `F_n` on its
tightness-exceptional sets produces a family that is deterministically bounded on every
compact. That does **not** follow from tightness in the form "for each compact there is
`M_K` with `P(sup_K|F_n| > M_K) → 0`": tightness constrains one compact at a time and gives
no common pathwise bound, so Montel's theorem had no family bound to apply to. The repair
is (α) to state the boundedness hypothesis *pointwise in `z` with an `n`-independent
bounding function*, exactly the form our application supplies, and (β) to carry out the
identification of the subsequential limit by a diagonal extraction plus the identity
theorem, so that no unproved pathwise statement is used anywhere.

**Lemma 3 (stochastic Vitali).** Let `Ω ⊂ ℂ` be a connected domain and `L : Ω → ℂ`
holomorphic. For each `n` let `F_n : Ω × Ω_ω → ℂ` be random and `E_n` an event with
`P(E_n) → 1`, such that
- **(α1)** for every `ω ∈ E_n`, `F_n(·,ω)` is holomorphic on `Ω`;
- **(α2)** there is a *continuous* `h : Ω → [0,∞)`, **not depending on `n`**, with
  `|F_n(z,ω)| ≤ h(z)` for **every** `z ∈ Ω`, **every** `n` and **every** `ω ∈ E_n`;
- **(β1)** there is a nonempty open `U ⊆ Ω` with `F_n(z) → L(z)` in probability for every
  `z ∈ U`.

Then for every compact `K ⊂ Ω`, `sup_{z∈K}|F_n(z) - L(z)| → 0` in probability.

*Proof.* Define `G_n := F_n` on `E_n` and `G_n := L` on `E_n^c`. Then for every `n` and
every `ω`:
1. `G_n(·,ω)` is holomorphic on `Ω` (it is `F_n(·,ω)` or `L`);
2. `|G_n(z,ω)| ≤ max(h(z), |L(z)|) =: H(z)` for all `z ∈ Ω`, where `H` is continuous and
   `n`-independent. This is the pointwise statement that replaces the invalid one: no
   exceptional set survives in the bound, and `H` does not depend on `K` or `n`;
3. for `z ∈ U`, `P(|G_n(z) - L(z)| > ε) ≤ P(E_n^c) + P(|F_n(z) - L(z)| > ε) → 0`.

By 1 and 2, `{G_n}` is locally bounded by the continuous function `H`, so it is a normal
family: every subsequence has a further subsequence converging locally uniformly on `Ω` to
a holomorphic limit (`Montel`).

Fix a compact `K ⊂ Ω` and let `D ⊂ U` be countable and dense in `U`. Let `(n_j)` be any
subsequence. By normality, along a further subsequence `G_{n_j} → G` locally uniformly on
`Ω`, `G` holomorphic on `Ω`. By 3 and countability of `D`, along a further subsequence
`G_{n_j}(z) → L(z)` simultaneously for all `z ∈ D`, off a null set. On that set,
`G(z) = L(z)` for every `z ∈ D`; `D` has accumulation points in the domain `Ω` (it is dense
in the nonempty open `U`), and `Ω` is connected, so the identity theorem gives `G ≡ L` on
`Ω`; in particular uniform convergence on `K` gives `sup_K|G_{n_j} - L| → 0` a.s.

Hence every subsequence of `(G_n)` has a further subsequence along which
`sup_K|G_n - L| → 0` a.s., which is equivalent to `sup_K|G_n - L| → 0` in probability.
Finally `P(sup_K|F_n - L| > ε) ≤ P(E_n^c) + P(sup_K|G_n - L| > ε) → 0`. ∎

**Why (α2) and not tightness.** (α2) is strictly stronger than "for every compact `K` there
is `M_K` with `P(sup_K|F_n| > M_K) → 0`, and it is what the resolvent estimates actually
give: on the spectral event `E_n` the bound `|F_n^⊥(z)| ≤ Δ/dist(z,[-b,b])` is a fixed
function of `z` and is *n-independent*, so it holds for every `z` and every `n`
simultaneously, which yields 2 above. No step of the proof needs a bound that is only
available with high probability at a chosen `n`.

### 3.3 Step 3 (P): removing the Perron pole, then propagation

Let `η > 0`, `b := 2√(d-1) + η`, `Ω := ℂ ∖ [-b,b]`, and `L(z) := ΔG_d(z)`, which is
holomorphic on `Ω`. Applying Lemma 3 directly to `F_n` cannot reach the window
`(2√(d-1), d)`: every `F_n` has a **pole at `z = d`** (the Perron eigenvalue; the residue is
`Δ²/n` because `1_T^T 1 = Δ ≠ 0`), and the point `d` separates that window from `{|z| > d}`
inside any domain on which all `F_n` are holomorphic. So the pole is removed first.

Let `G_n` be connected. Then `u_1 = n^{-1/2}1`, `A_n u_1 = d u_1`, `P_n = u_1u_1^T`, and
```
F_n^⊥(z) := 1_T^T (z-A_{G_n})^{-1}(1 - P_n) 1_T  =  F_n(z) - Δ²/(n (z-d))
```
is holomorphic on `ℂ ∖ (spec(A_n) ∖ {d})`.

For compact `K ⊂ Ω` put `δ_K := dist(K, [-b,b]) > 0` and
`E_n := {G_n` connected`} ∩ {spec(A_n)∖{d} ⊆ [-b,b]}`. On `E_n` we have
`dist(z, spec(A_n)∖{d}) ≥ δ_K` for every `z ∈ K`, hence by the spectral theorem
```
sup_{z∈K} |F_n^⊥(z)|  ≤  Δ/δ_K ,     on E_n ,
        because |F_n^⊥(z)| = |⟨1_T, (z-A)^{-1}(1-P_n)1_T⟩| ≤ ||1_T||·||(1-P_n)1_T||/dist(z,spec(A_n)∖{d}) ≤ Δ/dist(z,spec∖{d}).
```
Step 1 gives `F_n(z) → ΔG_d(z)` in probability for every `z ∈ S := (d+1,∞) ⊂ Ω`, and
`|Δ²/(n(z-d))| ≤ Δ²/(n|z-d|) → 0`, so `F_n^⊥(z) → ΔG_d(z)` in probability on the *open*
set `U := (d+1,∞) ⊆ Ω`, which is what (β1) requires. Lemma 3 now applies to the family
`F_n^⊥` on the connected domain `Ω = ℂ∖[-b,b]` with `L := ΔG_d`, `E_n` as above and
`h(z) := Δ/dist(z,[-b,b])`, and its three hypotheses are exactly what §3.3 has verified:
**(α1)** on `E_n`, `spec(A_n)∖{d} ⊆ [-b,b]`, so `F_n^⊥` is holomorphic on `Ω`;
**(α2)** on `E_n`, for **every** `z ∈ Ω` (not merely for `z` in a chosen compact and at a
chosen `n`), `|F_n^⊥(z)| ≤ Δ/dist(z, spec(A_n)∖{d}) ≤ Δ/dist(z,[-b,b]) = h(z)`, a bound
that is finite, continuous and independent of `n` on `Ω`;
**(β1)** as just noted. The conclusion of Lemma 3 is
```
sup_{z∈K} | F_n^⊥(z) - ΔG_d(z) |  →  0    in probability   for every compact K ⊂ Ω.   (†)
```
This is Theorem A(a), on a domain containing the whole window `(2√(d-1), d)` and all of
`{|z| > d}`. Theorem A(b) follows from `|F_n(λ) - F_n^⊥(λ)| = Δ²/(n|λ-d|)`.

**(L) Friedman's theorem** (used only to show `P(E_n) → 1`). For fixed `d ≥ 3` and every
`η > 0`, a uniform random simple `d`-regular graph on `n` vertices satisfies
`max_{2 ≤ i ≤ n}|λ_i| ≤ 2√(d-1) + η` with probability `→ 1`
(J. Friedman, *A proof of Alon's second eigenvalue conjecture and related problems*,
arXiv:cs/0405020v1; Mem. AMS 195 (2008), main theorem; also quoted as L1 in the m5 dossier
and used there for the same purpose). *Hypotheses checked:* fixed `d`, uniform simple
`d`-regular graph, `n → ∞` — our model by Lemma 1(i); `λ_1 = d` exactly for every `d`-regular
graph, so the statement is exactly "the second and all other eigenvalues are within
`2√(d-1) + η`"; `P(G_n` connected`) → 1` is classical. ∎

**Remark 3.1.** The argument uses *no* local law and no bulk input. Its two ingredients are
(i) absolute convergence of the walk series above `||A|| = d`, and (ii) holomorphy plus
`spec(A_n) ⊆ [-d,d]`. The whole content of the "exterior real energy" difficulty is in
Step 1, solved by the decay `(|t|d)^K → 0`, not by taking `Im z ↓ 0` in a bulk theorem.
The one place where the real-energy window costs something is the Perron pole of §3.3: what
converges locally uniformly on the window is `F_n^⊥`, and `F_n - F_n^⊥ = Δ²/(n(λ-d))` is
exactly the finite-size term of the dossier's §2.5, which is `Θ(1/n)` and not negligible
uniformly in `λ → d`.

**Remark 3.2 (bounded local cycles).** Where do short cycles enter? In Step 1 the tree
answer `Δ c_k` is the correct walk count on the event that `B_K(T)` is a forest, which fails
with probability `O(1/n)`; cycles of length `≤ 2K` through `T` are precisely that failure
event. Their effect on the resolvent is therefore invisible at fixed `K` as `n → ∞`, and the
`K → ∞` limit of the remainder `ρ_K` is what absorbs them. Hence, for a fixed label set,
bounded local cycles do **not** create a counterexample, a limiting random law, or a
nonvanishing variance: their total effect is `O(1/n)` at fixed radius and the geometric
weight `ρ_K` kills every radius beyond `K`. For a *structural* pattern (Theorem B) the short
cycles touching the pattern are part of the limit gadget and do survive; that is exactly the
difference between the two theorems.

---

## 4. Theorem B (P): the finite-pattern correction

The claim `-ΔG_d` is a statement about *asymptotically separated* attachment sets: for
`T = {1,…,Δ}` two distinct attachment labels satisfy `dist(s,t) → ∞` in probability, and
`r^{dist} → 0`. If the attachment pattern has bounded diameter, the off-diagonal tree
entries survive in the limit and the correct limit is the resolvent of the local limit.

**Theorem B.** Let `o ∈ [n]` be a fixed label, `R, Δ` fixed, and let `T_n` be a set of at most
`Δ` vertices determined by the rooted isomorphism class of `B_R(o)` (two instances:
`T_n = {o, one neighbour of o}`; `T_n = N(o)`). Let `η > 0`, `b := 2√(d-1)+η`,
`Ω := ℂ∖[-b,b]`. Then, with `Δ_n := |T_n|` and `P_n = 11^T/n`,
```
sup_{z∈K} | 1_{T_n}^T (z-A_{G_n})^{-1}(1-P_n) 1_{T_n} - G_d(z) Σ_{s,t∈T_∞} r(z)^{d_∞(s,t)} |
      →  0   in probability,
```
for every compact `K ⊂ Ω`, where `(T_d, T_∞)` is the a.s. limit of `(B_R(o), T_n)` in the
local weak sense and `d_∞(s,t)` the distance in `T_d`. (For both instances the gadget is
`T_d` itself: all its degrees are `d` and it is a tree.) Consequently, on every compact
`K ⊂ (2√(d-1), d) ∪ (d, ∞)`, dropping the projector changes nothing:
```
sup_{λ∈K} | 1_{T_n}^T (A_{G_n}-λ)^{-1} 1_{T_n} + G_d(λ) Σ_{s,t} r(λ)^{d_∞(s,t)} |  → 0
in probability, and the batch value -Δ G_d(λ) is correct only if d_∞(s,t) = ∞ for all s≠t.
```

*Proof.* Identical to Theorem A. (i) For `|z| > d` the walk expansion is absolutely
convergent, and `1_{T_n}^T A^k 1_{T_n}` equals the walk count of `(B_K(o), T_n)` for every
`k ≤ K`; the latter equals the tree count `Σ_{s,t}r`-expansion term on the event that
`B_K(o)` is the radius-`K` ball of `T_d` with marked set `T_n` at the limit distances, which
fails with probability `O(1/n)` by the exploration argument of Lemma 2 (the marks are a
function of `B_R(o)`, `R` fixed, hence constant on that event). (ii) `L(z) :=
G_d(z)Σ_{s,t}r(z)^{d_∞(s,t)}` is holomorphic on `Ω ⊃` the window, since it is a rational
function of `r(z)` and `r` is holomorphic off `[-2√(d-1), 2√(d-1)]`; the pole-subtracted
family with `Δ_n = |T_n|` is holomorphic on `Ω` on the event `E_n` of §3.3, where also
`|1_{T_n}^T(z-A)^{-1}(1-P_n)1_{T_n}| ≤ Δ_n/δ_K ≤ Δ/δ_K`. (iii) Lemma 3 applies with the
same `E_n`. ∎

**Corollary B' (why Theorem A is the special case).** If the marks become infinitely far
apart in the limit, the terms with `s ≠ t` vanish and `Σ_{s,t}r^{d_∞} = Δ`. For a fixed label
set, `P(dist(s,t) ≤ K) = O(n^{-1})` for each fixed `K`, so `d_∞(s,t) = ∞`. ∎

### 4.1 Exact gadget values (C)

**(a) `T = {s,t}` adjacent, `dist = 1`.** `G_∞ = T_d` (all degrees `d`, no cycles), so
```
1_T^T(z - A_{T_d})^{-1}1_T = G_d(z)(2 + 2 r(z)) .
```
**(b) `T = N(c)`, `|T| = Δ`, all leaves at pairwise distance 2.** The gadget: centre `c`
adjacent to `Δ` leaves, each leaf carrying `d-1` half-trees. Each leaf's Schur complement
diagonal is `a = λ - (d-1) r`, and `a = 1/r` because `λ = (d-1)r + 1/r`; the centre has
diagonal `b = λ`. Solving the `(Δ+1)×(Δ+1)` reduced system with couplings `1`:
```
G_{ℓℓ} = r(λ - Δ r + r)/(λ - Δ r),      G_{ℓℓ'} = r²/(λ - Δ r)   (ℓ ≠ ℓ') ,
```
hence
```
1_T^T (λ - A)^{-1} 1_T  =  Δ G_{ℓℓ} + Δ(Δ-1) G_{ℓℓ'}  =  Δ λ r /(λ - Δ r) .
```
Equivalently `= G_d(λ) · (Δ + Δ(Δ-1) r²)`, i.e. `Δ_eff = Δ + Δ(Δ-1)r²`: the correction is
exactly the sum of `r^{dist}` over the pairs at distance 2. For `Δ = d` this is finite and
positive because `λ - dr = (1-r²)/r > 0`.

**(c) Consequence for the threshold.** The limiting secular equation is
`λ = G_d(λ) Σ_{s,t} r^{dist(s,t)}`, not `λ = Δ G_d(λ)`. At the bulk edge
`λ = 2√(d-1)`, `r = 1/√(d-1)`, and the existence threshold becomes
`Σ_{s,t} r^{dist} > 2(d-2)`. For `d = 3`, `T` an adjacent pair: `2 + 2/√2 = 3.414 > 2 = 2(d-2)`,
so a defect eigenvalue exists although `Δ = 2 ≤ 2(d-2) = 2`. The dossier's `Δ > 2(d-2)`
threshold is therefore a statement about separated `T` only, and its "degree census"
reading (F5, §3 of the dossier) fails for clustered attachments.

---

## 5. What this does and does not settle

* Proved: hypothesis (H) exactly as stated in the dossier, uniformly on compact subsets of
  the required window, for fixed label sets (Theorem A). This is the missing resolvent
  input; no expectation was substituted for convergence in probability, no random `T` for
  fixed `T`, no tree branch for the Kesten–McKay transform.
* Proved: the corrected limit for bounded-diameter patterns (Theorem B), with the
  correction being exactly `Σ_{s≠t} r^{dist(s,t)}`; the batch statement is right exactly
  when those terms vanish.
* **Residual issues, stated explicitly.** (a) *Source.* One literature input is used in
  the whole proof, Friedman's second-eigenvalue bound, and it is cited as in the m5 dossier
  (arXiv:cs/0405020v1) rather than re-read page by page here; the other input,
  Lemma 1(ii), was verified against the paper text this run (`papers/avhh.txt`, lines
  194–220). No other external theorem is used: Lemma 2, Corollary 2.1, Lemma 3, Steps 1 and
  3 are proved in this file. (b) *Tightness.* There is no remaining tightness assumption:
  the compactness input is the deterministic local bound `h(z) = Δ/dist(z,[-b,b])`, which
  holds for every `n` and every `z ∈ Ω` on `E_n`, and `P(E_n) → 1` is the only stochastic
  input to it.
* Not proved here: (i) the transfer from the resolvent limit to
  `λ_1,λ_2 → max/min(d, λ_f)` — this needs the root bookkeeping, host-pole exclusion at
  `λ = d` and the exclusion of further real roots, which is the content of the other
  directions and is not re-derived here; (ii) any rate in `n` (Theorem A is a limit
  statement; `(†)` gives no modulus, and the `O(1/n)` Perron term is identified but not
  bounded below); (iii) uniformity in `d`
  (all bounds are for fixed `d` and are not uniform as `d→∞`: `R_0 = Δd^{K+1}` and
  `ρ_K = Δ²|t|(|t|d)^K/(1-|t|d)` both depend on `d` exponentially); (iv) behaviour at the
  bulk edge `λ = 2√(d-1)`, where `|t|d = 1` at the boundary of the walk-series region and
  Step 1 degenerates — Theorem A covers only a positive distance from the bulk plus the
  Perron pole, and the approach to `2√(d-1)` is the genuine edge regime (Tracy–Widom scale)
  which this argument does not and cannot reach; (v) Theorem B for patterns whose local
  limit is not deterministic (e.g. `T_n` chosen at random), where the limit would be a
  random variable; (vi) the case of `Δ = Δ_n` growing with `n` (e.g. `Δ_n → ∞` slowly), where
  `R_0` and `ρ_K` are not uniform — this is a real restriction, the theorem is fixed-`Δ`.

---

## 6. Numerics (N)

All in `resolvent_patterns.py` / `accept_check.py`; raw output in `out_*.txt`.
Sampler: pairing model with rejection (Lemma 1, *certified* uniform — not
`networkx.random_regular_graph`). Fixed seeds 11, 12, 21. Linear solves with
`scipy.sparse.linalg.spsolve` on `(λI - A)`; value reported is `1_T^T(λI-A)^{-1}1_T`,
which by Theorem A/B should equal the gadget value.

`d = 3`, `n = 8000`. Predictions: `G_d(2.95)=0.73200`, `G_d(3.2)=0.52016`,
`r(2.95)=0.527962`, `r(3.2)=0.425834`.

| λ | pattern | measured (s11) | predicted | batch value |
|---|---|---|---|---|
|3.2|single vertex|0.52037|0.52016|0.52016|
|3.2|far pair (dist 15)|1.04074|1.04032|1.04031|
|3.2|adjacent pair|1.48470|1.48331|1.56047|
|3.2|`T=N(c)`|2.12734|2.12641|1.56047|
|2.95|single vertex|0.72921|0.73200|0.73200|
|2.95|far pair (dist 15)|1.44556|1.46411|1.46401|
|2.95|adjacent pair|2.23011|2.23695|2.19601|
|2.95|`T=N(c)`|3.38036|3.42026|2.19601|

Seed 12 (n=8000, λ=3.2): single 0.52022, far pair 1.04115, adjacent 1.48360, `N(c)`
2.16698. Seed 12 (λ=2.95): 0.72674 / 1.44932 / 2.21666 / 3.62086.

Reading: at `λ = 3.2` the four patterns are reproduced by Theorem A/B to `≤5·10^{-3}`
(single, far pair, adjacent) and `2·10^{-3}`/`4·10^{-2}` for `T=N(c)`, while the
batch value `-ΔG_d` is off by 4.9% (adjacent pair) and 36% (`N(c)`). At `λ = 2.95`,
only `0.12` above the bulk edge, the finite-`n` edge bias is a few times `10^{-2}`
(the single-vertex entry is 0.4% low at `n=8000`, 2.2% low at `n=2000`), so the
adjacent-pair discrimination is marginal there and the `N(c)` one is not (3.38 vs 2.20).
The near-edge bias is a genuine finite-size effect of the bulk edge, not a defect of the
sampler; the honest conclusion is that at `n = 8000` the discriminations at `λ = 3.2` are
clean and those within `0.12` of the edge are not.

**Accounted offset.** Every measured number contains the Perron term of §3.3,
`Δ²/(n(λ-d))`, which the predictions of Theorem A/B deliberately exclude: at `n = 8000`,
`λ = 3.2` it is `6.3·10^{-4}`, `2.5·10^{-3}`, `5.6·10^{-3}` for `Δ = 1,2,3`. Adding it
improves the `N(c)` entry from `2.12734` vs `2.12641` to vs `2.13204`, i.e. the residual is
between `-5·10^{-3}` and `+10^{-3}` in all four patterns. This is the only place where the
`O(1/n)` term is visible in these experiments.

Acceptance rates of the sampler (n=2000, 4000–8000 attempts): `d=3` 0.12525 (predicted
0.13534), `d=4` 0.02350 (0.02352), `d=5` 0.002375 (0.002479) — corroborating Lemma 1(ii).

---

## 7. Reproduction

```
python3 resolvent_patterns.py 8000 3 2.95,3.2 11,12      # ~25 s
python3 resolvent_patterns.py 2000 3 2.95,3.2 11         # ~1 s
python3 accept_check.py                                  # ~5 s
```
