"""Check: a connected graph with exactly 3 distinct eigenvalues has
A^2 in span{I, A, J} and diameter at most 2, hence n <= d^2+1 when d-regular.
Enumerated over all connected graphs with n <= 8 vertices."""
import subprocess, json
import numpy as np
import networkx as nx

def decode_g6(s):
    data=bytes(s.strip(),'ascii'); n=data[0]-63; bits=[]
    for ch in data[1:]:
        b=ch-63
        for k in range(5,-1,-1): bits.append((b>>k)&1)
    A=np.zeros((n,n),dtype=np.int8); idx=0
    for j in range(1,n):
        for i in range(j):
            if bits[idx]: A[i,j]=A[j,i]=1
            idx+=1
    return A

viol=[]; maxdist=0; n3=0; regular_viol=[]
for n in range(2,9):
    out=subprocess.run(["nauty-geng","-c","-q",str(n)],capture_output=True,text=True)
    for s in [l for l in out.stdout.split("\n") if l.strip()]:
        A=decode_g6(s); ev=np.round(np.linalg.eigvalsh(A.astype(float)),8)
        if len(np.unique(ev))!=3: continue
        n3+=1
        G=nx.from_numpy_array(A)
        diam=nx.diameter(G)
        maxdist=max(maxdist,diam)
        if diam>2: viol.append((n,s,diam))
        degs=set(dict(G.degree()).values())
        if len(degs)==1:
            d=degs.pop()
            if n>d*d+1: regular_viol.append((n,s,d,n))
print(json.dumps(dict(graphs_with_3_distinct=n3,max_diameter=maxdist,
    diameter_violations=viol[:5],n_violations=len(viol),
    regular_moore_violations=regular_viol[:5],n_regular_violations=len(regular_viol)),indent=1))
