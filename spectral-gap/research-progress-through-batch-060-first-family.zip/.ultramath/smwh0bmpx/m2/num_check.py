#!/usr/bin/env python3
"""Numerical verification, staged to stay inside the wall clock.

Stage 1 (cheap): direct eigensolver values nu_1, nu_2 of G'_n and the pointwise resolvent
limit 1_T^T(lam-A)^{-1}1_T vs -G_d P_T(r) + Delta^2/(n(d-lam)).
Stage 2 (moderate n only): the secular zero of Sigma_n vs the direct eigenvalues.

Sampler: pairing model rejection -> exactly uniform simple d-regular. Fixed seeds printed.
Every record is appended to out/numeric.jsonl as it is produced.
"""
import json
import sys
import time

import numpy as np
import scipy.sparse as sp
import scipy.sparse.linalg as spl

T0 = time.time()
OUT = open("out/numeric.jsonl", "a")


def emit(rec):
    OUT.write(json.dumps(rec) + "\n")
    OUT.flush()
    print(json.dumps(rec), flush=True)


def sample_regular(d, n, rng):
    tries = 0
    while True:
        tries += 1
        stubs = np.repeat(np.arange(n), d)
        rng.shuffle(stubs)
        a, b = stubs[0::2], stubs[1::2]
        if np.any(a == b):
            continue
        lo, hi = np.minimum(a, b), np.maximum(a, b)
        key = lo.astype(np.int64) * n + hi
        if np.unique(key).size != key.size:
            continue
        return lo, hi, tries


def adjacency(n, lo, hi):
    return sp.csr_matrix((np.ones(2 * lo.size),
                          (np.concatenate([lo, hi]), np.concatenate([hi, lo]))),
                         shape=(n, n))


def branch(d, lam):
    r = (lam - np.sqrt(lam * lam - 4.0 * (d - 1))) / (2.0 * (d - 1))
    return r, r / (1.0 - r * r)


def P_of(pattern, d, r):
    if pattern == "N(c)":
        return d + d * (d - 1) * r * r
    if pattern == "adj":
        return 2.0 + 2.0 * r
    return 1.0


def Phi(pattern, d, lam):
    r, Gd = branch(d, lam)
    return lam - Gd * P_of(pattern, d, r)


def lamP_exact(pattern, d):
    if pattern == "N(c)":
        return 2.0 * d / np.sqrt(d + 1.0)
    if pattern == "adj" and d == 3:
        rr = [z.real for z in np.roots([2.0, 2.0, 1.0, 0.0, -1.0])
              if abs(z.imag) < 1e-13 and 0 < z.real < 1]
        assert len(rr) == 1
        return (d - 1) * rr[0] + 1.0 / rr[0]
    return None


def build(d, n, seed):
    rng = np.random.default_rng(seed)
    lo, hi, tries = sample_regular(d, n, rng)
    return adjacency(n, lo, hi), tries


def attachments(A, d, pattern):
    c = 0
    nb = np.sort(A[c].indices)
    if pattern == "N(c)":
        return nb
    if pattern == "adj":
        return np.array([c, nb[0]])
    return np.array([c])


def aug(A, T):
    n = A.shape[0]
    v = np.zeros(n)
    v[T] = 1.0
    M = sp.bmat([[A, sp.csr_matrix(v[:, None])],
                 [sp.csr_matrix(v[None, :]), None]], format="csr")
    return M, v


def make_fac(A):
    n = A.shape[0]
    I = sp.identity(n, format="csr")

    def fac(lam):
        return spl.splu((A - lam * I).tocsc())
    return fac


def sigma(fac, v, lam):
    x = fac(lam).solve(v)
    return lam + float(v @ x)


def secular_zero(fac, v, lo, hi, steps=44):
    flo = sigma(fac, v, lo)
    for _ in range(steps):
        mid = 0.5 * (lo + hi)
        fm = sigma(fac, v, mid)
        if (fm > 0) == (flo > 0):
            lo, flo = mid, fm
        else:
            hi = mid
    return 0.5 * (lo + hi)


def main(stage):
    for d in (3, 4):
        ns = (1000, 2000, 4000, 8000) if stage == 1 else (1000, 2000)
        for n in ns:
            seeds = (20240601, 20240602) if n <= 2000 else (20240601,)
            for seed in seeds:
                A, tries = build(d, n, seed)
                evA = np.sort(spl.eigsh(A, k=3, which="LA",
                                        return_eigenvectors=False))[::-1]
                fac = make_fac(A)
                for pattern in ("N(c)", "adj", "single"):
                    T = attachments(A, d, pattern)
                    M, v = aug(A, T)
                    evG = np.sort(spl.eigsh(M, k=3, which="LA",
                                            return_eigenvectors=False))[::-1]
                    lp = lamP_exact(pattern, d)
                    rec = {"stage": stage, "d": d, "n": n, "seed": seed,
                           "pattern": pattern, "T": [int(t) for t in T],
                           "tries": int(tries),
                           "lam1_A": float(evA[0]), "lam2_A": float(evA[1]),
                           "nu1": float(evG[0]), "nu2": float(evG[1]),
                           "nu1_minus_nu2": float(evG[0] - evG[1]),
                           "d_minus_nu2": float(d - evG[1]),
                           "nu1_minus_d": float(evG[0] - d),
                           "n_times_d_minus_nu2": float(n * (d - evG[1])),
                           "n_times_nu1_minus_d": float(n * (evG[0] - d)),
                           "sqrtn_d_minus_nu2": float(np.sqrt(n) * (d - evG[1])),
                           "sqrtn_nu1_minus_d": float(np.sqrt(n) * (evG[0] - d)),
                           "lamP_exact": (None if lp is None else float(lp)),
                           "nu2_minus_lamP": (None if lp is None else float(evG[1] - lp)),
                           "Phi_at_d": float(Phi(pattern, d, d)),
                           "d_exact_root_of_Phi": bool(abs(Phi(pattern, d, d)) < 1e-14)}
                    # pointwise resolvent limit (away from the Perron pole)
                    err = {}
                    for lam in (2.95, 3.2, 3.6, 4.6):
                        if lam <= 2 * np.sqrt(d - 1) + 1e-9 or abs(lam - d) < 0.05:
                            continue
                        r, Gd = branch(d, lam)
                        pred = lam - Gd * P_of(pattern, d, r) + v.sum() ** 2 / (n * (d - lam))
                        err[str(lam)] = float(sigma(fac, v, lam) - pred)
                    rec["resolvent_err"] = err
                    emit(rec)
                    if stage == 2:
                        z2 = secular_zero(fac, v, evA[1] + 1e-11, d - 1e-11)
                        z1 = secular_zero(fac, v, d + 1e-9, d + 1.0)
                        emit({"stage": 2, "d": d, "n": n, "seed": seed, "pattern": pattern,
                              "zero_gap": float(z2), "zero_above": float(z1),
                              "zero_gap_minus_nu2": float(z2 - evG[1]),
                              "zero_above_minus_nu1": float(z1 - evG[0]),
                              "elapsed": round(time.time() - T0, 1)})
    print("done %.1f s" % (time.time() - T0), flush=True)


if __name__ == "__main__":
    main(int(sys.argv[1]))
