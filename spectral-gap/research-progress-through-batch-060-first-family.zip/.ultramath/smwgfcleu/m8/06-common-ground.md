# 6. Common ground with the four local dossiers, and with the other directions

## 6.1 The mechanism the four dossiers share, stated once

All four dossiers are about the same two-stage mechanism.

1. **An infinite local limit with an exactly computable spectral edge.** For a `d`-regular tree the
   edge is `2 sqrt(d-1)`, for a biregular tree it is `sqrt(d_1-1)+sqrt(d_2-1)`, and in the
   relativised setting it is `sqrt(rho_1)` where `rho_1` is the Perron value of the base Hashimoto
   matrix.
2. **Control of rare defects.** A finite piece with too much "irreducible" growth (a tangle) forces
   a genuine eigenvalue above the edge. Tangles of order `r` occur with probability `n^(-r)`, so
   removing them costs a polynomial probability, and the exponent is the least order of a strict
   feasible tangle.

The hypergraph theory is the same mechanism with two twists, both of which this dossier isolates:

* the local limit is **not** a tree (it is the `2`-section of the `(d,k)`-biregular tree, a tree of
  `k`-cliques), which changes the edge from `2 sqrt((k-1)d-1)` to `k-2+2 sqrt((d-1)(k-1))` (T7),
* the Perron value is **not** the only structurally forced eigenvalue: there is an entire plateau at
  `-d` whose exact size is `n - rank(X)` (T1, T5), and this plateau interacts with the definition of
  Ramanujan (T9), with covers (T12), and with the signed Gram identity (T15).

## 6.2 Dossier by dossier

**`alon-second-eigenvalue`** (Friedman 2004, arXiv:cs/0405020v1). Supplies the `k = 2` benchmark:
`2 sqrt(d-1)` is both the Alon-Boppana lower bound and the a.a.s. upper edge, and `d` is the unique
trivial eigenvalue of a connected `d`-regular graph. In this dossier's language, `k = 2` is exactly
the case where the naive tree benchmark is correct (T7(1)) and where the `-d` plateau has no
rectangular source. The general phenomenon in this dossier is the `k >= 3` failure of both.

**`biregular-spectral-gap`** (Brito-Dumitriu-Decker Harris 2021, arXiv:1804.07808v6). This paper is
the engine of the whole hypergraph theory, because the incidence graph of a `(d,k)`-regular
hypergraph is a `(d,k)`-biregular bipartite graph and the Gram identity `A_H + dI = X X^T` converts
the biregular singular-value theorem into a statement about `A_H`. Dumitriu-Zhu say so explicitly
("it turns out to be a simple consequence of the spectral gap of uniformly random bipartite biregular
graphs"). The one genuinely new thing this dossier adds in that direction is T13: the base Hashimoto
Perron value of a biregular structure is pinned by the degrees alone, so the relativised programme
cannot move the threshold. That is a structural remark about that paper's Theorem 4, not a
correction to it.

**`friedman-second-eigenvalue-lifts`** (Bordenave 2019, arXiv:1502.04482v4). Supplies Theorem 23,
the random-lift bound `sqrt(rho_1)`, which is the load-bearing input of open target O1. The
Ihara-Bass quartic used in Step 4 of O1 is the same quartic as the biregular one, and the conversion
between real and non-real Hashimoto eigenvalues described in `04-open-directions.md` is a piece of
bookkeeping that I have not seen written down in that form and that is easy to get wrong.

**`relativized-second-eigenvalue`** (Friedman-Kohler 2014, arXiv:1403.3462v1). Supplies the shape of
Conjecture O1 (the `n^(-eta)` exponent, the notion of fundamental order) and the warning that the
exponent is the interesting object once the threshold is pinned. It also supplies the methodological
caution used throughout this dossier: the source contains notation defects, so statements must be
quoted from the theorems and not from informal passages.

## 6.3 Other directions in this swarm, and the neighbouring menu items

* **Menu item A, periodic lattices and Bloch band edges** is held by another member of this swarm.
  T11 is a hypergraph instance of exactly that phenomenon (a fixed periodic symbol, a finite sample
  of the top Bloch band, a `Theta(n^-2)` gap). I include it only as the falsification of
  "regular equals expander" for the hypergraph model, and the general lattice-points-near-a-critical-
  point theory is that member's direction, not mine. The overlap is deliberate and should be read as
  a consistency check on both.
* **Menu item C, uniform regular hypergraphs and higher-order gaps** is my direction. This dossier
  is the "careful definition plus exact structure plus falsification" part of it. It does not attempt
  higher-order tensor gaps (Friedman-Wigderson, Lenz-Mubayi, Cioaba et al.) except to note in
  `02-literature.md` that the Feng-Li matrix theory and the tensor theory have different trivial
  spectra, so a statement about "the gap at index 3" must say which of the two it means.
* **Menu item D, hypergraph non-backtracking and covering thresholds.** T13, T15 and open target O1
  are squarely in that area. The reason they are in this dossier is that they are forced by the
  trivial-spectrum analysis: `-d` is what decides whether a cover can be Ramanujan, and the signed
  Gram identity is the exact mechanism. If another member is working on hypergraph non-backtracking
  thresholds, T13 (the base threshold is pinned) and T15 (no signing goes below `-d`) are the two
  facts they would need, and they are proved here.
* **Menu item E, random Cayley graphs.** Not touched here. There is, however, a clean Cayley-type
  example inside T11: the cyclic interval hypergraph is a Cayley hypergraph on `Z_q` (it is invariant
  under translation, so its Feng-Li operator is a group-circulant), and its symbol is the Fejer
  kernel. So it is a Cayley hypergraph with an exactly computable spectrum and a `Theta(q^-2)` gap.
  Any statement about random Cayley graphs having good gaps must not be confused with the
  deterministic circulant case, and T11 is the exact counterexample to the confusion.
* **Menu item F, general finite group Cayley graphs, representation and filtered trace methods.** T4
  is the hypergraph analogue of the fact that a symmetric design has few distinct eigenvalues: the
  complete `k`-partite hypergraph has an exactly determined spectrum with multiplicities `1`, `k-1`,
  `n-k` that are forced by the representation theory of the partition structure. The `k-1` copies of
  `-d` are the `k-1` nontrivial characters of `Z_k` acting on the `k` classes. This is the
  hypergraph version of "filtered trace" bookkeeping and it is the cleanest possible illustration.
* **Menu item H, discovering a cross-cutting link.** The link this dossier proposes is the pair
  (Gram identity, signed Gram identity): `A_H + d I = X X^T` and `S + d I = Xtilde Xtilde^T`. Both
  are exact, both are positive semidefiniteness statements, and together they say that the whole
  theory of hypergraph spectra and of signed hypergraph spectra is the theory of Gram matrices of
  signed incidence matrices. That is an algebraic link, not an analytic one, and it is why the
  trivial spectrum is what it is.

## 6.4 What the four dossiers do not contain, and which this dossier adds

The four dossiers are all about graphs. None of them contains:

* the Gram identity and its consequences for the trivial spectrum,
* the observation that the local limit is a tree of cliques rather than a tree,
* the `-d` plateau and its rank formula,
* the exact square identities `(t-1)^2` and `(sqrt(d-1)-sqrt(k-1))^2`,
* the signed Gram identity for covers, and the resulting `d = k` versus `d < k` dichotomy for
  Ramanujan coverings,
* the observation that the base Hashimoto Perron value of a regular structure is pinned by the
  degrees, so relative expansions cannot improve the threshold.

Each of these is a place where the graph case is a special case that hides a phenomenon. That is the
main claim to novelty in this dossier.
