"""Exact spectra of the structured families: Paley graphs, rook graphs, Hamming.
Shows the (degree, second-eigenvalue multiplicity) trade-off."""
import numpy as np, json
import networkx as nx

def spec_mult(A,tol=1e-7):
    ev=np.linalg.eigvalsh(np.array(A,dtype=float)); out=[]
    for x in ev:
        if out and abs(x-out[-1][0])<tol: out[-1][1]+=1
        else: out.append([round(float(x),8),1])
    return out

def paley_graph(q):
    G=nx.Graph(); G.add_nodes_from(range(q))
    sq={ (a*a)%q for a in range(1,q)}
    for i in range(q):
        for j in range(q):
            if i!=j and ((i-j)%q) in sq: G.add_edge(i,j)
    return G

def rook(m):
    G=nx.Graph(); G.add_nodes_from([(i,j) for i in range(m) for j in range(m)])
    for i in range(m):
        for j in range(m):
            for k in range(m):
                if k!=j: G.add_edge((i,j),(i,k))
                if k!=i: G.add_edge((i,j),(k,j))
    return G

rows=[]
for q in [13,17,29,37,41]:
    G=paley_graph(q); A=nx.to_numpy_array(G); n=A.shape[0]
    s=spec_mult(A); lam2=s[-2]  # second largest distinct value, the largest is (q-1)/2
    rows.append(dict(family=f"Paley({q})",n=n,deg=sorted(set(dict(G.degree()).values())),
                     n_distinct=len(s),top3=s[::-1][:3],
                     ratio_mult_over_n=round(lam2[1]/n,4)))
for m in [3,4,5,6,8]:
    G=rook(m); A=nx.to_numpy_array(G); n=A.shape[0]
    s=spec_mult(A)
    rows.append(dict(family=f"Rook({m})",n=n,deg=sorted(set(dict(G.degree()).values())),
                     n_distinct=len(s),spectrum=s, ratio_mult_over_n=round(s[-2][1]/n,4)))
for d in [3,4,5]:
    G=nx.convert_node_labels_to_integers(nx.hypercube_graph(d)); A=nx.to_numpy_array(G); n=A.shape[0]
    s=spec_mult(A)
    rows.append(dict(family=f"Q{d}",n=n,deg=[d],n_distinct=len(s),spectrum=s,
                     ratio_mult_over_n=round([k for a,k in s if abs(a-(d-2))<1e-9][0]/n,4)))
json.dump(rows,open("out/srg_families.json","w"),indent=1)
for r in rows: print(r)
