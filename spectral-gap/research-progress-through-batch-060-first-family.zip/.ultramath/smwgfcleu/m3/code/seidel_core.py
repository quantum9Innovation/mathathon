"""Exact checks for the Seidel/multiplicity dictionary.

All objects are integer or simple algebraic. We report exact rational data
where possible and float eigenvalues with residual checks.
"""
import itertools, json
import numpy as np
import sympy as sp

def seidel_from_adj(A):
    n = A.shape[0]
    return np.ones((n,n), dtype=np.int64) - np.eye(n, dtype=np.int64) - 2*A

def seidel_adj(S):
    n = S.shape[0]
    return (np.ones((n,n), dtype=np.int64) - np.eye(n,dtype=np.int64) - S)//2

def switching(S, x):
    d = np.array([-1 if b else 1 for b in x])
    return (d[:,None]*S*d[None,:])

def mult_bound(n, theta):
    return sp.Rational(n*(n-1),1) / (sp.Integer(n-1) + sp.nsimplify(theta)**2)

def check_relative_bound(n, theta, k):
    """k <= n(n-1)/(n-1+theta^2)  <=>  n <= d(1-a^2)/(1-d a^2) with a=-1/theta, d=n-k."""
    lhs = sp.Integer(n) <= mult_bound(n, theta)
    d = n-k; a2 = sp.Rational(1,1)/sp.nsimplify(theta)**2
    rhs = sp.Rational(d,1)*(1-a2)/(1-d*a2)
    return lhs, sp.simplify(rhs)

# ---- Paley conference / two-graph construction -------------------------
def paley_seidel(q):
    """q prime power with q = 1 mod 4: set S_ij = chi(i-j) for i != j, 0 diagonal.
    Then S is a Seidel matrix with S^2 = q I  (conference), q+1 vertices."""
    # build F_q when q is prime, otherwise return None
    if not sp.isprime(q):
        return None
    chi = np.zeros(q, dtype=np.int64)
    for a in range(1,q):
        chi[a] = 1 if pow(a,(q-1)//2,q)==1 else -1
    S = np.zeros((q+1,q+1), dtype=np.int64)
    # index 0 = infinity
    for i in range(q):
        S[0,i+1] = 1; S[i+1,0] = 1
    for i in range(q):
        for j in range(q):
            if i!=j:
                S[i+1,j+1] = chi[(i-j)%q]
    return S

rows = []
for q in [5,9,13,17]:
    if not sp.isprime(q):
        continue
    S = paley_seidel(q)
    n = S.shape[0]
    ev = np.linalg.eigvalsh(S.astype(float))
    # exact checks
    assert np.array_equal(S, S.T) and np.all(np.diag(S)==0)
    assert np.all(np.abs(S[np.triu_indices(n,1)])==1)
    tr2 = int(np.trace(S@S))
    # two eigenvalues?
    lam = np.round(ev,9)
    pos = lam[lam>1e-6]; neg = lam[lam<-1e-6]
    rows.append(dict(q=q, n=n, trS=int(np.trace(S)), trS2=tr2, n_times_nm1=n*(n-1),
                     n_pos=int(len(pos)), val_pos=float(pos.mean()) if len(pos) else None,
                     n_neg=int(len(neg)), val_neg=float(neg.mean()) if len(neg) else None,
                     max_resid=float(np.max(np.abs(S@S - q*np.eye(n,dtype=np.int64)))),
                     S2_eq_qI=bool(np.array_equal(S@S, q*np.eye(n,dtype=np.int64)))))
    # equiangular Gram with alpha = 1/sqrt(q) (theta_min = -sqrt q)
    alpha = 1.0/np.sqrt(q)
    G = np.eye(n) + alpha*S.astype(float)
    evG = np.linalg.eigvalsh(G)
    r = int(np.sum(evG>1e-9))
    # relative bound attained?
    d = r; a2 = sp.Rational(1,q)
    bound = sp.Rational(d,1)*(1-a2)/(1-d*a2)
    rows[-1].update(alpha2=float(alpha**2), rankG=r, n_eq_d=int(d==n-r and bound==n),
                    relative_bound_value_sp=str(bound), n_lines=n, mult_bound_str=str(mult_bound(n,-np.sqrt(q))))
print(json.dumps(rows, indent=1))
