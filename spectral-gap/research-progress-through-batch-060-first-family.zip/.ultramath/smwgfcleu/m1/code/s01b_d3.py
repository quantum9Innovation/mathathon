r"""d = 3: the exponent 2/d = 2/3 for cubic quotients, and N^-2 for skewed ones."""
import sys, os, itertools, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
import lib

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "out")


def gap_cubic(n):
    pts = np.array(list(itertools.product(range(n), repeat=3)), dtype=float)/n
    vals = np.sort(2*np.cos(2*np.pi*pts).sum(axis=1))[::-1]
    return 6 - vals[1]


def gap_skew(N):
    """Lambda = <(N,0,0),(0,1,0),(0,0,1)>: Lambda*/Z^3 = {(j/N,0,0)}."""
    pts = np.array([[j/N, 0.0, 0.0] for j in range(1, N)])
    vals = np.sort(2*np.cos(2*np.pi*pts).sum(axis=1))[::-1]
    return 6 - vals[0]


log = ["cubic quotients of the 3-torus Z^3/nZ^3, S = {+-e_1,+-e_2,+-e_3}",
       "   n      N        gap          gap*n^2      4pi^2"]
for n in [2, 3, 4, 6, 8, 12, 16, 24, 32]:
    g = gap_cubic(n)
    log.append(f"  {n:3d} {n**3:7d}  {g:.12e}  {g*n*n:.9f}  {4*np.pi**2:.9f}")

log += ["", "skewed quotients Lambda = <(N,0,0),(0,1,0),(0,0,1)>, index N, |V|=N",
        "   N        gap          gap*N^2      4pi^2"]
for N in [2, 5, 10, 20, 50, 100, 200, 400]:
    g = gap_skew(N)
    log.append(f"  {N:4d}  {g:.12e}  {g*N*N:.9f}  {4*np.pi**2:.9f}")

txt = "\n".join(log)
open(os.path.join(OUT, "s01b_d3.log"), "w").write(txt)
print(txt)
