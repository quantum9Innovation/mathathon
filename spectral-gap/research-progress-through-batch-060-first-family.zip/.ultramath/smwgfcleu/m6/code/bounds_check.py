"""Checks the two elementary lower bounds on lambda_2 for Cayley graphs on F_2^rho.

Dictionary (classical, see dossier section 3): lambda_2 = d - 2*d_min(C) where C is
the row space of the rho x d matrix whose columns are the elements of S.

Bound A (Parseval / flatness, Theorem 4):
    sum over a != 0 of lambda_a^2 = |G| d - d^2, hence
    lambda_2 >= sqrt( d (1 - d/|G|) ).

Bound B (shortening plus Plotkin, Theorem 5):
    lambda_2 >= rho - 1 - log2 d = log2(|G|/d) - 1 .

The script checks A and B on exhaustive small cases, on random cases, and on the
cubic moment-curve family, and tabulates when B forces lambda_2 > 2 sqrt(d-1).
"""
import itertools
import json
import math
import random


def popcount(v):
    return bin(v).count('1')


def code_of(rho, S):
    d = len(S)
    rows = []
    for i in range(rho):
        m = 0
        for j, s in enumerate(S):
            if (s >> i) & 1:
                m |= 1 << j
        rows.append(m)
    basis = []
    for v in rows:
        for b in basis:
            v = min(v, v ^ b)
        if v:
            basis.append(v)
            basis.sort(reverse=True)
    code = {0}
    for b in basis:
        code |= {c ^ b for c in code}
    we = {}
    for c in code:
        w = popcount(c)
        we[w] = we.get(w, 0) + 1
    return we, len(basis)


def lam2(d, we):
    nz = sorted(w for w in we if w > 0)
    return d - 2 * nz[0], we[nz[0]]


def bounds(rho, d):
    A = math.sqrt(max(0.0, d * (1 - d / (1 << rho))))
    B = rho - 1 - math.log2(d)
    return A, B


def cubic_family(k):
    polys = {2: 0b111, 3: 0b1011, 4: 0b10011, 5: 0b100101, 6: 0b1000011,
             7: 0b10001001, 8: 0b100011101, 9: 0b1000001001}
    mod = polys[k]

    def mul(a, b):
        r = 0
        while b:
            if b & 1:
                r ^= a
            b >>= 1
            a <<= 1
            if a >> k:
                a ^= mod
        return r

    return [x | (mul(mul(x, x), x) << k) for x in range(1, 1 << k)]


def main():
    rng = random.Random(4242)
    out = {'checks': [], 'cubic': [], 'crossover': []}
    fails = 0
    # exhaustive small
    for rho in (2, 3, 4):
        for d in range(1, (1 << rho)):
            for S in itertools.combinations(range(1, 1 << rho), d):
                we, rank = code_of(rho, list(S))
                if rank < rho:
                    continue
                lam, mult = lam2(d, we)
                A, B = bounds(rho, d)
                ok = (lam >= A - 1e-9) and (lam >= B - 1e-9)
                if not ok:
                    fails += 1
                out['checks'].append({'rho': rho, 'd': d, 'lambda_2': lam,
                                      'parseval_A': round(A, 3),
                                      'shortening_B': round(B, 3), 'ok': ok})
    # random larger
    for rho, d in [(6, 8), (8, 12), (10, 20), (12, 20), (12, 60), (16, 30),
                   (16, 150), (20, 25), (20, 100), (20, 400), (24, 30)]:
        S = rng.sample(range(1, 1 << rho), d)
        we, rank = code_of(rho, S)
        if rank < rho:
            out['checks'].append({'rho': rho, 'd': d, 'rank': rank, 'skipped': True})
            continue
        lam, mult = lam2(d, we)
        A, B = bounds(rho, d)
        ok = (lam >= A - 1e-9) and (lam >= B - 1e-9)
        if not ok:
            fails += 1
        out['checks'].append({'rho': rho, 'd': d, 'lambda_2': lam, 'mult': mult,
                              'parseval_A': round(A, 3), 'shortening_B': round(B, 3),
                              'ok': ok})
    # cubic family
    for k in range(3, 10):
        S = cubic_family(k)
        rho, d = 2 * k, len(S)
        we, rank = code_of(rho, S)
        lam, mult = lam2(d, we)
        A, B = bounds(rho, d)
        ok = (lam >= A - 1e-9) and (lam >= B - 1e-9)
        if not ok:
            fails += 1
        nz = sorted(w for w in we if w > 0)
        out['cubic'].append({'k': k, 'rho': rho, 'd': d, 'lambda_2': lam,
                             'lambda_min': d - 2 * nz[-1],
                             'A': round(A, 3), 'B': round(B, 3),
                             'bench': round(2 * math.sqrt(d - 1), 3),
                             'beats_bench': lam < 2 * math.sqrt(d - 1), 'ok': ok})
    # crossover: smallest rho with B > 2 sqrt(d-1)
    for d in (16, 32, 64, 128, 256, 1024, 4096):
        r = 1
        while r - 1 - math.log2(d) <= 2 * math.sqrt(d - 1):
            r += 1
        out['crossover'].append({'d': d, 'rho_needed': r,
                                 'log2_G': r,
                                 'G_over_d': round((1 << r) / d, 3) if r < 40 else 'huge',
                                 'log2_d': round(math.log2(d), 2)})
    out['failures'] = fails
    print(json.dumps(out, indent=1))


if __name__ == '__main__':
    main()
