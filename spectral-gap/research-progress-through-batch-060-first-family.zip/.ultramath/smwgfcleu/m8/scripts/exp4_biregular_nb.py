"""The non-backtracking operator of the incidence structure of a (d,k)-regular hypergraph.

The incidence graph Inc(H) is (d,k)-biregular bipartite.  Its Hashimoto matrix B has
directed-edge states (u -> e) and (e -> u), so
        B = [[0, K], [D, 0]],   K: (u,e) -> (e,v), v != u   (k-1 choices)
                                D: (e,u) -> (u,f), f != e   (d-1 choices)
and B^2 = diag(KD, DK).  Row sums of KD are (k-1)(d-1) = ab, so rho(B) = sqrt(ab), and
the biregular Ihara-Bass identity reads
        det(lam I - B) = (lam^2 - 1)^(|E|-|V|) det(lam^2 I - lam A + (Ddeg - I)).
Checks below are deterministic for each displayed instance.
"""
import numpy as np
from hyp import config_model_hypergraph, fengli

rng = np.random.default_rng(4242)


def build_nb(X):
    n, m = X.shape
    flags = [(u, e) for u in range(n) for e in range(m) if X[u, e]]
    idx = {f: i for i, f in enumerate(flags)}
    N = len(flags)
    B = np.zeros((2 * N, 2 * N))
    # state a = (u -> e) at index idx[(u,e)], state b = (e -> u) at index N + idx[(u,e)]
    for (u, e) in flags:
        i = idx[(u, e)]
        for v in range(n):
            if v != u and X[v, e]:
                B[i, N + idx[(v, e)]] += 1.0
        for f in range(m):
            if f != e and X[u, f]:
                B[N + i, idx[(u, f)]] += 1.0
    return B, flags


def check_ihara_bass(X, B, lam):
    """det(lam I - B) = (lam^2-1)^(|E|-|V|) det(lam^2 I - lam A + (Ddeg - I)) for G = Inc(H).
    |E| = number of edges of Inc(H) = n*d, |V| = n+m."""
    n, m = X.shape
    nE = int(X.sum())
    nV = n + m
    A = np.zeros((nV, nV))
    A[:n, n:] = X
    A[n:, :n] = X.T
    Dm = np.diag(A.sum(axis=1) - 1)
    lhs = np.linalg.det(lam * np.eye(B.shape[0]) - B)
    rhs = (lam ** 2 - 1) ** (nE - nV) * np.linalg.det(lam ** 2 * np.eye(nV) - lam * A + Dm)
    return lhs, rhs


print("=== trivial spectrum of the non-backtracking matrix of the incidence structure ===")
print(f"{'d':>2} {'k':>2} {'n':>4} {'|E|':>4} {'|V|':>4} {'|E|-|V|':>7} {'ab':>5} "
      f"{'top |mu|':>9} {'2nd |mu|':>9} {'(ab)^1/4':>9} {'# +-sqrt(ab)':>13} {'# +-1':>7}")
for (d, k, n) in ((2, 3, 12), (3, 4, 12), (4, 3, 12), (3, 3, 10), (2, 5, 15), (3, 5, 15)):
    if (n * d) % k:
        continue
    E = config_model_hypergraph(n, d, k, rng)
    A, X = fengli(E, n)
    m = X.shape[1]
    B, flags = build_nb(X)
    mu = np.linalg.eigvals(B)
    ab = (d - 1) * (k - 1)
    roots_ab = int(np.sum(np.abs(np.abs(mu) - np.sqrt(ab)) < 1e-7))
    ones = int(np.sum(np.abs(np.abs(mu) - 1.0) < 1e-7))
    mods = np.sort(np.abs(mu))[::-1]
    print(f"{d:2d} {k:2d} {n:4d} {int(X.sum()):4d} {n+m:4d} {int(X.sum())-(n+m):7d} {ab:5d} "
          f"{mods[0]:9.5f} {mods[2]:9.5f} {ab**0.25:9.5f} {roots_ab:13d} {ones:7d}")
    # Ihara-Bass identity at random complex lam
    for lam in (0.37 + 0.71j, -1.9 + 0.2j, 2.3 - 1.1j):
        lhs, rhs = check_ihara_bass(X, B, lam)
        rel = abs(lhs - rhs) / max(1.0, abs(lhs))
        assert rel < 1e-8, (d, k, n, lam, lhs, rhs, rel)
    print(f"     Ihara-Bass determinant identity verified at 3 complex lam (max rel err "
          f"{max(abs(check_ihara_bass(X, B, l)[0] - check_ihara_bass(X, B, l)[1]) / max(1.0, abs(check_ihara_bass(X, B, l)[0])) for l in (0.37+0.71j, -1.9+0.2j, 2.3-1.1j)):.2e})")

print("\n=== the 2-section spectrum as a function of the singular values of X ===")
print("A_H + d I = X X^T, so singular values of X are sqrt(d + lambda_i(A_H)) exactly.")
d, k, n = 3, 4, 12
E = config_model_hypergraph(n, d, k, rng)
A, X = fengli(E, n)
w = np.linalg.eigvalsh(A.astype(float))[::-1]
sv = np.linalg.svd(X.astype(float), compute_uv=False)
pred = np.sqrt(np.maximum(d + w, 0.0))
r = min(n, X.shape[1])
print("singular values of X          :", np.round(sv, 8))
print("sqrt(d + lambda_i(A_H)), i<=r :", np.round(pred[:r], 8))
print("max abs difference            :", np.abs(sv - pred[:r]).max())
print("lambda_i(A_H) for i>r (all must equal -d):", np.round(w[r:], 8), " -d =", -d)
assert np.abs(w[r:] + d).max() < 1e-8
assert np.abs(sv - pred[:r]).max() < 1e-8
print("lambda_max(A_H) =", w[0], " d(k-1) =", d * (k - 1),
      "  sigma_max =", sv[0], " sqrt(dk) =", np.sqrt(d * k))
