"""Closes the loop for Lemma L3: the positive root t_n of
      t*(d - Gamma_n(d + t/n)) + t^2/n = Delta^2          (star)
must equal n*(lambda_1(M_n) - d) computed from a direct eigendecomposition."""
import numpy as np, json
exec(open('scripts/check_secular.py').read().split('if __name__')[0])

def run(n, d, Delta, seed):
    rng = np.random.default_rng(seed)
    A, tries = reg_config_sparse_ = reg_config(n, d, rng)
    T = np.arange(Delta); ones = np.zeros(n); ones[T] = 1.0
    w, V = np.linalg.eigh(A)
    s = (V.T @ ones)**2
    G = lambda lam: np.sum(s/(lam - w))          # 1_T^T (lam I - A)^{-1} 1_T
    # F_n(d + t/n) = d + t/n - G(d + t/n) = 0, G the FULL resolvent form; 
    # multiplying by t and using the Perron term (Delta^2/n)/(t/n) = Delta^2/t
    # this is equivalent to (star).
    star = lambda t: d + t/n - G(d + t/n)
    lo, hi = 1e-3, 1.0   # t is O(1) here; avoid the float spacing of d at t ~ 1e-15
    assert star(lo) < 0
    while star(hi) < 0: hi *= 2
    for _ in range(200):
        m = 0.5*(lo+hi)
        if star(m) < 0: lo = m
        else: hi = m
    t_star = 0.5*(lo+hi)
    M = np.zeros((n+1,n+1)); M[:n,:n] = A; M[T,n] = 1; M[n,T] = 1
    t_dir = n*(np.linalg.eigvalsh(M)[-1] - d)
    return dict(n=n, d=d, Delta=Delta, seed=seed, t_from_star=t_star, t_from_eig=t_dir,
                absdiff=abs(t_star-t_dir),
                Gamma_perp_at_d=float(np.sum(s[:-1]/(d - w[:-1]))))

for (n,d,Delta,seed) in [(1000,3,1,2000),(2000,3,2,4000),(1000,3,3,3000),(2000,4,2,3000),(1000,5,1,5000)]:
    r = run(n,d,Delta,seed)
    print(json.dumps({k:(round(v,12) if isinstance(v,float) else v) for k,v in r.items()}), flush=True)
