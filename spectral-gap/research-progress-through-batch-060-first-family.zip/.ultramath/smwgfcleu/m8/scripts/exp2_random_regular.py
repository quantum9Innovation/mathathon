"""Random (d,k)-regular hypergraphs: where does lambda_2(A_H) actually sit?

Compares the empirical lambda_2 with
  true_edge = k - 2 + 2 sqrt((d-1)(k-1))     (universal-cover / Li-Sole window top)
  naive     = 2 sqrt((k-1)d - 1)             (what a (k-1)d-regular tree would give)
"""
import json
import time
import numpy as np
from scipy.linalg import eigh
import sympy
from hyp import config_model_hypergraph, fengli, components, window

rng = np.random.default_rng(20261114)
rows = []
configs = [((3, 3), [250, 500, 1000, 2000, 3000]),
           ((2, 4), [250, 500, 1000, 2000]),
           ((4, 3), [250, 500, 1000, 2000]),
           ((3, 4), [250, 500, 1000, 2000]),
           ((2, 3), [300, 600, 1200, 2400]),
           ((5, 3), [250, 500, 1000, 2000])]
TRIALS = 3

for (d, k), ns in configs:
    for n in ns:
        if (n * d) % k:
            continue
        vals = []
        for t in range(TRIALS):
            E = config_model_hypergraph(n, d, k, rng)
            A, X = fengli(E, n)
            w = eigh(A.astype(float), eigvals_only=True, driver="evr")
            w = w[::-1]
            vals.append((w[1], w[-1], components(A)))
        lam2 = np.array([v[0] for v in vals])
        lammin = np.array([v[1] for v in vals])
        ncomp = max(v[2] for v in vals)
        t_edge = k - 2 + 2 * np.sqrt((d - 1) * (k - 1))
        naive = 2 * np.sqrt((k - 1) * d - 1)
        rec = dict(d=d, k=k, n=n, trials=TRIALS, max_components=int(ncomp),
                   lam2_mean=float(lam2.mean()), lam2_std=float(lam2.std()),
                   true_edge=float(t_edge), naive=float(naive),
                   true_minus_lam2_mean=float((t_edge - lam2).mean()),
                   lam2_minus_naive_mean=float((lam2 - naive).mean()),
                   lam2_minus_naive_min=float((lam2 - naive).min()),
                   lammin_mean=float(lammin.mean()),
                   win_lo=float(window(d, k)[0]))
        rows.append(rec)
        print(f"d={d} k={k} n={n:5d} comps={ncomp} lam2={lam2.mean():9.5f} "
              f"std={lam2.std():.5f} edge={t_edge:9.5f} naive={naive:9.5f} "
              f"edge-lam2={t_edge-lam2.mean():8.5f} lam2-naive={(lam2.mean()-naive):8.5f} "
              f"lammin={lammin.mean():9.5f} winlo={window(d,k)[0]:9.5f}", flush=True)

json.dump(rows, open("../outputs/exp2_random_regular.json", "w"), indent=1)

print("\nsummary: is lam2 above the naive tree benchmark in every run?")
print("min over runs of (lam2 - naive) =", min(r["lam2_minus_naive_min"] for r in rows))
print("runs:", len(rows), " runs with lam2 <= naive:", sum(1 for r in rows if r["lam2_minus_naive_min"] <= 0))
