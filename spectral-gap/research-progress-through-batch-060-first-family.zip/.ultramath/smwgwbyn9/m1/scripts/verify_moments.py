"""Exact check: Kesten-McKay moments m_k  (i) via spectral series of G_d,
   (ii) via closed-walk counts on a truncated d-regular tree.  Exact integers."""
from fractions import Fraction
import collections

def poly_mul(a,b,N):
    c=[Fraction(0)]*N
    for i,ai in enumerate(a):
        if ai==0: continue
        for j,bj in enumerate(b):
            if i+j<N: c[i+j]+=ai*bj
    return c

def moments_series(d,K):
    N=K+3
    Cat=[1]
    for n in range(1,N): Cat.append(Cat[-1]*2*(2*n-1)//(n+1))
    # w = sum_{n>=1} Catalan_{n-1} (d-1)^n eps^{2n}
    w=[Fraction(0)]*N
    for n in range(1,N):
        if 2*n<N: w[2*n]=Fraction(Cat[n-1]*(d-1)**n)
    # beta = w/((d-1) eps)
    beta=[Fraction(0)]*N
    for m in range(1,N): beta[m-1]=w[m]/Fraction(d-1)
    # G = beta/(1-beta^2)
    b2=poly_mul(beta,beta,N)
    one=[Fraction(0)]*N; one[0]=Fraction(1)
    den=[one[i]-b2[i] for i in range(N)]           # 1 - beta^2, constant term 1
    # invert den as power series
    dinv=[Fraction(0)]*N; dinv[0]=Fraction(1)
    for m in range(1,N):
        s=Fraction(0)
        for j in range(1,m+1): s+=den[j]*dinv[m-j]
        dinv[m]=-s
    G=poly_mul(beta,dinv,N)
    m=[0]*(K+1)
    for k in range(K+1):
        assert G[k+1].denominator==1,(k,G[k+1])
        m[k]=int(G[k+1])
    return m

def moments_walks(d,K):
    R=K//2+1
    adj=collections.defaultdict(list)
    def rec(path,depth):
        if depth==R: return
        if len(path)==1:
            for i in range(d):
                ch=path+(i,); adj[path].append(ch); adj[ch].append(path); rec(ch,depth+1)
        else:
            adj[path].append(path[:-1])
            for i in range(d-1):
                ch=path+(i,); adj[path].append(ch); adj[ch].append(path); rec(ch,depth+1)
    rec((0,),0)
    nodes=list(adj.keys()); idx={v:i for i,v in enumerate(nodes)}; N=len(nodes)
    nbrs=[sorted({idx[w] for w in adj[v]}) for v in nodes]
    vec=[0]*N; vec[0]=1; out=[1]
    for k in range(1,K+1):
        new=[0]*N
        for u in range(N):
            if vec[u]:
                for w in nbrs[u]: new[w]+=vec[u]
        vec=new; out.append(vec[idx[(0,)]])
    return out

for d in (3,4,5,6):
    K=12
    a=moments_series(d,K); b=moments_walks(d,K)
    print(f"d={d}\n  series   {a}\n  tree-walk{b}\n  ", "MATCH" if a==b else "*** MISMATCH ***")
