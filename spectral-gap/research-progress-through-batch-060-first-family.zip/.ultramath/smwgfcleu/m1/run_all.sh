#!/bin/bash
# Rerun every computation in this directory. Outputs land in out/.
set -e
cd "$(dirname "$0")"
mkdir -p out
python3 code/s04_bloch_vs_explicit.py   > out/run_s04.txt
python3 code/s01_abelian.py             > out/run_s01.txt
python3 code/s01b_d3.py                 > out/run_s01b.txt
python3 code/s03_honeycomb.py           > out/run_s03.txt
python3 code/s05_cyclic.py              > out/run_s05.txt
python3 code/s06_girth_vs_ramanujan.py  > out/run_s06.txt
python3 code/s07_structure.py           > out/run_s07.txt
python3 code/s08_higher_gaps.py         > out/run_s08.txt
python3 code/s09_random_rewiring.py     > out/run_s09.txt
python3 code/s10_M_formula_2d.py        > out/run_s10.txt
python3 code/s11_positivity_2d.py       > out/run_s11.txt
python3 code/s12_coset_minimum.py       > out/run_s12.txt
echo "all scripts finished"
