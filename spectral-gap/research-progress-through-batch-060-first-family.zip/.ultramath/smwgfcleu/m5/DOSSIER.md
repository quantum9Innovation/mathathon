# Almost regular graphs, single degree defects, and what $d-\lambda_k$ actually measures

Swarm member m5, direction d3. Working directory `.ultramath/smwgfcleu/m5/`.
All scripts, raw outputs and derivations cited below are in that directory.

## 0. Summary

I study the smallest possible failure of regularity: a graph that is $d$-regular
except at one vertex. The results are exact, and they contradict three natural
benchmarks.

1. **Spiked tree (proved here, Theorem A).** Let $T(d,\Delta)$ be the tree with one
   vertex of degree $\Delta$ and every other vertex of degree $d$. Then
   $\sigma_{\mathrm{ess}}(A_T) = [-2\sqrt{d-1},\,2\sqrt{d-1}]$, and the discrete
   spectrum outside the bulk is empty when $\Delta \le 2(d-1)$ and equals
   $\{\pm \lambda_*(\Delta)\}$ with
   $$\lambda_*(\Delta) = \frac{\Delta}{\sqrt{\Delta+1-d}}$$
   when $\Delta > 2(d-1)$. At the critical value $\Delta = 2(d-1)$ the would be
   eigenvalue sits exactly on the bulk edge, so no eigenvalue is created.

2. **Finite graphs (proved exact identity, Proposition B).** For any graph $G$ and
   any vertex set $T$ of size $\Delta$, adding one vertex adjacent exactly to $T$
   gives the exact characteristic polynomial identity
   $$\det(\lambda I - A_{G'}) \,=\, \det(\lambda I - A_G)\,
     \Big(\lambda + \mathbf{1}_T^{\top}(A_G-\lambda I)^{-1}\mathbf{1}_T\Big).$$
   Hence the new spectrum is governed by one scalar equation, and a host eigenvalue
   survives exactly when $\mathbf 1_T$ is orthogonal to its eigenspace.

3. **The finite graph threshold is not the tree threshold (conjecture with strong
   numerical support, Proposition D).** For a uniform random $d$-regular host plus
   one spike of fixed degree $\Delta$, the two largest eigenvalues are predicted to
   satisfy
   $$\lambda_1 \to \max(d,\lambda_f), \qquad \lambda_2 \to \min(d,\lambda_f),$$
   where $\lambda_f$ is the unique root of $\lambda = \Delta G_d(\lambda)$ in
   $(2\sqrt{d-1},\infty)$ and $G_d(\lambda)=\int \mathrm{d}\mu_{\mathrm{KM},d}(x)/(\lambda-x)$
   is the Kesten-McKay Stieltjes transform. A root exists exactly when
   $\Delta > 2(d-2)$, which is strictly below the tree threshold $2(d-1)$.
   Numerically $\lambda_f$ wins and $\lambda_*$ loses by a wide margin
   (Section 5, `out/convergence.txt`).

4. **Consequence for $d-\lambda_k$.** For a random $d$-regular graph,
   $d-\lambda_2 \to (\sqrt{d-1}-1)^2 > 0$. A single extra vertex of degree
   $\Delta \ge 5$ in a cubic host drives $\lambda_2$ to $d$ at rate
   $d-\lambda_2 \sim \Delta^2/(n(\Delta G_d(d)-d))$, which was confirmed to about
   one percent (`out/convergence.txt`). Therefore for almost regular graphs
   $d-\lambda_k$ is a degree census, not an expansion or tangle measure. No cut
   and no bottleneck is present.

Status legend used throughout. (L) checked literature statement with URL or arXiv
identifier. (C) exact calculation, reproducible from the files listed. (P) proof
supplied here, written out. (N) numerical experiment, reproducible, not a proof.
(S) conjecture or speculation.

## 1. Model, normalisation, ordering, regimes, and why it matters

**Model A (spiked tree).** $d \ge 3$, $\Delta \ge 1$. $T(d,\Delta)$ is the unique
(free) tree in which exactly one vertex $o$ has degree $\Delta$ and all other
vertices have degree $d$. Such a tree exists for every $\Delta \ge 1$: start from
the $d$-regular tree and, at one vertex, attach $\Delta-d$ extra branches if
$\Delta > d$, or delete $d-\Delta$ branches if $\Delta < d$. This is the universal
cover of a graph that is $d$-regular away from one vertex of degree $\Delta$, with
all neighbours of $o$ having degree $d$. It is the exact local limit at a defect.

**Model B (finite almost regular graph).** $G$ is a simple $d$-regular graph on $n$
vertices, $T \subseteq V(G)$ with $|T| = \Delta$ distinct vertices, and $G'$ is $G$
together with one new vertex $x$ adjacent exactly to $T$. Degrees in $G'$ are
$\Delta$ at $x$ and $d$ elsewhere. Random model: $G$ uniform random $d$-regular,
$T$ a fixed set, $n \to \infty$ with $d$ and $\Delta$ fixed. The regime is
$\Delta = O(1)$, that is, a bounded number of defects, in contrast with the
biregular model of the source dossier where every vertex is perturbed.

**Spectral data.** $A_H$ is the adjacency matrix, eigenvalues ordered
$\lambda_1 \ge \lambda_2 \ge \dots \ge \lambda_{|H|}$. No normalisation is applied
to $A$. The bulk of the $d$-regular infinite tree is
$\mathrm{bulk}_d := [-2\sqrt{d-1},\,2\sqrt{d-1}]$, and
$\mu_{\mathrm{KM},d}$ is the Kesten-McKay measure, the spectral measure of the
$d$-regular tree, supported on $\mathrm{bulk}_d$ with second moment $d$.

**Auxiliary functions.** For $\lambda \notin \mathrm{bulk}_d$ let $r(\lambda)$ be
the unique root of
$$(d-1)\,r + \frac{1}{r} = \lambda,\qquad |r(\lambda)| < 1 .$$
For $\lambda > 2\sqrt{d-1}$ one has $0 < r(\lambda) < 1/\sqrt{d-1}$, the map is
strictly decreasing, and
$$G_d(\lambda) := \int \frac{\mathrm{d}\mu_{\mathrm{KM},d}(x)}{\lambda - x}
= \frac{r(\lambda)}{1-r(\lambda)^2} = \frac{1}{\lambda - d\,r(\lambda)} > 0 .$$
Two special values are used repeatedly:
$$r(d) = \frac{1}{d-1}, \qquad G_d(d) = \frac{d-1}{d(d-2)} .$$

**Why it matters.** Both source dossiers that treat spectral gaps
(Alon's conjecture and the biregular paper) assume exact regularity or an exact
two-class regularity. The user's question about "almost regular graph formats" is
precisely the question of what survives when that hypothesis is weakened. The
answer here is sharp and mildly surprising: the *bulk* is stable under a bounded
number of degree defects, the *near-trivial cluster* is not, and the resulting
change in $d-\lambda_2$ is of constant order even though the graph remains a
bounded degree expander.

## 2. Exact results

### 2.1 Lemma 1 (one-sided regular tree) (P)

Let $D$ be the one sided $d$-regular tree: a root with $d-1$ children, every other
vertex of degree $d$. Then

* $\sigma(A_D) = \mathrm{bulk}_d$, with no eigenvalues,
* for $\lambda > 2\sqrt{d-1}$ the root resolvent is
  $\langle \delta_{\mathrm{root}}, (A_D-\lambda)^{-1}\delta_{\mathrm{root}}\rangle = -r(\lambda)$.

*Proof.* (i) $D$ is a subgraph of the $d$-regular tree $T_d$, so $\ell^2(D)$ is a
subspace of $\ell^2(T_d)$ and $A_D$ is the compression $P A_{T_d} P$. Hence
$\|A_D\| \le \|A_{T_d}\| = 2\sqrt{d-1}$ and $\sigma(A_D)\subseteq \mathrm{bulk}_d$.
(ii) For the reverse inclusion let $\lambda = 2\sqrt{d-1}\cos\theta$ with
$\theta\in(0,\pi)$ and put $z = e^{i\theta}/\sqrt{d-1}$, so that
$(d-1)z^2-\lambda z+1=0$. Let $v^{(N)}$ have $v^{(N)}_0 = 0$ and
$v^{(N)}_n = \mathrm{Re}(z^n)$ for $1\le n\le N$, and $0$ beyond. The eigenvalue
recursion $\lambda v_n = (d-1)v_{n+1}+v_{n-1}$ holds at every level
$1\le n\le N-1$, and the only defect is at level $N$, where the residual is
$-(d-1)v^{(N)}_{N+1}$. Since $N_n=(d-1)^n$ and $|z|=1/\sqrt{d-1}$ give
$\sum_n N_n |v_n|^2 = \Theta(N)$, while
$\|(A_D-\lambda)v^{(N)}\|^2 = O(N_N)=O((d-1)^N)$, the Rayleigh quotient of the
residual tends to $0$. Weyl's criterion gives $\lambda\in\sigma(A_D)$.
(iii) Let $u_n = -r^{n+1}$ with $r=r(\lambda)$. At the root,
$(d-1)u_1 - \lambda u_0 = -(d-1)r^2+\lambda r = 1$ by the defining equation, and
at levels $n\ge1$ the recursion $u_{n-1}+(d-1)u_{n+1}=\lambda u_n$ holds. Also
$\sum (d-1)^n u_n^2 < \infty$ because $r<1/\sqrt{d-1}$. So $u$ is the resolvent
vector and $u_0 = -r$. $\square$

### 2.2 Theorem A (spectrum of the spiked tree) (P)

For $d\ge 3$ and $\Delta\ge1$,
$$\sigma_{\mathrm{ess}}\big(A_{T(d,\Delta)}\big) = \mathrm{bulk}_d,$$
and the discrete spectrum outside $\mathrm{bulk}_d$ is

* empty, if $\Delta \le 2(d-1)$,
* $\{+\lambda_*(\Delta), -\lambda_*(\Delta)\}$ with
  $\lambda_*(\Delta) = \Delta/\sqrt{\Delta+1-d} > 2\sqrt{d-1}$, if
  $\Delta > 2(d-1)$.

*Proof.* Delete the defect vertex $o$. The remaining graph is the disjoint union of
$\Delta$ copies of the one sided tree $D$ of Lemma 1, each rooted at a neighbour of
$o$. Write the block form $A_T - \lambda I = \begin{pmatrix}-\lambda & u^\top\\ u & C-\lambda I\end{pmatrix}$
on $\mathbb{C}\oplus\ell^2(T\setminus\{o\})$, where $u$ is the indicator of the
$\Delta$ neighbours of $o$ and $C$ is the direct sum of the $\Delta$ copies of
$A_D$. By Lemma 1, $\sigma(C)=\mathrm{bulk}_d$, purely essential. The difference
$A_T - (0\oplus C)$ has rank at most $2\Delta$, so Weyl's theorem gives
$\sigma_{\mathrm{ess}}(A_T)=\sigma_{\mathrm{ess}}(C)=\mathrm{bulk}_d$, in
particular $\mathrm{bulk}_d \subseteq \sigma(A_T)$. For $\lambda \notin\mathrm{bulk}_d$
the operator $C-\lambda I$ is invertible and the Schur complement is the scalar
$$S(\lambda) = -\lambda - u^\top (C-\lambda I)^{-1} u = -\lambda - \Delta\cdot\big(-r(\lambda)\big) = -\lambda + \Delta\, r(\lambda),$$
using Lemma 1 in each copy. A standard Schur complement argument gives: for
$\lambda \notin \mathrm{bulk}_d$, $\lambda \in \sigma(A_T)$ if and only if
$S(\lambda)=0$.

It remains to solve $S=0$. On $(2\sqrt{d-1},\infty)$ the function
$\varphi(\lambda) := \Delta r(\lambda)$ is continuous and strictly decreasing, with
$\varphi(2\sqrt{d-1}^+) = \Delta/\sqrt{d-1}$ and $\varphi(\infty)=0$. Hence
$\lambda \mapsto \lambda - \varphi(\lambda)$ is strictly increasing from
$2\sqrt{d-1}-\Delta/\sqrt{d-1}$ to $+\infty$, and a zero exists if and only if
$\Delta/\sqrt{d-1} > 2\sqrt{d-1}$, that is $\Delta > 2(d-1)$. The zero is unique.
Substituting $\lambda = \Delta r$ into $(d-1)r+1/r=\lambda$ gives
$r^2(\Delta-d+1)=1$, hence $r=1/\sqrt{\Delta+1-d}$ and
$\lambda_*=\Delta r=\Delta/\sqrt{\Delta+1-d}$. One checks
$\lambda_*^2-4(d-1) = (\Delta-2(d-1))^2/(\Delta+1-d) > 0$ for
$\Delta>2(d-1)$, so $\lambda_*$ is strictly outside the bulk. The same computation
on $(-\infty,-2\sqrt{d-1})$ gives $-\lambda_*$, which is also forced by the fact
that every tree is bipartite and has a symmetric spectrum. At $\Delta = 2(d-1)$
the two fixed point branches merge at $r=1/\sqrt{d-1}$,
$\lambda = 2\sqrt{d-1}$, which lies on the bulk edge, so no eigenvalue appears.
$\square$

**Remarks.**

* $\lambda_*(\Delta) \to \sqrt{\Delta}$ as $\Delta\to\infty$, the expected scale of
  a star, and $\lambda_*(d)=d$, the trivial Perron value that the infinite tree
  does not carry in $\ell^2$.
* The theorem is a statement about the *essential* spectrum plus discrete spectrum.
  I do not claim here that there are no eigenvalues embedded in $\mathrm{bulk}_d$.
  The numerics of Section 5 show the spectrum of large balls concentrating on
  $\mathrm{bulk}_d \cup \{\pm\lambda_*\}$, which is consistent with no other atoms.
* The mechanism is worth naming: the defect changes the *boundary condition at
  infinity*, not the interior recursion. This is why the bulk is untouched and why
  a single number, $r(\lambda)$, controls everything.

### 2.3 Proposition B (exact secular identity for one added vertex) (P, verified exactly)

Let $G$ be any graph on $n$ vertices, $T\subseteq V(G)$, and let $G'$ be $G$
together with one new vertex adjacent exactly to $T$. With $p_H(\lambda)=\det(\lambda I - A_H)$,
$$\boxed{\,p_{G'}(\lambda) = p_G(\lambda)\Big(\lambda + \mathbf 1_T^{\top}(A_G-\lambda I)^{-1}\mathbf 1_T\Big)\,}$$
as an identity of rational functions, polynomial after multiplying out.

*Proof.* Order the vertices of $G'$ with the new vertex first. The Schur complement
of the $(1,1)$ block of $\lambda I - A_{G'}$ is the scalar
$\lambda + \mathbf 1_T^\top(A_G-\lambda I)^{-1}\mathbf 1_T$ whenever
$\lambda\notin\sigma(A_G)$, and the determinant is the product. Both sides are
rational functions agreeing off a finite set, hence identical. $\square$

**Corollaries (P).**

1. For $\lambda\notin\sigma(A_G)$, $\lambda\in\sigma(A_{G'})$ if and only if
   $$\Sigma(\lambda) := \lambda + \sum_i \frac{(\mathbf 1_T^\top u_i)^2}{\lambda_i-\lambda} = 0 ,$$
   where $(\lambda_i,u_i)$ is an orthonormal eigenbasis of $A_G$.
2. (Survival criterion.) If $\lambda_i$ is an eigenvalue of $A_G$ of multiplicity
   $m_i$, then $\lambda_i$ is an eigenvalue of $A_{G'}$ of multiplicity $m_i$ if
   $\mathbf 1_T \perp \ker(A_G-\lambda_i I)$, and of multiplicity at least
   $m_i-1$ otherwise. Exact examples are in `out/exact_secular.txt`:
   for $G=K_{3,3}$ and $T$ one side, the host eigenvalues $\pm3$ are destroyed and
   only $0$ survives, and $G'=K_{3,4}$ has spectrum $\{\pm2\sqrt3, 0^{5}\}$.
3. (Interlacing, classical Cauchy.) The eigenvalues of $A_G$ interlace those of
   $A_{G'}$: exactly one new eigenvalue appears in each gap of $\sigma(A_G)$, one
   above $\lambda_1(A_G)$ and one below $\lambda_{|G|}(A_G)$.
4. $\Sigma$ has a simple pole at each $\lambda_i$ with
   $\mathbf 1_T^\top u_i \neq 0$, and $\Sigma(\lambda)\sim\lambda$ as
   $|\lambda|\to\infty$. Hence on a window strictly above the bulk of a random
   regular host the only relevant balance is between the smooth part and the
   Perron pole at $\lambda_1=d$.

The identity was checked in exact integer and rational arithmetic, with no floating
point, on three instances: $K_{3,3}$ plus a spike of degree 3 (giving $K_{3,4}$),
the cube $Q_3$ plus a spike of degree 5, and $K_5$ plus a spike of degree 2. In
each case $p_G\Sigma - p_{G'} = 0$ identically (sign convention of
$\det(\lambda I - A)$). See `scripts/exact_secular.py` and
`out/exact_secular.txt`.

### 2.4 Lemma C (near trivial cluster, unconditional) (P)

Let $H$ be a graph on $N$ vertices whose degrees satisfy $|\deg_H(v)-d|\le \eta$ for
$v\in S$ and $\deg_H(v)=d$ otherwise. Then $A_H$ has an eigenvalue in the interval
$[\,d-\eta\sqrt{|S|/N},\, d+\eta\sqrt{|S|/N}\,]$.

*Proof.* Let $v = N^{-1/2}\mathbf 1$. Then
$\|(A_H-dI)v\| = N^{-1/2}\|(\deg_H-d\mathbf 1)\| \le \eta\sqrt{|S|/N}$, and for a
symmetric matrix the distance from $d$ to the spectrum is at most
$\|(A_H-dI)v\|$. $\square$

For Model B, $|S|=1$, $\eta = |\Delta-d|$, so one of $\lambda_1,\lambda_2$ is
within $|\Delta-d|/\sqrt{n+1}$ of $d$. This statement is elementary and certainly
folklore (the equality case $|\Delta-d|=0$ is the classical fact
$\lambda_1 \ge \overline{\deg}$, with equality iff regular). Its content here is
qualitative: the "trivial eigenvalue" $d$ of a regular graph is not trivial for an
almost regular graph, and it drags a genuine spectral point with it. The sharper
$O(1/n)$ statement in Proposition D needs the extra input described in Section 4.

### 2.5 Proposition D (finite graph, conditional asymptotic) (S, numerically supported)

Fix $d\ge3$ and $\Delta\ge1$. Let $G_n$ be uniform random $d$-regular on $n$
vertices, $T_n$ a fixed $\Delta$-set, $G_n'$ the graph plus the spike. Assume

**(H)** for every compact $K\subset (2\sqrt{d-1},d)\cup(d,\infty)$ and every fixed
finite $T$,
$$\sup_{\lambda\in K}\Big|\,\mathbf 1_T^\top(A_{G_n}-\lambda I)^{-1}\mathbf 1_T
+ \Delta\, G_d(\lambda)\Big| \longrightarrow 0 \quad\text{in probability.}$$

Let $\lambda_f=\lambda_f(d,\Delta)$ be the unique root of
$\lambda = \Delta G_d(\lambda)$ in $(2\sqrt{d-1},\infty)$, and set
$\lambda_f := 2\sqrt{d-1}$ when $\Delta \le 2(d-2)$. Then
$$\lambda_1(G_n') \to \max(d,\lambda_f), \qquad
  \lambda_2(G_n') \to \min(d,\lambda_f)$$
in probability, and the root exists exactly when $\Delta > 2(d-2)$.

*Derivation.* $\Sigma(\lambda) = \lambda + \mathbf 1_T^\top(A_G-\lambda)^{-1}\mathbf 1_T$.
By (H) and Corollary 4, on a compact window avoiding $d$ and the bulk,
$$\Sigma(\lambda) \approx \big(\lambda - \Delta G_d(\lambda)\big)
+ \frac{\Delta^2}{n(\lambda-d)},$$
because $u_1 = n^{-1/2}\mathbf 1$ exactly for a connected $d$-regular graph and
$\mathbf 1_T^\top u_1 = \Delta/\sqrt n$, so the Perron term contributes exactly
$\Delta^2/(n(\lambda-d))$. Three consequences.

(a) At $\lambda\downarrow 2\sqrt{d-1}$ the first bracket equals
$\sqrt{d-1}\,(2-\Delta/(d-2))$, which is negative exactly when $\Delta>2(d-2)$,
while as $\lambda\uparrow d$ the last term tends to $+\infty$. So a root of
$\Sigma$ in $(2\sqrt{d-1},d)$ is forced exactly when $\Delta>2(d-2)$, and this is
the root that becomes $\lambda_2$ when $\Delta G_d(d)-d>0$ and $\lambda_1$ when
$\Delta G_d(d)-d<0$.

(b) As $\lambda\downarrow d$ the last term tends to $-\infty$ and as
$\lambda\to+\infty$ we have $\Sigma\sim\lambda$, so there is always a root in
$(d,\infty)$. This is why $\lambda_1(G')>d$ always, in agreement with interlacing.

(c) The two roots carry the two largest eigenvalues, in the order determined by the
sign of $\Delta G_d(d)-d$. The remaining root converges to $\lambda_f$ as the
Perron term becomes negligible away from $d$. $\square$

**Explicit finite size law** (same derivation, keeping $\varepsilon=d-\lambda$):
$$\lambda_2(G_n') = d - \varepsilon,\qquad
\varepsilon = \frac{\Delta^2}{n\big(\Delta G_d(d)-d\big)}\,(1+o(1)),$$
valid when $\Delta G_d(d) > d$, that is when
$\Delta > d^2(d-2)/(d-1)$. The derivation keeps the next term,
$\varepsilon^2 + \varepsilon(\Delta G_d(d)-d) = \Delta^2/n$, which is why the
leading order has no free constant. Equivalently
$$d-\lambda_2 \,\sim\, \frac{\Delta^2\, d(d-2)}{n\big(\Delta(d-1)-d^2(d-2)\big)} .$$
For $d=3$, $\Delta=6$ this predicts $n(d-\lambda_2)\to 36 = \Delta^2$, observed
values $31.1,\,35.0,\,35.9,\,35.5,\,36.0$ for $n=10^3,\dots,1.6\cdot10^4$
(`out/convergence.txt`). This is a one percent agreement with an asymptotic law
that contains no fitted constant.

**Threshold comparison.**

| quantity | value | exists when |
|---|---|---|
| regular Alon-Boppana and Friedman threshold | $2\sqrt{d-1}$ | always |
| spiked tree eigenvalue $\lambda_*$ | $\Delta/\sqrt{\Delta+1-d}$ | $\Delta > 2(d-1)$ |
| finite graph fixed point $\lambda_f$ | root of $\lambda=\Delta G_d(\lambda)$ | $\Delta > 2(d-2)$ |
| mean degree benchmark (irregular) | $2\sqrt{\bar d-1}$, $\bar d\to d$ | always |

The three thresholds $2(d-2)$, $2(d-1)$ and $\infty$ are genuinely different, and
the correct one for a bounded number of defects is $2(d-2)$. The numerical
discriminator is unambiguous: for $(d,\Delta)=(3,6)$ the tree predicts $3.0$ and
the fixed point predicts $3.1807$, and the observed $\lambda_1$ tends to
$3.1817$ from above as $n$ grows, see Section 5.

## 3. Falsification: which candidate benchmark fails, and how

The point of this section is that four plausible statements are all wrong for
almost regular graphs, and each fails in a different way. All numbers are from
`out/convergence.txt`, `out/almost_regular_census.txt`,
`out/spiked_tree_jacobi.txt` and `out/verify_tree_balls.txt`.

**F1. "A single degree defect cannot beat the regular Alon-Boppana threshold."**
False. Theorem A gives a defect eigenvalue for every $\Delta>2(d-1)$, and
Proposition D predicts the same separation from the bulk for finite graphs already
at $\Delta > 2(d-2)$. Example $(d,\Delta)=(5,8)$: bulk edge $4$, observed
$\lambda_2 = 4.052$ at $n=4000$ and $4.0619$ at $n=16000$, predicted
$\lambda_f = 4.0630$. The excess over $2\sqrt{d-1}$ is a constant, not $o(1)$.

**F2. "The local limit at the defect gives the defect eigenvalue."** False for
finite graphs, and this is the sharpest negative result of the dossier. The local
limit is $T(d,\Delta)$, whose defect eigenvalue is $\lambda_*$. For
$(d,\Delta)=(4,7)$: $\lambda_*=3.5$, $\lambda_f=3.62843$, observed
$\lambda_2 = 3.6635,\,3.6299,\,3.6067,\,3.6319,\,3.6242$ for
$n=10^3,\dots,1.6\cdot10^4$, converging to $\lambda_f$ and not to $\lambda_*$.
The two thresholds also differ, $2(d-2)=4$ versus $2(d-1)=6$. The mechanism is
visible in Proposition B: in a finite $d$-regular host the Perron eigenvalue is
exactly $d$, so the host resolvent has a pole at the trivial value $d$ that the
infinite tree does not have (the constant function is not $\ell^2$ on a tree). The defect eigenvalue of the infinite tree is a property of the boundary at
infinity, and the finite graph never sees that boundary. It sees the host instead.

**F3. "The correct benchmark in the irregular case is the mean degree, $2\sqrt{\bar d-1}$."**
Not sharp. Here $\bar d \to d$, so the mean degree benchmark is
$2\sqrt{d-1}+o(1)$, which is F1 again. The existing irregular Alon-Boppana theory
(Rahman, arXiv:1609.02209) is a lower bound in terms of the mean degree of a
unimodular local limit and is not designed to be attained.

**F4. "The limiting spectral distribution edge bounds $\lambda_2$."** Not
attained. Dogon and Maor (arXiv:2611.09732) report for the irregular configuration
model that the limiting spectral edge is $2\sqrt{\delta-1}/\delta$ in their
normalisation while the observed second eigenvalues stay strictly and
substantially below it. My single defect computation is the extreme case of the
same phenomenon in the other direction: the spectral measure of the spiked graph
converges to the *unchanged* Kesten-McKay measure plus a vanishing atom (mass
$1/n$ at the defect eigenvalue), so the limiting spectral distribution cannot see
the defect eigenvalue at all, while $\lambda_2$ moves by $\Theta(1)$.

**F5. "Small $d-\lambda_2$ means a bottleneck."** False in the almost regular
setting. For a random cubic host plus one vertex of degree 6, $d-\lambda_2 \to 0$
while the graph has edge expansion bounded below by
$(d-\lambda_2^{\mathrm{reg}})/2$ of the host in the sense of Cheeger for the host,
and no cut of size $o(n)$ exists. In the language of the source dossiers, there is
no tangle: the lowering mechanism is not a rare defect of the walk count, it is a
single vertex.

**Quantitative summary for the user's question.** For a graph that is $d$-regular
off a bounded set of defect vertices of degrees $\Delta_1,\dots,\Delta_k$, the
prediction is that $\lambda_1,\dots,\lambda_{k+1}$ are the multiset
$$\{d\} \cup \{\lambda_f(\Delta_i) : \Delta_i > 2(d-2)\} \cup
\{2\sqrt{d-1}\ \text{with multiplicity } k - \#\{i:\Delta_i>2(d-2)\}\}$$
sorted, up to $o(1)$. Hence $d-\lambda_2, d-\lambda_3,\dots,d-\lambda_{k+1}$ is a
*sorted list of defect degrees*, transformed by an explicit monotone map
$\Delta \mapsto d-\lambda_f(\Delta)$, and says nothing about $3$-way or $k$-way
structure. Numerical support for two and three spikes is in
`out/almost_regular_census.txt`, qualitatively correct and quantitatively noisy:
for $d=5$ and degrees $\{9,14,20\}$ the predicted defect values are
$5.1147,\,4.5565,\,4.1265$ and the observed top four are
$5.260,\,4.894,\,4.526,\,4.117$. The two $o(1)$ defects visible in that table are
the finite size correction $\Delta^2/n$ of Section 2.5, which is large there
($\Delta^2/n\approx0.1$).

## 4. The single technically hardest missing estimate

Everything in Proposition D and in F2 traces to one statement, hypothesis (H):

> **Missing estimate.** For uniform random $d$-regular $G_n$, every fixed finite
> $T$, and every compact $K\subset(2\sqrt{d-1},d)\cup(d,\infty)$,
> $$\sup_{\lambda\in K}\Big|\,\mathbf 1_T^\top (A_{G_n}-\lambda I)^{-1}\mathbf 1_T
> - \big(-\Delta\, G_d(\lambda)\big)\Big| \to 0$$
> in probability, with a rate, and the same for finite rank perturbations of
> $\mathbf 1_T$.

Why this is the hard part, and why nothing cheaper suffices:

1. **Spectrum alone is not enough.** A deterministic bound using only
   $\lambda_2(G_n)\le \Lambda$ and $\|\mathbf 1_T\|^2=\Delta$ gives
   $|\mathbf 1_T^\top(A_G-\lambda)^{-1}\mathbf 1_T|\le \Delta/(\lambda-\Lambda)$
   on the spectral side, which for $\lambda$ within $O(1)$ of $\Lambda$ is a
   constant much larger than the true value $-\Delta G_d(\lambda)$. Comparing the
   two at $(d,\Delta)=(3,6)$, $\lambda\approx 3.18$: the true value is
   $-6\times 0.179 \approx -1.07$, while the spectral bound is at least
   $6/(3.18-2.83)\approx 17$. So the spectral hypothesis is off by an order of
   magnitude and cannot locate the root. The missing input is genuinely a
   *delocalisation* statement about eigenvectors at a fixed finite set, not a
   statement about eigenvalues.
2. **The bulk local law does not cover the window.** The strongest available input
   is the local Kesten-McKay law of Bauerschmidt, Huang and Yau
   (arXiv:1609.09052), which approximates Green's functions by tree-like graphs
   inside the bulk, down to the optimal scale, and gives complete delocalisation of
   bulk eigenvectors. The window needed here is *outside* the bulk,
   $\lambda\in(2\sqrt{d-1},d)$, where the resolvent kernel is not oscillatory and
   should be easier, but a statement uniform in the two-point set $T$ and in
   $\lambda$ is not among the standard local law statements.
3. **The expected route.** Three ingredients, all standard in principle.
   (a) A completely analytic expansion of $(A_G-\lambda)^{-1}_{yy'}$ over
   non-backtracking paths with weight $\prod r(\lambda)$-type factors. For
   $\lambda>2\sqrt{d-1}$ the weights decay geometrically in the path length, so the
   resolvent entry is determined by a window of radius $O(\log n)$.
   (b) The radius $c\log n$ neighbourhood of a fixed finite set is a tree with high
   probability (this is Lemma 5 of the biregular dossier and Lemma 5 of
   Bordenave's lifts paper, both available in `.paper-mastery`).
   (c) A second moment or concentration bound over the random matching, as in
   Friedman's or Bordenave's moment method, but applied to the resolvent rather
   than to traces.
   The technically hardest single step is (c) with the correct centring, because the
   resolvent expansion sums $n^{O(1)}$ non-backtracking paths and the centring must
   not lose the factor $n^{-1}$ that makes the $O(1/n)$ correction in Section 2.5
   visible.
4. **What would falsify the programme.** A counterexample to (H), for instance a
   random regular graph with an edge eigenvector with mass $\gg n^{-1/2}$ on a
   fixed finite set in the window above the bulk. Nothing in the numerics suggests
   this, and the local law in the bulk rules out the analogous phenomenon there.
   Equally, (H) could fail only for $\lambda$ exponentially close to $d$, which is
   precisely the regime that the finite size law of Section 2.5 quantifies.

## 5. Numerical experiments

All scripts are in `scripts/`, all raw outputs in `out/`. Each script is
self-contained, takes no arguments and uses fixed seeds.

| file | what it does | key numbers |
|---|---|---|
| `scripts/spiked_tree_jacobi.py` | truncated radial Jacobi matrix of $T(d,\Delta)$, $N=4000$ | reproduces $\pm\lambda_*$ to six decimals for seventeen $(\Delta,d)$ pairs, and $\pm2\sqrt{d-1}$ for all $\Delta\le2(d-1)$ |
| `scripts/verify_tree_balls.py` | genuine balls of $T(d,\Delta)$, sparse eigensolver | top eigenvalue of balls converges to $\lambda_*$ for $\Delta>2(d-1)$ and to the bulk edge otherwise, up to $1.3\cdot10^6$ vertices |
| `scripts/exact_secular.py` | exact rational verification of Proposition B | identity holds identically on three graphs, survival criterion confirmed |
| `scripts/one_spike_finite.py` | random $d$-regular host plus one spike, several $(d,\Delta)$ | $\lambda_1$ tracks the fixed point, not $\lambda_*$ |
| `scripts/almost_regular_census.py` | one, two and three spikes, threshold scan | threshold $2(d-2)$ confirmed, census prediction qualitatively confirmed |
| `scripts/convergence.py` | convergence in $n$ for three $(d,\Delta)$ pairs | $n(d-\lambda_2)\to\Delta^2$ for $(d,\Delta)=(3,6)$, and $\lambda_2\to\lambda_f$ for $(4,7)$, $(5,8)$ |
| `scripts/diag_secular.py` | direct evaluation of the secular sum against the exact spectrum | identifies the sign and the size of each term |
| `scripts/arxiv_q.py`, `scripts/arxiv_abs.py` | arXiv API queries used for Section 6 | raw metadata in `out/abs_batch*.txt` |

Selected raw output, `out/spiked_tree_jacobi.txt` (columns: $d$, $\Delta$,
$2(d-1)$, extreme eigenvalues, prediction, bulk edge):

```
  d  Delta  2(d-1)      lam_max      lam_min     pred +     pred -      edge
  3      4       4    -2.828427     2.828427        nan        nan  2.828427
  3      5       4    -2.886751     2.886751   2.886751  -2.886751  2.828427
  3     12       4    -3.794733     3.794733   3.794733  -3.794733  2.828427
  4      6       6    -3.464101     3.464101        nan        nan  3.464102
  4      7       6    -3.500000     3.500000   3.500000  -3.500000  3.464102
  4     20       6    -4.850713     4.850713   4.850713  -4.850713  3.464102
  5      8       8    -4.000000     4.000000        nan        nan  4.000000
  5      9       8    -4.024922     4.024922   4.024922  -4.024922  4.000000
```

The critical cases $\Delta=2(d-1)$, namely $(3,4),(4,6),(5,8)$, are exactly the
rows where the prediction is empty and the extreme eigenvalue equals the bulk edge.
That is the resonance of Theorem A, and it is exact to six decimals.

Selected raw output, `out/convergence.txt`:

```
 d  Del       n       lam1       lam2  lam*=tree      lamf    d-lam2  n*(d-lam2) |lam1-lamf|
 3    6    1000   3.207730   2.968902   3.000000  3.180699  0.031098     31.0975    0.027032
 3    6    4000   3.184565   2.991013   3.000000  3.180699  0.008987     35.9461    0.003866
 3    6   16000   3.181661   2.997748   3.000000  3.180699  0.002252     36.0367    0.000962
 4    7    1000   4.035837   3.663496   3.500000  3.628433  0.336504    336.5038    0.035837
 4    7   16000   4.002206   3.624207   3.500000  3.628433  0.375793   6012.6901    0.002206
 5    8    4000   5.005526   4.051504        nan  4.062981  0.948496    3793.9849    0.005526
 5    8   16000   5.001391   4.061854        nan  4.062981  0.938146   15010.3335    0.001391
```

Reading the table: $|\lambda_1-\lambda_f|$ decreases like $1/n$ across two orders
of magnitude in $n$, and $\lambda_2$ converges to $\lambda_f$ for $(4,7)$ and
$(5,8)$ while the tree prediction $3.5$ and `nan` is decisively excluded. For
$(3,6)$, where $\lambda_f>d$, $\lambda_1\to\lambda_f$ and $\lambda_2\to d$ with
$n(d-\lambda_2)\to36=\Delta^2$ as predicted in Section 2.5.

Convention note for `out/diag_secular.txt`: the printed column `S(lam)` is
$\lambda+\sum_i(\mathbf 1_T^\top u_i)^2/(\lambda-\lambda_i)$, that is the
resolvent with denominators $\lambda-\lambda_i$. The secular function used in
Proposition B is $\Sigma(\lambda)=\lambda+\sum_i(\mathbf 1_T^\top u_i)^2/(\lambda_i-\lambda)$,
and the two are related by $S+\Sigma=2\lambda$. The zero crossing of $\Sigma$
computed from that file agrees with the direct eigenvalue of $A_{G'}$ to five
decimals, which is how the identity was first located.

Two honest caveats about the numerics. First, `nx.random_regular_graph` is not a
certified uniform sampler for large $n$, so the experiments test the law of a
random regular graph with the standard generator, not a formally specified
measure. Second, all spectral solver calls use `scipy.sparse.linalg.eigsh` with
default tolerances, so the last digit or two of every printed number is not
significant. Neither caveat affects the comparisons made, which are at the
$10^{-2}$ level between predictions that differ by $10^{-1}$.

## 6. Literature, with exact statements

All statements in this section are (L) unless noted. Where I read an abstract only,
I say so. Versions are the arXiv versions quoted, accessed 2026-11-14. Local copies
of the raw metadata are in `out/abs_batch1.txt`, `out/abs_batch2.txt`,
`out/abs_batch3.txt` and `out/blm.txt`.

**L1. Friedman, Alon's second eigenvalue conjecture.**
J. Friedman, *A Proof of Alon's Second Eigenvalue Conjecture and Related Problems*,
arXiv:cs/0405020v1. For fixed $d\ge3$ and every $\varepsilon>0$, a uniform random
$d$-regular graph on $n$ vertices satisfies $\lambda_2 \le 2\sqrt{d-1}+\varepsilon$
with probability tending to $1$. This is the $d$-regular benchmark that my
Proposition D shows to be unstable under one degree change.

**L2. Brito, Dumitriu, Decker Harris, biregular spectral gap.**
arXiv:1804.07808v6, Combinatorics, Probability and Computing 31 (2022) 229-267.
For a uniform simple bipartite graph with biadjacency
$X\in\{0,1\}^{n\times m}$ with row sums $d_1$ and column sums $d_2$, fixed
$d_1\ge d_2\ge3$, asymptotically almost surely: second singular value
$\eta \le \sqrt{d_1-1}+\sqrt{d_2-1}+\varepsilon_n'$ (Theorem 4(i)) and second
non-backtracking eigenvalue $|\lambda_2(B)| \le ((d_1-1)(d_2-1))^{1/4}+\varepsilon_n$
(Theorem 3). This is the exact "two degree classes" analogue of my model, and it is
the natural contrast case: when a positive fraction of vertices is perturbed, the
threshold becomes a genuine two-type expression of size $\sqrt{d_1-1}+\sqrt{d_2-1}$,
while for a bounded number of defects the threshold is the fixed point $\lambda_f$
of Section 2.5. The two regimes do not interpolate naively.

**L3. Bordenave, Friedman's theorem via non-backtracking and random lifts.**
arXiv:1502.04482v4, to appear in Annales scientifiques de l'ENS. The proof reduces
the spectral statement to a non-backtracking moment computation with tangle
deletion and local tree-likeness at radius $c\log n$. My missing estimate of
Section 4 is the resolvent analogue of the same architecture.

**L4. Friedman and Kohler, relativized second eigenvalue.**
arXiv:1403.3462v1. For a fixed $d$-regular base $B$ and a random cover
$G\in\mathcal C_n(B)$ in the Broder-Shamir model, $\Pr[\rho_B^{\mathrm{new}}(A_G)
\ge 2\sqrt{d-1}+\varepsilon] \le C_{B,\varepsilon}n^{-1}$ (Theorem 0.1.1), and for
Ramanujan bases the sharp exponent is the fundamental order $\eta_{\mathrm{fund}}(B)$,
the minimum order of a strict tangle in $B$ (Theorem 0.1.3). The mechanism is a
tangle in the base, counted with a rare defect exponent. My model has no base and
no cover, and the mechanism is a single vertex, so the relativized paradigm does not
apply. This is the reason I state F5 (no tangle) explicitly.

**L5. Bordenave, Lelarge, Massoulié, non-regular Ramanujan graphs.**
arXiv:1501.06087v2. From the paper text (page 2, read locally in `out/blm.txt`):
Lubotzky's extension of the Ramanujan property to non-regular graphs is
$$\max\{|\lambda| : \lambda\in\mathrm{spec}(A),\ |\lambda|\neq\rho\}\le\sigma,$$
where $\rho$ is the spectral radius of $A$ and $\sigma$ is the spectral radius of
the adjacency operator on the universal covering tree of $G$. The same text records
the Stark-Terras graph Riemann hypothesis, that the non-backtracking matrix has no
eigenvalue with modulus in $(\sqrt{\rho_B},\rho_B)$, and notes that for regular
graphs the two notions coincide. The paper studies the non-backtracking spectrum of
sparse Erdős-Rényi graphs and the stochastic block model.

*Important qualification.* Lubotzky's $\sigma$ is the spectral radius of the
*universal cover*, and the universal cover of a graph with one degree-$\Delta$
vertex has infinitely many degree-$\Delta$ vertices, one for each homotopy class.
So $\sigma$ for a spiked graph is not the spectral radius of $T(d,\Delta)$. My
$T(d,\Delta)$ is the Benjamini-Schramm local limit rooted at the defect, a different
infinite object. I have not computed $\sigma$ for the spiked graph, and I make no
claim about whether $\lambda_2$ can exceed it.

**L6. Rahman, Alon-Boppana for irregular graphs.**
arXiv:1609.02209v4. Abstract statement: a lower bound for the spectral radius of the
adjacency operator and of the Markov operator of a unimodular network in terms of its
average degree, giving an Alon-Boppana type bound for large connected bounded degree
graphs that generalises the regular Alon-Boppana theorem. This is the existing
irregular benchmark, and it is a mean-degree bound, hence of size $2\sqrt{d-1}+o(1)$
for a bounded number of defects. It is consistent with my results and far from sharp
for the quantity $d-\lambda_2$.

**L7. Jiang, spectral radii of unraveled balls.**
arXiv:1710.06719v2. Abstract statement: if the average degree of $G$ after deleting
any ball of radius $r$ is at least $d$, then
$\lambda_2(G)\ge 2\sqrt{d-1}\cos(\pi/(r+1))$. Again a lower bound of regular-tree
type, and again insensitive to a bounded number of defects.

**L8. Dogon and Maor, typical spectra of irregular graphs.**
arXiv:2611.09732v1, submitted 2026-11-06. Abstract statements, quoted because they
are the closest recent work: for the irregular configuration model with a uniformly
bounded degree sequence with nonconstant limiting degree law of minimum $\delta\ge2$,
the interlacing bound of Cohen and Maor, asymptotically $2\sqrt{\mu-1}/\mu$ for
limiting average degree $\mu$, is atypical, and a random graph exceeds it by a
positive constant with high probability. The gap is explained by the limiting
spectral distribution, whose support edge is $2\sqrt{\delta-1}/\delta$. They also
report that second eigenvalues remain far below this limiting edge for the largest
graphs tested, propose that scarcity of minimum-degree trees explains it, and
estimate spectral witnesses within $O((\log\log n)^{-2})$ of the limiting edge.
(Their normalisation is not the raw adjacency, so the constants should not be
compared directly with mine.) This is the closest existing evidence that, for
irregular graphs, the bulk edge and $\lambda_2$ decouple. My Section 3, F4, is the
extreme case of that decoupling in the opposite direction: one defect moves
$\lambda_2$ by $\Theta(1)$ while the limiting spectral distribution does not move at
all.

**L9. Bauerschmidt, Huang, Yau, local Kesten-McKay law.**
arXiv:1609.09052v3. Abstract statement: for random $d$-regular graphs with large but
fixed $d$, in the bulk of the spectrum down to the optimal spectral scale, Green's
functions are approximated by those of infinite tree-like graphs depending only on
the local structure, which implies the Kesten-McKay law down to the smallest scale
and complete delocalisation of bulk eigenvectors. This is the strongest available
input towards my missing estimate (H), and it does not cover the window outside the
bulk that Proposition D needs.

**L10. Benaych-Georges, Bordenave, Knowles, largest eigenvalues of sparse inhomogeneous Erdős-Rényi graphs.**
arXiv:1704.02953v1. Abstract statement: for maximal mean degree $d\ll\log n$, the
$n^{1-o(1)}$ largest eigenvalues of the adjacency matrix are governed at first order
by the largest degrees and by the nonzero eigenvalues of the expectation matrix. The
qualitative message, that a small number of high degrees controls the top of the
spectrum, is consistent with my $\lambda_1\to\max(d,\lambda_f)$ and $\lambda_f\asymp
\sqrt{\Delta}$ for large $\Delta$. The models differ (inhomogeneous ER versus exact
regular plus one spike), so this is context, not a special case.

**L11. Abbe and Ralli, Alon-Boppana for powered graphs.**
arXiv:2006.11248v1. Abstract statement: a generalisation of Alon-Boppana to the
$r$-th power of a graph, including irregular graphs, with a corresponding notion of
generalised Ramanujan graph, and the observation that the powering notion is more
robust than the non-backtracking notion under adversarial modification of
$\log^c n$ vertices. This is the only source I found that explicitly addresses
robustness of a Ramanujan-type threshold under vertex-level modification, and it
addresses a different modification (subgraph replacement) and a different operator
(graph powers).

**L12. Keller, Lenz, Warzel, and Keller, spectra of substitution type trees.**
arXiv:1001.3600v2 and arXiv:1101.2975v1. Abstract statements: for rooted trees
generated by substitution processes (a class containing all regular trees) the
spectrum of the graph Laplacian is purely absolutely continuous with finitely many
bands, and small radially symmetric perturbations can destroy the absolutely
continuous spectrum for regular trees but not for non-regular ones. Theorem A is a
finite defect statement outside that class (a single defect is not radially
symmetric in the substitution sense, and the defect is not small), so these results
do not imply it. The "stability of the absolutely continuous spectrum fails exactly
for regular trees" message is the structural analogue of my F2.

**L13. Cohen and Maor, cited in L8.** I did not read this source and therefore make
no statement about it beyond what L8 reports.

**What is not in the literature, as far as I could check.** I found no source that
states Theorem A (the exact spiked tree threshold $2(d-1)$ and the resonance at
$\Delta=2(d-1)$), and no source that states the finite-graph fixed point
$\lambda=\Delta G_d(\lambda)$ with threshold $2(d-2)$ for a single degree defect.
The ingredient identities (Schur complement, interlacing, Ihara-Bass) are classical,
and the BBP-type centreing on a Stieltjes transform is standard in the deformed
random matrix literature (L10 and its companion). I therefore present Theorem A and
Proposition B as results with complete proofs here, and Proposition D as a
conjecture with a derivation, numerical support, and one clearly identified missing
estimate. I cannot certify novelty exhaustively.

## 7. Common ground with the four source dossiers

**Alon's second eigenvalue (Friedman, arXiv:cs/0405020v1).** Shared object: the
non-backtracking operator and the local tree limit $T_d$ with bulk
$[-2\sqrt{d-1},2\sqrt{d-1}]$. Shared mechanism: a sharp infinite-object threshold
plus control of local defects. Difference: Friedman controls *rare walk defects*
(tangles) in a regular graph and keeps regularity. I keep the walk structure regular
and put the defect in the degree sequence. The two controls are of different natures:
Friedman's failure probability is $O(n^{-\eta})$ with $\eta$ the fundamental order,
while my defect is deterministic and produces an $O(1)$ spectral shift.

**Biregular spectral gap (arXiv:1804.07808v6).** Shared object: the two sided
Ihara-Bass transfer $y = x + ab/x + a + b$, which in my notation is the content of
$G_d$ and $r(\lambda)$. Their $|x|=\sqrt{ab}$ circle corresponds to my bulk edge, and
their upper edge $\sqrt{a}+\sqrt{b}$ is exactly my $\sqrt{d_1-1}+\sqrt{d_2-1}$. The
"fixed degrees, all vertices perturbed" hypothesis is the boundary case of the
present work at the opposite extreme from one defect. My Section 3 shows that the
two extremes give genuinely different thresholds, so a unified statement would need
a second parameter, the density of defects.

**Friedman's theorem via lifts (Bordenave, arXiv:1502.04482v4).** Shared object:
non-backtracking paths, tangle-free local structure at radius $c\log n$, and the
passage from non-backtracking scale to adjacency scale. My missing estimate (H) is
precisely the resolvent version of that passage, and the reason I need it rather
than an eigenvalue count is that a bounded number of defects changes only $O(1)$
eigenvalues, so trace or moment statements at scale $n$ cannot see them.

**Relativized second eigenvalue (arXiv:1403.3462v1).** Shared object: the notion of
"new" spectrum in a cover and the tangle as the mechanism that creates exceptional
eigenvalues. Difference: their new spectrum is exactly the part not inherited from
the base, and the base is fixed. My model has no base and the new spectrum is exactly
two eigenvalues, one at each end of the spectrum, with an explicit scalar equation.
This is a case where the relativized question has a completely explicit answer,
because the "base" is a single vertex.

## 8. Relation to the other swarm directions

* Direction d1 (m8), hypergraph normalisation and the cliques expansion $W$. If one
  takes the cliques expansion of a $k$-uniform $d$-regular hypergraph and then
  perturbs the degree of a single vertex, my Lemma C and Proposition B apply
  verbatim, because they are statements about an arbitrary graph plus one vertex.
  The $k$-uniform structure enters only through the values of $d$ and $\Delta$.
  This gives a cheap way to test d1's normalisation claims on a family where the
  answer is known exactly.
* Direction d2 (m1), abelian covers and Bloch band edges. Their "band edge sampling"
  defect is a lattice effect that persists as $n\to\infty$ at rate $n^{-2}$. Mine is
  a single vertex effect that persists at rate $1/n$ but changes the *value* of
  $\lambda_2$ by $\Theta(1)$. The two mechanisms are additive in the simplest
  combined model, namely a periodic host plus one defect, and that combined model is
  the natural next experiment, listed as P2 below.

## 9. Unresolved steps and prioritized next work

**P1 (highest value). Prove hypothesis (H), or a version of it with a rate.** The
natural target is: for fixed $\lambda > 2\sqrt{d-1}+\eta$ and fixed finite $T$,
$\mathbf 1_T^\top(A_{G_n}-\lambda)^{-1}\mathbf 1_T = -\Delta G_d(\lambda) + O(n^{-1/2+\epsilon})$
with high probability. This would upgrade Proposition D from conjecture to theorem
and would also give the finite size law of Section 2.5 with a rate. The route is
sketched in Section 4: non-backtracking resolvent expansion, tree-likeness at
$c\log n$, and a second moment over the configuration model.

**P2. Settle the intermediate density regime.** With $k=k(n)$ defects,
$1 \ll k \ll n$, one expects a crossover between the fixed point $\lambda_f$ (which
depends only on the defect degrees) and the biregular or multi-type threshold of
L2. The natural conjecture is that the crossover happens when the density $k/n$
exceeds $n^{-1/2}$, because the defect eigenvalues then interact with the extended
states. A clean statement would need the two-type cavity system for the
configuration model with degrees in $\{d,\Delta\}$, and would connect directly to
L8 and to the biregular dossier.

**P3. Two interacting defects.** My census prediction ignores the graph distance
between defects. If two defects are adjacent or share neighbours, the exact secular
equation acquires cross terms
$2(A_G-\lambda)^{-1}_{yy'}$ which decay like $r^{\mathrm{dist}(y,y')}$ times an
$n$-dependent factor. A quantitative statement about when the census prediction
holds is a concrete, finite computation with the tools of Proposition B.

**P4. The negative spectrum.** All trees are bipartite, so Theorem A gives
$\pm\lambda_*$. For a non-bipartite host (for instance a random regular host of odd
girth), the negative side behaves differently and the exact statement is open. This
matters for the user's question about $\lambda_3$ and $\lambda_4$, because an extra
eigenvalue at the bottom of the spectrum shifts the index of every gap.

**P5. Verify the $\Delta \le 2(d-2)$ threshold more sharply.** The prediction is that
no defect eigenvalue separates from the bulk, so $\lambda_2 \to 2\sqrt{d-1}$ exactly
as for the regular graph. My data at $(5,4)$ and $(5,6)$ are consistent but at
$n\le4000$. A convergence study at $n$ up to $10^5$ with a faster sampler would
decide whether the approach is from above at rate $n^{-2/3}$ (edge fluctuation) or
$n^{-1}$ (defect correction). This is a cheap and decisive experiment.

## 10. What is not claimed

* Nothing here is formally verified. No proof assistant was run. The Lean toolchain
  is available in the environment but I did not use it, so no statement in this
  dossier is machine checked.
* I did not prove hypothesis (H). Proposition D and the finite size law are (S),
  supported by (N), not (P).
* I did not prove the absence of eigenvalues embedded in the bulk of $T(d,\Delta)$.
  Theorem A is a statement about the essential spectrum and the discrete spectrum
  outside the bulk.
* The multi-spike census of Section 3, F5, is qualitative. Two and three spike data
  show the right pattern with visible $O(\Delta^2/n)$ corrections, and I do not
  claim more.
* I did not read Cohen and Maor, and I did not verify the exact non-regular
  Ramanujan threshold formula of L5 beyond the definitional passage quoted above.
* The random regular sampling uses `networkx.random_regular_graph`, which is not a
  certified uniform sampler at the sizes used.

## 11. Reproduction

From `.ultramath/smwgfcleu/m5/`:

```
python3 scripts/spiked_tree_jacobi.py     > out/spiked_tree_jacobi.txt
python3 scripts/verify_tree_balls.py      > out/verify_tree_balls.txt      # about 2 minutes
python3 scripts/exact_secular.py          > out/exact_secular.txt          # exact arithmetic
python3 scripts/one_spike_finite.py       > out/one_spike_finite.txt
python3 scripts/almost_regular_census.py  > out/almost_regular_census.txt
python3 scripts/convergence.py            > out/convergence.txt
python3 scripts/diag_secular.py           > out/diag_secular.txt
```

`scripts/arxiv_q.py` and `scripts/arxiv_abs.py` regenerate the literature metadata.
Dependencies: python3, numpy, scipy, sympy, networkx, all present in the VM image.
