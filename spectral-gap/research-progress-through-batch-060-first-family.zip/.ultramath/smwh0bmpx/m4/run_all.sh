#!/bin/bash
# Reproduce every check in this directory.  Outputs land in out/.
set -e
mkdir -p out
python3 exact_checks.py   | tee out/exact_checks.txt
python3 exact_checks3.py  | tee out/exact_checks3.txt
python3 check_rank_one_identity.py | tee out/rank_one_identity_check.txt
python3 numerics.py       | tee out/numerics.txt
python3 numerics2.py      | tee out/numerics2.txt
