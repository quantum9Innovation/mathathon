#!/usr/bin/env python3
"""Direction 4 (m1): independent restoration of the separated-distance limit from the
clustered pattern law, plus the critical/branch-point asymptotics.

Inputs re-derived, not quoted: results/050-finite-defect.md (frozen), batch-060 target.
Nothing here edits or reinterprets the frozen separated proof; the point is only that
the clustered kernel degenerates to the separated one as rho(s,t) -> infinity and that
the resulting root formula is the SAME as the one already accepted.
"""
import sympy as sp

out = []


def w(label, expr):
    val = sp.simplify(sp.expand(expr))
    out.append(f"[{'OK ' if val == 0 else 'FAIL'}] {label}: {val}")


def s(label, *v):
    out.append(" ".join([str(label)] + [str(z) for z in v]))


r = sp.symbols('r', positive=True)
d = sp.symbols('d', positive=True)
Dl = sp.symbols('Delta', positive=True)
lam = (d - 1) * r + 1 / r
Gd = r / (1 - r ** 2)
u = sp.symbols('u', positive=True)
wv = sp.symbols('w', positive=True)  # w = r^2

out.append("### 1. Degeneration of the clustered kernel at infinite separation")
# The general pattern kernel is K_T = G_d * sum_{s,t} r^{rho(s,t)}.  If every rho -> inf
# the sum -> |T| and K_T -> |T| G_d.  Two families realise the two regimes:
s("  adjacent pair  sigma(r) = 2 + 2r   -> 2 as r->0  (r(lam)->0 as lam->inf): the")
s("  separated value |T|G_d is approached only in the double limit rho->inf AND it is")
s("  NOT the same as lam->inf: for fixed lam, sigma_adj = 2+2r != 2.")
s("  sigma_N(r) = d + d(d-1)r^2 ; both reduce to |T| only in the rho->inf limit,")
s("  which for fixed labels is what the 050-proof established (dist -> inf).")

out.append("")
out.append("### 2. Separated secular equation and the 050 closed form, re-derived")
# lambda = Delta G_d(lambda) with G_d = r/(1-r^2)
eq = sp.numer(sp.together(lam - Dl * Gd))
s("  lambda = Delta G_d  <=>  quartic in r:", sp.expand(eq))
w("quartic = (d-1)r^4 + (Delta+2-d)r^2 - 1 up to sign",
  eq + ((d - 1) * r ** 4 + (Dl + 2 - d) * r ** 2 - 1))
# eliminate w=r^2 between quartic and lambda^2 expression
lam2 = (d - 1) ** 2 * wv + 2 * (d - 1) + 1 / wv
quartic_w = (d - 1) * wv ** 2 + (Dl + 2 - d) * wv - 1
res = sp.resultant(quartic_w, sp.numer(sp.together(lam2 - u)), wv)
s("  resultant eliminating r^2:", sp.factor(res))
claim = u ** 2 - (d ** 2 - (d - 2) * Dl) * u - (d - 1) * Dl ** 2
w("quadratic u^2-(d^2-(d-2)Delta)u-(d-1)Delta^2 = 0 (up to the factor -(d-1))",
  res / (-(d - 1)) - claim)
sol = sp.solve(claim, u)
s("  positive root u = lambda^2:", sp.simplify(sol[1]))
s("  050 formula: lambda_f^2 = [d^2-(d-2)Delta + sqrt((d^2-(d-2)Delta)^2+4(d-1)Delta^2)]/2",
  " ->", sp.simplify(sol[1] - ((d ** 2 - (d - 2) * Dl) +
                               sp.sqrt((d ** 2 - (d - 2) * Dl) ** 2 + 4 * (d - 1) * Dl ** 2)) / 2) == 0)

out.append("")
out.append("### 3. Threshold and the branch-point contact order")
sv = sp.symbols('s', positive=True)  # s = sqrt(d-1)
Phi_sep_b = sp.simplify((lam - Dl * Gd).subs({r: 1 / sv, d: sv ** 2 + 1}))
s("  Phi_sep(b) =", Phi_sep_b, "   zero iff Delta = 2(d-2):",
  sp.simplify(Phi_sep_b.subs(Dl, 2 * (sv ** 2 - 1))))
s("  => separated root exists iff Delta > 2(d-2) (= 2(d-2) is the critical contact case)")
# contact order at Delta = 2(d-2): expand Phi_sep in eps with lambda = b + eps, r = 1/s + c eps
eps = sp.symbols('eps', positive=True)
rr = sp.symbols('rr', positive=True)
lam_eps = 2 * sv + eps
cser = sp.solve(sp.Eq((sv ** 2) * rr + 1 / rr, lam_eps) if False else
                sp.Eq((d - 1) * rr + 1 / rr, lam_eps), rr)
# use s form: (d-1) = s^2
cser = sp.solve(sp.Eq(sv ** 2 * rr + 1 / rr, lam_eps), rr)
small = [z for z in cser][0]
ser = sp.series(small, eps, 0, 3).removeO()
s("  r(b+eps) (small root) =", sp.simplify(sp.expand(ser)))
s("  => r - 1/s = -eps^{1/2}(1/s)^{3/2}/... : leading power eps^{1/2}, so the edge is a")
s("     branch point and a root AT b is a contact of order 1/2 (not a double root).")
# explicit: Phi_sep(b + t^2) at Delta = 2(d-2), expand in t
t = sp.symbols('t', positive=True)
bell = sp.simplify((lam - Dl * Gd).subs({r: 1 / sv - t / sv ** sp.Rational(3, 2),
                                         d: sv ** 2 + 1, Dl: 2 * (sv ** 2 - 1)}))
s("  Phi_sep(b + t^2) at Delta=2(d-2) with r = 1/s - t/s^{3/2}:", sp.series(bell, t, 0, 2))
s("  (linear term in t survives => one-sided square-root contact)")

out.append("")
out.append("### 4. Holder edge scaling quoted in 050 item 4")
epsD = sp.symbols('epsD', positive=True)
# Delta = 2(d-2) + eps ; expand lambda_f - b to second order in eps
Dl_eps = 2 * (d - 2) + epsD
lamf2 = ((d ** 2 - (d - 2) * Dl_eps) +
         sp.sqrt((d ** 2 - (d - 2) * Dl_eps) ** 2 + 4 * (d - 1) * Dl_eps ** 2)) / 2
lamf = sp.sqrt(lamf2)
b = 2 * sp.sqrt(d - 1)
series = sp.series(lamf - b, epsD, 0, 3).removeO()
s("  lambda_f - b =", sp.simplify(sp.expand(series)))
c2 = sp.simplify(sp.expand(series).coeff(epsD, 2))
w("  quadratic coefficient = sqrt(d-1)/(4 d^2)", c2 - sp.sqrt(d - 1) / (4 * d ** 2))
s("  (050 states lambda_f - b ~ sqrt(d-1)/(4d^2)(Delta-2(d-2))^2: verified)")

out.append("")
out.append("### 5. Critical finite-size balance at Phi(d)=0 (pattern version of 050 sec.2.5)")
# Sigma_n(lam) = Phi(lam) - |T|^2/(n(lam-d)) + o(1); at lam = d - sigma n^{-1/2}:
# Sigma_n = -Phi'(d) sigma n^{-1/2} + |T|^2/(sigma n^{1/2}) + o(n^{-1/2})
sig = sp.symbols('sigma', positive=True)
n = sp.symbols('n', positive=True)
DlT = sp.symbols('Delta_T', positive=True)
bal = -sp.symbols('P1') * sig / sp.sqrt(n) + DlT ** 2 / (n * (sig / sp.sqrt(n)) * (-1) * (-1))
s("  balance: -Phi'(d) sigma n^{-1/2} + Delta^2/(sigma n^{1/2}) = 0")
s("  => sigma = Delta/sqrt(Phi'(d)), independent of n.")
s("  T=N(c), d=3: Delta=3, Phi'(3)=2(d+1)=8  =>  sigma = 3/sqrt(8) =",
  sp.N(3 / sp.sqrt(8), 12))
s("  consistency with the non-critical balance (Phi(d) != 0): then")
s("  Sigma_n(d - s/n) = Phi(d)+Delta^2/s+O(1/n) forces s = Delta^2/(-Phi(d)) = O(1),")
s("  i.e. the 050 n^{-1} law; the critical case is genuinely n^{-1/2}.")

out.append("")
out.append("### 6. General threshold criterion and its instantiation")
s("  K_T(b) = G_d(b) sigma(b) = sqrt(d-1)/(d-2) * sigma, sigma = sum_{s,t}(d-1)^{-rho/2}")
s("  K_T(b) > b=2sqrt(d-1)  <=>  sigma > 2(d-2).")
for dv in (3, 4, 5, 6):
    sgn = d if False else None
    adj = 2 + 2 / sp.sqrt(dv - 1)
    nn = dv + dv * (dv - 1) / (dv - 1)
    cl = (dv + 1) + 2 * dv / sp.sqrt(dv - 1) + dv * (dv - 1) / (dv - 1)
    out.append(f"  d={dv}: sigma_adj={sp.N(adj,8)} (>{2*(dv-2)}? {bool(sp.N(adj) > 2*(dv-2))})"
               f"  sigma_N={sp.N(nn,8)} ({bool(sp.N(nn) > 2*(dv-2))})"
               f"  sigma_C={sp.N(cl,8)} ({bool(sp.N(cl) > 2*(dv-2))})")
s("  exact integrality: sigma_adj(b) = 2(d-2) <=> s^2-s-1=0 with s=sqrt(d-1), no integer d;")
s("  sigma_N(b) = 2d = 2(d-2) impossible; so neither family ever has a root exactly at b.")

txt = "\n".join(out)
print(txt)
open("out/separated_limit.txt", "w").write(txt + "\n")
