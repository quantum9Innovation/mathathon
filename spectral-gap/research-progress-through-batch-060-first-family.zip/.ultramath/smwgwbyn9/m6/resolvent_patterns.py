#!/usr/bin/env python3
"""
m6 / swarm smwgwbyn9, direction d4 (role 1).

Certified-uniform sampler: configuration (pairing) model with rejection of the
non-simple outcomes.  Every simple d-regular graph on n labelled vertices is
realised by exactly (d!)^n pairings of the nd labelled stubs, so conditioning the
pairing model on simplicity is EXACTLY uniform on simple d-regular labelled
graphs.  No networkx.random_regular_graph is used anywhere.

We measure, for fixed real lambda > 2 sqrt(d-1),
    S_T(lambda) = 1_T^T (lambda I - A)^{-1} 1_T
for three attachment patterns T:
  (P1) T = {u}                     (single vertex)   : tree value  G_d
  (P2) T = two vertices at large graph distance        : tree value  2 G_d
  (P3) T = two ADJACENT vertices                       : tree value  G_d (2 + 2 r)
  (P4) T = N(c), the d neighbours of a fixed vertex c  : tree value  d*lam*r/(lam - d*r)
The claimed limit in the batch target is S_T -> |T| G_d in all cases; P3, P4 are
the finite-pattern corrections.  Here r = r(lambda) solves (d-1) r + 1/r = lambda
with 0 < r < 1/sqrt(d-1) and G_d = r/(1-r^2).
"""
import sys, json, time
import numpy as np
import scipy.sparse as sp
import scipy.sparse.linalg as spla


# ---------------------------------------------------------------- sampler
def pairing_regular(n, d, rng):
    """Exactly uniform simple d-regular graph on n labelled vertices (rejection)."""
    if (n * d) % 2:
        raise ValueError("nd odd")
    stubs = np.repeat(np.arange(n), d)
    trial = 0
    while True:
        trial += 1
        s = stubs.copy()
        rng.shuffle(s)
        a = s[0::2]
        b = s[1::2]
        rows = np.concatenate([a, b])
        cols = np.concatenate([b, a])
        # reject loops and multi-edges
        if np.any(a == b):
            continue
        # multi-edge test on the unordered edge set
        u = np.minimum(a, b).astype(np.int64)
        v = np.maximum(a, b).astype(np.int64)
        key = u * n + v
        if np.unique(key).size != key.size:
            continue
        return rows, cols, trial


def adj_matrix(n, rows, cols):
    data = np.ones(rows.size)
    A = sp.csr_matrix((data, (rows, cols)), shape=(n, n))
    return A


# ---------------------------------------------------------------- exact limits
def tree_params(d, lam):
    """r in (0,1/sqrt(d-1)) solving (d-1)r + 1/r = lam, and G_d = r/(1-r^2)."""
    disc = lam * lam - 4 * (d - 1)
    if disc <= 0:
        raise ValueError("lambda inside the bulk")
    r = (lam - np.sqrt(disc)) / (2 * (d - 1))
    Gd = r / (1 - r * r)
    return r, Gd


def predictions(d, lam, delta):
    r, Gd = tree_params(d, lam)
    out = {
        "r": r,
        "Gd": Gd,
        "naive_claim": delta * Gd,               # -Delta G_d  (batch target)
        "far_pair": 2 * Gd,                       # two far vertices
        "adjacent_pair": Gd * (2 + 2 * r),        # adjacent pair
        "neighbourhood": d * lam * r / (lam - d * r),  # T = N(c), |T| = d
    }
    return out


# ---------------------------------------------------------------- measurement
def quadratic_form(A, n, T, lam):
    """1_T^T (lam I - A)^{-1} 1_T for a symmetric sparse A."""
    b = np.zeros(n)
    b[list(T)] = 1.0
    M = sp.identity(n, format="csr") * lam - A
    x = spla.spsolve(M.tocsc(), b)
    return float(b @ x)


def far_pair(A, n, rng):
    """Two vertices at (approximately) maximal graph distance: double BFS sweep."""
    D = sp.csgraph.dijkstra(A, indices=int(rng.integers(n)), unweighted=True)
    s = int(np.argmax(np.where(np.isinf(D), -1, D)))
    D = sp.csgraph.dijkstra(A, indices=s, unweighted=True)
    t = int(np.argmax(np.where(np.isinf(D), -1, D)))
    return s, t, int(D[t])


def run(n, d, lams, seeds):
    recs = []
    for seed in seeds:
        t0 = time.time()
        rng = np.random.default_rng(seed)
        rows, cols, trials = pairing_regular(n, d, rng)
        A = adj_matrix(n, rows, cols)
        # pattern anchors
        u0 = int(rng.integers(n))
        nb0 = A.indices[A.indptr[u0]:A.indptr[u0 + 1]]
        adj = (u0, int(nb0[0]))
        c = int(rng.integers(n))
        Nb = [int(x) for x in A.indices[A.indptr[c]:A.indptr[c + 1]]]
        s, t, fdist = far_pair(A, n, rng)
        for lam in lams:
            rec = dict(n=n, d=d, seed=seed, lam=lam, trials=trials,
                       single=quadratic_form(A, n, [u0], lam),
                       far_pair=quadratic_form(A, n, [s, t], lam),
                       adjacent=quadratic_form(A, n, list(adj), lam),
                       neighbourhood=quadratic_form(A, n, Nb, lam),
                       far_pair_dist=fdist)
            rec["pred"] = predictions(d, lam, len(Nb))
            rec["pred"]["far_pair_at_dist"] = rec["pred"]["Gd"] * (2 + 2 * rec["pred"]["r"] ** fdist)
            recs.append(rec)
            print(json.dumps(rec), flush=True)
        print(f"# n={n} d={d} seed={seed} wall={time.time()-t0:.1f}s trials={trials}",
              file=sys.stderr, flush=True)
    return recs


if __name__ == "__main__":
    n = int(sys.argv[1]) if len(sys.argv) > 1 else 2000
    d = int(sys.argv[2]) if len(sys.argv) > 2 else 3
    lams = [float(x) for x in (sys.argv[3].split(",") if len(sys.argv) > 3 else ["2.95", "3.2"])]
    seeds = [int(x) for x in (sys.argv[4].split(",") if len(sys.argv) > 4 else ["11", "12"])]
    run(n, d, lams, seeds)
