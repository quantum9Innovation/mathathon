r"""The geometry of cosets, not of lattice vectors.

For a positive definite M and Lambda <= Z^2 of index N,

    mu_M(Lambda) = min { z^T M z : z in Lambda^* \ Z^2 }
                 = min over nonzero cosets of the M-distance to Z^2.

Theorem 6 of PROOF-band-edge-law.md states

    lambda_min(M)/N^2  <=  mu_M(Lambda)  <=  4 (N)^{-2/d} ((det M)^{1/2}/omega_d)^{2/d}

and claims that both orders occur.  This script checks both inequalities exactly
over all index-N sublattices of Z^2 up to N = 256, folding each dual point into
the fundamental domain before minimising, and reports the attained ratios.
"""
import sys, os, json, itertools, math
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
from fractions import Fraction
import lib

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "out")
OMEGA2 = math.pi


def form_exact(Gint, z):
    """z^T Gint z exactly, z a pair of Fractions."""
    return (Gint[0][0]*z[0]*z[0] + 2*Gint[0][1]*z[0]*z[1]
            + Gint[1][1]*z[1]*z[1])


def coset_min(Gint, a, b, d):
    """Exact min of the form over nonzero elements of Lambda^*/Z^2, folded."""
    pts = lib.dual_points_2d(a, b, d)
    best = None
    best_k = None
    for k in pts:
        if k == (Fraction(0), Fraction(0)):
            continue
        for m0 in (-1, 0, 1):
            for m1 in (-1, 0, 1):
                z = (k[0]+m0, k[1]+m1)
                val = form_exact(Gint, z)
                if best is None or val < best:
                    best, best_k = val, z
    return best, best_k


def unfolded_min(Gint, a, b, d):
    pts = lib.dual_points_2d(a, b, d)
    return min(form_exact(Gint, k) for k in pts
               if k != (Fraction(0), Fraction(0)))


def main():
    log = []
    cases = {
        "square G=[[2,0],[0,2]]": ([[2, 0], [0, 2]],
                                   [(1, 0), (-1, 0), (0, 1), (0, -1)]),
        "triangular G=[[4,2],[2,4]]": ([[4, 2], [2, 4]],
                                       [(1, 0), (-1, 0), (0, 1), (0, -1),
                                        (1, 1), (-1, -1)]),
        "G=[[6,6],[6,12]]": ([[6, 6], [6, 12]],
                             [(1, 0), (-1, 0), (0, 1), (0, -1),
                              (1, 1), (-1, -1), (1, 2), (-1, -2)]),
        "golden G=[[2,1],[1,1]]": ([[2, 1], [1, 1]],
                                   [(1, 0), (-1, 0), (1, 1), (-1, -1),
                                    (0, 1), (0, -1)]),
    }
    summary = {}
    for name, (Gint, S) in cases.items():
        # all quantities are computed in units of the integral form G, which is
        # legitimate because the three displayed inequalities are invariant
        # under M -> c M with c > 0.
        M = np.array(Gint, dtype=float)
        detM = float(np.linalg.det(M))
        lmin = float(np.linalg.eigvalsh(M)[0])
        bound_const = 4*(math.sqrt(detM)/OMEGA2)      # d = 2
        log.append(f"\n{name}:  form G = {Gint} (M = 4 pi^2 G),  lambda_min(G) "
                   f"= {lmin:.6f},  det G = {detM:.6f},  bound constant = "
                   f"{bound_const:.6f} (all in units of G)")
        log.append("    N   #sub  max mu_M      lower lmin/N^2   upper const/N"
                   "    max/lower   max/upper   max*m(N)/... ")
        rows = []
        for N in [2, 3, 4, 5, 6, 8, 9, 12, 16, 25, 36, 49, 64, 100, 144, 196, 256]:
            mus = []
            fold_diff = 0
            for (a, b, d) in lib.sublattices_2d(N):
                mu, z = coset_min(Gint, a, b, d)
                mus.append(float(mu))
                if mu != unfolded_min(Gint, a, b, d):
                    fold_diff += 1
            lower = lmin/N**2
            upper = bound_const/N
            mx = max(mus)
            mn = min(mus)
            rows.append(dict(N=N, nsub=len(mus), mu_min=mn, mu_max=mx,
                             lower=lower, upper=upper,
                             ratio_min=mn/lower, ratio_max=mx/upper,
                             folded=fold_diff))
            log.append(f"  {N:4d} {len(mus):5d}  {mx:.6e}   {lower:.6e}    "
                       f"{upper:.6e}   {mx/lower:9.4f}  {mx/upper:9.6f}"
                       f"   folded-points-that-mattered={fold_diff}")
        summary[name] = rows
        worst = max(r["ratio_max"] for r in rows)
        log.append(f"  largest observed max/upper over these N: {worst:.6f} "
                   f"(must be <= 1)")
        log.append(f"  all lower bounds respected: "
                   f"{all(r['mu_min'] >= r['lower']*(1-1e-12) for r in rows)}")
    json.dump(summary, open(os.path.join(OUT, "s12_coset_minimum.json"), "w"),
              indent=1)
    txt = "\n".join(log)
    open(os.path.join(OUT, "s12_coset_minimum.log"), "w").write(txt)
    print(txt)


if __name__ == "__main__":
    main()
