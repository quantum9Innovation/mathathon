# Contents

- `main.md`, the research dossier. Model, normalisation, verified literature, exact theorems,
  exact computations, the two mechanisms, two obstructions, theorem targets, unresolved steps,
  prioritised next steps, common ground with the four local dossiers, evidence ledger.
- `derivations.md`, full proofs, the Paley identity proof, switching invariance, the equiangular
  extraction, the three eigenvalue enumeration, reproduction instructions with runtimes, and a
  list of negative and boundary results.
- `code/`, eight runnable Python scripts. `seidel_core.py`, `mult_bound.py`, `fold_and_equi.py`,
  `defect_count.py`, `three_eig.py`, `srg_families.py`, `extremal_cubic.py`, `extremal_more.py`.
- `out/`, the raw output of every script, as `.json` where structured and `.txt` for stdout.

Quick reproduction, from the directory containing `code/` and `out/`:

```
python3 code/seidel_core.py
python3 code/mult_bound.py
python3 code/fold_and_equi.py
python3 code/defect_count.py
python3 code/three_eig.py
python3 code/srg_families.py
python3 code/extremal_cubic.py
python3 code/extremal_more.py
```

Total runtime under three minutes on this VM, numpy 2.5.3, sympy 1.14.0, networkx 3.7,
nauty-geng at /usr/bin/nauty-geng.
