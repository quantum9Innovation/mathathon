"""Certified-uniform random d-regular graph: rejection sampling from the configuration model.
Conditioned on simplicity, the configuration model is EXACTLY uniform over simple
d-regular graphs.  So each accepted sample is an exact draw from the uniform model.
(No networkx.random_regular_graph: that is not certified uniform.)

Experiments (fixed seeds, reproducible):
  E1  fixed-host resolvent quadratic form  Q(lam)=1_T^T(A_G-lam)^{-1}1_T  vs  -Delta*G_d(lam)
  E2  secular roots of Sigma(lam)=lam+Q(lam) in (lam2(G),d) and in (d,inf), vs lam1(G'),lam2(G')
  E3  finite-size law  n*(d-lam2(G'))  ->  Delta^2/(Delta*G_d(d)-d)
"""
import numpy as np, scipy.sparse as sp, scipy.sparse.linalg as spl, json, sys

def cm_simple(d, n, rng):
    for att in range(1, 100000):
        pts = np.repeat(np.arange(n), d)
        rng.shuffle(pts)
        u = pts[0::2].astype(np.int64); v = pts[1::2].astype(np.int64)
        if np.any(u == v):
            continue
        key = np.minimum(u, v)*np.int64(n) + np.maximum(u, v)
        if np.unique(key).size != key.size:
            continue
        rows = np.concatenate([u, v]); cols = np.concatenate([v, u])
        A = sp.csr_matrix((np.ones(rows.size, dtype=float), (rows, cols)), shape=(n, n))
        return A, att
    raise RuntimeError

def Gmck(d, lam):
    disc = lam*lam - 4.0*(d-1)
    if disc <= 0: return None, None
    r = (lam - np.sqrt(disc))/(2.0*(d-1))
    return r/(1.0-r*r), r

def sigma(A, T, lam):
    n = A.shape[0]
    M = (A - lam*sp.identity(n, format='csc')).tocsc()
    tgt = np.zeros((n, 1))
    tgt[T, 0] = 1.0
    x = spl.spsolve(M, tgt)
    return lam + np.asarray(x).ravel()[T].sum()

def root_bisect(f, a, b, fa=None, fb=None, it=60, tol=1e-10):
    fa = f(a) if fa is None else fa; fb = f(b) if fb is None else fb
    assert fa*fb < 0, (a, b, fa, fb)
    for _ in range(it):
        if b-a < tol: break
        m = 0.5*(a+b); fm = f(m)
        if fm == 0: return m
        if fa*fm < 0: b, fb = m, fm
        else: a, fa = m, fm
    return 0.5*(a+b)

def run(d, Delta, ns, lams, seed, tag):
    rng = np.random.default_rng(seed)
    out = {"tag": tag, "d": d, "Delta": Delta, "seed": seed,
           "sampler": "config-model rejection (exactly uniform on simple d-regular graphs)",
           "rows": []}
    for n in ns:
        A, att = cm_simple(d, n, rng)
        T = np.arange(Delta)
        evG = np.sort(spl.eigsh(A, k=3, which='LA', return_eigenvectors=False))[::-1]
        # G' : new vertex n adjacent to T
        rows = np.concatenate([A.tocoo().row, np.full(Delta, n)])
        cols = np.concatenate([A.tocoo().col, T])
        Ap = sp.csr_matrix((np.ones(rows.size), (rows, cols)), shape=(n+1, n+1))
        Ap = (Ap + Ap.T); Ap.data[:] = 1.0
        evP = np.sort(spl.eigsh(Ap, k=3, which='LA', return_eigenvectors=False))[::-1]
        rec = {"n": n, "attempts": att, "lam1G": evG[0], "lam2G": evG[1],
               "lam1Gp": evP[0], "lam2Gp": evP[1], "Q": {}}
        for lam in lams:
            if lam <= evG[1] + 1e-9:
                rec["Q"][f"{lam}"] = None
                continue
            Sig = sigma(A, T, lam)          # Sigma = lam + Q
            Q = Sig - lam
            g, r = Gmck(d, lam)
            rec["Q"][f"{lam}"] = {"Q": Q, "negDeltaG": -Delta*g,
                                  "Q_residual=Q+Delta*G": Q + Delta*g,
                                  "negDelta_r_onesided_CLAIM": -Delta*r,
                                  "Sigma": Sig, "f=lam-DeltaG": lam - Delta*g,
                                  "Sigma_residual=Sigma-f": Sig - (lam - Delta*g)}
        # E2: roots of Sigma
        try:
            lo = evG[1] + 1e-8
            fa = sigma(A, T, lo)
            fb = sigma(A, T, evG[0] - 1e-8)
            if fa*fb < 0:
                rec["root_in_gap"] = root_bisect(lambda x: sigma(A, T, x), lo, evG[0]-1e-8, fa, fb)
        except Exception as e:
            rec["root_in_gap"] = f"err {e}"
        try:
            a0 = evG[0] + 1e-8; fa = sigma(A, T, a0)
            b0 = evG[0] + 10.0; fb = sigma(A, T, b0)
            if fa*fb < 0:
                rec["root_above_d"] = root_bisect(lambda x: sigma(A, T, x), a0, b0, fa, fb)
        except Exception as e:
            rec["root_above_d"] = f"err {e}"
        out["rows"].append(rec)
        print(json.dumps(rec, default=float), flush=True)
        json.dump(out, open(f"out/{tag}.json","w"), indent=1, default=float)
    return out

if __name__ == "__main__":
    d = int(sys.argv[1]); Delta = int(sys.argv[2])
    ns = [int(x) for x in sys.argv[3].split(",")]
    lams = [float(x) for x in sys.argv[4].split(",")]
    seed = int(sys.argv[5]); tag = sys.argv[6]
    import io
    orig = run
    res = run(d, Delta, ns, lams, seed, tag)
    json.dump(res, open(f"out/{tag}.json","w"), indent=1, default=float)
