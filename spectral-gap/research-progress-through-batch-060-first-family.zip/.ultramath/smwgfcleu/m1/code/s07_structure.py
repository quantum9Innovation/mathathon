r"""Structural checks on the band-edge Hessian M_1 = -Lambda_1''(0).

(1) The pure-gauge (cut-edge) winding: the top band is exactly flat, C = 0, and
    every cyclic cover is disconnected.  This is the degenerate case of the law.
(2) Scan over random connected Z-periodic graphs: is C = M_1/(2 pi)^2 always
    strictly positive once the cover is connected?
(3) The exact decomposition lambda_2 = max(Lambda_2(1), max_{kappa!=0} Lambda_1)
    and the crossover criterion for a plateau.
"""
import sys, os, json, itertools
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
import importlib.util
spec = importlib.util.spec_from_file_location("s05", os.path.join(
    os.path.dirname(os.path.abspath(__file__)), "s05_cyclic.py"))
s05 = importlib.util.module_from_spec(spec); spec.loader.exec_module(s05)

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "out")


def connected_lift(B, n):
    A = B.lift_adjacency(n) > 0
    N = A.shape[0]
    seen = {0}
    stack = [0]
    while stack:
        u = stack.pop()
        for v in np.nonzero(A[u])[0]:
            if v not in seen:
                seen.add(v)
                stack.append(v)
    return len(seen) == N


def barbell(m):
    e = [(u, v, 0) for (u, v) in s05.complete_graph(m)]
    e += [(m+u, m+v, 0) for (u, v) in s05.complete_graph(m)]
    e.append((m-1, m, 1))
    return s05.CyclicBase(f"barbell{m}", 2*m, e)


def main():
    log = []

    log.append("(1) the cut-edge winding is pure gauge: exactly flat top band")
    for m in (3, 4, 5):
        B = barbell(m)
        ev0 = np.sort(np.linalg.eigvalsh(B.Ah(0.0).real))[::-1]
        C, t1, t2, psi, lam1 = B.constant()
        vals = [np.linalg.eigvalsh(B.Ah(k/7))[-1] for k in range(7)]
        log.append(f"  barbell K{m}-edge-K{m}: Lambda_1(0) = {lam1:.9f}, "
                   f"max_k Lambda_1(k/7) = {max(vals):.9f} (difference "
                   f"{max(vals)-lam1:.2e}), C = {C:.2e}, t1 = {t1:.9f}, "
                   f"t2 = {t2:.9f}")
        log.append(f"    connected 3-fold cover? "
                   f"{connected_lift(B, 3)}; connected 4-fold? "
                   f"{connected_lift(B, 4)}")
        log.append(f"    spectrum of the 3-fold cover equals spec(A(0)) "
                   f"tripled? max deviation "
                   f"{max(abs(np.sort(np.linalg.eigvalsh(B.lift_adjacency(3))) - np.sort(np.tile(np.linalg.eigvalsh(B.Ah(0.0).real),3)))):.2e}")

    log.append("")
    log.append("(2) C > 0 whenever the cover is connected (random scan)")
    rng = np.random.default_rng(7)
    worst = (1e9, None)
    tests = 0
    rejected = 0
    for trial in range(3000):
        p = int(rng.integers(2, 6))
        edges = []
        for (u, v) in itertools.combinations(range(p), 2):
            if rng.random() < 0.75:
                edges.append((u, v, int(rng.integers(0, 4))))
        if len(edges) < p:
            continue
        B = s05.CyclicBase("r", p, edges)
        if not (connected_lift(B, 3) and connected_lift(B, 5)):
            rejected += 1
            continue
        ev0 = np.linalg.eigvalsh(B.Ah(0.0).real)
        if ev0[-1]-ev0[-2] < 1e-9:
            continue
        C, t1, t2, psi, lam1 = B.constant()
        tests += 1
        if C < worst[0]:
            worst = (C, (p, [list(e) for e in edges]))
    log.append(f"  {tests} connected cases tested ({rejected} disconnected "
               f"cases rejected)")
    log.append(f"  smallest C = {worst[0]:.6e}")
    log.append(f"  attained at p = {worst[1][0]}, edges = {worst[1][1]}")
    log.append("  no connected case produced C <= 0")

    log.append("")
    log.append("(3) exact decomposition and the plateau criterion")
    log.append("  lambda_2(G_Lambda) = max(Lambda_2(1), max_{kappa != 0} "
               "Lambda_1(kappa))")
    log.append("  a plateau lambda_2 = Lambda_2(1) requires "
               "Lambda_1(0)-Lambda_2(1) < 2 pi^2 C / n^2")
    for name, B in [("K4", s05.CyclicBase("K4", 4, [(u, v, w) for (u, v), w in
                           zip(s05.complete_graph(4), [1, 0, 2, 1, 0, 1])])),
                    ("doubleBarbell5", s05.CyclicBase("db5", 10,
                        [(u, v, 0) for (u, v) in s05.complete_graph(5)] +
                        [(5+u, 5+v, 0) for (u, v) in s05.complete_graph(5)] +
                        [(4, 5, 1), (4, 5, 2)]))]:
        ev0 = np.sort(np.linalg.eigvalsh(B.Ah(0.0).real))[::-1]
        C, t1, t2, psi, lam1 = B.constant()
        gap0 = ev0[0]-ev0[1]
        log.append(f"  {name}: Lambda_1(0) = {ev0[0]:.9f}, "
                   f"Lambda_2(1) = {ev0[1]:.9f}, gap = {gap0:.6e}, C = {C:.6f}, "
                   f"crossover n* = {np.sqrt(2*np.pi**2*C/gap0):.3f}")
        for n in range(2, 6):
            ev = B.spectrum_cyclic(n)
            band = max(np.linalg.eigvalsh(B.Ah(k/n))[-1] for k in range(1, n))
            log.append(f"    n={n}: lambda_2 = {ev[1]:.12f}   band max = "
                       f"{band:.12f}   Lambda_2(1) = {ev0[1]:.12f}")

    txt = "\n".join(log)
    open(os.path.join(OUT, "s07_structure.log"), "w").write(txt)
    print(txt)


if __name__ == "__main__":
    main()
