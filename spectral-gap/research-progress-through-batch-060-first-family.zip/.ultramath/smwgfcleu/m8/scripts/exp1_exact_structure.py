"""Exact checks of the trivial-spectrum claims for the Feng-Li operator A_H.

Every claim tested here is a deterministic statement about a specific hypergraph.
there is nothing asymptotic in this script.
"""
import itertools
import numpy as np
import sympy
from hyp import (fengli, spec, window, components, mult_close, rank_int,
                 degrees, is_regular, incidence)

np.set_printoptions(precision=6, suppress=True)
out = []


def report(name, A, X, d, k, n, extra=""):
    w = spec(A)
    m = X.shape[1]
    r = rank_int(X)
    perron = mult_close(w, d * (k - 1))
    negd = mult_close(w, -d)
    lo, hi = window(d, k)
    line = (f"{name:44s} n={n:4d} m={m:4d} d={d:3d} k={k:2d} "
            f"lam1={w[0]:10.5f} (d(k-1)={d*(k-1)}) "
            f"mult(Perron)={perron} comp={components(A)} "
            f"mult(-d)={negd} n-rank={n-r} n-m={n-m} "
            f"lamm={w[-1]:9.4f} win=({lo:.4f},{hi:.4f}) {extra}")
    out.append(line)
    # checks
    assert abs(w[0] - d * (k - 1)) < 1e-8 * max(1, d * (k - 1)), "Perron value"
    assert perron == components(A), f"Perron multiplicity != #components: {perron} vs {components(A)}"
    assert negd == n - r, f"mult(-d) != n - rank(X): {negd} vs {n-r}"
    assert w[-1] >= -d - 1e-9 * max(1, d), "lambda_min < -d"
    assert negd >= max(0, n - m), "mult(-d) < n-m"
    if extra.startswith("partite"):
        kk = int(extra.split("=")[1])
        assert negd >= kk - 1, f"k-partite but mult(-d)={negd} < k-1={kk-1}"
    return w


def complete_partite(k, s):
    """Complete k-partite k-uniform hypergraph, part size s.  n = k s, d = s^(k-1)."""
    verts = [list(range(i * s, (i + 1) * s)) for i in range(k)]
    edges = [tuple(t) for t in itertools.product(*verts)]
    return edges, k * s


def random_d_regular(n, d, k, seed):
    rng = np.random.default_rng(seed)
    from hyp import config_model_hypergraph
    return config_model_hypergraph(n, d, k, rng)


out.append("=== A. exact trivial spectrum: Perron multiplicity, mult(-d) = n - rank(X) ===")

# 1. complete k-partite, various k and part sizes (k-partite => mult(-d) >= k-1)
for k in (3, 4, 5):
    for s in (1, 2, 3):
        if s ** (k - 1) > 200:
            continue
        edges, n = complete_partite(k, s)
        A, X = fengli(edges, n)
        ok, dd = is_regular(edges, n)
        assert ok and dd[0] == s ** (k - 1)
        report(f"complete {k}-partite, part size {s}", A, X, int(dd[0]), k, n, f"partite={k}")

# 2. disjoint unions: Perron multiplicity = number of components
for t in (1, 2, 3, 4):
    edges, n0 = complete_partite(3, 2)     # 6 vertices, d = 4
    E = []
    for b in range(t):
        E += [tuple(v + b * n0 for v in e) for e in edges]
    A, X = fengli(E, t * n0)
    report(f"{t} disjoint copies of 3-partite(2)", A, X, 4, 3, t * n0, f"partite=3")

# 3. single edge repeated d times on k vertices: rank(X) = 1, mult(-d) = k-1 exactly
for k in (3, 4, 5):
    for d in (1, 2, 7):
        edges = [tuple(range(k))] * d
        A, X = fengli(edges, k)
        report(f"one k-set repeated d times", A, X, d, k, k)

# 4. d < k: rectangular deficiency forces mult(-d) >= n - m
for (d, k) in ((2, 3), (2, 4), (3, 5), (2, 5), (4, 6)):
    n = 4 * k * d
    if (n * d) % k:
        continue
    edges = random_d_regular(n, d, k, seed=100 + d * 10 + k)
    A, X = fengli(edges, n)
    report(f"random ({d},{k})-regular", A, X, d, k, n)
    m = len(edges)
    assert (n - m) > 0

# 5. d > k: no rectangular deficiency, mult(-d) = 0 for random H
for (d, k) in ((3, 2), (4, 3), (5, 3), (6, 4)):
    n = 4 * k * d
    edges = random_d_regular(n, d, k, seed=200 + d * 10 + k)
    A, X = fengli(edges, n)
    w = report(f"random ({d},{k})-regular", A, X, d, k, n)

print("\n".join(out))

print("\n=== B. the -d floor versus the Li-Sole window ===")
print("window = [k-2-2t, k-2+2t],  t = sqrt((d-1)(k-1)),  floor is -d")
print(f"{'d':>3} {'k':>3} {'t':>10} {'-d':>10} {'win_lo':>10} {'(sqrt(d-1)-sqrt(k-1))^2':>26} {'win_hi':>10} {'d(k-1)':>10} {'(t-1)^2':>10}")
for d in (2, 3, 4, 5, 10):
    for k in (2, 3, 4, 5):
        t = sympy.sqrt((d - 1) * (k - 1))
        lo = k - 2 - 2 * t
        hi = k - 2 + 2 * t
        f1 = sympy.simplify(lo - (-d))
        f2 = sympy.simplify(d * (k - 1) - hi)
        s1 = sympy.simplify((sympy.sqrt(d - 1) - sympy.sqrt(k - 1)) ** 2)
        s2 = sympy.simplify((t - 1) ** 2)
        assert sympy.simplify(f1 - s1) == 0, (d, k, f1, s1)
        assert sympy.simplify(f2 - s2) == 0, (d, k, f2, s2)
        print(f"{d:3d} {k:3d} {float(t):10.5f} {-d:10.2f} {float(lo):10.5f} {float(s1):26.5f} {float(hi):10.5f} {d*(k-1):10d} {float(s2):10.5f}")
print("both identities verified symbolically for the tested grid")

print("\n=== C. the naive tree benchmark 2*sqrt((k-1)d-1) versus the true edge ===")
print(f"{'d':>3} {'k':>3} {'naive':>10} {'true':>10} {'true-naive':>12} {'exact formula':>28}")
for d in (2, 3, 4, 5, 10, 50):
    for k in (2, 3, 4, 5, 6):
        D = (k - 1) * d
        naive = 2 * np.sqrt(D - 1)
        true = k - 2 + 2 * np.sqrt((d - 1) * (k - 1))
        exact = (k - 2) * (1 - 2 / (np.sqrt(D - k + 1) + np.sqrt(D - 1)))
        assert abs((true - naive) - exact) < 1e-9 * max(1, true)
        print(f"{d:3d} {k:3d} {naive:10.5f} {true:10.5f} {true-naive:12.6f} {exact:28.6f}")
