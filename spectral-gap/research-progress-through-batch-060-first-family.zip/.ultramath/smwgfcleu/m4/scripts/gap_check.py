"""Do truncated universal covers put eigenvalues inside the Floquet gaps?
If yes, sigma(A_T) is strictly larger than the radial Floquet set."""
import numpy as np
from floquet_bands import build_tree_sparse

def check(counts, depth, gaps, out):
    A, n = build_tree_sparse(counts[0]+1, counts, depth)
    ev = np.linalg.eigvalsh(A.toarray())
    out.write(f"counts={counts} depth={depth} verts={n}\n")
    for (lo,hi) in gaps:
        ins = ev[(ev>lo)&(ev<hi)]
        out.write(f"  gap ({lo:.6f},{hi:.6f}): {len(ins)} eigenvalues inside")
        if len(ins): out.write(f"  examples {np.round(ins[:6],6)}")
        out.write("\n")
    out.write(f"  full spectrum range [{ev[0]:.6f},{ev[-1]:.6f}], top 6 = {np.round(ev[-6:],6)}\n\n")
    return ev

with open("outputs/gap_check.txt","w") as out:
    # (1,2,3): bands [-2.785,-1.818] u [-0.967,0.967] u [1.818,2.785]
    for d in (8,10,12):
        check([1,2,3], d, [(0.9673790506,1.8180779107),(2.7854569613,4.0)], out)
    # (1,1,5): edges 0.6847, 2.2361, 2.9208 -> bands [0,0.6847] u [2.2361,2.9208]
    for d in (8,10,12):
        check([1,1,5], d, [(0.6847416490,2.2360679775),(2.9208096265,5.0)], out)
    # biregular (a,b)=(1,2): bands +-[0.4142,2.4142], gap (-0.4142,0.4142)
    for d in (8,10,12):
        check([2,1], d, [(-0.4142135624,0.4142135624),(2.4142135624,4.0)], out)
print(open("outputs/gap_check.txt").read())
