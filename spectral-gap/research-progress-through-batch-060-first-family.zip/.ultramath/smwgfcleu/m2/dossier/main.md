# One-sided spectra: the two Alon-Boppana constants for regular digraphs, and which gaps d - lambda_j are real

Research dossier for swarm `smwgfcleu`, member `m2`, direction `d6`.
Status labels used throughout: **(1) verified literature statement**, **(2) exact calculation**,
**(3) proof supplied here**, **(4) numerical experiment**, **(5) conjecture or speculation**.
Nothing below is claimed as formally verified.

## 0. Result summary

For a $k$-regular digraph (in-degree and out-degree both equal to $k$) there are two different
second-eigenvalue thresholds, and neither one is the classical $2\sqrt{k-1}$ of the undirected
theory in general:

* the **singular-value threshold** is $2\sqrt{k-1}$, for every $k$-regular digraph, with no
  symmetry hypothesis at all (Theorem A),
* the **eigenvalue threshold** is $2\sqrt{k-1}$ on the locus of *normal* digraphs of period one
  (Theorem B, sharp), while inside the larger class of $2$-normal digraphs the sharp constant is
  exactly $\sqrt{k}$ (Theorem C, using line digraphs of Ramanujan graphs). The jump happens between
  $r=1$ and $r=2$.

So the answer to "is the right threshold $\sqrt{d}$ or $2\sqrt{d-1}$" is: both, and the passage
between them is an exact algebraic map, the Ihara-Bass (Joukowski) substitution
$\lambda = 2\sqrt{k}\cos\theta \mapsto \mu = \sqrt{k}\,e^{i\theta}$, which carries the Hermitian
interval $[-2\sqrt{k},2\sqrt{k}]$ onto the circle $|\mu|=\sqrt{k}$ (Proposition E). The two
constants are one constant in two coordinate systems, not two competing benchmarks.

A second, independent contribution concerns the user's question about gaps $d-\lambda_3$,
$d-\lambda_4$. For a $k$-regular digraph of period $m$ the eigenvalues of maximal modulus $k$ are
**exactly** the $m$ numbers $k\zeta_m^j$ (Proposition D). Hence $\lambda_2$ is itself trivial as
soon as $m\ge2$, the additive gap $k-\lambda_2$ is identically $0$, and the first informative gap
in the list $\lambda_1,\lambda_2,\dots$ is $k-\lambda_{m+1}$. Concretely:

* period $m=2$ (bipartite digraphs, line digraphs of bipartite graphs, double covers of graphs):
  the first informative gap is $k-\lambda_3$,
* period $m=3$ (triperiodic digraphs, e.g. directed $3$-partite or cyclic tripartite structures):
  the first informative gap is $k-\lambda_4$.

So "$d-\lambda_3$" and "$d-\lambda_4$" are not arbitrary decorations: they are the correctly
indexed gaps for period $2$ and period $3$. The sharp *value* of that first informative gap depends
on the normality class, not on the index: $k-2\sqrt{k-1}$ for normal families of period one (and
conjecturally for every period, Corollary 3.5), $k-\sqrt{k}$ for $r\ge2$ families of any bounded
period, and $k$ for unrestricted families (De Bruijn digraphs are aperiodic and achieve
$\lambda_{m+1}=0$).

## 1. Model, normalization, ordering, regime

**Object.** $D=(V,E)$ a finite digraph with loops and multiple arcs allowed, on $n$ vertices, with
every vertex having exactly $k$ outgoing and exactly $k$ incoming arcs. $A=A_D\in\{0,1,\dots\}^{V\times V}$
is the adjacency matrix, so $A\mathbf{1}=k\mathbf{1}=A^{\mathsf T}\mathbf{1}$.

**Eigenvalues.** $\lambda_1,\dots,\lambda_n$ are the eigenvalues of $A$ (complex in general),
ordered by decreasing modulus, with $k=\lambda_1$ by Perron-Frobenius. Ties are broken arbitrarily.

**Trivial eigenvalues.** $D$ has period $m$ (the gcd of directed cycle lengths, $m=1$ is
"aperiodic") if and only if $V$ splits into $V_0,\dots,V_{m-1}$ with every arc going from $V_j$ to
$V_{j+1 \bmod m}$. Then $k\zeta_m^j$, $j=0,\dots,m-1$, are eigenvalues, and by Perron-Frobenius
these are exactly the eigenvalues of modulus $k$ (statement (1), Parzanchevski arXiv:1804.08028v4
Section 2, see Proposition D for the proof I supply). The **trivial space** is the span of the
corresponding eigenfunctions, $L_0^2$ is its orthogonal complement. This is the definition of
$\rho(D)$ used in the Ramanujan-digraph literature:

$$\rho(D) := \rho\!\left(A_D|_{L_0^2}\right),\qquad \text{Ramanujan digraph}\iff \rho(D)\le\sqrt{k}.$$

**Singular values.** $\sigma_1\ge\sigma_2\ge\dots\ge0$ are the singular values of $A$, and
$\sigma_1=k$ always (row sums $k$).

**Normality classes.** $A$ is *normal* if $AA^{\mathsf T}=A^{\mathsf T}A$ (then
$\{\sigma_i\}=\{|\lambda_i|\}$ as multisets). $A$ is *$r$-normal* if it is unitarily equivalent to
a block diagonal matrix with blocks of size at most $r$. A family is *almost-normal* if it is
$r$-normal for one fixed $r<\infty$. $r=1$ is normality.

**Regime.** $k\ge2$ fixed, $n\to\infty$, period $m$ fixed, normality class $r$ fixed. All results
below are asymptotic in $n$ with $k,m,r$ fixed. I never let $k\to\infty$ (this matters: the Paley
digraphs of Section 4 are normal, have $\rho=\sqrt{(k+1)/2}<\sqrt{k}$ in the limit $k\to\infty$, and
therefore contradict any claim of a uniform $2\sqrt{k-1}$ lower bound in the regime of growing $k$).

**Why it matters.** The four source dossiers all live on the Hermitian side, where the
local-limit operator is a tree with real spectrum and the threshold is $2\sqrt{d-1}$. But the
operators that carry the invariant mass of modern applications are one-sided: Hashimoto and
non-backtracking matrices, Markov transition matrices of sparse digraphs, Jacobians of dynamical
systems, directed edges of buildings. The dossiers' common mechanism, "sharp infinite-local-limit
threshold plus control of rare defects", survives in the one-sided world only after two
corrections: the local limit becomes the *directed* $k$-regular tree $T_k$ with spectrum the disk
$|z|\le\sqrt{k}$ (statement (1), Parzanchevski eq. (5.1), credited there to de la Harpe, Robertson
and Valette), and the singular values decouple from the eigenvalues through non-normality. This
dossier makes that decoupling exact and quantifies it.

## 2. Closest verified literature

Full statements, versions and URLs are in `literature.md`. In brief:

1. **(1)** O. Parzanchevski, *Ramanujan Graphs and Digraphs*, arXiv:1804.08028v4 (v4, 25 May 2020),
   LMS Lecture Note Series 461. Definition 2.2 (Ramanujan digraph, threshold $\sqrt{k}$),
   Definition 2.3 ($r$-normal), Section 3.4 and Remark 3.2 (De Bruijn digraphs have $\rho=0$ and
   therefore no Alon-Boppana theorem holds for general digraphs), Proposition 3.1 (finitely many
   normal Ramanujan digraphs of fixed $k$ and period), Theorem 4.3 (no infinite almost-normal family
   with $\rho\le\sqrt{k}-\varepsilon$), eq. (3.1), (3.2) (Ihara-Bass transfer for line digraphs),
   eq. (5.1) ($\mathrm{Spec}(T_k)=\{|z|\le\sqrt{k}\}$), eq. (5.4) and Theorem 5.3 (Alon's conjecture
   for random digraphs, true by Coste).
2. **(1)** S. Coste, *The Spectral Gap of Sparse Random Digraphs*, arXiv:1708.00530v2, Theorem 1 with
   $\delta=\Delta=k$: random $k$-regular digraphs satisfy $\rho\le\sqrt{k}+\varepsilon$ with
   probability tending to one. This is the matching upper bound at $\sqrt{k}$ for the non-normal
   world.
3. **(1)** G. Brito, I. Dumitriu, K. Decker Harris, *Spectral gap in random bipartite biregular
   graphs and applications*, arXiv:1804.07808v6, CPC 31 (2022) 229-267. Eq. (2) (page 2) is the
   biregular Alon-Boppana bound $\eta\ge\sqrt{d_1-1}+\sqrt{d_2-1}-\varepsilon$, attributed there to
   Feng (1996) and Li (1996), and derivable from Godsil-Mohar (1988) tree spectral measures. The
   same paper proves the matching upper bound $\eta\le\sqrt{d_1-1}+\sqrt{d_2-1}+o(1)$ for random
   simple biregular graphs (their Theorem 4).
4. **(1)** J. Friedman, *A proof of Alon's second eigenvalue conjecture*, arXiv:cs/0405020, and
   C. Bordenave, arXiv:1502.04482v4, and J. Friedman and D.-E. Kohler, arXiv:1403.3462: the
   Hermitian threshold $2\sqrt{d-1}$ and its relative versions (the four dossiers).
5. **(1)** A. Marcus, D. Spielman, N. Srivastava, *Interlacing families I*, Ann. of Math. 182 (2015):
   infinitely many $d$-regular bipartite Ramanujan graphs for every $d\ge3$. Used as the input that
   makes the constant $\sqrt{k}$ attained for every $k\ge2$.
6. **(1)** E. Lubetzky, Y. Peres, *Cutoff on all Ramanujan graphs*, GAFA 26 (2016): the line digraph
   $DL(G)$ is always $2$-normal.
7. **(2)** Classical and re-derived here: tournaments are normal ($AA^{\mathsf T}=A^{\mathsf T}A$),
   Paley digraphs have all nontrivial eigenvalue moduli equal to $\sqrt{(k+1)/2}$.

I did not find, in the sources read, the value $2\sqrt{k-1}$ as the Alon-Boppana constant on the
normal locus (Theorem B), nor the sharpness of the $\sqrt{k}$ constant inside $2$-normal families
(Theorem C). Both are short consequences of published statements, so they may well be folklore. The
dossier states them as results with complete proofs and flags exactly which input each one uses.

## 3. Main results

Throughout, "connected" for a digraph means strongly connected, and $o(1)$ means as $n\to\infty$
with $k$ fixed.

### 3.1 Lemma (double cover), corrected statement

Let $A$ be the adjacency matrix of a $k$-regular digraph $D$, with singular values
$\sigma_1\ge\dots\ge\sigma_n\ge0$ counted with multiplicity and $r=\operatorname{rank}A$. Then
$$\widetilde A=\begin{pmatrix}0&A\\ A^{\mathsf T}&0\end{pmatrix}$$
is the adjacency matrix of a $k$-regular *bipartite* graph $\widetilde D$ on $2n$ vertices (the
bipartite double cover), which is $(k,k)$-biregular, simple, and connected whenever $D$ is strongly
connected. Its spectrum, as a multiset over the **nonzero** singular values, is
$$\mathrm{Spec}(\widetilde A)=\{\sigma_1,\dots,\sigma_r,-\sigma_1,\dots,-\sigma_r\}\cup\{0\}^{2n-2r},$$
and therefore the second largest element of $\mathrm{Spec}(\widetilde A)$, and also the second largest
element of its absolute spectrum, equals $\sigma_2(A)$. **(2)**, elementary.

Two corrections relative to the first version of this dossier. The earlier display
$\{\pm\sigma_i(A)\}\cup\{0\}^{2n-2\operatorname{rank}A}$ double counted the zero singular values,
because the $\pm$ must run over the nonzero ones only. And $\sigma_2(A)$ is *not* the ordinary signed
$\lambda_2$ of a symmetric digraph: $K_4$ has $\sigma_2=1$ while $\lambda_2=-1$ in decreasing order.
The correct identity for symmetric $A$ is $\sigma_2(A)=\max_{j\ge2}|\lambda_j(A)|$.

### 3.2 Theorem A (universal singular-value threshold)

For every strongly connected $k$-regular digraph on $n$ vertices,
$$\sigma_2(A)\ \ge\ 2\sqrt{k-1}-o(1).$$
The constant is sharp: symmetric digraphs underlying $k$-regular graphs attain it.

*Proof.* Apply the biregular Alon-Boppana bound (item 3 of Section 2) to the double cover, whose
second largest absolute eigenvalue is $\sigma_2(A)$ by Lemma 3.1. Sharpness: for a $k$-regular graph
$G$ seen as a symmetric digraph, $A=A^{\mathsf T}$ and $\sigma_2(A)=\max_{j\ge2}|\lambda_j(G)|$ by
Lemma 3.1, and the two-sided Alon-Boppana bound gives
$\max_{j\ge2}|\lambda_j(G)|\ge2\sqrt{k-1}-o(1)$. $\square$

The content of Theorem A is the *absence of hypotheses*: no normality, no periodicity, no almost
normality. The bound is a statement about the Hermitian closure $\widetilde D$ of $D$, which is why
$2\sqrt{k-1}$, a two-sided constant, appears.

### 3.3 Theorem B (normal digraphs obey the two-sided constant)

Let $k\ge2$ and let $(D_n)$ be strongly connected, aperiodic, normal $k$-regular digraphs with
$n\to\infty$. Then
$$\rho(D_n)=\max_{j\ge2}|\lambda_j|\ \ge\ 2\sqrt{k-1}-o(1),$$
and the constant is sharp, attained by any family of $k$-regular graphs with
$\max_{j\ge2}|\lambda_j|\to2\sqrt{k-1}$ seen as symmetric digraphs (random $k$-regular graphs,
Friedman, in the two-sided form).

*Proof.* By normality, $\{\sigma_i(A_n)\}=\{|\lambda_i(A_n)|\}$ as multisets. By aperiodicity and
strong connectivity the Perron eigenvalue $k$ is simple, so
$\max_{j\ge2}|\lambda_j|=\sigma_2(A_n)$. Apply Theorem A. $\square$

**Comparison with the literature.** Theorem 4.3 of Parzanchevski gives $\rho\ge\sqrt{k}-\varepsilon$
for all almost-normal families. Since $2\sqrt{k-1}>\sqrt{k}$ for every $k\ge2$ (because
$4(k-1)>k$ if and only if $k>4/3$), Theorem B is strictly stronger on the normal locus, and it removes the $\ell$-power
machinery of that proof entirely. In particular Proposition 3.1 of the same source (finitely many
normal Ramanujan digraphs of fixed $k$ and period) follows from Theorem B without the symmetrization
and Nilli estimates: an aperiodic normal Ramanujan digraph would need
$2\sqrt{k-1}-o(1)\le\rho\le\sqrt{k}$, which forces $k\le4/3$, so for $k\ge2$ only finitely many
sizes are possible. **(3)**

### 3.4 Theorem C (constant exactly sqrt(k) for r at least 2, for every period)

Fix $k\ge2$, $m\ge1$, $r\ge2$.

(i) For every $\varepsilon>0$ there is no infinite family of strongly connected $r$-normal
$k$-regular $m$-periodic digraphs with $\rho\le\sqrt{k}-\varepsilon$.

(ii) There is an infinite family of strongly connected $2$-normal $k$-regular $m$-periodic digraphs
with $\limsup\rho\le\sqrt{k}$.

*Proof.* (i) is Theorem 4.3 of Parzanchevski (item 1), applied to the almost-normal class.

(ii) Take random $(k+1)$-regular graphs $G_n$. By Friedman they satisfy
$\max_{j\ge2}|\lambda_j|\le2\sqrt{k}+o(1)$, and they are connected and non-bipartite with
probability tending to one. Let $D_0=DL(G_n)$. By the Ihara-Bass relations (Parzanchevski (3.1),
(3.2)) every nontrivial eigenvalue $\lambda$ of $G_n$ contributes the two roots of
$\mu^2-\lambda\mu+k=0$. If $|\lambda|\le2\sqrt{k}$ the two roots are complex conjugates with product
$k$, so both have modulus exactly $\sqrt{k}$. If $2\sqrt{k}<|\lambda|<k+1$ the larger root has modulus
$<k$ (it equals $k$ only at $|\lambda|=k+1$, the trivial Perron value), and the trivial $\lambda=k+1$
produces the trivial eigenvalues $k$ and $1$. Hence every nontrivial eigenvalue of $DL(G_n)$ has
modulus $\sqrt{k}+o(1)$, and the eigenvalue $k$ is simple because $G_n$ is non-bipartite (a bipartite
$G_n$ would contribute $-k$). So $DL(G_n)$ is strongly connected, aperiodic, $2$-normal, $k$-regular
and $\rho(DL(G_n))=\sqrt{k}+o(1)$.

Now take the $m$-fold cyclic cover $A=P_m\otimes A_{DL(G_n)}$. By Proposition 6 of `proofs.md`,
applied with base period $m_0=1$, this is strongly connected, has period exactly $m$, is $2$-normal
(it is unitarily equivalent to a direct sum of $m$ copies of a $2$-normal matrix), is $k$-regular, and
has the same $\rho$. Since $n\to\infty$ this is an infinite family with $\limsup\rho\le\sqrt{k}$.
$\square$

**Correction note (review point 1).** The first version asserted that $P_m\otimes A_{D_0}$ has period
exactly $m$ because $P_m$ acts freely by automorphisms. That is false. The peripheral spectrum of
$P_m\otimes A_{D_0}$ is $\{k\zeta:\zeta^{\operatorname{lcm}(m,m_0)}=1\}$ where $m_0$ is the period of
$D_0$, each value with multiplicity $\gcd(m,m_0)$, so the period of the cover is
$\operatorname{lcm}(m,m_0)$, not $m$, and the cover is strongly connected only when
$\gcd(m,m_0)=1$. Explicit counterexample: $D_0=DL(K_{3,3})$ has period $2$ and $P_3\otimes A_{D_0}$
has period $6$, verified in `experiments/period_check.py` and `raw/period_check.json`. The repair is
to start from an **aperiodic** base, which is available for every $k$ because random
$(k+1)$-regular graphs are aperiodic and almost Ramanujan. The same computation verifies that
$DL(K_4)$, which is aperiodic, gives period exactly $m$ and $\rho=\sqrt2$ for $m=1,2,3$.

**Novelty adjustment (review point 5).** Section 5.3 of Parzanchevski already records that line
digraphs of Ramanujan graphs are Ramanujan digraphs. The line-digraph mechanism is therefore not new.
What this dossier adds is the *sharp constant classification*: the normal locus has constant
$2\sqrt{k-1}$ (Theorem B), the $2$-normal class has constant exactly $\sqrt{k}$ uniformly in the
period, the two values are the only ones that occur, and the jump sits between $r=1$ and $r=2$.

### 3.5 Corollary (the table of sharp constants)

Write $c(r,m)$ for the infimum of $\liminf\rho(D_n)$ over strongly connected $r$-normal $k$-regular
$m$-periodic digraphs, $k\ge2$ fixed.

| class | sharp constant $c$ | attained by |
|---|---|---|
| $r=1$ (normal), $m=1$ | exactly $2\sqrt{k-1}$ | symmetric digraphs of Alon-Boppana-tight graphs (random regular, LPS bipartite) |
| $r=1$ (normal), $m\ge2$ | in $[(2\sqrt{k^m-1})^{1/m},\,2\sqrt{k-1}]$, open | upper end attained by cyclic $m$-covers of aperiodic symmetric bases (Proposition 7) |
| $r\ge2$ (almost-normal), every $m$ | exactly $\sqrt{k}$ | cyclic $m$-covers of $DL(G_n)$, $G_n$ random regular (Theorem C(ii)), or of $DL(G)$ for Ramanujan $G$ when $m_0=1$ |
| no almost-normality | $0$ | De Bruijn digraphs $DB(k,s)$, $\rho=0$ exactly |

The only open cells are normal with period $m\ge2$: there the elementary bound
$\rho^m\ge2\sqrt{k^m-1}-o(1)$ (apply Theorem B to the $m$ aperiodic normal $k^m$-regular components
of $A^m$) gives only $(2\sqrt{k^m-1})^{1/m}\approx\sqrt{2k}$, which is strictly below $2\sqrt{k-1}$
for every $k\ge2$ (the two are equal only at $k=1$, and the inequality
$\sqrt{k^2-1}\ge2(k-1)$ fails for all $k\ge2$). **(5)** I conjecture that the truth is
$2\sqrt{k-1}$ for all $m$, that is, that periodicity alone does not lower the normal constant. The
evidence is one-sided: the cyclic $m$-cover of an aperiodic symmetric base attains $2\sqrt{k-1}$ for
every $m$ (Proposition 7), and I
have no construction below it. Note that the periodicity *does* lower the constant from $2\sqrt{k-1}$
to $\sqrt{k}$ as soon as normality is dropped to $2$-normality, so the open question is specifically
whether normality plus periodicity can beat $2\sqrt{k-1}$.

### 3.6 Proposition D (trivial spectrum, and where lambda_3 and lambda_4 come from)

Let $D$ be a strongly connected $k$-regular digraph of period $m$. Then the set of eigenvalues of
modulus $k$ is exactly $\{k\zeta_m^j: j=0,\dots,m-1\}$. Consequently

* $\lambda_1,\dots,\lambda_m$ are all trivial and $|\lambda_2|=k$ whenever $m\ge2$,
* the additive gap $k-\lambda_2$ carries no information for $m\ge2$, and
* the first informative gap is $k-|\lambda_{m+1}|=\rho(D)$ when the trivial eigenvalues are ordered
  first.

*Proof.* Perron-Frobenius for irreducible nonnegative matrices gives that the peripheral spectrum is
a cyclic group of order equal to the period, with the eigenvalues $k\zeta_m^j$, all simple (see
`proofs.md`). The statement is also recorded as (1) in Parzanchevski Section 2. $\square$

**Exact model example (2).** The complete $k$-regular $m$-periodic digraph $K_{k,m}$ (vertices
$(x,y)\in\mathbb Z/m\times[k]$, arcs $(x,y)\to(x+1,z)$) has spectrum
$$\{k\zeta_m^j: j<m\}\cup\{0\}^{(k-1)m},$$
because its adjacency matrix is the Kronecker product $P_m\otimes J_k$ of the cyclic shift and the
all-ones matrix, so the spectrum is the product set $\{\zeta\lambda:\zeta^m=1,\lambda\in\mathrm{Spec}(J_k)\}$
with $\mathrm{Spec}(J_k)=\{k,0^{(k-1)}\}$. This is checked in `experiments/exact_examples.py` for
$(k,m)\in\{(2,2),(2,3),(3,2),(3,3),(3,4),(4,3)\}$, where the number of eigenvalues of modulus $k$ is
$m$ in every case and all remaining eigenvalues are numerically zero.

**Interpretation for the swarm's question.** "$d-\lambda_3$" is the correctly indexed first gap for
period $2$, and "$d-\lambda_4$" for period $3$. This is consistent with, and independent of, the
opposite finding of direction `d1` for hypergraph clique expansions, where the Perron eigenvalue is
simple and $\lambda_3,\lambda_4$ are strictly weaker than $\lambda_2$. Both statements are true
statements about different operators: the index shift is created by the size of the trivial
spectrum, which is $1$ for the clique expansion and $m$ for a period-$m$ digraph.

**Numerical check (4).** Random $m$-periodic $k$-regular digraphs at $n=800$ to $1600$ (script
`experiments/periodic_and_line.py`) show exactly $m$ eigenvalues of modulus $k$ and a first
nontrivial modulus close to $\sqrt{k}$:

| $k$ | $m$ | top moduli | count at modulus $k$ | $\lambda_{m+1}$ | $\sqrt{k}$ | $2\sqrt{k-1}$ |
|---|---|---|---|---|---|---|
| 2 | 2 | 2.000, 2.000, 1.429 | 2 | 1.429 | 1.414 | 2.000 |
| 2 | 3 | 2.000, 2.000, 2.000, 1.436 | 3 | 1.436 | 1.414 | 2.000 |
| 3 | 2 | 3.000, 3.000, 1.768 | 2 | 1.768 | 1.732 | 2.828 |
| 3 | 3 | 3.000, 3.000, 3.000, 1.747 | 3 | 1.747 | 1.732 | 2.828 |
| 3 | 4 | 3.000 x4, 1.738 | 4 | 1.738 | 1.732 | 2.828 |
| 4 | 2 | 4.000, 4.000, 2.033 | 2 | 2.033 | 2.000 | 3.464 |
| 4 | 3 | 4.000 x3, 2.021 | 3 | 2.021 | 2.000 | 3.464 |

The first nontrivial modulus tracks $\sqrt{k}$, not $2\sqrt{k-1}$: these random periodic digraphs
are in the non-normal class, consistent with Theorem C.

### 3.7 Proposition E (Ihara-Bass dictionary: why the factor two)

Let $k\ge1$ and let $\lambda$ be **real**. The substitution
$$\lambda=2\sqrt{k}\cos\theta\ \Longleftrightarrow\ \mu=\sqrt{k}\,e^{i\theta}$$
is exactly the correspondence between an adjacency eigenvalue $\lambda$ of a $(k+1)$-regular graph
$G$ and a non-backtracking (line-digraph) eigenvalue $\mu$ of $DL(G)$, because $\mu$ solves
$\mu^2-\lambda\mu+k=0$. For real $\lambda$,

$$\lambda\in[-2\sqrt{k},2\sqrt{k}]\iff|\mu|=\sqrt{k},$$

and neither implication survives for complex $\lambda$, see the correction note below.

The parameter $\theta$ is simultaneously the angle on the circle and the Joukowski coordinate on the
interval, so the two sets are the same object written in two variables. The largest element of the
interval is $2\sqrt{k}$ and the radius of the circle is $\sqrt{k}$, and the ratio $2$ is exactly the
ratio between $2\cos\theta$ and $1$ at $\theta=0$, that is, the ratio between the two normalizations
of the same eigenparameter.

*Proof.* $\mu^2-\lambda\mu+k=0$ with $\lambda=2\sqrt{k}\cos\theta$ gives
$\mu=\sqrt{k}(\cos\theta\pm i\sin\theta)$. **(2)**, verified numerically in
`experiments/line_digraph_transfer.py` for $C_6$, $C_7$, $K_4$, $Q_3$, $K_{3,3}$, Petersen, Heawood.

**Correction note (review point 2).** The first version stated the equivalence for all complex
$\lambda$, which is false. Counterexample: $k=1$, $\lambda=2i$, the roots are $i(1\pm\sqrt2)$ with
moduli $\sqrt2+1$ and $\sqrt2-1$, not $1$. The real form is what the spectral application needs,
because adjacency eigenvalues of a $(k+1)$-regular graph are real. A correct complex statement is
that $|\mu|=\sqrt{k}$ holds if and only if $\lambda$ is real with $|\lambda|\le2\sqrt{k}$.

**Consequence.** Statements of the form "the digraph threshold is $\sqrt{k}$ while the graph
threshold is $2\sqrt{k-1}$, therefore one of them is wrong" are category errors. They are the same
threshold in the two coordinates linked by the Ihara-Bass quadratic. What genuinely changes between
the two worlds is not the constant but the *shape* of the spectrum: an interval for the Hermitian
operator, a circle (up to the interior point set $\{\pm1\}$) for the line digraph, a disk for the
directed tree $T_k$.

### 3.8 The non-normality index kappa

Define $\kappa(A)=\sigma_2(A)/\rho(D)$ when $\rho(D)>0$. Exact data points:

* $\kappa=1$ for every normal digraph with simple Perron eigenvalue (Theorems A and B), **(3)**
* $\kappa\ge2\sqrt{k-1}/k$ for every $k$-regular digraph, since $\sigma_2\ge2\sqrt{k-1}$ and
  $\rho\le k$, **(3)**
* $\kappa=\sqrt{k}$ for $DL(G)$ of a Ramanujan graph, because $\sigma_2(DL(G))=k$ with high
  multiplicity (statement (1) in Parzanchevski Section 3.5: "the trivial singular value $k$ repeats
  $|V_G|$ times") while $\rho=\sqrt{k}$, **(1)+(2)**
* $\kappa=\infty$ for De Bruijn digraphs, $\rho=0$ and $\sigma_2=k$, **(1)+(2)**
* $\kappa\to2\sqrt{k-1}/\sqrt{k}=2\sqrt{1-1/k}$ for random $k$-regular digraphs, which tends to $2$
  (numerics, Section 5).

So $\kappa$ measures how much of the two-sided spectral structure survives in a one-sided operator,
and the extreme values $1$, $\sqrt{k}$, $\infty$ are all attained by explicit families.

## 4. Exact examples with reproducible arithmetic

All numbers below are produced by `experiments/exact_examples.py` and stored raw in
`raw/exact_examples.json`. Exact identities are checked in integer arithmetic, eigenvalue
statements numerically in double precision with the residual always below $10^{-8}$.

### 4.1 Paley digraphs (normal, moment-sharp, and a warning about growing k)

For a prime $p\equiv3\pmod 4$ let $S\subset\mathbb Z_p$ be the set of quadratic residues and put an
arc $a\to b$ iff $b-a\in S$. Then $k=(p-1)/2$, the digraph is $k$-regular, and **(2)**

* $AA^{\mathsf T}=A^{\mathsf T}A$ exactly (checked in integer arithmetic for $p=3,\dots,83$),
* $\sum_j|\lambda_j|^2=nd$ exactly, so Schur's inequality is an equality (normality),
* the nontrivial eigenvalues are $(-1\pm i\sqrt p)/2$, so all nontrivial moduli equal
  $\sqrt{(p+1)/4}=\sqrt{(k+1)/2}$.

Because all nontrivial moduli are equal, the Paley digraph attains the trivial lower bound
$\max_{j\ge2}|\lambda_j|\ge\sqrt{(nd-k^2)/(n-1)}$ coming from
$\sum_{j\ge2}|\lambda_j|^2=nd-k^2$. Checked values: $p=7$ gives $\sqrt2$, $p=19$ gives $\sqrt5$,
$p=83$ gives $\sqrt{21}$, all to $10^{-9}$.

**Warning (5 -> 2).** Since $\sqrt{(k+1)/2}<\sqrt{k}<2\sqrt{k-1}$ for large $k$, Paley digraphs do
*not* contradict Theorem B: they are normal but their degree grows with $n$. Any proposed Alon-Boppana
theorem for digraphs must therefore either fix $k$ or pay a degree-dependent error. This is exactly
the regime split that the four dossiers handle with "$d$ fixed".

### 4.2 Complete periodic digraphs $K_{k,m}$ (exact trivial spectrum)

Spectrum $\{k\zeta_m^j:j<m\}\cup\{0\}^{(k-1)m}$, verified for six parameter pairs. This is the
cleanest exact witness of Proposition D: exactly $m$ eigenvalues of modulus $k$, all remaining ones
at zero, so $k-\lambda_2=0$ and $k-\lambda_{m+1}=k$ is the whole first gap.

### 4.3 De Bruijn digraphs (rho = 0 with sigma_2 = k, so kappa = infinity)

$DB(k,s)$ has $n=k^s$, is $k$-regular and aperiodic. **(1)** its nontrivial spectrum consists of
zeros, and its Jordan blocks have size $s$, so it is not almost-normal. **(2)** numerically:

| $k$ | $s$ | $n$ | $\lambda_2$ modulus | $\sigma_1$ | $\sigma_2$ | $\|AA^{\mathsf T}-A^{\mathsf T}A\|_F$ |
|---|---|---|---|---|---|---|
| 2 | 2 | 4 | $1.6\cdot10^{-8}$ | 2.000 | 2.000 | 5.66 |
| 2 | 4 | 16 | $3.6\cdot10^{-6}$ | 2.000 | 2.000 | 11.3 |
| 2 | 6 | 64 | $3.1\cdot10^{-3}$ | 2.000 | 2.000 | 22.6 |
| 3 | 3 | 27 | $1.0\cdot10^{-5}$ | 3.000 | 3.000 | 31.2 |
| 3 | 4 | 81 | $2.2\cdot10^{-4}$ | 3.000 | 3.000 | 54.0 |

So $\rho\to0$ while $\sigma_2=k$ exactly: the two thresholds of this dossier are maximally separated
on this family. This is the exact sense in which "$\rho\le\sqrt{k}$" cannot be a theorem for all
digraphs, and why almost-normality is not a technical convenience but the hypothesis that makes the
eigenvalue threshold exist at all.

### 4.4 Line digraphs (Ihara-Bass transfer, exact)

**One definition, used everywhere below.** A $d$-regular digraph or graph is called Ramanujan here
if **every eigenvalue that is not peripheral**, that is, every eigenvalue with $|\lambda|<d$, satisfies
$|\lambda|\le2\sqrt{d-1}$ (for a graph) or $|\lambda|\le\sqrt{k}$ (for a $k$-regular digraph, after
removing peripheral values). The peripheral eigenvalues $|\lambda|=d$ are excluded before the test,
because for a bipartite graph they include $-d$ and that value has nothing to do with expansion. The
first version of this dossier mixed two conventions, which is review point 5.

For $G\in\{C_6,C_7,K_4,Q_3,K_{3,3},\text{Petersen},\text{Heawood}\}$ the formula
$\mathrm{Spec}(DL(G))=\{(\lambda\pm\sqrt{\lambda^2-4k})/2\}\cup\{\pm1\}^{|E|-|V|}$ reproduces the
characteristic polynomial of the Hashimoto matrix up to $10^{-6}$ in every case. All seven graphs are
Ramanujan once the trivial $\pm(k+1)$ are removed. For the five with $k\ge2$ ($K_4$, $Q_3$,
$K_{3,3}$, Petersen, Heawood) every nontrivial modulus of $DL(G)$ equals $\sqrt{k}=\sqrt2$ or $1$,
confirming $\rho=\sqrt{k}$. The two cycle cases have $k=1$, where $\sqrt{k}=1$ coincides with the
trivial value and the nontrivial set is not separated by the modulus filter.

**Transfer experiment (4).** For random simple $d$-regular $G$ on $n$ vertices, the exact transfer
gives $\rho(DL(G))$:

| $d$ | $k=d-1$ | $n$ | non-peripheral $\max|\lambda(G)|$ | $2\sqrt{k}$ | $\rho(DL(G))$ | $\sqrt{k}$ |
|---|---|---|---|---|---|---|
| 3 | 2 | 200 | 2.81555 | 2.82843 | 1.41421 | 1.41421 |
| 3 | 2 | 2000 | 2.82400 | 2.82843 | 1.41421 | 1.41421 |
| 3 | 2 | 5000 | 2.82855 | 2.82843 | 1.42737 | 1.41421 |
| 4 | 3 | 2000 | 3.46149 | 3.46410 | 1.73205 | 1.73205 |
| 5 | 4 | 5000 | 3.99270 | 4.00000 | 2.00000 | 2.00000 |

The last row of the first block is the instructive one: once $\lambda_2(G)$ crosses $2\sqrt{k}$ by
$10^{-4}$, the transfer pushes $\rho(DL(G))$ above $\sqrt{k}$ by $10^{-2}$, the square-root
behaviour of the map at the edge of the interval. This is a deterministic transfer, not a
probabilistic statement.

## 5. Numerical experiments on random models

Script `experiments/random_numerics.py`, raw data `raw/random_numerics.json`, summary
`raw/random_summary.txt`. Two models, $k\in\{2,\dots,6\}$, $n$ up to 4000, two independent trials,
largest eigenvalues by ARPACK and $\sigma_2$ by ARPACK on the transpose-free singular problem.

**Model A (one-sided).** $A$ is the sum of $k$ independent uniform permutation matrices, the standard
uniform random $k$-regular digraph.

**Model B (normal control).** $A$ is the adjacency of a random $k$-regular undirected multigraph from
the configuration model, seen as a symmetric digraph.

| model | $k$ | $n$ | $\rho/\sqrt{k}$ | $\sigma_2/2\sqrt{k-1}$ | $\kappa$ | $2\sqrt{k-1}/\sqrt{k}$ |
|---|---|---|---|---|---|---|
| A | 2 | 4000 | 1.0051 | 1.0000 | 1.407 | 1.414 |
| A | 3 | 4000 | 1.0091 | 1.0001 | 1.619 | 1.633 |
| A | 4 | 4000 | 1.0111 | 0.9997 | 1.713 | 1.732 |
| A | 5 | 4000 | 1.0096 | 0.9988 | 1.770 | 1.789 |
| A | 6 | 4000 | 1.0071 | 0.9994 | 1.812 | 1.826 |
| B | 3 | 4000 | 1.6306 | 0.9986 | 1.0000 | 1.633 |
| B | 4 | 4000 | 1.7302 | 0.9989 | 1.0000 | 1.732 |
| B | 5 | 4000 | 1.7894 | 1.0003 | 1.0000 | 1.789 |
| B | 6 | 4000 | 1.8256 | 0.9999 | 1.0000 | 1.826 |

Readings.

1. In model B, $\rho=\sigma_2=\max_{j\ge2}|\lambda_j|$ and $\kappa=1.0000$ to four digits, and the
   common value tracks $2\sqrt{k-1}$. This is the numerical shadow of Theorem B plus Friedman's
   theorem. (The quantity is the second largest element of the absolute spectrum, the convention
   fixed in Section 4.4.)
2. In model A, $\sigma_2$ tracks $2\sqrt{k-1}$ while $\rho$ tracks $\sqrt{k}$, simultaneously. This
   is the numerical shadow of Theorem A (lower half) plus Coste's theorem (upper half for $\rho$)
   plus the biregular Kesten-McKay heuristic (upper half for $\sigma_2$, which is *not* proved for
   this model by the biregular theorem, since the double cover of a random digraph is a very special
   biregular graph).
3. Consequently $\kappa$ tracks $2\sqrt{k-1}/\sqrt{k}$ in model A, from below, with the finite-size
   error decreasing in $n$.

**What these experiments do not establish.** They do not prove any asymptotic statement. The
convergence of $\rho$ to $\sqrt{k}$ in model A is not a proof of Coste's theorem, and the observed
$\sigma_2\to2\sqrt{k-1}$ in model A is not implied by the biregular theorem (that theorem is for the
uniform simple biregular model, and the double cover is not uniform in that class). The
$\sigma_2$ statement for random digraphs is a genuine conjecture at this level of writing.

## 6. Theorem target, proof strategy, and the hardest missing estimate

### 6.1 Target T1 (quantitative Theorem B)

**Statement.** There is a constant $C_k<\infty$ such that every strongly connected aperiodic normal
$k$-regular digraph on $n\ge3$ vertices satisfies
$$\rho(D)\ \ge\ 2\sqrt{k-1}-C_k\,(\log n)^{-2}.$$

**Strategy.** By normality it suffices to prove a quantitative biregular Alon-Boppana bound for the
$(k,k)$-biregular double cover: for every connected $(k,k)$-biregular graph on $2n$ vertices,
$$\lambda_2\ \ge\ 2\sqrt{k-1}-C_k'\,(\log n)^{-2}.$$
The two available routes both reduce to counting closed walks on the $(k,k)$-biregular tree.

* *Girth route.* If the girth exceeds $2t$, every closed $2t$-walk from a vertex of the cover is a
  tree walk, so $\lambda_2\ge N_t^{1/(2t)}$ where $N_t$ is the number of closed $2t$-walks in the
  biregular tree from a fixed vertex. Since girth is at most $2\log_{k-1}(2n)+O(1)$, one takes
  $t\asymp\log n$ and needs the moment asymptotics of the Godsil-Mohar measure.
* *Nilli route.* Extend Nilli's tight estimate (as quoted in Parzanchevski's Theorem 3.4,
  $\lambda_2\ge2\sqrt{k_G-1}\cos(2\pi/\operatorname{diam}G)$) to biregular graphs and use the Moore
  bound for the cover, $\operatorname{diam}(\widetilde D)\le2\log_{k-1}(2n)+O(1)$.

**Hardest missing estimate (single item).** A two-sided, sharp-constant asymptotic for the moment
sequence of the $(k,k)$-biregular tree,
$$N_t=\Theta_k\bigl(t^{-3/2}\bigr)\,\bigl(2\sqrt{k-1}\bigr)^{2t}\qquad(k\ge3),$$
with the constant in $\Theta_k$ explicit and uniform in $k$. The algebraic prefactor is the whole
difficulty, and the first version of this dossier got it wrong: the closed-walk count is **not**
$(k-1)^t\mathrm{Cat}_t$, since for $k=2$ and $t=1$ the true count is $2$, not $1$. The correct
computation is in Proposition 9 of `proofs.md`: with $R(x)=\sum_t N_tx^t$ one has
$R=1/(1-kxF)$ and $F=1+(k-1)xF^2$, which gives $N_1=k$ and $N_2=2k^2-k$, and the singularity analysis
of $R$ at $x=1/(4(k-1))$ gives the exponent $-3/2$ for $k\ge3$ and the special value
$N_t=\binom{2t}{t}=\Theta(t^{-1/2})4^t$ at $k=2$, where the branch point is cancelled by a zero of the
prefactor. So the exponent itself depends on $k$, and any uniform-in-$k$ statement has to treat $k=2$
separately. Note the rate cost: with $N_t^{1/(2t)}=2\sqrt{k-1}\,(1-O(\log t/t))$ and
$t\asymp\log n$, the girth route produces only a deficit of order $(\log\log n)/(\log n)$, so the
$(\log n)^{-2}$ rate advertised in Target T1 must come from the Nilli/diameter route, and transferring
Nilli's argument to biregular graphs is where the sharp constant is genuinely at risk. Everything else
in the strategy is bookkeeping.

### 6.2 Target T2 (the open cell of Corollary 3.5)

**Statement.** For $m\ge2$ and $r=1$, decide whether $c(1,m)=2\sqrt{k-1}$ or whether periodicity
strictly lowers the normal constant.

**Why it is the interesting one.** For $r\ge2$ the answer is independent of $m$ (Theorem C plus the
aperiodic-base cover of Proposition 6). For $r=1$ and $m\ge2$ the elementary bound only gives
$(2\sqrt{k^m-1})^{1/m}$, which is about $\sqrt{2k}$, strictly less than $2\sqrt{k-1}$ for every
$k\ge2$. A proof that $c(1,m)=2\sqrt{k-1}$ would show that *periodicity alone never lowers the
constant*, only non-normality does. A counterexample family would be a genuinely new construction of
periodic normal digraphs whose nontrivial spectrum is confined to a smaller disk.

**Concrete experiment that decides it.** For $m=3$, $k=3$: search over $3$-periodic normal
$3$-regular digraphs with $A=P\otimes(\text{something})$ or with $A$ circulant over
$\mathbb Z/3\times\mathbb Z/L$, and compute $\rho$ by characters. Circulant constructions are
analytically tractable, the spectral description is closed-form, and if the infimum over the
circulant class is $2\sqrt{k-1}$ while the general question stays open, that is still a clean
intermediate result.

### 6.3 Target T3 (the sigma_2 statement for random digraphs)

**Statement.** For random $k$-regular digraphs (sum of $k$ uniform permutations),
$\sigma_2\to2\sqrt{k-1}$ in probability.

**Why it is not immediate.** The double cover of the permutation-model digraph is a $(k,k)$-biregular
graph carrying a fixed-point-free involution that swaps the parts. The uniform biregular theorem does
not apply directly. What is missing is a tangle-free *symmetric* biregular random model, that is, the
biregular analogue of the random-lift model of Bordenave's theorem. This is the natural next item for
someone with the tools of direction `d4`.

## 7. Unresolved steps and what evidence would decide them

1. **Novelty of Theorem B.** I found no statement of $2\sqrt{k-1}$ as the normal-locus constant in
   the literature read. Deciding evidence: a full-text search of the Ramanujan-digraph literature
   (Parzanchevski, Lubetzky-Peres, Lubetzky-Lubotzky-Parzanchevski, Parzanchevski-Sarnak) for
   "normal" plus "$2\sqrt{}$". If it is folklore, the dossier's contribution reduces to the sharp
   arrangement of Corollary 3.5, which is still not in the sources read.
2. **Open cells $r=1$, $m\ge2$.** See Target T2. Evidence: an explicit $m$-periodic normal family
   with $\rho<2\sqrt{k-1}-\delta$, or a proof that none exists.
3. **$\sigma_2$ for random digraphs.** See Target T3. Evidence: a tangle-free symmetric biregular
   model, or a numerical failure of $\sigma_2\to2\sqrt{k-1}$ at $n=10^4$ to $10^5$.
4. **The hypergraph analogue of Proposition D.** My numerical probe of the Berge flag
   non-backtracking operator (script `experiments/hypergraph_nb_trivial.py`, three successfully
   sampled linear random hypergraphs with $(k,d)\in\{(3,3),(4,2),(5,2)\}$) found a *simple* Perron
   eigenvalue in each case, so the naive Berge operator does not produce the multiplicity that would
   make $k-\lambda_3$, $k-\lambda_4$ the correctly indexed hypergraph gaps. This is a negative
   result about that operator only, on three samples, and should not be extrapolated. Evidence that
   would settle the hypergraph question: compute the trivial spectrum (eigenvalues of modulus equal
   to the Perron value) of the *controlled* hypergraph non-backtracking operators used in the
   zeta-function literature, for $k=3,4,5$, and read off the multiplicity.
5. **A weighted/irregular version of Theorem A.** For a digraph with in-degree and out-degree both
   equal to a vector $\mathbf d$ (a directed analogue of an irregular graph, which is direction
   `d3`'s territory), the double cover is $(d_v,d_v)$-biregular in a weighted sense and the correct
   threshold is the spectral radius of the weighted biregular tree. This is not addressed here.

## 8. Prioritized next steps

1. Compute the sharp constant numerically for circulant $3$-periodic normal digraphs over
   $\mathbb Z_3\times\mathbb Z_L$ (Target T2, $m=3$), then for $m=2$ over $\mathbb Z_2\times\mathbb Z_L$.
   Cheap, decide within one session.
2. Search the Ramanujan-digraph literature full-text for the normal-locus constant (item 1 above).
3. Prove the biregular moment asymptotic of Section 6.1 and with it Target T1. This is the single
   hardest estimate of the whole direction.
4. Test the "trivial spectrum multiplicity" question for the controlled hypergraph non-backtracking
   operators (item 4 above). This directly serves direction `d1`.
5. Extend Theorem A to irregular digraphs by a weighted double cover, and compare with `d3`.

## 9. Common ground with the four source dossiers and with other directions

Statements in this section that are not already proved in Sections 2 to 3 are interpretation **(5)**,
not verified fact.

**Dossier 1 (Friedman, Alon's second eigenvalue conjecture).** Theorem B is sharp exactly because of
Friedman's theorem. Random $k$-regular graphs have $\lambda_2\le2\sqrt{k-1}+o(1)$, so
$2\sqrt{k-1}$ cannot be improved on the normal locus. The dossier's mechanism (local limit plus tangle
control) is the mechanism that produces the matching upper bound in the normal class.

**Dossier 2 (Brito-Dumitriu-Decker Harris, biregular spectral gap).** This is the single most
important source for this direction. The double cover of a $k$-regular digraph is a $(k,k)$-biregular
graph, and the biregular Alon-Boppana bound of that paper (their eq. (2), attributed to Feng and Li)
is precisely Theorem A. So the "two-sided threshold" of the biregular dossier is, verbatim, the
singular-value threshold of every regular digraph. Their Theorem 4 (upper bound for random biregular)
is also what makes the random-digraph $\sigma_2$ prediction plausible, though the double cover is not
in their model class (Target T3).

**Dossier 3 (Bordenave, random lifts).** The non-backtracking operator of a graph is exactly the
adjacency of a line digraph, and the Ihara-Bass transfer of Proposition E is the transfer used
throughout that paper. In this dossier's language, Bordenave's $\sqrt{\rho_1}$ bound for new
non-backtracking eigenvalues is a $\sqrt{k}$-type statement about a $1$-periodic or $2$-periodic
line digraph, which is consistent with Theorem C: the $2$-normal class has constant exactly $\sqrt{k}$.

**Dossier 4 (Friedman-Kohler, relativized second eigenvalue).** The relative (new) spectrum of a
cover is the natural directed analogue of $\rho(D)$ after removing the old spectrum, and the
"trivial space" $L_0^2$ here plays the role of the complement of the pulled-back base spectrum there.
The $\sqrt{k}$ versus $2\sqrt{k-1}$ split should have a relative version: for a random lift of a base
digraph, the new eigenvalues should be governed by the spectral radius of the base non-backtracking
operator, and the Ihara-Bass substitution should convert the $\sqrt{\rho_1}$ threshold into the
appropriate one-sided constant. That is direction `d4`'s territory, and this dossier supplies the
exact dictionary.

**Direction `d1` (hypergraph gap normalization).** Complementary, not overlapping. `d1` shows that
for the clique/codegree operator the Perron eigenvalue is simple, so $d-\lambda_3$, $d-\lambda_4$ are
weaker than $d-\lambda_2$. Proposition D shows the opposite regime: when the trivial spectrum has
size $m$, the correctly indexed gap is $d-\lambda_{m+1}$, and for period $2$ and $3$ those are
exactly the user's $\lambda_3$ and $\lambda_4$. The two findings are consistent because they refer to
different operators. The shared rule is: *the index of the first informative gap equals one plus the
number of trivial eigenvalues of maximal modulus*.

**Direction `d2` (Bloch/abelian covers).** For an abelian Cayley digraph, all eigenvalues are
character values $\chi(S)$ with $|\chi(S)|\le k$ and the near-trivial characters give
$\rho\to k$. So algebraic and lattice-like one-sided structures are the worst case, the exact
counterpoint of the amenability picture in `d2`. The cyclic-cover step of Theorem C is the
representation-theoretic shadow of the Bloch decomposition: $A_D=P_m\otimes A_{D_0}$ is a direct
integral over the $m$ characters of the cyclic group, and Proposition 6 is exactly the statement that
this direct integral multiplies the peripheral spectrum by the $m$-th roots of unity, hence changes
the period to $\operatorname{lcm}(m,m_0)$.

**Direction `d3` (almost regular graphs).** The $\kappa$ index is the natural one-sided analogue of
the degree-defect question. A single vertex of out-degree different from its in-degree already
destroys normality, so `d3`'s "rare defect" analysis should have a one-sided version in which a
single defect moves $\kappa$ away from $1$ without moving $\rho$.

## 10. Epistemic ledger

| item | category | where |
|---|---|---|
| Ramanujan digraph definition and threshold $\sqrt{k}$ | (1) | Parzanchevski 1804.08028v4 Def 2.2 |
| trivial eigenvalues $k\zeta_m^j$, exactly the peripheral spectrum | (1) + (3) | Parzanchevski Section 2, proof in `proofs.md` |
| no Alon-Boppana for general digraphs (De Bruijn, $\rho=0$) | (1) + (2) | Parzanchevski Remark 3.2, recomputed here |
| Alon-Boppana for almost-normal digraphs, constant $\sqrt{k}$ | (1) | Parzanchevski Theorem 4.3 |
| random regular digraphs have $\rho\le\sqrt{k}+\varepsilon$ | (1) | Coste 1708.00530v2 Thm 1, recorded as Thm 5.3 in Parzanchevski |
| biregular Alon-Boppana $\sqrt{d_1-1}+\sqrt{d_2-1}$ | (1) | Brito-Dumitriu-Decker Harris 1804.07808v6 eq. (2) |
| double cover identity and Theorem A | (3) | `proofs.md` Prop 1, Thm A |
| Theorem B ($2\sqrt{k-1}$ on the normal locus, sharp) | (3) | `proofs.md` Thm B |
| period bookkeeping for cyclic covers, $\operatorname{lcm}(m,m_0)$ | (2)+(3)+(4) | `proofs.md` Prop 6, `raw/period_check.json` |
| closed-walk counts on the $k$-regular tree, $N_1=k$, $N_2=2k^2-k$, exponent $-3/2$ vs $-1/2$ | (2)+(3) | `proofs.md` Prop 9 |
| Theorem C sharpness at $\sqrt{k}$ via line digraphs, all periods | (1)+(2)+(3) | `proofs.md` Thm C, Prop 6, `raw/period_check.json` |
| Corollary 3.5 table, including the open $m\ge2$ cells | (3)+(5) | Section 3.5 |
| Proposition D and the $d-\lambda_3$, $d-\lambda_4$ reading | (1)+(3) | Section 3.6 |
| Proposition E Ihara-Bass dictionary, real form only | (2) | Section 3.7, `proofs.md` Prop 8, numerics |
| Paley, $K_{k,m}$, De Bruijn, line-digraph data | (2)+(4) | Section 4, `raw/` |
| random model tables | (4) | Section 5, `raw/` |
| Berge non-backtracking simple Perron (three samples) | (4) | Section 7 item 4 |
| Targets T1, T2, T3 and the conjecture $c(1,m)=2\sqrt{k-1}$ | (5) | Section 6 |

## 11. Files and reproduction

* `dossier/README.md` index and headline results
* `dossier/main.md` this document
* `dossier/proofs.md` complete proofs of Proposition 1, Theorems A, B, C, D, E
* `dossier/literature.md` verified statements, versions, URLs
* `dossier/experiments.md` script by script description and exact commands
* `experiments/lib.py`, `experiments/exact_examples.py`, `experiments/random_numerics.py`,
  `experiments/periodic_and_line.py`, `experiments/line_digraph_transfer.py`,
  `experiments/period_check.py`, `experiments/hypergraph_nb_trivial.py`
* `raw/exact_examples.json`, `raw/random_numerics.json`, `raw/random_summary.txt`,
  `raw/periodic_and_line.json`, `raw/line_digraph_transfer.json`, `raw/period_check.json`,
  `raw/hypergraph_nb_trivial.json`
* `papers/parzanchevski.pdf`, `papers/parzanchevski.txt` (downloaded primary source, text extract)

Reproduce with, from the member directory:

```
python3 experiments/exact_examples.py
python3 experiments/random_numerics.py
python3 experiments/periodic_and_line.py
python3 experiments/line_digraph_transfer.py
python3 experiments/period_check.py
python3 experiments/hypergraph_nb_trivial.py
```

## 12. Corrections made after the first review

The first submission was rejected with five concrete corrections. All five are accepted and fixed
here. This section records what changed, so a reader can see which statements in revision 1 were
wrong.

**C1, period of cyclic covers (fatal).** Revision 1 claimed that $P_m\otimes A_{D_0}$ has period $m$
because $P_m$ acts freely by automorphisms. False. Proposition 6 of `proofs.md` now computes the
peripheral spectrum: the moduli-$k$ eigenvalues of the cover are $k$ times the
$\operatorname{lcm}(m,m_0)$-th roots of unity, each with multiplicity $\gcd(m,m_0)$, where $m_0$ is
the period of the base. So the cover has period $\operatorname{lcm}(m,m_0)$ and is strongly connected
only when $\gcd(m,m_0)=1$. Counterexample reproduced: $D_0=DL(K_{3,3})$ has period $2$ and
$P_3\otimes A_{D_0}$ has period $6$, not $3$ (`experiments/period_check.py`, `raw/period_check.json`).
Repair: Theorem C(ii) and Proposition 7 now start from an **aperiodic** base, which exists for every
$k$ because random $(k+1)$-regular graphs are aperiodic, connected and almost Ramanujan, and random
$k$-regular graphs are aperiodic almost surely. The same script verifies that $DL(K_4)$ (aperiodic)
gives period exactly $m$ and $\rho=\sqrt2$ for $m=1,2,3$, and that random cubic graphs give period
exactly $m$ with $\rho\approx2\sqrt2$ for $m=1,\dots,5$.

**C2, complex Ihara-Bass (fatal).** Revision 1 asserted $|\lambda|\le2\sqrt k\iff|\mu|=\sqrt k$ for
complex $\lambda$. False: $k=1$, $\lambda=2i$ gives roots $i(1\pm\sqrt2)$ with moduli
$\sqrt2\pm1$. Proposition 8 of `proofs.md` and Section 3.7 now state the real form only, which is what
the spectral application needs, and the counterexample is recorded explicitly.

**C3, singular values versus signed eigenvalues.** Revision 1 wrote the double-cover spectrum as
$\{\pm\sigma_i\}\cup\{0\}^{2n-2\operatorname{rank}A}$, which double counts the zero singular values,
and claimed $\sigma_2(A)=\lambda_2(G)$ for symmetric digraphs, which fails for $K_4$
($\sigma_2=1$, signed $\lambda_2=-1$). Proposition 1 of `proofs.md` and Section 3.1 now state the
multiset over the nonzero singular values only, and all statements about symmetric digraphs use
$\sigma_2(A)=\max_{j\ge2}|\lambda_j(A)|$, the second largest element of the absolute spectrum. Every
sharpness statement (Theorems A and B, Proposition 7) was rewritten accordingly. The intended
universal lower bound is unaffected.

**C4, closed walks on the tree.** Revision 1 asserted $N_t=(k-1)^t\mathrm{Cat}_t$. False at $t=1$,
$k=2$, where the true count is $2$. Proposition 9 of `proofs.md` now derives the count exactly:
$R=1/(1-kxF)$ with $F=1+(k-1)xF^2$, hence $N_1=k$ and $N_2=2k^2-k$, with asymptotic
$\Theta_k(t^{-3/2})(2\sqrt{k-1})^{2t}$ for $k\ge3$ and $\binom{2t}{t}$ for $k=2$. The exponent itself
depends on $k$, which sharpens the statement of the hardest missing estimate in Section 6.1.

**C5, one consistent Ramanujan convention.** Revision 1 used two conventions in different scripts,
and `experiments/exact_examples.py` marked $K_{3,3}$ and Heawood as not Ramanujan while the narrative
called every example Ramanujan. Section 4.4 now fixes a single definition (exclude peripheral
eigenvalues first, then require the bound), and the script is patched to use it, so the narrative and
the raw data agree. Also, Section 5.3 of Parzanchevski already records that line digraphs of
Ramanujan graphs are Ramanujan digraphs, so the novelty claim in Section 3.4 and Section 2 has been
narrowed to the sharp constant classification and the period bookkeeping.

**What survives unchanged.** Proposition 2 (peripheral spectrum), Proposition D and the
$d-\lambda_3$, $d-\lambda_4$ index rule, Theorem A, Theorem B, the real Joukowski correspondence, and
the open cells of Corollary 3.5. The open cells were re-examined after the corrections: the lower
bounds are unchanged, and the upper ends are now justified by aperiodic bases, so the table stands
with corrected justifications.
