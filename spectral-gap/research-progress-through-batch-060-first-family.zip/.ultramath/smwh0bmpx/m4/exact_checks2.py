"""Second exact-check pass: finite-ball kernel (corrected), high-precision root constants,
contact-order constant, and the >0-strictness of Phi on the exterior branch."""
import sympy as sp
from fractions import Fraction as F

LOG=[]
def rep(s=""):
    LOG.append(str(s)); print(s)

d, r, lam, eps = sp.symbols('d r lam eps', positive=True)

rep("="*78); rep("I'. exact rational finite-ball verification of K_adj (corrected)")
def K_trunc(dd, zz, R):
    s = F(1)/zz
    for _ in range(R):
        s = F(1)/(zz - (dd-1)*s)
    a = zz - (dd-1)*s
    return (2*a + 2)/(a*a - 1)          # 1^T S^{-1} 1 with S=[[a,-1],[-1,a]]
for dd, rr in [(3, F(2,5)), (4, F(2,7)), (5, F(1,3)), (3, F(1,2)), (6, F(1,4))]:
    zz = (dd-1)*rr + 1/rr
    Kinf = 2*rr/(1-rr)
    ratio_theory = (dd-1)*rr*rr
    rep("  d=%d, r=%s (z=%s), K_inf=2r/(1-r)=%s ; self-energy ratio (d-1)r^2=%s"
        % (dd, rr, zz, Kinf, float(ratio_theory)))
    prev=None
    for R in [1,2,3,4,6,8,10,12,14]:
        KR = K_trunc(dd, zz, R); err = KR-Kinf
        rep("     R=%2d K_R=%s  err=%s  ratio=%s" % (R, sp.N(KR,14), sp.N(err,6),
             "-" if prev is None else sp.N(err/prev,6)))
        prev=err

rep(); rep("="*78); rep("L. exact exterior root for d=3 (closed form) and its numerical value")
# P(r)=2r^3+r-1 ; Cardano
disc = sp.Rational(29,432)
rc = sp.Rational(1,4)
def _cr(x):
    x = sp.nsimplify(x)
    return sp.sign(x)*sp.Abs(x)**sp.Rational(1,3)     # REAL cube root
rstar = _cr(rc+sp.sqrt(disc)) + _cr(rc-sp.sqrt(disc))
rep("  r* = cbrt(1/4+sqrt(29/432)) + cbrt(1/4-sqrt(29/432))")
rep("  P(r*) = %s" % sp.simplify(2*rstar**3+rstar-1))
rep("  r* = %s" % sp.N(rstar, 20))
lamstar = sp.simplify(2*rstar + 1/rstar)
rep("  lam* = 2r*+1/r* = %s" % sp.N(lamstar, 20))
rep("  check r* also satisfies lam*^3-lam*^2-4lam*-4 = %s"
    % sp.N(lamstar**3 - lamstar**2 - 4*lamstar - 4, 20))
rep("  lam* - 2sqrt2 = %s   (root strictly inside (b,d))" % sp.N(lamstar-2*sp.sqrt(2), 12))
rep("  d - lam*       = %s" % sp.N(3-lamstar, 12))
rep("  Phi'(lam*)|_{d=3} = %s"
    % sp.N((1+2*rstar**2/((1-rstar)**2*(1-2*rstar**2))), 12))
rep("  also: 2+2r* = %s ; K_adj(lam*) = %s = lam* ? %s"
    % (sp.N(2+2*rstar, 12), sp.N(2*rstar/(1-rstar), 12),
       sp.N(2*rstar/(1-rstar) - lamstar, 15)))
# other two roots of the d=3 cubic
cub3 = sp.Poly(lam**3 - lam**2 - 4*lam - 4, lam)
rep("  all roots of lam^3-lam^2-4lam-4: %s" % [sp.N(t,12) for t in sp.nroots(cub3)])
rep("  (exactly one real root => the elimination has no genuine second exterior root)")

rep(); rep("="*78); rep("M. threshold as a function of the real degree; contact order at d_c")
Ks = lambda dd: 2/(sp.sqrt(dd-1)-1)
Phis = lambda dd: 2*sp.sqrt(dd-1) - Ks(dd)
dc = (5+sp.sqrt(5))/2
rep("  Phi(b(d);d) = 2sqrt(d-1) - 2/(sqrt(d-1)-1)")
rep("  Phi(b(d_c);d_c) = %s   [d_c=(5+sqrt5)/2=%s]" % (sp.simplify(Phis(dc)), sp.N(dc,14)))
dPhi = sp.simplify(sp.diff(Phis(d), d))
rep("  d/dd [Phi(b(d);d)] at d_c = %s = %s" % (dPhi.subs(d,dc), sp.N(dPhi.subs(d,dc),12)))
rep("  sign for d<d_c negative? Phi(b(3.5))=%s , Phi(b(3.7))=%s"
    % (sp.N(Phis(sp.Rational(7,2)),12), sp.N(Phis(sp.Rational(37,10)),12)))
# (the square-root edge coefficient and the contact constant are computed in
#  exact_checks3.py, section M', which uses the u=sqrt(eps) substitution)

rep(); rep("="*78); rep("N. arithmetic identities in exact integer/rational form for integer d")
for dd in range(3, 11):
    Kb = sp.nsimplify(sp.radsimp(2/(sp.sqrt(dd-1)-1)))
    rep("  d=%2d: K_adj(b) = %s = %s ; b = %s ; Phi_adj(b) = %s"
        % (dd, sp.radsimp(2/(sp.sqrt(dd-1)-1)), sp.N(2/(sp.sqrt(dd-1)-1), 10),
           sp.nsimplify(sp.radsimp(2*sp.sqrt(dd-1))), sp.N(Phis(dd), 10)))
rep("  threshold criterion Sigma_{s,t} r_b^rho > 2(d-2) becomes 2+2/sqrt(d-1) > 2(d-2)")
for dd in range(3, 9):
    lhs = 2+sp.Rational(2,1)/sp.sqrt(dd-1)
    rep("  d=%d: 2+2/sqrt(d-1) = %s  vs 2(d-2) = %d  -> %s"
        % (dd, sp.N(lhs,10), 2*(dd-2), "ROOT" if sp.N(lhs) > 2*(dd-2) else "no root"))

rep(); rep("="*78); rep("O. the d=3 root vs the separated-pair prediction (same Delta=2)")
rep("  separated pair (dist->inf), d=3, Delta=2: Delta=2 = 2(d-2) exactly (critical),")
rep("  so m2/batch050 give lambda_f = 2sqrt(d-1) = %s i.e. NO exterior root." % sp.N(2*sp.sqrt(2),12))
rep("  clustered adjacent pair, d=3: single exterior root lam* = %s in (b,d)." % sp.N(lamstar,12))
rep("  separation gap  lam* - b = %s" % sp.N(lamstar-2*sp.sqrt(2),12))
with open('out/exact_checks2.txt','w') as f: f.write("\n".join(LOG)+"\n")
