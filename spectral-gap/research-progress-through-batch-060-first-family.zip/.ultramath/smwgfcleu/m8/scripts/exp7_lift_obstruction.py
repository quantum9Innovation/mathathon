"""Two exact checks on 2-covers.

(1) The published existence theorem (Song-Fan-Miao Thm 1.6: every connected (d,r)-regular
    hypergraph has a RIGHT-SIDED Ramanujan 2-covering) predicts that some signing has
    top eigenvalue <= window top.  We verify this holds in every base we test.
(2) For d < k the Feng-Li operator of the cover has at least 2n-2m eigenvalues equal to -d,
    and the inherited part accounts for only n-rank(X_H) of them, so the NEW spectrum must
    contain -d.  We verify mult_{-d}(S) >= n - m.
"""
import itertools
import numpy as np
from hyp import fengli, spec, window, config_model_hypergraph, cyclic_interval_hypergraph, degrees
from exp6_two_lifts import setup, signed_matrix

rng = np.random.default_rng(999)


def scan(name, edges, n, max_all=9000, trials=300, seed=0):
    d = int(degrees(edges, n)[0])
    k = len(edges[0])
    A, X = fengli(edges, n)
    m = X.shape[1]
    r = np.linalg.matrix_rank(X.astype(float))
    lo, hi = window(d, k)
    inc, index, tree, free = setup(edges, n, rng)
    rank = len(free)
    total = 2 ** rank
    exhaustive = total <= max_all
    rng2 = np.random.default_rng(seed)
    it = itertools.product((0, 1), repeat=rank) if exhaustive else (
        [int(x) for x in rng2.integers(0, 2, size=rank)] for _ in range(trials))
    right = left = both = 0
    min_mult_negd = 10 ** 9
    tried = 0
    for bits in it:
        w = np.linalg.eigvalsh(signed_matrix(edges, n, inc, list(bits), free))
        tried += 1
        if w[-1] <= hi + 1e-9:
            right += 1
        if w[0] >= lo - 1e-9:
            left += 1
        if w[-1] <= hi + 1e-9 and w[0] >= lo - 1e-9:
            both += 1
        min_mult_negd = min(min_mult_negd, int(np.sum(np.abs(w + d) < 1e-8)))
    print(f"{name:34s} d={d} k={k} n={n:3d} m={m:3d} rank(X)={r:3d} {'ALL' if exhaustive else 'rnd'} "
          f"tried={tried:5d} | right-sided ok: {right:5d} | left-sided ok: {left:5d} | "
          f"both: {both:5d} | n-m={n-m:3d} | min mult_S(-d)={min_mult_negd}", flush=True)


print("=== right-sided Ramanujan 2-covers (existence is a published theorem) and the -d plateau ===")
scan("cyclic interval H(6,3)", *cyclic_interval_hypergraph(6, 3), seed=1)
scan("cyclic interval H(9,3)", *cyclic_interval_hypergraph(9, 3), seed=2)
scan("cyclic interval H(12,3)", *cyclic_interval_hypergraph(12, 3), seed=3)
for (d, k, n, s) in ((2, 3, 12, 5), (3, 4, 12, 9), (2, 4, 16, 11), (2, 5, 20, 12), (3, 3, 12, 6)):
    E = config_model_hypergraph(n, d, k, np.random.default_rng(s))
    scan(f"random ({d},{k})-regular", E, n, seed=10 + s)
