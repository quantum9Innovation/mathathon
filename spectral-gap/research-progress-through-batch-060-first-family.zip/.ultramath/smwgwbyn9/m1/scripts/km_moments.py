"""Exact Kesten-McKay moments = closed-walk counts from the root of the d-regular tree.
   Recursion: a_j = # walks length j from v to v ; b_j = # walks length j from v to a fixed nbhd.
   a_j = d*b_{j-1} ;  b_j = a_{j-1} + (d-1)*b_{j-1} ;  a_0=1, b_0=0.  (exact integers)"""
def km_moments(d, K):
    a=[0]*(K+1); b=[0]*(K+1)
    a[0]=1; b[0]=0
    for j in range(1,K+1):
        a[j]=d*b[j-1]
        b[j]=a[j-1]+(d-1)*b[j-1]
    return a
for d in (3,4,5):
    print("d =",d,"  m_0..m_12 =", km_moments(d,12))
