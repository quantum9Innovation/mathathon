# m4 / direction d1 — summary (batch 060, adjacent-pair clustered attachment)

## What is proved (self-contained, in `NOTE.md`)

For $T=\{c,u_n\}$, $u_n$ the least-labelled neighbour of a fixed label $c$, $G_n$ uniform simple
$d$-regular, $G'_n=G_n+$ one vertex adjacent to $c,u_n$:

* **Theorem A (resolvent limit, with the pattern off-diagonal terms kept).**
  $\mathbf 1_T^\top(A-\lambda I)^{-1}\mathbf 1_T\to-K_{\rm adj}(\lambda)=\frac{2r}{1-r}
  =G_d(2+2r)$ uniformly on compacts of $(2\sqrt{d-1},d)\cup(d,\infty)$, in probability
  ($\ge1-Cn^{-3/4}$), with an explicit geometric error bound. The exact finite-$n$ splitting and
  the corrected rank-one identity are displayed.
* **Theorem B (complete root law).** $\Phi_{\rm adj}=\lambda-\frac{2r}{1-r}$ is strictly increasing
  on $(2\sqrt{d-1},\infty)$ with $\Phi'_{\rm adj}=1+\frac{2r^2}{(1-r)^2(1-(d-1)r^2)}>0$; hence at
  most one exterior root and **no repeated root ever** (the simple-root premise is proved, not
  imported). $K_{\rm adj}(b)=\frac{2}{\sqrt{d-1}-1}$,
  $\Phi_{\rm adj}(b)=\frac{2(d-\sqrt{d-1}-2)}{\sqrt{d-1}-1}$, and
  $\Phi_{\rm adj}(b)<0\iff d<\frac{5+\sqrt5}{2}$: **only $d=3$ has an exterior root**, namely
  $\lambda_\star=2.875129794\ldots\in(2\sqrt2,3)$, simple, $\Phi'_{\rm adj}(\lambda_\star)=14.579$.
  For $d\ge4$ no exterior root (the cubic $\lambda^3-(d-2)\lambda^2-4\lambda-4$'s real root is
  spurious: it lies on the *large* branch). $\Phi_{\rm adj}(d)=d-\frac2{d-2}\ne0$ for integer $d$
  (only $1\pm\sqrt3$ would work), so the host Perron point is never a pattern-law root. Contact
  order at the bulk edge is $1/2$: $\lambda_\star-b\sim0.11271(d-d_c)^2$, $d_c=3.618\ldots$
* **Theorem C (limiting eigenvalues).** $\lambda_1(G'_n)\to d$ and
  $\lambda_2(G'_n)\to\lambda_\star$ ($d=3$) or $2\sqrt{d-1}$ ($d\ge4$), i.e.
  $\lambda_1\to\max(d,\lambda_{\rm adj})$, $\lambda_2\to\min(d,\lambda_{\rm adj})$, with
  $d\notin\sigma(A^+)$ and the interlacing/bracketing bookkeeping done without assuming that the
  host eigenvector is loaded. **Sharp separation from the separated model:** the same $\Delta=2$
  at $d=3$ gives no exterior root there ($\lambda_2\to2\sqrt2$), so clustering moves $\lambda_2$
  by $0.0467$.
* **Theorem D ($1/n$ at the Perron point).** $n(\lambda_1(G'_n)-d)\to4/\Phi_{\rm adj}(d)
  =\frac{4(d-2)}{d^2-2d-2}$ — derived, not obtained by substituting $\Delta$ in batch 050's
  constant (which would give $12/5$ vs the true $4$ at $d=3$, $16/13$ vs $4/3$ at $d=4$).

## Two corrections to the frozen material (old files untouched)

1. `ERRATUM-060-target-edge-value.md` (also in `out/exact_checks.txt` §D): the target file's
   $K_{\rm adj}(b)=2/(1-1/\sqrt{d-1})$ is too large by exactly $\sqrt{d-1}$; the truth is
   $2/(\sqrt{d-1}-1)$. This flips the $d=4$ conclusion: with the printed value $d=3,4$ would have
   defect roots and $d=5$ would be exactly critical; in truth only $d=3$ does.
2. `ERRATUM-050-rank-one-resolvent-identity.md`: batch 050's / m2's
   $(A-\lambda I)^{-1}=\frac{P}{d-\lambda}-\sum_k(A')^k/\lambda^{k+1}$ is missing $+\frac{P}{\lambda}$;
   exactly refuted in rational arithmetic (error $=|T|^2/(n\lambda)$, $26\,000\times$ a rigorous
   tail bound). No batch-050 limit theorem changes (the term is $O(1/n)$); the identity itself
   does.

## Files

| file | content |
|---|---|
| `NOTE.md` | the theorem and the full proofs (primary deliverable) |
| `SUMMARY.md` | this file |
| `ERRATUM-060-target-edge-value.md` | correction of the target's bulk-edge kernel value |
| `ERRATUM-050-rank-one-resolvent-identity.md` | correction of the frozen rank-one identity |
| `exact_checks.py`, `exact_checks2.py`, `exact_checks3.py` | sympy: kernel, Schur complement, poles, threshold, monotonicity, Perron point, contact order, cubic/spurious branch |
| `check_rank_one_identity.py` | exact rational test of the (repaired) rank-one identity with a rigorous tail bound, Petersen graph |
| `numerics.py`, `numerics2.py` | exactly-uniform sampler (pairing conditioned on simplicity), direct eigensolvers, secular zeros, seed-averaged trends |
| `out/*.txt`, `out/*.json` | raw logs and raw numbers (kept) |

Reproduce: `bash run_all.sh`.

## Verification status

* Exact (symbolic/rational, no floating point in any claimed identity): kernel
  $2r/(1-r)=G_d(2+2r)$, $2\times2$ Schur complement, pole set $\{\pm d\}$ (large branch only),
  $K_{\rm adj}(b)$, threshold, $\Phi'_{\rm adj}$ identity, $\Phi_{\rm adj}(d)\ne0$, Cardano root,
  contact constant, spurious branch at $d=4$, finite-ball rational convergence, secular identity
  on Petersen, repaired rank-one identity.
* Numerics (corroboration only): secular zero $=$ eigensolver $\lambda_2(G')$ to $\le1.3\cdot10^{-13}$
  in all 30 runs; $d=3,n=8000$: $\lambda_2(G')=2.874880\pm0.000929$ vs $\lambda_\star=2.875130$
  (separated prediction $2.828427$ is 50 sd away); $d=4$: $3.463571\pm0.004573$ vs $2\sqrt3$;
  $n(\lambda_1-d)=3.9754$ ($d=3$) vs $4$, $1.3317$ ($d=4$) vs $4/3$.

## Not done / remaining obstructions

1. Only this one pattern is completed. For a general bounded pattern the skeleton of §3–§4 carries
   over, but the two pattern-specific inputs are missing: the exact kernel
   $K_T=G_d\sum_{s,t}r^{\rho(s,t)}$ (for $T=N(c)$: direction d2) and the root analysis of
   $\Phi_T=\lambda-K_T$, where $\Phi_T$ need not be monotone and $\Phi_T(d)=0$ *can* occur
   (a genuine branch that must not be excluded).
2. No uniformity in $d$; nothing in the bulk $|\lambda|\le2\sqrt{d-1}$; no rate better than
   $n^{-\gamma}$ with small $\gamma$ near the edge.
3. No Lean formalisation is claimed; all exact checks are sympy/`fractions`.
