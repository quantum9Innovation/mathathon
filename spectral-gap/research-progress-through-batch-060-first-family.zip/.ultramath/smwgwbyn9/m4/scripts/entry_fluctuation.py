import numpy as np, json, sys, collections
import scipy.sparse as sp
from scipy.sparse.linalg import cg

def reg_config_sparse(n, d, rng):
    while True:
        stubs = np.repeat(np.arange(n), d)
        s = stubs[rng.permutation(stubs.size)]
        a, b = s[0::2], s[1::2]
        if np.any(a == b): continue
        e = np.sort(np.stack([a,b],1),1)
        if np.unique(e, axis=0).shape[0] != e.shape[0]: continue
        A = sp.coo_matrix((np.ones(len(a)), (a,b)), shape=(n,n)).tocsr()
        return (A + A.T).tocsr()

def Gamma(A, n, d, T):
    """Gamma_n(d) = 1_T^T L^+ 1_T  via CG on (dI-A) restricted to 1^perp."""
    r = np.zeros(n); r[list(T)] = 1.0; r -= len(T)/n
    M = (d*sp.identity(n, format='csr') - A)
    y, info = cg(M, r, rtol=1e-13, atol=0.0, maxiter=5000)
    assert info == 0, info
    return float(r @ y)

rows=[]
for n in (1000, 4000, 16000, 64000):
    for s in range(8):
        rng = np.random.default_rng(7000*n + s)
        A = reg_config_sparse(n, 3, rng)
        T0 = [0]                                    # fixed vertex, Delta=1
        perm = rng.permutation(n); S = [int(v) for v in perm[:16]]
        g_fixed = Gamma(A, n, 3, T0)
        g_avg   = float(np.mean([Gamma(A, n, 3, [u]) for u in S]))
        rows.append(dict(n=n, seed=7000*n+s, fixed0=g_fixed, avg16=g_avg))
        print(json.dumps({k:(round(v,8) if isinstance(v,float) else v) for k,v in rows[-1].items()}), flush=True)
print("---- d=3, Delta=1, G_d(d)=2/3=%.6f ; 10 graphs per n ----" % (2/3), flush=True)
by = collections.defaultdict(list)
for r in rows: by[r['n']].append(r)
for n in sorted(by):
    f = np.array([r['fixed0'] for r in by[n]]); a = np.array([r['avg16'] for r in by[n]])
    print("n=%7d fixed0: mean=%.6f sd=%.6f | avg16: mean=%.6f sd=%.6f" % (n,f.mean(),f.std(ddof=1),a.mean(),a.std(ddof=1)), flush=True)
