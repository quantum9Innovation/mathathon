# Erratum: the bulk-edge value of $K_{\rm adj}$ in `results/060-clustered-attachment-target.md`

**Old file left untouched.** This is a separate erratum, as required by
`results/spectral-research/batch-060/FROZEN-SEPARATED-CASE.md`.

## Statement in the target file

> At the bulk edge $b=2\sqrt{d-1}$, $K_{\rm adj}(b)=\dfrac{2}{1-1/\sqrt{d-1}}$. This already
> distinguishes $d=3,4$ from larger-degree cases and must not be masked by an asymptotic
> expansion that loses the branch point.

## Correct value

$$K_{\rm adj}(b)=G_d(b)\big(2+2r_b\big)=\frac{2r_b}{1-r_b}=\frac{2}{\sqrt{d-1}-1},\qquad r_b=\frac1{\sqrt{d-1}}.$$
The target's value is $\frac{2}{1-r_b}$, i.e. it drops a factor $r_b$: the two differ by exactly
$\sqrt{d-1}=1/r_b$. (Symbolically verified: sympy returns the ratio
$\big(2/(1-1/\sqrt{d-1})\big)/\big(2r_b/(1-r_b)\big)=\sqrt{d-1}$.)

## Why it is not cosmetic

$\Phi_{\rm adj}(b)=b-K_{\rm adj}(b)=\dfrac{2(d-\sqrt{d-1}-2)}{\sqrt{d-1}-1}$, which is negative iff
$s^2-s-1<0$ with $s=\sqrt{d-1}$, i.e. iff $d<d_c=\frac{5+\sqrt5}{2}=3.618034$. Hence:

| $d$ | correct $K_{\rm adj}(b)$ | correct $\Phi_{\rm adj}(b)$ | target's $\Phi_{\rm adj}(b)$ | exterior root? (correct / target's formula) |
|---|---|---|---|---|
| 3 | 4.828427 | $-2.000000$ | $-4.000000$ | yes / yes |
| 4 | 2.732051 | $+0.732051$ | $-1.267949$ | **no** / yes |
| 5 | 2.000000 | $+2.000000$ | $0.000000$ | **no** / critical |
| 6 | 1.618034 | $+2.854102$ | $+0.854102$ | no / no |

So with the printed value the conclusion would be "d=3,4 have defect roots, d=5 is exactly
critical"; the truth is "only d=3". The threshold statement is nevertheless recoverable in the
intended form: $K_{\rm adj}(b)>b$ (a root) iff $\sum_{s,t}r_b^{\rho(s,t)}=2+2/\sqrt{d-1}>2(d-2)$
(the m6 §4.1(c) pattern criterion), and that criterion is also satisfied only at $d=3$ — the two
correct routes agree, and both disagree with the printed number. The contact at the critical real
degree $d_c$ is of order $1/2$ in $\varepsilon=\lambda-b$, so the root displacement from the edge
is quadratic in $d-d_c$ (see `NOTE.md` §5.4).

## Independent numerical confirmation

Exact rational truncated-ball evaluation of the pair Green function
(`exact_checks.py` §I / `out/exact_checks.txt`, `fractions.Fraction`, self-energy recursion)
converges to $2r/(1-r)$, and at $d=4,b=3.4641016$ gives $2.7320508$ to $10^{-10}$, i.e. the
printed $4.7320508$ is excluded. Direct eigensolver runs at $d=4$ show $\lambda_2(G')\to2\sqrt3=
3.4641016$ with no defect eigenvalue, as the corrected value predicts.
