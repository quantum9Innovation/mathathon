# Two trivial values, not one

## The exact trivial spectrum of the Feng-Li operator of a regular uniform hypergraph, and what it does to the hypergraph Ramanujan threshold

This is a research dossier on the following question. For a `k`-uniform `d`-regular hypergraph
with `k >= 3`, what are the eigenvalues of the Feng-Li adjacency operator that are forced by
structure alone, at which positions in the ordered spectrum do they sit, and which of the
commonly quoted gap quantities (`d - lambda_2`, `d - lambda_3`, `d - lambda_4`, `d(k-1) - lambda_2`,
`lambda_2 - (k-2)`) are therefore the right objects?

The short answer, proved below, is that the forced ("trivial") spectrum has **one value at the top
and a plateau at the bottom**. The top value is `d(k-1)` and it is simple on a connected
hypergraph, so the first genuinely nontrivial eigenvalue is `lambda_2` and not `lambda_3`. The
bottom value is `-d`, and its multiplicity is exactly `n - rank(X)` where `X` is the incidence
matrix, so it can be as large as `n-1` or as large as `k-1`. Any statement of the form
"`d - lambda_3`" or "`d - lambda_4`" is therefore either measuring a shift of a pinned value or
comparing against a constant that is not an eigenvalue.

## Evidence labels

Every substantive claim below carries one of five labels.

* **[LIT]** a literature statement that I have checked against the primary source or against a
  verbatim quotation of it in a source I did check, with the URL and version recorded in
  `02-literature.md`.
* **[CALC]** an exact calculation (symbolic or exact integer) that I performed. The script and its
  raw output are named.
* **[PROOF]** a mathematical proof supplied here, written out in `03-exact-theorems.md`.
* **[NUM]** a numerical experiment. Script and raw output named in `05-experiments.md`.
* **[CONJ]** a conjecture or speculation.

Numerics never certify an asymptotic statement. The three asymptotic statements in this dossier
(`lambda_2` of a random regular hypergraph tends to the Li-Sole window top, the `Theta(n^-2)` gap of
the cyclic interval family, and the `-d` plateau under covers) are each either [LIT] plus [PROOF],
or [PROOF] with [NUM] as a check.

## Headline results

1. **The Gram identity and the floor [PROOF, T1].** For every `k`-uniform hypergraph with
   incidence matrix `X` and Feng-Li operator `A_H` one has `A_H + d I = X X^T` when `H` is
   `d`-regular. Hence `lambda_min(A_H) >= -d` always, and `-d` occurs with multiplicity exactly
   `n - rank(X)`.
2. **Two independent sources of `-d` [PROOF, T5].** Rectangularity (`d < k` gives `n - rank >= n - m`)
   and strong `k`-partiteness (`k` classes, every edge meets every class once, gives `n - rank >= k-1`).
   The second source is not the first one, and it survives `d >= k`.
3. **The complete `k`-partite hypergraph has a fully determined spectrum [PROOF, T4].**
   For part size `s`, `d = s^(k-1)`, `n = ks`:
   `spec(A_H) = {d(k-1)} union {0}^(n-k) union {-d}^(k-1)`. Every eigenvalue is trivial.
4. **Three exact square identities [PROOF, T6].** With `t = sqrt((d-1)(k-1))`,
   `d(k-1) - (k-2+2t) = (t-1)^2` and `(k-2-2t) - (-d) = (sqrt(d-1)-sqrt(k-1))^2`.
   These are the exact sizes of the Perron gap to the Ramanujan window and of the `-d` deficit.
5. **The naive tree benchmark is false for every `k >= 3` [PROOF, T7].** The quantity
   `2 sqrt((k-1)d - 1)`, which is what a locally tree-like `(k-1)d`-regular graph would give, is
   strictly smaller than the true edge `k-2+2 sqrt((d-1)(k-1))` for every `d >= 2` and `k >= 3`,
   and equal to it exactly when `k = 2`. The exact deficit is displayed. Consequently no family of
   `(d,k)`-regular hypergraphs can satisfy `lambda_2 <= 2 sqrt((k-1)d-1) + o(1)`. [NUM] confirms
   this in 32 random instances with margins between 0.34 and 1.69.
6. **The Li-Sole Ramanujan definition fails on a natural family [PROOF, T9].** A `k`-partite
   `(d,k)`-regular hypergraph with `d > k` carries `-d` with multiplicity at least `k-1`, and
   `-d` lies below the window bottom by `(sqrt(d-1)-sqrt(k-1))^2 > 0`. So it is not Ramanujan in
   the two-sided sense, for every `d > k`. The smallest witness is the complete 4-partite
   4-uniform hypergraph with part size 2, `spec = {24, 0,0,0,0, -8,-8,-8}`.
7. **For `d = k` the left-sided condition is automatic [PROOF, T10].** The window bottom equals
   `-d` exactly when `d = k`, and `lambda_min >= -d` always, so for `d = k` "right-sided Ramanujan"
   and "Ramanujan" coincide. Combined with the published existence of right-sided Ramanujan
   2-coverings this gives two-sided Ramanujan 2-coverings for every connected `(d,d)`-regular
   hypergraph.
8. **For `d < k` no regular cover is Ramanujan, of any degree [PROOF, T12].** The `-d` plateau of
   the cover has at least `2n(1-d/k)` members and only `n(1-d/k)` of them are inherited, so at
   least `n(1-d/k)` new eigenvalues equal `-d`. Exhaustive enumeration of all 2-covers of three
   bases confirms it and the count matches exactly. [NUM]
9. **A periodic family has a `Theta(n^-2)` gap [PROOF, T11].** For the cyclic interval hypergraph
   on `Z_q` with edges `{i,...,i+k-1}`, the symbol is exactly the Fejer kernel minus `k`,
   `p(theta) = |sin(k theta/2)/sin(theta/2)|^2 - k`, the spectrum is `{p(2 pi m/q)}` and
   `d(k-1) - lambda_2 = pi^2 k^2 (k^2-1)/(3 q^2) - 4 pi^4 S4/(3 q^4) + O(q^-6)` with
   `S4 = k^2(k-1)(k+1)(2k^2-3)/60`. So "almost regular" periodic formats are not expanders in the
   absolute sense, whatever their local regularity.
10. **The relativized threshold cannot improve on Alon-Boppana for regular bases [PROOF, T13].**
    The non-backtracking matrix of a connected `(d,k)`-biregular incidence structure has Perron
    value exactly `sqrt((d-1)(k-1))`, determined by the degrees alone. So in the random-lift
    framework the base's own threshold already equals the universal-cover threshold, and the only
    thing a "relative Ramanujan" theorem for regular hypergraphs can improve is the probability
    exponent.

11. **A signed Gram identity for covers [PROOF, T15].** The new part `S` of a 2-cover satisfies
    `S + d I = Xtilde Xtilde^T` with `Xtilde[v,e] = X[v,e] (-1)^(volt[v,e])`, so no signing can push
    the new spectrum below `-d`. Combined with T10 and T12 this gives a clean dichotomy: for `d = k`
    the left-sided Ramanujan condition is automatic for every cover, for `d < k` it fails for every
    cover, and only for `d > k` is it a genuine condition.

## Files

| file | content |
| --- | --- |
| `01-model-and-normalisation.md` | model, conventions, ordering, the five normalisations in use, the index dictionary |
| `02-literature.md` | verified literature, URLs, versions, exact statements, what I could not find |
| `03-exact-theorems.md` | T1 to T15 with proofs, plus a sharpness summary |
| `04-open-directions.md` | two precise open targets, proof strategies, the single hardest missing lemma |
| `05-experiments.md` | every computation, its script, its raw output, what it does and does not show |
| `06-common-ground.md` | relation to the four local dossiers and to the other swarm directions |
| `scripts/` | all Python, runnable from that directory |
| `outputs/` | raw outputs, JSON summaries, one figure |
| `lit/` | downloaded PDFs and extracted text of the sources I actually read |

## What this dossier does not claim

It does not claim that the sharp threshold `k-2+2 sqrt((d-1)(k-1))` for random regular hypergraphs
is new. It is not. It is due to Dumitriu and Zhu, and the matching Alon-Boppana lower bound is due
to Feng and Li. Section `02-literature.md` records the exact statements and shows that the
threshold follows in three lines from the biregular bipartite theorem of Brito, Dumitriu and
Decker Harris through the Gram identity T1, which is exactly the route Dumitriu and Zhu take.

It does not claim that the `-d` eigenvalue is new. It is in the literature under the name "obvious
eigenvalue", in the rectangular case `d < r`. What is new here is the exact rank criterion that
unifies the rectangular and the partite sources, the consequences T9, T10, T12 for the definitions
and for covers, the exact comparison with the naive tree benchmark, and the indexing analysis T8.

It does not claim any formal verification. No proof assistant was run on any statement here.
