"""Exhaustive test: is there a 2-cover of a (d,k)-regular hypergraph that is Ramanujan?

A Z_2-cover of H is the same thing as a Z_2-voltage assignment on the incidences of the
incidence graph Inc(H).  Gauge fixing along a spanning tree of Inc(H) leaves
    rank = |incidences| - |V(Inc H)| + 1 = nd - (n+m) + 1
free bits, so there are exactly 2^rank covers up to gauge.  For a signing volt, the cover
splits under the sheet-swap involution, the symmetric part reproduces the base spectrum,
and the antisymmetric ('new') part is the incidence-signed hypergraph

    S_uv = sum_{e superset {u,v}} (-1)^{volt[u,e] + volt[v,e]},   S_uu = 0.

So the new spectrum is spec(S).  Different bases are treated below either exhaustively
(2^rank small) or by random sampling (2^rank large).
"""
import itertools
import numpy as np
from hyp import fengli, spec, window, config_model_hypergraph, cyclic_interval_hypergraph, degrees


def setup(edges, n, rng):
    """Return the incidence list, a spanning tree of Inc(H), and the free incidences."""
    inc = [(v, j) for j, e in enumerate(edges) for v in e]
    index = {pe: i for i, pe in enumerate(inc)}
    nv, ne = n, len(edges)
    adj = [[] for _ in range(nv + ne)]
    for (v, j) in inc:
        adj[v].append((nv + j, (v, j)))
        adj[nv + j].append((v, (v, j)))
    tree = set()
    seen = [False] * (nv + ne)
    stack = [0]
    seen[0] = True
    while stack:
        x = stack.pop()
        for (y, pe) in adj[x]:
            if not seen[y]:
                seen[y] = True
                tree.add(pe)
                stack.append(y)
    assert all(seen), "incidence graph not connected"
    free = [pe for pe in inc if pe not in tree]
    return inc, index, tree, free


def signed_matrix(edges, n, inc, free_bits, free):
    volt = {}
    for pe in inc:
        volt[pe] = 0
    for pe, b in zip(free, free_bits):
        volt[pe] = b
    S = np.zeros((n, n))
    for j, e in enumerate(edges):
        sg = {v: 1.0 if volt[(v, j)] == 0 else -1.0 for v in e}
        for a in e:
            for b in e:
                if a != b:
                    S[a, b] += sg[a] * sg[b]
    return S


def build_cover(edges, n, inc, free_bits, free):
    volt = {pe: 0 for pe in inc}
    for pe, b in zip(free, free_bits):
        volt[pe] = b
    out = []
    for j, e in enumerate(edges):
        for s in (0, 1):
            out.append(tuple(sorted(int(v) + n * ((s + volt[(v, j)]) % 2) for v in e)))
    return out


def analyse(name, edges, n, max_exhaust=20000, trials=300, seed=0):
    rng = np.random.default_rng(seed)
    d = int(degrees(edges, n)[0])
    k = len(edges[0])
    assert len(set(degrees(edges, n).tolist())) == 1
    A, X = fengli(edges, n)
    wbase = spec(A)
    lo, hi = window(d, k)
    inc, index, tree, free = setup(edges, n, rng)
    rank = len(free)
    total = 2 ** rank
    exhaustive = total <= max_exhaust

    # sanity: the empty signing reproduces the base operator
    S0 = signed_matrix(edges, n, inc, [0] * rank, free)
    assert np.abs(S0 - A).max() < 1e-12, "empty signing is not the base operator"
    # sanity: spec(cover) = spec(base) + spec(S) for a random signing
    bits = [int(x) for x in rng.integers(0, 2, size=rank)]
    cov = build_cover(edges, n, inc, bits, free)
    Ac, _ = fengli(cov, 2 * n)
    joint = np.sort(np.concatenate([wbase, spec(signed_matrix(edges, n, inc, bits, free))]))
    assert np.abs(np.sort(spec(Ac)) - joint).max() < 1e-8, "old/new splitting failed"

    best_top = np.inf
    best_bot = -np.inf
    both = 0
    tried = 0
    if exhaustive:
        it = itertools.product((0, 1), repeat=rank)
    else:
        it = ([int(x) for x in rng.integers(0, 2, size=rank)] for _ in range(trials))
    for bits in it:
        w = np.linalg.eigvalsh(signed_matrix(edges, n, inc, list(bits), free))
        tried += 1
        top, bot = w[-1], w[0]
        best_top = min(best_top, top)
        best_bot = max(best_bot, bot)
        if top <= hi + 1e-9 and bot >= lo - 1e-9:
            both += 1
    print(f"{name:36s} d={d} k={k} n={n:3d} 2^rank={total:>9d} "
          f"{'ALL' if exhaustive else 'rand':>4s} tried={tried:>6d}  "
          f"window=({lo:8.4f},{hi:8.4f})  min top={best_top:8.4f}  max bottom={best_bot:8.4f}  "
          f"covers inside window: {both}", flush=True)
    return dict(name=name, d=d, k=k, n=n, rank=rank, total=total, exhaustive=exhaustive,
                tried=tried, lo=float(lo), hi=float(hi), best_top=float(best_top),
                best_bot=float(best_bot), both=both)


res = []
print("=== can a 2-cover of a (d,k)-regular hypergraph be Ramanujan? ===")
res.append(analyse("cyclic interval H(6,3) (3-partite)", *cyclic_interval_hypergraph(6, 3), seed=1))
res.append(analyse("cyclic interval H(9,3) (3-partite)", *cyclic_interval_hypergraph(9, 3), seed=2))
res.append(analyse("cyclic interval H(8,4) (4-partite)", *cyclic_interval_hypergraph(8, 4), seed=3))
res.append(analyse("cyclic interval H(12,3) (3-partite)", *cyclic_interval_hypergraph(12, 3), max_exhaust=5000, seed=4))
for (d, k, n, s) in ((2, 3, 12, 5), (3, 3, 12, 6), (3, 3, 9, 7), (4, 3, 12, 8), (3, 4, 12, 9)):
    E = config_model_hypergraph(n, d, k, np.random.default_rng(s))
    res.append(analyse(f"random ({d},{k})-regular", E, n, max_exhaust=9000, seed=10 + s))

import json
json.dump(res, open("../outputs/exp6_two_lifts.json", "w"), indent=1)
print("\nIf 'covers inside window' is 0 and the search was exhaustive, then no 2-cover of that")
print("base is Ramanujan in the Li-Sole sense (the left-sided bound fails or the top fails).")
