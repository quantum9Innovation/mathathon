# Authoritative claim ledger for the current spectral audit

Integrator: the problem 21 manuscript session, with its owned board in [manuscript-round-01](manuscript-round-01/TEAM_BOARD.md). Reconciled on November 14, 2026. The separate problem 138 round retains its own ownership.

This ledger governs the new work outside the imported snapshot. Historical acceptance labels inside snapshot remain historical evidence. A reviewed proof is not an external refereeing or formal-verification certificate.

| ID | Exact claim and hypotheses | Mathematical status | Dependencies and proof | Review and limits |
| --- | --- | --- | --- | --- |
| SG-01 | The centered diagonal moments of a uniform permutation satisfy the positive row-sum recurrence in Proposition 3.3 | proved, sourced | Collins and Nagatsu, published equation 16 and its proof, also reconstructed in sharp-scaling-v2.md | Primary source checked. This recurrence and its normalized form are prior results |
| SG-02 | For arbitrary multiplicities and independent permutation colors, with a distinct cells, h consistent centered singletons, b inconsistent centered singletons and 2<=a<=sqrt(n), the mixed product has absolute expectation at most e times 2^b n^(-a) times beta^h, where beta=sqrt(a-1)/(sqrt(n)-sqrt(a-1)) | proved | SG-01 extended to a prescribed compatible set, affine indicator expansion, [permutation-proof-v2.md](audit-2026-11-14/permutation-proof-v2.md) | Integrator reconstructed both revisions. The one-cell case and the larger-a prefactor are stated separately. Later trace estimates are outside this claim |
| SG-03 | The unrestricted conditional assertion in Bordenave equation 62 fails for the displayed shared-row and disjoint-cell examples | proved counterexamples | [source-findings-v2.md](audit-2026-11-14/source-findings-v2.md), [independent enumeration](integration-audit-2026-11-14/source-counterexamples.json) | Two independent reconstructions. Proposition 28 itself is not refuted. SG-02 supplies a replacement proof |
| SG-04 | For 2<=k<=N, R_k-1>=2k^3/(27N), and R_k<=exp(3k^3/N) if 2k<=N. Along N tending to infinity, R_k tends to one exactly when k^3/N tends to zero, and stays bounded exactly when k^3/N stays bounded | proved | SG-01 and the explicitly defined parity-dependent leading terms, [sharp-scaling-v2.md](audit-2026-11-14/sharp-scaling-v2.md) | [Independent cross-review](cross-review-2026-11-14/by-algebra.md) checks revision 1. Integrator checked revision 2's bounded-comparability corollary and attribution changes. No literature-priority certificate |
| SG-05 | For fixed T, M>=1, N>=4M+2 and M^3/N<=T, the even and odd ratios have the hyperbolic-function approximations C1 and C2 with uniform error at most C_T M^2/N. If k^3/N tends to c, the parity limits are cosh(2 sqrt(c)/3) and sinh(2 sqrt(c)/3)/(2 sqrt(c)/3). For growing k with k^3/N tending to zero, the relative excess constants are 2/9 and 2/27 | proved | SG-01, the parity-dependent leading terms, and the uniform residual and stability argument in [critical-scale-v1.md](audit-2026-11-14/critical-scale-v1.md) | [Independent review](cross-review-2026-11-14/critical-scale-by-algebra.md) and [integrator review](integration-audit-2026-11-14/CRITICAL_SCALE_REVIEW.md). The odd quotient is one at c=0. No claim for unbounded critical parameter |

## Reviewed revisions and evidence

The initial audited results remain attached to their original revisions. The manuscript refinements below add separate claims and reviews.

## Manuscript-round refinements

The prior SG-01 through SG-05 statements and frozen evidence remain valid. The following additions strengthen them without rewriting the accepted input files.

| ID | Exact claim and hypotheses | Mathematical status | Dependencies and proof | Review and limits |
| --- | --- | --- | --- | --- |
| SG-06 | For the mixed product of SG-02, 2 <= a <= n, the bound is 2^b n^(-a) beta^h F_n(a-h), where F_n(q)=n^q/(n)_q. When a^2 <= n, the universal prefactor is sqrt(e), and no smaller universal constant works for the stated arbitrary mixed-product class | proved | SG-01 extended to compatible conditioning, affine coefficient inequalities, factorial merging. [Frozen proof v3](manuscript-round-01/proof/permutation-proof-v3.md) | [Integrator reconstruction](manuscript-round-01/reviews/mixed-v3-integrator-review.md). The singleton factor itself is not claimed optimal. The larger graph proof remains separate |
| SG-07 | Put K=2 floor(k/2), lambda=(2/3)sqrt(K^3/N), and H_k=cosh(lambda) for even k or sinh(lambda)/lambda for odd k. For 2 <= k <= N/4, (1-4k^2/(3N))H_k <= R_k <= exp(4k^2/N)H_k. If 4k^2 <= N, the logarithmic relative error lies between -2k^2/N and 4k^2/N. Thus R_k/H_k tends to one for k=o(sqrt N) | proved | SG-01 and the known leading terms. Classical generating-function reformulation, positive partition weights and availability bounds. [EXT-A in frozen extension v1](manuscript-round-01/extensions/hyperbolic-window-v1.md) | [Independent extension review](manuscript-round-01/reviews/extension-review-v1.md), exact source hash recorded there. Independent of SG-05. Finite checks corroborate only |
| SG-08 | Under the SG-07 normalization, if k^2/N tends to d in (0,infinity), then R_k/H_k tends to exp(d/4). For each fixed C>0, the relative error of R_k against exp(k^2/(4N))H_k tends uniformly to zero over integer 2 <= k <= C sqrt N | proved | Exact partition representation, aggregate Poisson tail, pair-depletion logarithm, and parity-weighted mean convergence. SG-07 handles zero-boundary subsequences. [EXT-B in frozen extension v1](manuscript-round-01/extensions/hyperbolic-window-v1.md) | [Independent extension review](manuscript-round-01/reviews/extension-review-v1.md). No rate or extension to unbounded k/sqrt N is asserted |

Priority: the [source audit](manuscript-round-01/priority/PRIORITY_AUDIT_V1.md) verifies the published cubic-scale question, known recurrences, known mixed estimate and classical Laguerre identity. Its bounded search found no exact duplicate of the quantitative refinements, but historical priority remains provisional. Preprint Lemma 7 in the biregular paper is published Lemma 5.6.

Final assembled review: the [fresh referee](manuscript-round-01/reviews/manuscript-referee-v1.md) independently reconstructed the manuscript's theorem chain and identified five local explanation or boundary issues. The [revision-4 acceptance](manuscript-round-01/reviews/manuscript-referee-v4.md) closes all five and accepts the 19-page manuscript and five-page guide at manifest SHA256 `75e0b0233130978fc41d9abb2e622e760a35a2395e0e94e6ba09032b7ad3556e`. None of the corrections weakened a main theorem. No end-to-end formalization or complete graph-level proof is claimed.

## Starting-proof hashes

- SG-02 proof SHA256: a660dae8d97b5b9d0bb17cbfa6122518d488c48464804fda1ee0b1e7184c85af. The integrator reviewed the new row-sum derivation, the exact supersolution identity and the generalized prefactor after reconstructing revision 1. The earlier [review](integration-audit-2026-11-14/REVIEW_V1.md) remains attached to its original bytes.
- SG-04 proof SHA256: 4eefcef438bbac40639e2324076bd9c0bf96dc50600acf8b75f2152529a38a4e. The cross-review's frozen revision-1 hash is recorded in that review. The [integrator review](integration-audit-2026-11-14/SCALING_REVIEW_V1.md) independently proves the bounded-comparability consequence, and the revision diff changes no recurrence or inequality.
- SG-05 proof SHA256: ea79cdd43ae88afcc2ca5008e4c4a95e50e12b37ca87904db25ce7cdad0b5596. Independent review SHA256: d9fc48eb1a6f31db229da13d94fb23494bc4450e9f44058cadfc8dc77c6bd517. The frozen proof's awaiting-review sentence records its state at freezing. This ledger records the later completed review.
- Symbolic proofs establish the uniform claims. Exact recurrence, finite-permutation, incidence-pattern and multicolor checks are corroborating evidence in the audit directory. No finite range is used as a proof of the general statements.
- No claim above has an end-to-end formal proof in this packet. Primary-source priority searches are targeted and incomplete.

## Separate frontier and historical work

SG-05 is a separately reviewed extension and is not a premise of SG-02 or SG-04. Its growing-odd-order consequence proves the optimality of the lower-bound constant in SG-04. Imported finite-defect and adjacent-family results were not fully re-audited in this run. Their pending reports remain pending.

## Dependency changes

If a reviewed recurrence, leading-term definition or proof revision changes, mark the affected review stale and reassess all dependent claims before reuse. A source attribution correction does not by itself alter a proved identity, but it does alter the known-versus-new statement.

November 14: SG-01 through SG-04 integrated from the frozen proofs and the independent reviews. The source conditioning defect is bypassed by compatible-set conditioning, rather than silently repaired in the imported paper.

November 14: SG-05 integrated after independent reconstruction of initialization, uniform residual constants, stability, parity limits and sharpness. The critical-scale investigation ended before its 5:30 PM cutoff. Historical manifests remain unchanged.
