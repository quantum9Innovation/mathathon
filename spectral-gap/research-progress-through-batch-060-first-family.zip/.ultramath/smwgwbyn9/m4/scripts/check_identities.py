"""Symbolic and analytic checks for notes/secular-theorem.md.
Run: python3 scripts/check_identities.py"""
import sympy as sp
import numpy as np
from scipy.integrate import quad
import networkx as nx

# --- L1: exact Schur factor, symbolically on C_4 with T={0,2} ---
lam = sp.symbols('lam')
A = sp.Matrix([[0,1,1,0],[1,0,0,1],[1,0,0,1],[0,1,1,0]])
T = [0,2]; ind = sp.Matrix([1 if i in T else 0 for i in range(4)])
M = sp.zeros(5,5); M[:4,:4] = A
for i in T: M[i,4] = 1; M[4,i] = 1
lhs = sp.expand((lam*sp.eye(5)-M).det())
rhs1 = sp.expand((lam*sp.eye(4)-A).det()*(lam - (ind.T*(lam*sp.eye(4)-A).inv()*ind)[0]))
rhs2 = sp.expand((lam*sp.eye(4)-A).det()*(lam + (ind.T*(A-lam*sp.eye(4)).inv()*ind)[0]))
print("[L1] Schur identity (lam I - A)^-1 form :", sp.simplify(lhs-rhs1)==0)
print("[L1] Schur identity (A - lam I)^-1 form :", sp.simplify(lhs-rhs2)==0)

# --- KM transform: closed form, moments, special values, density ---
z, d = sp.symbols('z d')
h = (z - sp.sqrt(z**2-4*(d-1)))/(2*(d-1))
G = 1/(z - d*h)
print("[KM] G_d rationalised closed form equals 1/(z-d h):",
      sp.simplify(G - 2*(d-1)/((d-2)*z + d*sp.sqrt(z**2-4*(d-1)))) == 0)
def tree(dd, depth):
    Gg = nx.Graph(); Gg.add_node(0); frontier=[0]; nxt=1
    for _ in range(depth):
        new=[]
        for u in frontier:
            for _ in range(dd if u==0 else dd-1):
                Gg.add_edge(u,nxt); new.append(nxt); nxt+=1
        frontier=new
    return Gg
for dd in (3,4,5):
    Ad = nx.to_numpy_array(tree(dd,4))
    mom = [int(round((np.linalg.matrix_power(Ad,k))[0,0])) for k in (0,2,4,6,8)]
    ser = sp.series(G.subs(d,dd), z, sp.oo, 11).removeO()
    got = [int(sp.expand(ser).coeff(z, -(k+1))) for k in (0,2,4,6,8)]
    print("[KM] d=%d tree closed-walk moments %s vs transform moments %s : %s"
          % (dd, mom, got, mom==got))
def GK(dd,zz):
    hh = (zz-np.sqrt(zz*zz-4*(dd-1)))/(2*(dd-1)); return 1/(zz-dd*hh)
def dens(dd,x):
    return dd*np.sqrt(max(4*(dd-1)-x*x,0.0))/(2*np.pi*(dd*dd-x*x))
for dd in (3,4,5):
    for zz in (2*np.sqrt(dd-1)+0.4, dd+0.3, 7.0):
        val = quad(lambda x: dens(dd,x)/(zz-x), -2*np.sqrt(dd-1), 2*np.sqrt(dd-1), limit=400)[0]
        print("[KM] d=%d z=%.4f  int dmu_KM/(z-x)=%.10f  closed form=%.10f  diff=%.1e"
              % (dd, zz, val, GK(dd,zz), abs(val-GK(dd,zz))))
print("[KM] G_d(d) = (d-1)/(d(d-2)) :",
      all(abs(GK(dd,float(dd)) - (dd-1)/(dd*(dd-2))) < 1e-12 for dd in (3,4,5,6,7)))
# exact algebraic identity at the edge (numeric evaluation there loses all digits)
ds = sp.symbols('d', positive=True)
edge = sp.simplify((2*(ds-1)/((ds-2)*z + ds*sp.sqrt(z**2-4*(ds-1)))).subs(z, 2*sp.sqrt(ds-1))
                   - sp.sqrt(ds-1)/(ds-2))
print("[KM] G_d(2 sqrt(d-1)) = sqrt(d-1)/(d-2) exactly (symbolic residual = %s) : %s"
      % (sp.simplify(edge), sp.simplify(edge)==0))
print("     (direct floating-point evaluation at the edge is unreliable: cancellation; "
      "d=3 gave 1.4142134992 vs 1.4142135624, d=4 gave sqrt of a tiny negative)")
