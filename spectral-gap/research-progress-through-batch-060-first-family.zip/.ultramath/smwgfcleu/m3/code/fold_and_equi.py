"""Ihara-Bass fold check and explicit equiangular systems from two-eigenvalue Seidel matrices."""
import numpy as np, json
import networkx as nx

def nb(G):
    arcs=[]
    for u,v in G.edges(): arcs += [(u,v),(v,u)]
    idx={a:i for i,a in enumerate(arcs)}
    B=np.zeros((len(arcs),len(arcs)))
    for (u,v) in arcs:
        for w in G.neighbors(v):
            if w!=u: B[idx[(u,v)],idx[(v,w)]]=1
    return B

def match_dev(pred, got):
    pred=np.array(pred,dtype=complex); got=np.array(got,dtype=complex)
    assert len(pred)==len(got)
    used=np.zeros(len(got),bool); worst=0.0
    for z in pred:
        d=np.abs(got-z); d[used]=np.inf; i=int(np.argmin(d))
        used[i]=True; worst=max(worst,float(d[i]))
    return worst

rows=[]
for name,G in [("K4",nx.complete_graph(4)),("K33",nx.complete_bipartite_graph(3,3)),
               ("Petersen",nx.petersen_graph()),("Heawood",nx.heawood_graph()),
               ("rand3_40",nx.random_regular_graph(3,40,seed=5)),
               ("rand4_30",nx.random_regular_graph(4,30,seed=5))]:
    n=G.number_of_nodes(); m=G.number_of_edges(); d=set(dict(G.degree()).values())
    assert len(d)==1; d=d.pop()
    evB=np.linalg.eigvals(nb(G))
    lam=np.linalg.eigvalsh(nx.to_numpy_array(G,dtype=float))
    pred=[]
    for x in lam:
        r=np.sqrt(complex(x*x-4*(d-1)))
        pred += [(x+r)/2,(x-r)/2]
    pred += [1.0]*(m-n) + [-1.0]*(m-n)
    rows.append(dict(graph=name,n=n,m=m,d=d,max_dev_fold=match_dev(pred,evB),
                     sqrt_d_minus_1=round(float(np.sqrt(d-1)),8)))
print(json.dumps(rows,indent=1))

# ---- equiangular systems ------------------------------------------------
def paley_seidel(q):
    chi=np.zeros(q,dtype=np.int64)
    for a in range(1,q): chi[a]=1 if pow(a,(q-1)//2,q)==1 else -1
    S=np.zeros((q+1,q+1),dtype=np.int64)
    for i in range(q): S[0,i+1]=1; S[i+1,0]=1
    for i in range(q):
        for j in range(q):
            if i!=j: S[i+1,j+1]=chi[(i-j)%q]
    return S
def rook44_seidel():
    n=16; A=np.zeros((n,n),dtype=np.int64)
    for i in range(4):
        for j in range(4):
            for k in range(4):
                if k!=j: A[4*i+j,4*i+k]=1
                if k!=i: A[4*i+j,4*k+j]=1
    return np.ones((n,n),dtype=np.int64)-np.eye(n,dtype=np.int64)-2*A, A

out=[]
def check(S,label):
    n=S.shape[0]
    ev=np.linalg.eigvalsh(S.astype(float))
    vals,counts=np.unique(np.round(ev,9),return_counts=True)
    thetamin=float(vals.min()); k=int(counts[np.argmin(vals)])
    alpha=-1.0/thetamin
    G=np.eye(n)+alpha*S.astype(float)
    w,V=np.linalg.eigh(G)
    keep=w>1e-8
    r=int(np.sum(keep))
    U=V[:,keep]
    X=np.sqrt(n/r)*U.T
    colnorm=np.linalg.norm(X,axis=0)
    Gram=X.T@X
    off=np.abs(Gram-np.diag(np.diag(Gram)))
    angs=off[np.triu_indices(n,1)]
    out.append(dict(label=label,n=n,d=r,alpha=round(alpha,12),
        distinct_seidel=[[round(float(a),8),int(b)] for a,b in zip(vals,counts)],
        gram_min_eig=float(w.min()),
        max_col_norm_dev=float(np.max(np.abs(colnorm-1))),
        max_offdiag_dev=float(np.max(np.abs(angs-alpha))),
        relative_bound_rhs=float(r*(1-alpha**2)/(1-r*alpha**2))))
check(paley_seidel(5),"Paley_q5")
check(paley_seidel(13),"Paley_q13")
check(paley_seidel(17),"Paley_q17")
S,A=rook44_seidel(); check(S,"Rook4x4")
K5=np.ones((5,5),dtype=np.int64)-np.eye(5,dtype=np.int64)
check(np.ones((5,5),dtype=np.int64)-np.eye(5,dtype=np.int64)-2*K5,"K5_as_seidel")
print(json.dumps(out,indent=1))
json.dump(out,open("out/equiangular.json","w"),indent=1)
