# Erratum (separate, additive) — batch 050, `Theorem C`: the claimed `O(log n/n)` scaled error is not established

**Status of this file.** Additive erratum. The frozen files
`.ultramath/smwgwbyn9/m2/proof.md` (SHA256 `0e7f5b98…913c98`) and `results/050-finite-defect.md`
(SHA256 `f06df232…ae5a`) are **not** edited, and no statement of theirs is reinterpreted here.
The claim which fails is a *rate*; the *limit* that batch 050 calls Theorem C survives. Nothing
in batch 060 depends on the rate: `.ultramath/smwh0bmpx/m2/PROOF.md` Theorem 4 claims only the
limit (`s_n = Δ²/c₁ + o(1)`), never `O(log n/n)`.

## The claim

`.ultramath/smwgwbyn9/m2/proof.md`, §0 Theorem C and §5, and `results/050-finite-defect.md`
§1 ("The `1/n` correction near `d`") state, for `Δ G_d(d) > d`:

```
n(d - λ_2(G'_n)) → Δ²/(Δ G_d(d) - d),
```

and, in §2 of the same file, "The proof establishes the stronger scaled error `O(log n/n)`
about the limiting value", i.e. `|s_n - Δ²/c₁| = O(log n / n)` where `λ_2(G'_n) = d - s_n/n`,
`c₁ = ΔG_d(d) - d > 0`.

## The error in the proof of the rate

The decomposition used (that file, §5) is, at `λ = d - s/n` with `s ∈ (0,C₁]`:

```
Σ_n(d - s/n) = f(d - s/n) + Δ²/s + (Δ²/n)Σ_{k≤L}(d/λ)^k · (1/λ) + R_L ,
```

and the files assert that "the only error term that is not `O(log n/n)` or exponentially small
is the explicit `Δ²/(n(d-λ)) = Δ²/s`". But the bound proved for `R_L` in that same file,
Lemma 2, is

```
|R_L(λ)| ≤ Δ² ρ^{L+1} / (λ(1-ρ)),        ρ = ρ(λ) = ‖A'‖/λ,
```

and on the event `‖A'‖ ≤ e + δ` with `e = 2√(d-1)` this is *not* exponentially small in `n`
and not `O(log n/n)`: at `λ = d - s/n = d(1 + O(1/n))` one has `ρ = (e+δ)/d + o(1)`, and with
`L = ⌊c log_{d-1} n⌋`, `c < 1/2`,

```
ρ^{L+1} ≈ n^{c · log((e+δ)/d) / log(d-1)} .
```

For `d = 3`, `c = 1/2`: `log(e/3)/log 2 = log(0.942809)/log 2 = -0.08496`, so
`ρ^{L+1} ≈ n^{-0.0425}`, and the same exponent appears in the completed-tree tail
`Δ Σ_{k>L} c_k/λ^{k+1} ≤ Δρ₁^{L+1}/(λ(1-ρ₁))` with `ρ₁ = e/λ`. Hence the honest conclusion of
the exhibited decomposition is

```
Σ_n(d - s/n) = f(d - s/n) + Δ²/s + O(n^{-0.0425}) (d=3)  + O(log n/n),
```

i.e. a relative error of order `n^{-0.0425}` in the balance, not `O(log n/n)`.

## What survives

The zero `s_n` of `Σ_n` satisfies `Δ²/s_n = c₁ + c₂ s_n/n·(-1)+ O(n^{-0.0425})`; since the error
tends to `0`, `s_n → Δ²/c₁`. So **the limit statement of Theorem C is unaffected**, as is
`results/050-finite-defect.md`'s "stronger scaled error" only in the weak sense `o(1)`. What is
withdrawn is the specific `O(log n/n)` modulus and any inference from it. In particular the
batch-050 numerical series `n(d-λ_2) = 30.77, 33.72, 35.94, 36.17` for `n = 10³…8·10³` is a
consistent approach to `36`; it does not discriminate a `1/n` modulus from an `n^{-0.0425}` one.

## Why it is a real obstruction, not an artefact of one bound

`1_T^T A'^k 1_T = 1_T^T A^k 1_T - Δ²d^k/n`, and for `k ≈ L ≈ (c/2)log n` the truncated walk
count `1_T^T A^k 1_T` is a genuinely global quantity (the walk explores the whole graph). A
bound better than `‖A'‖^k` on the tail requires a concentration statement for these walk counts
uniform in `k`, i.e. a second-moment or eigenvector-delocalisation input that the batch-050
proof does not use and does not claim. The batch-050 files state "no variance is needed" for
Theorem A — correct for Theorem A, whose statement has no rate — but the `O(log n/n)` clause of
Theorem C does need one.

## Reviewed replacement (this batch, `m2` direction `d3`)

`.ultramath/smwh0bmpx/m2/PROOF.md` Theorem 4 states exactly the limit,

```
τ = Φ_T(d) ≠ 0  ⟹  n|λ_i(G'_n) - d| → Δ²/|τ|   (i = 2 if τ<0, i = 1 if τ>0),
τ = 0            ⟹  √n |λ_i(G'_n) - d| → Δ/√(Φ_T'(d)) ,
```

with the same explicit decomposition and no rate claim. The `τ = 0` branch is a genuine new
branch (it is realised by `T = N(c)`, `d = 3`, `Φ_T(d) = 0`), and on it the `1/n` scaling is
false: the displacement is `Θ(n^{-1/2})`.

## Exact next action

If a rate is wanted, prove concentration of `1_T^T A^k 1_T` about `W_k` (its tree value) for
`k ≤ c log n` at relative precision `n^{-1+ε}`, or replace the geometric tail bound by a
resolvent identity that avoids the truncated series; then the `O(log n/n)` modulus can be
reinstated or replaced by the true exponent.
