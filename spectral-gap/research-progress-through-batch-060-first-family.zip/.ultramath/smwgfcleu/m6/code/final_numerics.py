"""Final numerics for the dossier.

Dictionary: for connected S in F_2^rho with |S| = d, the spectrum is
{d - 2 wt(c) : c in C}, C = row space of the rho x d column matrix of S.  Hence
    lambda_2 = d - 2 d_min(C),   lambda_min = d - 2 d_max(C),
and the multiplicity of d - 2w is the weight-enumerator coefficient A_w(C).

Bounds checked here (both proved in the dossier):
  A  (flatness)   max(|lambda_2|, |lambda_min|)^2 >= (|G| d - d^2)/(|G| - 1),
                  i.e. the two-sided bias is at least sqrt(d(1 - d/|G|)) up to the
                  factor |G|/(|G|-1).
  B  (shortening) lambda_2 >= rho - 1 - log2 d.
"""
import itertools
import json
import math
import random
from sympy import Poly, symbols, GF, factor_list

X = symbols('x')


def popcount(v):
    return bin(v).count('1')


def code_of(rho, S):
    d = len(S)
    rows = []
    for i in range(rho):
        m = 0
        for j, s in enumerate(S):
            if (s >> i) & 1:
                m |= 1 << j
        rows.append(m)
    basis = []
    for v in rows:
        for b in basis:
            v = min(v, v ^ b)
        if v:
            basis.append(v)
            basis.sort(reverse=True)
    code = {0}
    for b in basis:
        code |= {c ^ b for c in code}
    we = {}
    for c in code:
        w = popcount(c)
        we[w] = we.get(w, 0) + 1
    return we, len(basis)


def spectrum_data(d, we):
    nz = sorted(w for w in we if w > 0)
    return d - 2 * nz[0], d - 2 * nz[-1], we[nz[0]], nz


def irreducible_poly(k):
    """Lowest-weight irreducible polynomial of degree k over GF(2), as a bitmask."""
    import itertools as it
    for weight in range(2, 7):
        for mids in it.combinations(range(1, k), weight - 2):
            c = 1 | (1 << k)
            for i in mids:
                c |= 1 << i
            p = Poly(sum(((c >> i) & 1) * X ** i for i in range(k + 1)), X, domain=GF(2))
            fl = factor_list(p)
            if len(fl[1]) == 1 and fl[1][0][1] == 1 and fl[1][0][0].degree() == k:
                return c
    raise RuntimeError


def cubic_family(k):
    mod = irreducible_poly(k)

    def mul(a, b):
        r = 0
        while b:
            if b & 1:
                r ^= a
            b >>= 1
            a <<= 1
            if a >> k:
                a ^= mod
        return r

    return [x | (mul(mul(x, x), x) << k) for x in range(1, 1 << k)]


def main():
    rng = random.Random(99)
    bad = []
    n_ex = 0
    minlam = {}
    for rho in (2, 3, 4):
        for d in range(1, (1 << rho)):
            best = None
            for S in itertools.combinations(range(1, 1 << rho), d):
                we, rank = code_of(rho, list(S))
                if rank < rho:
                    continue
                lam2, lammin, mult, nz = spectrum_data(d, we)
                n_ex += 1
                G = 1 << rho
                bias = max(abs(lam2), abs(lammin))
                flat_ok = bias * bias * (G - 1) >= G * d - d * d      # exact
                short_ok = True
                if d <= G - 2:
                    short_ok = (1 << (lam2 + 1)) * d >= G             # exact
                neg_ok = (lam2 >= 0) or (lam2 == -1 and d == G - 1)
                if not (flat_ok and short_ok and neg_ok):
                    bad.append({'rho': rho, 'd': d, 'S': list(S), 'lam2': lam2,
                                'lammin': lammin, 'flat_ok': flat_ok,
                                'short_ok': short_ok, 'neg_ok': neg_ok})
                if best is None or lam2 < best[0]:
                    best = (lam2, list(S), mult, nz, lammin)
            minlam.setdefault(rho, {})[d] = best
    rand = []
    for rho, d in [(6, 8), (8, 12), (10, 20), (12, 20), (12, 60), (16, 30),
                   (16, 150), (20, 25), (20, 100), (20, 400), (24, 30), (24, 300)]:
        S = rng.sample(range(1, 1 << rho), d)
        we, rank = code_of(rho, S)
        lam2, lammin, mult, nz = spectrum_data(d, we)
        G = 1 << rho
        bias = max(abs(lam2), abs(lammin))
        flat_ok = bias * bias * (G - 1) >= G * d - d * d
        short_ok = (1 << (lam2 + 1)) * d >= G if d <= G - 2 else True
        ok = rank == rho and flat_ok and short_ok
        if not ok:
            bad.append({'rho': rho, 'd': d, 'rank': rank, 'lam2': lam2,
                        'lammin': lammin})
        rand.append({'rho': rho, 'd': d, 'rank': rank, 'lam2': lam2,
                     'lammin': lammin, 'mult_lambda2': mult,
                     'flatness_floor': round(math.sqrt((G * d - d * d) / (G - 1)), 3),
                     'shortening_floor': round(rho - 1 - math.log2(d), 3),
                     'bench': round(2 * math.sqrt(d - 1), 3),
                     'lam2_over_bench': round(lam2 / (2 * math.sqrt(d - 1)), 3)})
    cub = []
    for k in range(3, 11):
        S = cubic_family(k)
        rho, d = 2 * k, len(S)
        we, rank = code_of(rho, S)
        lam2, lammin, mult, nz = spectrum_data(d, we)
        G = 1 << rho
        cub.append({'k': k, 'rho': rho, 'd': d, 'rank': rank, 'lam2': lam2,
                    'lammin': lammin, 'd_min': nz[0], 'd_max': nz[-1],
                    'mult_lambda2': mult,
                    'bias_over_d': round(max(abs(lam2), abs(lammin)) / d, 4),
                    'flatness_floor': round(math.sqrt((G * d - d * d) / (G - 1)), 3),
                    'bench': round(2 * math.sqrt(d - 1), 3),
                    'beats_bench': lam2 < 2 * math.sqrt(d - 1)})
    cross = []
    for d in (16, 64, 256, 1024, 4096, 10 ** 6):
        r = 1
        while r - 1 - math.log2(d) <= 2 * math.sqrt(d - 1):
            r += 1
        cross.append({'d': d, 'rho_needed_for_shortening_to_beat_benchmark': r,
                      'log2_d': round(math.log2(d), 2),
                      'rho_over_log2_d': round(r / math.log2(d), 2),
                      'log2_G_over_d': round(r - math.log2(d), 2)})
    minlam_out = {}
    for rho, tab in minlam.items():
        minlam_out[str(rho)] = {}
        for d, v in tab.items():
            if v is None:
                continue
            minlam_out[str(rho)][str(d)] = {'lam2': v[0], 'S': v[1], 'mult': v[2],
                                            'weights': v[3], 'lammin': v[4]}
    print(json.dumps({'failures': bad, 'n_exhaustive_connected': n_ex,
                      'min_lambda2_table': minlam_out, 'random': rand,
                      'cubic': cub, 'crossover': cross,
                      'irreducible_polys': {k: irreducible_poly(k) for k in range(3, 11)}},
                     indent=1))


if __name__ == '__main__':
    main()
