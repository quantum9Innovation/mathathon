# Relative spectra of random lifts of irregular bases: exact universal-cover bands, a two-periodic threshold, and the conversion obstruction

Research dossier, swarm `smwgfcleu`, member `m4`, direction `d4` (menu item G:
irregular universal covers, quotient matrices, random lifts, relative spectra
beyond the regular case).

Status labels used throughout, and never upgraded:

- **[LIT]** checked against a primary source, with version and URL
- **[CALC]** exact computation, reproducible from the scripts in `scripts/`
- **[PROOF]** mathematical proof supplied here (complete or with every cited
  ingredient named)
- **[NUM]** numerical experiment (never used as a proof of an asymptotic claim)
- **[CONJ]** conjecture or speculation

Absolute paths of everything needed to check this document:

- `scripts/floquet_bands.py`, `scripts/gap_check.py` (Floquet bands, truncated
  spherically homogeneous trees)
- `scripts/cover_tools.py` (universal cover balls, random lifts, exact old/new
  separation)
- `scripts/biregular_checks.py` (Ihara-Bass quartic correspondence, injection
  test, exact spectra)
- `scripts/lift_scan_final.py`, `scripts/checks_extra.py`,
  `scripts/experiments_final.py` (randomised or truncated runs),
  `scripts/radial_diagnosis.py`, `scripts/bound_state_check.py` (Section 3.3)
- `outputs/floquet_bands.txt`, `outputs/gap_check.txt`,
  `outputs/biregular_checks.txt`, `outputs/experiments_final.txt`,
  `outputs/lift_scan_final.txt`, `outputs/gap_test_final.txt`,
  `outputs/checks_extra.txt`, `outputs/radial_diagnosis.txt`,
  `outputs/bound_state_check.txt`

Note on `outputs/experiments_final.txt`: the cover-ball columns (certified lower
bounds for `ρ(A_T)`) are deterministic and correct, but the two lift columns in
that file were produced by an earlier version of the old/new separation and are
superseded by `outputs/lift_scan_final.txt`, which uses the exact separation
`spec(A_G) = spec(A_B) ⊔ spec(new)` verified in `outputs/checks_extra.txt`.

All paths are relative to `.ultramath/smwgfcleu/m4/`.

---

## 0. What is established here, in one page

The relativized Alon conjecture of Friedman asks whether the *new* spectrum of a
random covering of a fixed base `B` concentrates at the spectrum of the
adjacency operator of the universal cover `B̂`. For regular bases this is
Friedman's theorem and its refinements. For irregular bases the conjecture was
resolved qualitatively by Bordenave and Collins in 2019 (**[LIT]**, full
Hausdorff convergence in probability), while the two *quantitative* questions
that the four local dossiers are built on remain untouched: polynomial
exceptional probability (the rare-defect or tangle side) and exact identification
of the threshold in terms of computable invariants of `B̂`.

This dossier contributes four things to the irregular case.

1. **Exact universal-cover bands for biregular bases.** For the
   `(d₁,d₂)`-biregular tree `T` with `a = d₁-1`, `b = d₂-1`,

   ```
   ρ(A_T) = √a + √b                       [PROOF, Section 3.1]
   σ(A_T) ⊇ ±[|√a-√b|, √a+√b]             [PROOF, Section 3.2]
   σ(A_T) = ±[|√a-√b|, √a+√b]  when b = 1 [PROOF, Section 3.2, exact]
   ```

   The interval is not an artefact: it is exactly the support of the
   Godsil-Mohar limiting spectral measure of random biregular graphs
   (**[LIT]**), so the "Kesten-McKay/Godsil-Mohar" world and the "relativized
   Alon" world share one object. The inequality `√a+√b ≤ 2√(max(a,b))`, strict
   unless `a = b`, is the exact quantitative gap between the truth and the bound
   proved by Friedman and Kohler for irregular bases (**[LIT]**).

2. **A complete explanation of where `2√(d_max-1)` comes from.** A single
   exponential test function `w(x) = γ^{dist}` gives the bound `2√(Δ-1)` and
   nothing better, while a two-periodic test function
   `w(x) = c_{k mod 2} γ^k` gives `√a+√b` exactly (**[PROOF]**, Section 3.1).
   The Friedman-Kohler irregular threshold is therefore the exact optimum of a
   restricted test-function class, not a technical accident.

3. **The conversion obstruction.** The Hashimoto (non-backtracking) trace
   method, which is the only route that produces polynomial exceptional
   probability, controls new *non-backtracking* eigenvalues. Passing to the
   adjacency spectrum requires the Ihara-Bass quadratic, which exists only when
   the degree is constant. For biregular graphs there is a *quartic* replacement,
   and I derive it from scratch, prove the injection it induces, and prove that
   the injection is equivariant under the deck group (**[PROOF]**, Section 3.4).
   This yields, conditionally on the Friedman-Kohler Hashimoto theorem, an
   `O(n^{-1})` relativized bound for biregular bases with the optimal threshold
   (**[PROOF]**, Section 3.5). For general irregular bases the same step is
   blocked by the degree matrix inside the Ihara-Bass determinant. That is the
   single hardest missing estimate, stated precisely in Section 5.

4. **The Floquet edge is not the radius.** For irregular type structure the
   degree-type Floquet band computation gives only the essential spectrum:
   I exhibit a spherically homogeneous tree whose bands are `±[√2-1, √2+1]`
   while `λ = √6 = 2.4494897428` is an exact eigenvalue with an explicit `ℓ²`
   eigenvector, so `ρ(A_T) ≥ √6 > √2+1` (**[PROOF]**, Section 3.3). The
   mechanism is a discrete bound state above the bands at the root defect, not
   angular components (an earlier version of this dossier had that diagnosis
   wrong, see the correction notice in Section 3.3). Any threshold formula for
   the irregular case that computes only the band edge is therefore wrong.

Everything numerical below is consistent with, and in one case (the
Bordenave-Collins base) independently reproduces, published numbers.

---

## 1. Model, notation, ordering, regime

**Base.** `B` is a finite connected multigraph, without loops in the numerical
experiments, with minimum degree at least 2 so that homotopy classes of paths
coincide with non-backtracking walks and the universal cover is the tree of
non-backtracking walks. `A_B` is the adjacency matrix, eigenvalues ordered
`λ₁ ≥ λ₂ ≥ … `, and `ρ(A_B) = max|λᵢ|`.

**Universal cover.** `T = B̂` is the universal covering tree, `A_T` the adjacency
operator on `ℓ²(V(T))`, `σ(A_T)` its spectrum (a compact subset of `ℝ`,
symmetric about 0 because trees are bipartite), `ρ(A_T) = ‖A_T‖ = sup σ(A_T)`.

**Random lifts.** Fix `n`. Give every edge *occurrence* of `B` an independent
uniform permutation of `[n]`, and join `(u,i)` to `(v,σ_e(i))`. The result `G` is
an `n`-lift, `π: G → B` is a covering of degree `n`. This is the
Broder-Shamir / permutation model used by Friedman, Bordenave and
Bordenave-Collins.

**Old and new spectrum, exactly.** The space of functions constant on every
fibre is invariant, of dimension `|V(B)|`, and `A_G` acts on it as `A_B`. Hence

```
spec(A_G) = spec(A_B) ⊔ spec(new),     |spec(new)| = (n-1)|V(B)|,
```

where the old part keeps the *same* multiplicities as in the base, not `n` copies
of them. This is worth stating because it is easy to get wrong: it is not true
that each base eigenvalue appears with multiplicity `n` (only the *dimension* of
the fibre-constant space is `|V(B)|`). `[PROOF]` and `[NUM]`, verified to
`1e-15` in `outputs/checks_extra.txt`. The relative second eigenvalue is

```
ρ_B^new(A_G) = max{ |μ| : μ ∈ spec(new) }.
```

**Regime.** `B`, its degrees, and `ε > 0` are fixed, `n → ∞`. No statement here
is uniform in `B`.

**Why the relative notion matters.** For regular bases the old spectrum is a
single pair `±d` and `ρ_B^new` is the honest second eigenvalue. For irregular
bases `ρ(A_B)` itself can exceed every candidate threshold. Example
`[CALC]`, `outputs/lift_scan_final.txt`: the 5-vertex base with degrees
`(3,3,3,3,2)` has `λ₁ = 2.855773` while `ρ(A_T) ≤ 2.828427 = 2√(d_max-1)` and
the computed cover balls give `ρ(A_T) ≥ 2.7087`. The lift inherits the old
eigenvalue `2.855773` at every degree, so "`λ₂` of the lift" says nothing about
expansion. Relative expansion is a statement about the new part only.

---

## 2. Closest verified literature, with exact statements

**[LIT] Friedman, 2003.** *Relative expanders or weakly relatively Ramanujan
graphs*, Duke Math. J. **118** (2003), 19-35. Conjecture (as quoted in
[arXiv:1502.04482v4](https://arxiv.org/abs/1502.04482), Section 4, and in
[arXiv:1212.5216](https://arxiv.org/abs/1212.5216), Section 1): for a fixed base
`B` and a random `n`-cover `G`, for every `ε>0` almost surely as `n → ∞` the
largest absolute value of a **new** adjacency eigenvalue is `< ρ + ε`, where `ρ`
is the spectral radius of the adjacency operator of the universal cover.

**[LIT] Friedman and Kohler, 2014.** *The Relativized Second Eigenvalue
Conjecture of Alon*, [arXiv:1403.3462v1](https://arxiv.org/abs/1403.3462v1), 144
pages. Conjecture 0.2.5 is the statement above with `ρ(A_B̂)`. Theorem 0.2.7
(their Section 3.1) proves it with `ρ(A_B̂)` replaced by `2√(d_max-1)`, using
Kotani-Sunada. Their own text says the technique "more directly addresses the
expected trace of powers of the Hashimoto matrix rather than the adjacency
matrix". For a `d`-regular base they note `ρ(A_B̂) = 2√(d-1)`, and they remark
that for bases with degrees in `{d_max-1, d_max}` one has
`ρ(A_B̂) ≥ 2√(d_min-1)`, which makes Theorem 0.2.7 an improvement on Puder in
that class. Source cautions from the local dossier `09-assumptions-and-weak-points.md`
apply to Theorem 3.3.2 and Theorem 3.3.4, not to Conjecture 0.2.5 or
Theorem 0.2.6.

**[LIT] Puder, 2015.** *Expansion of random graphs: new proofs, new results*,
[arXiv:1212.5216](https://arxiv.org/abs/1212.5216), Invent. Math. **201** (2015).
For an arbitrary base `H`, the new adjacency eigenvalues of a random
`n`-covering are at most `√3 ρ + ε` almost surely, where `ρ = ρ(A_Ĥ)`, and
`ρ + 0.84` in the regular case. This was the best general bound before 2019.

**[LIT] Bordenave, 2019.** *A new proof of Friedman's second eigenvalue theorem
and its extension to random lifts*, [arXiv:1502.04482v4](https://arxiv.org/abs/1502.04482v4),
to appear in Ann. Sci. ENS. For every finite connected base with `|E|>|V|`, if
`λ₁` is the largest new eigenvalue of the non-backtracking matrix in absolute
value and `ρ₁` its Perron eigenvalue on the base, then for every `ε>0`,
`|λ₁| ≤ √ρ₁ + ε` with probability tending to one (the random-lift theorem of
their Section 3, Theorem 3 in the published numbering and Theorem 23 on page 32
in the numbering of the local dossier `.paper-mastery/friedman-second-eigenvalue-lifts`).
Their Corollary for the adjacency matrix is stated only for `d`-regular bases,
"through the Ihara-Bass formula". Their Section 4 states explicitly: "Theorem
[3] proves this phenomenon for the specific case of the non-backtracking
operator", and attributes `ρ(NB of T) = √ρ₁` to Angel-Friedman-Hoory.

**[LIT] Bordenave and Collins, 2019.** *Eigenvalues of random lifts and
polynomials of random permutation matrices*, Ann. of Math. **190** (2019),
811-875, [arXiv:1801.00876](https://arxiv.org/abs/1801.00876). Their Theorem
(the `th:main` of the source) states: for symmetric random permutations and the
symmetry condition, the Hausdorff distance between `σ(A_{|H_0})` and `σ(A_⋆)`
converges to 0 in probability, where `A_⋆` is the adjacency operator of the
universal covering tree and `H_0` is the orthogonal complement of the
fibre-constant space. **This settles Friedman's 2003 conjecture for arbitrary
bases, in the strong two-sided (Hausdorff) form, in probability.** Their Figure 2
caption gives an explicit irregular base (5 vertices, degrees `4,4,2,2,2`) with
`σ(A_⋆) = [-a,-b] ∪ {0} ∪ [b,a]`, `a ≃ 2.866`, `b ≃ 0.283`. Consequence for this
dossier: no qualitative statement about the threshold `ρ(A_B̂)` can be new after
2019. Quantitative statements can be.

**[LIT] Godsil and Mohar, 1988.** As reported in Brito-Dumitriu-Decker Harris,
[arXiv:1804.07808v6](https://arxiv.org/abs/1804.07808v6), Section 1, they
computed the limiting spectral measure of random `(d₁,d₂)`-biregular graphs, with
a point mass at 0 of size `|d₁-d₂|/(2(d₁+d₂))` and continuous part supported on
`|√(d₁-1)-√(d₂-1)| ≤ |λ| ≤ √(d₁-1)+√(d₂-1)`. That support interval is exactly
`σ(A_T)` for the `(d₁,d₂)`-biregular tree, which Section 3 proves directly.

**[LIT] Feng and Li, 1996, and Li and Solé, 1996.** The Alon-Boppana bound for
biregular graphs: every sequence of `(d₁,d₂)`-biregular graphs has
`λ₂ ≥ √(d₁-1)+√(d₂-1) - ε` eventually.

**[LIT] Brito, Dumitriu, Decker Harris, 2022.** *Spectral gap in random bipartite
biregular graphs and applications*, Combin. Probab. Comput. **31** (2022),
229-267, [arXiv:1804.07808v6](https://arxiv.org/abs/1804.07808v6). Their
Equation 7, the biregular Ihara-Bass transfer,

```
λ⁴ - (ξ² - d₁ - d₂ + 2) λ² + (d₁-1)(d₂-1) = 0,
```

relates a non-backtracking eigenvalue `λ` to a singular value `ξ` of the
bipartite adjacency matrix. Their Theorem 3 is the non-backtracking bound
`((d₁-1)(d₂-1))^{1/4} + ε`, their Theorem 4 the adjacency bound
`√(d₁-1)+√(d₂-1)+ε`, for **uniform random biregular graphs** (not for lifts of a
fixed biregular base). Section 3.4 below re-derives their quartic and adds the
two facts the lift application needs.

**[LIT] Local dossiers used.** `.paper-mastery/alon-second-eigenvalue`
(Friedman's theorem, tangle order, `τ_fund`), `.paper-mastery/biregular-spectral-gap`
(quartic, Godsil-Mohar, Feng-Li, Li-Solé), `.paper-mastery/friedman-second-eigenvalue-lifts`
(Bordenave's Theorem 23 on non-backtracking new eigenvalues, `|E|>|V|`
hypothesis, and the explicit statement that the adjacency consequence is
attributed to Friedman-Kohler and restricted to regular bases),
`.paper-mastery/relativized-second-eigenvalue` (Conjecture 0.2.5, Theorem 0.2.6,
Theorem 0.2.7, tangle order, `η_fund`, and the documented source defects).

**What is therefore not new.** The value `ρ(A_T) = √(d₁-1)+√(d₂-1)` is
classical (Godsil-Mohar, Feng-Li, Li-Solé). Qualitative convergence for
arbitrary bases is Bordenave-Collins. The non-backtracking bound for arbitrary
bases is Bordenave. **What is new here** is the elementary two-sided proof of
Section 3.1, the exact quartic injection lemma with its equivariance
(Section 3.4), the resulting quantitative biregular theorem with an explicit
`δ(ε)` (Section 3.5), the exact bound state above the Floquet bands which shows
that the band edge is not the radius (Section 3.3), and the identification of the
conversion step as the exact obstruction for general irregular bases (Section 5).

---

## 3. Exact results

### 3.1 The two-periodic test function gives exactly √a+√b  [PROOF]

Let `T` be the `(d₁,d₂)`-biregular tree, `a = d₁-1 ≥ b = d₂-1 ≥ 1`, rooted at a
vertex `r` of degree `d₁`. Write `k(x) = dist(r,x)`. Vertices at even distance
have degree `a+1`, at odd distance degree `b+1`.

**Theorem 1.** `ρ(A_T) ≤ √a + √b`.

**Proof.** Put `ρ = √a+√b`, `γ = (ab)^{-1/4}`, `c = (c₀,c₁) = (a^{1/4},b^{1/4})`,
and `w(x) = c_{k(x) mod 2} γ^{k(x)}`.

*Root.* `(Aw)(r) = d₁ c₁ γ = (a+1) b^{1/4} (ab)^{-1/4} = (a+1) a^{-1/4}`, and
`(a+1) a^{-1/4} ≤ (√a+√b)a^{1/4} = a + √(ab)`, which is true.

*Non-root vertex at even distance `k ≥ 2`* (degree `a+1`, one neighbour at
`k-1`, `a` neighbours at `k+1`):

```
(Aw)(x) = c₁γ^{k-1} + a c₁γ^{k+1} = c₁γ^k (γ^{-1}+aγ),
γ^{-1}+aγ = (ab)^{-1/4}(√(ab)+a) = (ab)^{-1/4}√a(√a+√b) = (ab)^{-1/4}√a ρ,
c₁γ^{-1}... : c₁(γ^{-1}+aγ) = b^{1/4}(ab)^{-1/4}√a ρ = a^{1/4} ρ = c₀ ρ.
```

So equality holds.

*Non-root vertex at odd distance* (degree `b+1`): the same computation gives
`c₀(γ^{-1}+bγ) = a^{1/4}(ab)^{-1/4}√b ρ = b^{1/4}ρ = c₁ρ`. Equality again.

Hence `Aw ≤ ρw` pointwise with `w > 0`. For any finite subgraph `H` of `T`, the
restriction of `w` is a positive vector with `A_H w_H ≤ ρ w_H`, so by
Collatz-Wielandt `ρ(A_H) ≤ ρ`. Finally `ρ(A_T) = sup_H ρ(A_H)` over finite
subgraphs `H` (because `‖A_T‖ = sup{⟨Af,f⟩ : ‖f‖=1, f finite support}` and every
finite-support vector is supported in a ball). So `ρ(A_T) ≤ √a+√b`. ∎

**Remark 1.0 (why the Friedman-Kohler threshold is exactly the single-exponential optimum).**
Take the one-parameter weight `w(x) = γ^{dist(r,x)}` with a single `γ`. At a
non-root vertex of degree `a+1` the quotient `(Aw)(x)/w(x)` is `γ^{-1}+aγ`,
minimized over `γ>0` at `2√a`. At a vertex of degree `b+1` it is `γ^{-1}+bγ`,
minimized at `2√b`. Both cannot be minimized at the same `γ` unless `a = b`, so
the best bound available from this class is `2√(max(a,b)) = 2√(d_max-1)`, which
is exactly the irregular threshold of Friedman-Kohler. The period-two weight of
Theorem 1 removes the conflict and gains the factor `(2√a)/(√a+√b)`, which tends
to 2 as `b/a → 0`. This is a statement about the test-function class, not a lower
bound for `ρ(A_T)`.

**Remark 1.1.** The weight is exactly the Perron eigenvector of the
two-dimensional "type" quotient evaluated at the critical parameter:
`c₁/c₀ = (b/a)^{1/4}` is the Perron vector of `[[0, A],[B,0]]` with
`AB = ρ²`. This is the same computation as the parabolic condition of the
continued fraction in Section 3.2, seen from the maximization side.

**Remark 1.2.** The matching lower bound `ρ(A_T) ≥ √a+√b` holds and is sharp,
with three independent confirmations:
(i) `[PROOF]` for `b = 1` via the exact subdivision identity, Section 3.2,
Corollary 2.2, which gives the whole spectrum, not only its top;
(ii) `[PROOF]` in general via the periodic Jacobi reduction of Section 3.2,
whose Floquet set contains the interval `[|√a-√b|, √a+√b]`;
(iii) `[NUM]` truncated universal cover balls increase to `√a+√b`, see
`outputs/biregular_checks.txt` and `outputs/checks_extra.txt`: for the
`(3,2)`-biregular base the certified lower bounds are
`2.3114763859, 2.3582944712, 2.3767148313, 2.3880229968` at depths
`6, 9, 12, 15` against `2.4142135624`, and for `(4,2)` they are
`2.6457513111, 2.6698933376, 2.6849232938` at depths `8,10,12` against
`2.7320508076`.

### 3.2 Floquet theory: the radial part, bands, and the exact case b = 1

**Reduction to a Jacobi operator  [PROOF].** For a spherically homogeneous tree
(every vertex at distance `k` from the root has exactly `n_k` children) let
`S_k` be the sphere of radius `k`, `w_k = |S_k| = n₀n₁…n_{k-1}`. On the
subspace of radial functions, `(Af)(k) = n_{k-1}f(k-1) + n_k f(k+1)`. In the
coordinates `g(k) = √(w_k) f(k)` the quadratic form becomes
`2 Σ_k √(n_k) g(k)g(k+1)`, so the radial part of `A_T` is unitarily equivalent
to the Jacobi operator on `ℓ²(ℕ₀)`

```
(Jg)(k) = √(n_{k-1}) g(k-1) + √(n_k) g(k+1).
```

Since `A_T = A_radial ⊕ A_rest`, `σ(A_T) ⊇ σ(A_radial)`. `[PROOF]`, elementary.

**Floquet condition  [PROOF by transfer matrices].** The tail recursion for the
Green's function is `t_k = 1/(λ - n_k t_{k+1})`, a composition of Moebius maps
with matrices `M_k(λ) = [[0,1],[-n_k, λ]]`. If `n_{k+m} = n_k` for all `k ≥ 1`,
put `P(λ) = M₁(λ)…M_m(λ)`. The Moebius map `P` is elliptic or parabolic exactly
when

```
tr P(λ)² ≤ 4 det P(λ),        det P(λ) = n₁n₂…n_m,
```

and by the standard Floquet theory of periodic Jacobi matrices the **essential
spectrum** of the radial part is the closure of that set. `[PROOF]` for the
transfer computation (displayed below), `[LIT]`-standard for the identity
"radial essential spectrum = Floquet set" (periodic Jacobi matrices, see
Teschl's monograph or any treatment of periodic Jacobi operators).
Discrete eigenvalues outside that set are possible when the coefficients fail to
be periodic near the boundary. Section 3.3 gives an exact example in which such a
bound state lies strictly above the top of the bands, so the Floquet edge is not
`ρ(A_T)` in general.

**m = 2, exact.** For tail counts `(n₁,n₂) = (b,a)`:

```
P = M₁M₂ = [[-a, λ],[-λa, λ²-b]],  tr P = λ² - a - b,  det P = ab,
tr P² - 4det P = (λ² - a - b)² - 4ab,
```

so the Floquet set is `|λ² - a - b| ≤ 2√(ab)`, i.e.

```
λ² ∈ [(√a-√b)², (√a+√b)²],
essential spectrum of A_radial = ±[|√a-√b|, √a+√b].
```

**Corollary 2.1.** `[PROOF]` For the `(d₁,d₂)`-biregular tree,
`ρ(A_T) ≥ √a+√b` (radial part), hence with Theorem 1,
`ρ(A_T) = √a+√b`, and `σ(A_T)` contains the two bands `±[|√a-√b|, √a+√b]`. In
particular the spectrum of the universal cover has a **gap** `(-|√a-√b|, |√a-√b|)`
whenever `d₁ ≠ d₂`. For `d₁ = d₂` the gap closes and the classical Kesten value
`2√(d-1)` is recovered.

**Corollary 2.2 (exact spectrum when b = 1).  [PROOF]** If `b = 1` then `T` is
the tree obtained from an `(a+1)`-regular tree by subdividing every edge once.
Indeed every vertex of even distance has degree `a+1` and every vertex of odd
distance has degree 2, each odd vertex having exactly one even neighbour on each
side. For a graph `G` let `S(G)` be its subdivision (one new vertex per edge).
Since `BᵀB = D + A_G = (a+1)I + A_G` for the incidence matrix `B` of `G`,
`spec(A_{S(G)}) = ±√((a+1) + spec(A_G))`. With `G` the `(a+1)`-regular tree,
`spec(A_G) = [-2√a, 2√a]`, so

```
σ(A_T) = ±[√(a+1-2√a), √(a+1+2√a)] = ±[|√a-1|, √a+1].
```

This is `±[|√a-√b|, √a+√b]` with `b = 1`, and it proves both the top edge and the
inner edge exactly, with no Jacobi theory. Check: `a = 2` gives
`±[√2-1, √2+1] = ±[0.4142135624, 2.4142135624]`. `[CALC]` reproduces this to 10
digits from truncated covers, `outputs/biregular_checks.txt`.

**m = 3, exact band polynomials  [CALC]**. `scripts/floquet_bands.py` computes
`tr P² - 4 det P` symbolically. Two examples from `outputs/floquet_bands.txt`:

```
(n₁,n₂,n₃) = (1,2,3):  λ⁶ - 12λ⁴ + 36λ² - 24,
    real roots ±0.9673790506, ±1.8180779107, ±2.7854569613,
    radial bands [-2.785457,-1.818078] ∪ [-0.967379, 0.967379] ∪ [1.818078, 2.785457]

(n₁,n₂,n₃) = (1,1,5):  (λ²-5)(λ⁴ - 9λ² + 4),
    real roots ±0.6847416490, ±2.2360679775, ±2.9208096265.
```

So three-periodic type trees have two or three bands per side, computable
exactly as the real roots of an explicit polynomial. This is a general exact
algorithm for the essential spectrum of the radial part of a periodic-type tree.
It computes `ρ(A_T)` only when no discrete eigenvalue sits above the bands,
which is the case for biregular trees by Theorem 1 but not in general, see
Section 3.3.

### 3.3 The Floquet edge is not the radius: an exact bound state  [PROOF]

**Correction notice.** An earlier version of this dossier claimed that the top
eigenvalue of the example below is carried by non-radial ("angular") components.
That is false. Direct computation shows that the top eigenvalue of every
truncated ball of this tree coincides, to `1e-15`, with the top eigenvalue of the
radial compression (the Jacobi matrix with off-diagonals `√(n_k)`), so the top
eigenvector is radial, `outputs/radial_diagnosis.txt`. What is true, and is
proved below, is that the *Floquet band edge* is not `ρ(A_T)`: the radial part
has a discrete eigenvalue strictly above its essential spectrum, created by the
defect at the root. The negative conclusion survives in this corrected form.

**Proposition 3.** Let `T` be the spherically homogeneous tree with root having
`n₀ = 3` children and with children counts `n₁,n₂,n₃,… = 2,1,2,1,…`. Then:

(i) the essential spectrum of the radial part of `A_T` is
`±[√2-1, √2+1]`, whose top is `√2+1 = 2.4142135624`;
(ii) `λ = √6 = 2.4494897428` is an eigenvalue of the radial part, hence of
`A_T`, with an explicit `ℓ²` eigenvector;
(iii) hence `ρ(A_T) ≥ √6 > √2+1`: the Floquet edge is strictly below the
spectral radius.

**Proof.** Let `b_k = √(n_k)`, so `b₀ = √3` and `b_k = √2` for odd `k` and `1`
for even `k ≥ 2`. The radial eigenvalue equation is
`b_{k-1}u_{k-1} + b_k u_{k+1} = λu_k` for `k ≥ 1` with the root boundary
condition `b₀u₁ = λu₀`.

*The essential spectrum.* By the Floquet computation of Section 3.2 with tail
counts `(n₁,n₂) = (2,1)`, the bands are `|λ² - 3| ≤ 2√2`, that is
`±[√2-1, √2+1]`. Part (i) is that identity, which is `[LIT]`-standard periodic
Jacobi theory plus the transfer computation already displayed.

*The eigenvector.* Put `λ = √6`, `u₀ = 1`, `u₁ = √2`, `u₂ = √(3/2)`, `u₃ = 1`,
`u₄ = √3/2`, and extend by `u_{k+2} = u_k/√2` for `k ≥ 3`. The root condition
reads `√3·√2 = √6 = λu₀` and holds exactly. The residuals
`r_k = b_{k-1}u_{k-1} + b_k u_{k+1} - λu_k` vanish identically for `k = 1,…,6`
(checked exactly in `outputs/bound_state_check.txt`). Since `b_{k+2} = b_k` and
`b_{k+1} = b_{k-1}` for `k ≥ 2`, and since the scaling `u ↦ u/√2` is linear,
`r_{k+2} = r_k/√2`. Hence `r_k = 0` for all `k ≥ 1`. The sequence is square
summable with `Σu_k² = 8` and decay `|u_k| ≤ 2^{-k/4+1}`, so `u ∈ ℓ²`. Therefore
`λ = √6` is an eigenvalue of the radial part, and the radial part is an
invariant subspace of `A_T`. This proves (ii) and (iii).
∎

**Corroboration. [NUM]** `outputs/radial_diagnosis.txt`:
the top eigenvalue of the ball of radius `D` and of the radial Jacobi matrix of
size `D+1` agree to `1e-14` at `D = 6, 9, 12, 15, 18`, both reaching
`2.4488676957068` at `D = 15`. The radius-15 ball has `1528` vertices and the
residual of its top eigenvector is `3e-15`. Jacobi truncations of sizes
`100, 200, 400` have **exactly one** eigenvalue above `√2+1`, namely
`2.44948974278318 = √6` to all printed digits, while the second largest
increases to the band top (`2.4129, 2.4139, 2.4141`). This is exactly the
profile of an isolated eigenvalue above an absolutely continuous band.

**Interpretation.** The correct negative result is this: `ρ(A_T)` is not a
function of the degree sequence computed through the Floquet or continued
fraction band condition, because that condition gives only the essential
spectrum. A single type defect, here the root having one neighbour more than the
periodic pattern would give (`b₀ = √3` against the periodic value `1`), creates a
bound state above the bands, exactly as a local potential well creates a bound
state above the continuous spectrum in Schrödinger theory. For biregular trees no
such bound state exists, because Theorem 1 gives `ρ(A_T) ≤ √a+√b` and the
essential spectrum already reaches `√a+√b`. The example tree is not biregular,
and deliberately so: its root has degree 3 and its neighbours also have degree 3,
while vertices at even distance have degree 2, so the phase relation between root
degree and tail that Theorem 1 requires is violated. That is exactly why no
contradiction with Theorem 1 arises. So the phenomenon is genuinely a feature of
irregular type structure, but its mechanism is a discrete radial eigenvalue, not
angular components.

What survives, and is now the operational method, is a rigorous two-sided
computational scheme for `ρ(A_T)`: truncated cover balls give **certified lower
bounds** increasing to `ρ(A_T)`, and positive test functions `w` with `Aw ≤ λw`
give **certified upper bounds** (Collatz-Wielandt). Theorem 1 is the sharp
instance of the second half. In `outputs/experiments_final.txt` the scheme pins
`ρ(A_T)` to within about `0.02` for the Bordenave-Collins base (`2.8453` at depth
21 against their `2.866`) and for the `(3,3,3,3,2)` base (`2.7087` at depth 18).

**Three different criteria, which must not be conflated.**

1. *Floquet (elliptic) condition* on the period transfer matrix: gives the
   **essential spectrum** of the radial part, i.e. the bands. Computed exactly in
   Section 3.2 for `m = 2` and via the polynomial `tr P² - 4 det P` in general.
2. *Positivity of the continued fraction* (a positive solution of the tail
   system, equivalently a positive λ-harmonic function on the tree): gives the
   **radius** `ρ(A_T)`, which can be strictly larger than the top band because of
   a discrete bound state, as in Proposition 3. A single exponential weight is
   the crudest instance (Remark 1.0).
3. *Oriented-edge system* for trees that are not spherically homogeneous (the
   universal cover of a base with several vertex degrees in an irregular
   pattern): here the top eigenvector need not be radial, so a vertex-type system
   is not enough and the system must be indexed by oriented-edge types
   `y_k = 1/(λ - n_k y_{k+1})` and `z_k = 1/(λ - z_{k-1} - (n_k-1)y_{k+1})`
   for the spherically homogeneous case, with one equation per oriented-edge
   type in general.

Criterion 1 was used correctly for the biregular bands. Criterion 2 is what
Theorem 1's weight provides. Criterion 3 is the object needed in Section 5.

### 3.4 The biregular quartic correspondence: derivation, injection, equivariance

**Setting.** `G` is a `(d₁,d₂)`-biregular graph with bipartition `L ∪ R`, every
`L`-vertex of degree `d₁`, every `R`-vertex of degree `d₂`. `X` is the `L × R`
bipartite adjacency matrix. `H` is the Hashimoto matrix on directed edges
`(u → v)`: `(Hh)(u→v) = Σ_{w ~ v, w ≠ u} h(v→w)`.

**Lemma 4 (quartic correspondence).  [PROOF]** Let `ξ` be a real singular value
of `X` with singular vectors `f` (on `L`) and `g` (on `R`), so `Xg = ξf` and
`Xᵀf = ξg`. Let `w` be a root of

```
w² - (ξ² - a - b) w + ab = 0,       a = d₁-1, b = d₂-1,      (Q)
```

and `μ` a square root of `w`. Then `μ` is an eigenvalue of `H`, with eigenvector

```
h(u→v) = A f(u) + B g(v)     (u ∈ L, v ∈ R)
h(v→u) = A' g(v) + B' f(u),
```

where `(A,B) ≠ (0,0)` solves `A/B = -ξ/(μ²+a)`, `A' = -B/μ`, `B' = -μA`.

**Proof.** Apply `H` to `h` at a state `(u→v)` with `u ∈ L`, `v ∈ R`. The
non-backtracking successors are the states `(v→w)` with `w ∈ L`, `w ~ v`,
`w ≠ u`. Then

```
(Hh)(u→v) = Σ_{w ∈ L, w~v, w≠u} [A' g(v) + B' f(w)]
          = (d₂-1) A' g(v) + B'( (Xᵀf)(v) - f(u) )
          = (d₂-1) A' g(v) + B'( ξ g(v) - f(u) ).
```

Matching coefficients against `μ(A f(u) + B g(v))` gives

```
-B' = μA,        (d₂-1)A' + ξB' = μB.                       (1)
```

The same computation at a state `(v→u)`, `v ∈ R`, `u ∈ L`, using `Xg = ξf` and
`d₁ = a+1`, gives

```
-B = μA',        (d₁-1)A + ξB = μB'.                        (2)
```

Substituting `B' = -μA` and `A' = -B/μ` into (1) and (2):

```
(d₂-1)(-B/μ) + ξ(-μA) = μB  →  A ξ μ² = -B(μ² + d₂ - 1),
(d₁-1)A + ξB = -μ²A        →  A(μ² + d₁ - 1) = -ξ B.
```

Eliminating `A/B` gives `(μ²+a)(μ²+b) = ξ² μ²`, which after the substitution
`w = μ²` is exactly (Q). The vector `h` is nonzero because `A/B ≠ 0` when
`ξ ≠ 0` and `μ ≠ 0` (`μ = 0` would force `ab = 0`). ∎

This reproduces Equation 7 of Brito-Dumitriu-Decker Harris, with a proof
short enough to check by hand.

**Lemma 4.1 (injection and sign pattern).  [PROOF]** Fix `ξ ≥ 0` and let `w₊, w₋`
be the two roots of (Q), with `w₊w₋ = ab`. Then:

(i) if `ξ > √a+√b`, both roots are real and positive, `w₋ < √(ab) < w₊`, and
`|√w₊| = √(w₊) > (ab)^{1/4}`;
(ii) if `0 ≤ ξ < |√a-√b|` (only possible when `a ≠ b`), both roots are real and
negative;
(iii) if `|√a-√b| < ξ < √a+√b`, the roots are a complex conjugate pair.

Distinct singular values produce disjoint sets of eigenvalues of `H`, because
`ξ` is recovered from `μ` by `ξ² = μ² + ab/μ² + a + b`.

**Proof.** The discriminant is `D = (ξ²-a-b)² - 4ab`. Since
`(√a+√b)² = a+b+2√(ab)` and `(√a-√b)² = a+b-2√(ab)`, the inequality `D ≥ 0` is
equivalent to `|ξ²-a-b| ≥ 2√(ab)`, which is equivalent to `ξ² ≥ (√a+√b)²` or
`ξ² ≤ (√a-√b)²`. In case (i), both the sum `ξ²-a-b` and the product `ab` of the
roots are positive, so both roots are positive, and their product is `ab`. In
case (ii) the sum is negative
and the product positive, so both roots are negative. Case (iii) is the
remaining range. The recovery formula is a rearrangement of (Q). ∎

**Lemma 4.2 (equivariance).  [PROOF]** In the situation of Lemma 4, let `Γ` be a
group of automorphisms of `G` acting on `L` and on `R` separately and preserving
`X`. The map `(f,g) ↦ h` of Lemma 4 is `Γ`-equivariant: `h(γf, γg) = γ h(f,g)`
for all `γ ∈ Γ`, because the coefficients `A,B,A',B'` depend only on `ξ` and on
the chosen root `w`, not on the vertex. Consequently, for an `n`-lift whose deck
group acts with fibre-constant functions as its invariant subspace, a *new*
singular value `ξ` (one whose singular space is not contained in the
fibre-constant space) produces a *new* non-backtracking eigenvalue `μ`.

**Proof.** Equivariance is immediate from the displayed formula for `h`, since
`f` on `L` and `g` on `R` are acted on separately and the coefficients are
scalars. A `Γ`-equivariant linear map sends the `Γ`-nontrivial part of the
singular space into the `Γ`-nontrivial part of the corresponding eigenspace.
For the permutation lift model the invariant functions on `V(G)` are exactly the
fibre-constant ones, because the edge permutations at a vertex generate the full
symmetric group on its fibre, so nontrivial means new. ∎

**Lemma 4.3 (from adjacency outliers to non-backtracking outliers).  [PROOF]**
Let `ξ` be a new singular value of an `n`-lift of a `(d₁,d₂)`-biregular base and
suppose `|ξ| ≥ √a+√b+ε`. Then `H` has a new eigenvalue `μ` with

```
|μ| ≥ (ab)^{1/4} + δ,     δ = δ(ε,a,b) > 0,
δ = √( (ξ²-a-b+√((ξ²-a-b)²-4ab))/2 ) - (ab)^{1/4}.
```

**Proof.** Take the root `w₊` of Lemma 4.1(i), `μ = √(w₊) ≥ (ab)^{1/4}`, and
apply Lemma 4.2. The function `ξ ↦ w₊(ξ)` is continuous and strictly increasing
on `(√a+√b, ∞)` with `w₊(√a+√b) = √(ab)`. ∎

`[CALC]` The injection has zero violations on the three test graphs in
`outputs/biregular_checks.txt` (subdivision of `K₄`, subdivision of `K₅`,
Heawood), and the quartic reproduces `16/24`, `20/40`, `28/42` non-backtracking
eigenvalues respectively, the remainder being the "spurious" eigenvalues counted
in Remark 4.4.

**Remark 4.4 (spurious count).  [PROOF]** `H` has `2|E| = 2nd₁` eigenvalues
(`n = |L|`). Lemma 4 produces four eigenvalues per singular value of `X`, and `X`
has `n` singular values, so `4n` eigenvalues are accounted for and
`2n(d₁-2)` are not. These spurious eigenvalues are the analogue of the `±1`
eigenvalues of the Hashimoto matrix of a regular graph. Note `w = 1` and
`w = ab` both give `ξ² = (a+1)(b+1) = d₁d₂`, which is the trivial singular value,
so the two trivial non-backtracking radii are `1` and `√(ab)`, with
`ρ(H) = √(ab)`.

### 3.5 The relativized upper edge for biregular bases

**Theorem 5.  [PROOF, conditional on the quoted external theorems]** Let `B` be
a connected `(d₁,d₂)`-biregular graph with `d₁ ≥ d₂ ≥ 2` and
`(d₁-1)(d₂-1) > 1`, and let `G` be a random `n`-lift in the permutation model.
Then for every `ε>0`, for all `n` large,

```
Pr[ ρ_B^new(A_G) ≤ √(d₁-1) + √(d₂-1) + ε ] → 1,
```

which is the conclusion of Friedman's 2003 conjecture with the optimal threshold
`ρ(A_B̂) = √(d₁-1)+√(d₂-1)`. Moreover, if the Hashimoto theorem of Friedman and
Kohler (their Theorem 0.2.6, applied with `τ₀ = ((d₁-1)(d₂-1))^{1/4}`) is
available, the exceptional probability is `O_{B,ε}(n^{-1})`.

**Proof.** Let `ξ` be a new singular value of the lift with
`|ξ| ≥ √a+√b+ε`. By Lemma 4.3 there is a new eigenvalue `μ` of `H_G` with
`|μ| ≥ (ab)^{1/4}+δ(ε)`. Every `n`-lift of `B` is again `(d₁,d₂)`-biregular, so
its non-backtracking Perron eigenvalue is `ρ(H_G) = √(ab)` (the all-ones
eigenvector, Remark 4.4). Bordenave's Theorem 3, applied to the base `B`, gives
that the largest new non-backtracking eigenvalue of the lift is at most
`√ρ(H_B) + δ = (ab)^{1/4}+δ` with probability tending to one, for the choice
`δ = δ(ε)`. This contradicts the displayed lower bound. Hence all new singular
values satisfy `|ξ| ≤ √a+√b+ε`. The adjacency spectrum of a bipartite graph is
`±` its singular values, and the new part of the adjacency spectrum corresponds
to the new singular values, so `ρ_B^new(A_G) ≤ √a+√b+ε`. The `O(n^{-1})` rate is
the same argument with Friedman-Kohler Theorem 0.2.6 in place of Bordenave's
Theorem 3, using `ρ(H_G) ≤ τ₀²` (equality) and the Kotani-Sunada bound for
non-real non-backtracking eigenvalues, which for biregular graphs follows from
Lemma 4.1(iii): every non-real branch has `|w| = √(ab)`, so
`|μ| = (ab)^{1/4}`. ∎

**Remark 5.1 (why this is not new qualitatively).** Theorem 5 is a special case
of Bordenave-Collins 2019, which gives Hausdorff convergence for arbitrary bases
in probability. Its content is the explicit threshold identification, the
elementary route, and the polynomial rate. It does not claim a new qualitative
theorem. `[CONJ]` I believe the `O(n^{-1})` statement is not in the literature
for any irregular base, and the fine tangle exponent is not even defined there.

**Remark 5.2 (numerical check).  [NUM]** `outputs/lift_scan_final.txt`:

```
(3,2)-biregular, subdivision of K4; thresholds: √a+√b = 2.414214,
    2√(d₁-1) = 2.828427, √3(√a+√b) = 4.181541
  n=  5   max|new| = 2.379546 ± 0.018
  n= 20   max|new| = 2.407304 ± 0.0057
  n= 60   max|new| = 2.412075 ± 0.0019

(4,2)-biregular, subdivision of K5; thresholds: √3+1 = 2.732051, 2√3 = 3.464102
  n= 60   max|new| = 2.729582 ± 0.0027
```

The new spectrum approaches the predicted edge from below and stays far below
both `2√(d₁-1)` and `√3(√a+√b)`. For `(4,2)` the Friedman-Kohler threshold
overestimates the truth by a factor approaching `2√a/(√a+√b)`, which tends to
`2√(d₁-1)/(√(d₁-1)+1) → 2` as `d₁ → ∞` with `d₂ = 2`.

**Remark 5.3 (the gap survives).  [NUM]** For the same `(3,2)` lifts, the open
gap is `(-0.4142135624, 0.4142135624)`. Counting new eigenvalues in the open gap
with `|λ| > 1e-5` gives zero in every trial for `n = 5, 10, 20, 40, 60`
(`outputs/gap_test_final.txt`). The only new eigenvalues in the gap are exactly
`0`, forced by the unequal bipartition sizes (`20` versus `30` at `n = 5`, so
`10` forced zeros). This is consistent with Bordenave-Collins's two-sided
Hausdorff statement and with the Godsil-Mohar point mass at `0` of size
`|d₁-d₂|/(2(d₁+d₂))`, which here equals `1/10`.

---

## 4. The general irregular case: where exactly it breaks

For a graph of non-constant degrees the Ihara-Bass determinant formula reads

```
det(I - tH) = (1-t²)^{|E|-|V|} det(I - tA + t²(D - I)),
```

with `D` the diagonal degree matrix. Setting `μ = 1/t` and multiplying by `μ²`,
an eigenvalue `λ` of `A` and a non-backtracking eigenvalue `μ` are related only
through the *matrix pencil*

```
(A - μ^{-1}(D - I)) f = μ f,      equivalently   (D-I) - μA + μ² I = 0,
```

which is not a scalar quadratic unless `D` is constant. In the regular case
`D = dI` gives `μ² - λμ + (d-1) = 0`. In the biregular case, the two vertex
classes give the two quadratics `μ² - λμ + (c-1) = 0` and `μ² - λμ + (d-1) = 0`
which are incompatible, and that incompatibility is exactly what forces the
quartic (Q) instead. For general irregular `D` there is no per-eigenvalue
equation at all.

**The quantitative consequence. [PROOF]** For any tree `T` and any `λ > 0` with a
positive solution of the tail system, `Aw ≤ λw` for a suitable `w`. In
particular the single-exponential choice gives

```
ρ(A_T) ≤ 2√(Δ-1),    Δ = max degree of T,
```

with equality if and only if `T` is `Δ`-regular. In the two families where
both quantities are known exactly, the adjacency radius satisfies
`ρ(A_T) = √a+√b ≥ 2(ab)^{1/4} = 2√(ρ(NB T))`, with equality if and only if
`a = b`, that is if and only if `T` is regular. The deficit is
`√a+√b - 2(ab)^{1/4} = (a^{1/4}-b^{1/4})²`.
So the Angel-Friedman-Hoory identity `ρ(NB T) = √ρ₁` converts into the adjacency
threshold only for regular trees, and the loss is exactly `(a^{1/4}-b^{1/4})²` in
the biregular case.

---

## 5. A feasible theorem target and the single hardest missing estimate

**Target theorem.** *Let `B` be a finite connected graph with minimum degree at
least 2 and let `T = B̂`. Then for every `ε>0` there are `C(B,ε)` and
`η(B,ε) > 0` with*

```
Pr[ ρ_B^new(A_G) ≥ ρ(A_T) + ε ] ≤ C n^{-η}
```

*for random `n`-lifts `G`, with the threshold `ρ(A_T)` sharp.*

**Why it is feasible.** The upper edge `ρ(A_T)` is correct (Friedman 2003,
Bordenave-Collins 2019). The trace method that produces polynomial probability
already exists for non-backtracking eigenvalues on arbitrary bases
(Bordenave 2019, Friedman-Kohler). What is missing is one conversion step.

**The missing estimate, stated exactly.** *A degree-aware conversion lemma.*
Find a function `Φ_B : ℂ → ℝ` with the two properties

```
(i)  for every cover G of B and every adjacency eigenvalue λ of A_G with
     a nontrivial deck-group component, there is a non-backtracking eigenvalue
     μ of H_G in the same component with |μ| ≥ Φ_B(λ),
(ii) Φ_B(λ) > √ρ(H_B) whenever λ > ρ(A_T) + ε.
```

In the biregular case `Φ_B` exists and equals the increasing branch of the
quartic (Lemma 4.3). In the regular case it is the Ihara quadratic. In general
it does not exist as a function of `λ` alone, precisely because the pencil
`(D-I) - μA + μ²I = 0` couples `λ`, `μ` and the degree vector. Two ways to
repair it, in order of my current preference:

**(a) Degree-weighted non-backtracking operator.** Replace `H` by the operator
on directed edges with weights depending on the head vertex, e.g.
`(H_θ h)(u→v) = Σ_{w~v, w≠u} θ_v^{-1/2} θ_w^{1/2} h(v→w)` for a suitable positive
`θ`. This is a diagonal similarity of `H`, so its spectrum is unchanged, but its
*truncations* and its radial eigenfunctions are degree-aware, and the
corresponding trace method should produce the threshold `ρ(A_T)` directly. The
critical estimate is the growth of `‖(H_θ^s) δ_e‖₁` along the base, replacing
Bordenave's Lemma 31 (`‖(B*)^s δ_e‖₁ ≤ c_ρ ρ^s`) by a version with
`ρ = ρ(A_T)`. Conjecture `[CONJ]`: such a weighted version exists with
`ρ` replaced by the "Collatz-Wielandt radius" of the degree-weighted operator,
which equals `ρ(A_T)` for trees with a finite-type quotient.

**(b) A two-variable side-stepping.** Keep `H`, but let the side-stepping lemma
produce information about the pencil `(D-I) - μA + μ²I` directly, i.e. treat
`μ` as a matrix-valued variable. The technical difficulty is that the
side-stepping proof uses a scalar polynomial `Q(S)` in the shift operator to
annihilate known exponential bases, and matrix-valued bases would need a
non-commutative version.

**Why the band-edge shortcut is not a way out.** Section 3.3 shows that the
Floquet band edge can lie strictly below `ρ(A_T)` (an exact bound state at `√6`
against bands topping at `√2+1`), so no argument that reads `ρ(A_T)` off the
radial band computation can be correct. This rules out the most tempting
simplification without contradicting the radial nature of the top eigenvector.

---

## 6. Unresolved steps and what evidence would decide them

1. **Is `Φ_B` (Section 5) ever available beyond biregular?** Decisive evidence
   would be an explicit base with three distinct degrees where a new adjacency
   outlier provably does *not* force a new non-backtracking outlier above
   `√ρ(H_B)`. A numerical search over small bases with three degree values,
   comparing `max|new adjacency|` to the largest real eigenvalue of `H_G` outside
   the bulk, would either find such a base or support the general conversion.
   `[NUM]` preliminary: for the `(3,3,3,3,2)` base, `max|new| = 2.730` at `n=60`
   while the largest new non-backtracking eigenvalue was not recorded, so this
   experiment is still open.
2. **Is the `O(n^{-1})` rate optimal for biregular bases?** The Friedman-Kohler
   fine exponent `η_fund(B)` is defined only for regular bases. For biregular
   bases the natural candidate is the least order of a strict feasible
   `B`-subgraph with non-backtracking radius exceeding `(ab)^{1/4}`; the
   `(3,2)`-biregular base with its unique shortest cycle gives an explicit
   candidate. `[CONJ]`
3. **Does the gap survive with polynomial probability?** The gap of `σ(A_T)` for
   `a ≠ b` is invisible to moduli of non-backtracking eigenvalues: from
   `ξ² = μ² + ab/μ² + a + b`, a real `ξ` with `|ξ| < |√a-√b|` corresponds to a
   purely imaginary `μ` with `|μ| ∈ (√b, √a)` (Lemma 4.1(ii)), and conversely an
   imaginary non-backtracking eigenvalue of modulus in `(√b, √a)` that lies in
   the range of the correspondence gives `|ξ| < |√a-√b|` (spurious eigenvalues
   are not covered by this). A polynomial-probability gap theorem therefore needs
   a *lower* bound on `|μ|` on the imaginary axis, which is a genuinely different
   estimate from anything in the trace-method literature. `[NUM]` the gap holds
   in all trials so far, `outputs/gap_test_final.txt`.
4. **Quantitative lower edge.** Bordenave-Collins give Hausdorff convergence, so
   the new spectrum also fills the bands. No quantitative (rate) statement is
   known, and the natural attack is again a second-moment computation on the
   twisted adjacency, not on `H`.

---

## 7. Prioritized next steps

1. Implement experiment 1 of Section 6 (three-degree bases, with the largest new
   non-backtracking eigenvalue computed separately in the fibre-constant
   complement of the directed-edge space). Cost: one script. Payoff: decides
   whether `Φ_B` can be degree-blind.
2. Compute `ρ(A_T)` for the `(3,3,3,3,2)` base and the Bordenave-Collins base
   with the certified two-sided scheme to `1e-3` (cover balls with sparse
   eigensolvers at depth `25` to `30`, plus a Collatz-Wielandt weight built from
   the ball's Perron vector). Payoff: a table of thresholds, and a check of how
   far the true radius sits above the top band.
3. Turn criterion 3 of Section 3.3 into an algorithm: for a type-finite tree the
   oriented-edge continued fraction system is finite, and its positivity
   threshold is `ρ(A_T)`. Payoff: an exact `ρ(A_T)` for all universal covers of
   graphs with a vertex-transitive quotient, and a cheap way to decide whether a
   computed band edge is the radius or only the essential spectrum.
4. Test the weighted-operator conjecture of Section 5(a) numerically: build
   `H_θ` for a small irregular base, compute its radial eigenvalues, and check
   whether the top is `ρ(A_T)`.
5. Literature: check whether the polynomial-probability relativized bound for
   irregular bases appears in the Puder or Linial-Puder line (their moment
   methods also give `n^{-c}` bounds in some ranges), and whether the "weak
   Ramanujan" terminology of Bordenave's Section 4 has been strengthened.

---

## 8. Common ground with the four source dossiers

- **`.paper-mastery/alon-second-eigenvalue`.** The regular threshold `2√(d-1)`
  is the special case `a = b = d-1` of Theorem 1. The tangle/rare-defect
  mechanism is the source of the polynomial probability in Theorem 5, and the
  "single exponential test function" remark of Section 3.1 explains why the
  irregular threshold `2√(d_max-1)` is exactly the optimum of the unrefined
  version of the same estimate that Friedman's tangle analysis refines.
- **`.paper-mastery/biregular-spectral-gap`.** Equation 7 of that paper is
  Lemma 4 here, with an independent proof. Their Theorem 4 (random biregular
  graphs) and Theorem 5 here (lifts of a fixed biregular base) are different
  models with the same threshold, and Godsil-Mohar's support interval is exactly
  `σ(A_T)`.
- **`.paper-mastery/friedman-second-eigenvalue-lifts`.** Bordenave's Theorem 23
  is the quantitative input for the non-backtracking side, and his explicit
  remark that the adjacency consequence of his Corollary 24 is restricted to
  regular bases is exactly the gap that Lemma 4.3 fills for biregular bases.
  His `|E|>|V|` hypothesis is satisfied for biregular bases with
  `(d₁-1)(d₂-1) > 1`.
- **`.paper-mastery/relativized-second-eigenvalue`.** Conjecture 0.2.5 is
  Friedman's conjecture. Theorem 5 verifies it for biregular bases with the
  exact threshold and an explicit rate, conditionally on Theorem 0.2.6.
  Theorem 0.2.7 (the `2√(d_max-1)` bound) is strictly weaker than Theorem 1's
  threshold, with the exact loss `2√a - (√a+√b)`. The dossier's documented
  source defects (Theorem 3.3.2, Theorem 3.3.4) do not affect Theorem 0.2.6.

Other directions in the swarm: `d1` (hypergraph clique-expansion gap
normalization) is adjacent through the incidence-graph realisation of
`k`-uniform `d`-regular hypergraphs, which are exactly `(d,k)`-biregular
bipartite graphs. Theorem 1 then gives the universal-cover threshold
`√(d-1)+√(k-1)` for the *incidence* spectrum of such a hypergraph, which is the
object that `d1` calls the "corrected" gap. `d2` (abelian covers of periodic
graphs) shares the Floquet technology of Section 3.2 but in the dual direction:
there the quotient spectrum samples a fixed band structure, here the band
structure itself is the object.

---

## 9. Status ledger

| Item | Status |
| --- | --- |
| Friedman 2003 conjecture statement | [LIT] arXiv:1502.04482v4 Section 4, arXiv:1212.5216 Section 1 |
| `2√(d_max-1)` irregular theorem | [LIT] arXiv:1403.3462v1 Theorem 0.2.7 |
| Friedman-Kohler Hashimoto theorem 0.2.6 | [LIT], with the local dossier's source cautions on other statements |
| Bordenave's new non-backtracking bound for arbitrary bases | [LIT] arXiv:1502.04482v4 Theorem 3 |
| Bordenave-Collins Hausdorff convergence for arbitrary bases | [LIT] arXiv:1801.00876, Theorem `th:main` |
| Puder's `√3 ρ` | [LIT] arXiv:1212.5216 abstract and Section 1 |
| Godsil-Mohar support interval, Feng-Li, Li-Solé | [LIT] as reported in arXiv:1804.07808v6 Section 1 |
| `ρ(A_T) = √a+√b` for biregular trees | [PROOF] Section 3.1 + Corollary 2.1 (and classical, Godsil-Mohar) |
| Floquet band formula, `m=2` exact, `m=3` polynomials | [PROOF] + [CALC] Section 3.2, `outputs/floquet_bands.txt` |
| Exact `σ(A_T)` for `b = 1` via subdivision | [PROOF] Corollary 2.2 |
| Bound state above the Floquet bands (band edge is not the radius) | [PROOF] Proposition 3 plus [NUM] corroboration |
| Quartic correspondence, injection, equivariance | [PROOF] Lemmas 4, 4.1, 4.2, 4.3 |
| `O(n^{-1})` biregular relativized bound | [PROOF] Theorem 5, conditional on Theorem 0.2.6 |
| Numerical band edges and lift spectra | [NUM] `outputs/biregular_checks.txt`, `outputs/lift_scan_final.txt` |
| Gap survival | [NUM] `outputs/gap_test_final.txt`, plus [PROOF] of the imaginary-axis correspondence |
| Fine exponent `η_fund` for biregular bases | [CONJ] Section 6 item 2 |
| General conversion lemma `Φ_B` | open, Section 5 |
