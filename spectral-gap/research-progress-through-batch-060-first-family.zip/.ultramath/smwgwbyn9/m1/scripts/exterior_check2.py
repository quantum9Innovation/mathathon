import numpy as np, scipy.sparse as sp, scipy.sparse.linalg as spla
from collections import deque

def config_regular(n, d, rng):
    while True:
        stubs = np.repeat(np.arange(n), d); rng.shuffle(stubs)
        a = stubs[0::2]; b = stubs[1::2]
        if np.any(a == b): continue
        lo = np.minimum(a,b).astype(np.int64); hi=np.maximum(a,b).astype(np.int64)
        key = lo*n+hi
        if len(np.unique(key)) != len(key): continue
        return sp.coo_matrix((np.ones(2*len(a)), (np.concatenate([a,b]), np.concatenate([b,a]))), shape=(n,n)).tocsr()

def km_moments(d,K):
    a=[0]*(K+1); b=[0]*(K+1); a[0]=1
    for j in range(1,K+1):
        a[j]=d*b[j-1]; b[j]=a[j-1]+(d-1)*b[j-1]
    return a

def tree_radius(A,y,Lmax):
    n=A.shape[0]; seen=np.zeros(n,bool); seen[y]=True
    frontier=[y]; verts=1; edges=0
    for depth in range(1,Lmax+1):
        nf=[]
        for u in frontier:
            nb=A.indices[A.indptr[u]:A.indptr[u+1]]
            edges += len(nb)
            for w in nb:
                if not seen[w]: seen[w]=True; verts+=1; nf.append(w)
        frontier=nf
        if not frontier: break
        if edges//2 != verts-1: return depth-1
        return_at=depth
    verts_idx=np.nonzero(seen)[0]
    return Lmax

def g_d(lam,d):
    disc=lam*lam-4*(d-1); r=(lam-np.sqrt(disc))/(2*(d-1)); return r/(1-r*r), r

d=3; rng=np.random.default_rng(20260514)
n=2000; A=config_regular(n,d,rng)
K=14; m=km_moments(d,K)
P=sp.identity(n,format='csr'); viol=0; checked=0; per={}
for k in range(1,K+1):
    P=(P@A).tocsr()
    for y in rng.choice(n,40,replace=False):
        L=tree_radius(A,y,7)
        if 2*L>=k:
            checked+=1; val=int(round(P[y,y]))
            per.setdefault(k,[0,0]); per[k][0]+=1
            if val!=m[k]: viol+=1; per[k][1]+=1
print("KM moments d=3:",m[:13])
print("moment identity: checked",checked,"pairs (y,k) with k<=2L(y); violations =",viol)
print("per-k [checked,violations]:",per)

print("\n--- deviation vs n, fixed T ---")
def dev(n,d,lam,Delta,seeds=5,label='fixed'):
    out=[]
    for s in range(seeds):
        r=np.random.default_rng(7000+s)
        A=config_regular(n,d,r)
        T=np.arange(Delta) if label=='fixed' else r.choice(n,Delta,replace=False)
        x=np.zeros(n); x[T]=1.0
        z=spla.spsolve((A-lam*sp.identity(n,format='csr')).tocsc(), x)
        out.append(float(x@z))
    G,_=g_d(lam,d); return G, np.abs(np.array(out)+Delta*G)
for lam in (2.95,3.3):
    G,rr=g_d(lam,d); print(f"\nlam={lam} r={rr:.6f} G_d={G:.6f}")
    for Delta in (1,2):
        for n in (250,500,1000,2000,4000,8000):
            G,dev_=dev(n,d,lam,Delta)
            print(f"  D={Delta} n={n:5d} med={np.median(dev_):.3e} max={dev_.max():.3e} med*n^0.5={np.median(dev_)*np.sqrt(n):.4f}")
