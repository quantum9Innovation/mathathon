# Batch 050 / member m2 (role 6): the fixed-host resolvent limit is TRUE

**Status.** The missing estimate (H) of `.ultramath/smwgfcleu/m5/DOSSIER.md` is proved,
with probability tending to 1 (hence in probability). Consequently the fixed-point law
$\lambda_1,\lambda_2(G'_n)\to\max/\min(d,\lambda_f)$ and the finite-size law
$n(d-\lambda_2)\to\Delta^2/(\Delta G_d(d)-d)$ are theorems, not conjectures. The proof
imports exactly one nontrivial external theorem (Bordenave/Friedman second eigenvalue
bound). Two refutations accompany it: the fixed-$T$ resolvent limit is **not**
determined by local weak convergence + empirical spectral measure, and the one-sided
tree branch $-r(\lambda)$ is off by the factor $1/(1-r^2)$.

Notation follows the dossier: $G_n$ uniform simple $d$-regular on $V=[n]$, $d\ge3$ fixed,
$T\subseteq V$ fixed with $|T|=\Delta$; $G'_n$ = $G_n$ plus one new vertex $x$ adjacent to
exactly $T$; $A=A_{G_n}$; $\mu_{\mathrm{KM},d}$ the Kesten--McKay measure;
$r(\lambda)$ the root of $(d-1)r+1/r=\lambda$ with $|r|<1$;
$G_d(\lambda)=\int \mathrm{d}\mu_{\mathrm{KM},d}(t)/(\lambda-t)=r/(1-r^2)$ for
$\lambda\notin[-2\sqrt{d-1},2\sqrt{d-1}]$;
$\mathbf 1_T\in\mathbb R^n$ the indicator of $T$;
$\Sigma_n(\lambda)=\lambda+\mathbf 1_T^\top(A-\lambda I)^{-1}\mathbf 1_T$;
$f(\lambda)=\lambda-\Delta G_d(\lambda)$; $\lambda_f$ the root of $f$ in
$(2\sqrt{d-1},\infty)$ when it exists ($\iff\Delta>2(d-2)$).

---

## 0. The results

**Theorem A (fixed-host resolvent limit; = hypothesis (H) of the dossier, proved).**
Fix $d\ge3$ and a fixed finite $T$. Let $K\subset(2\sqrt{d-1},d)\cup(d,\infty)$ be compact
and let $L_n=\lfloor c\log_{d-1}n\rfloor$ with $c\in(0,\tfrac12)$. There are constants
$C=C(d,\Delta,K)$ and $\rho=\rho(d,K)\in(0,1)$ such that for every $n$ (with $dn$ even),
with probability at least $1-Cn^{-1/2}$,
$$
\sup_{\lambda\in K}\Big|\mathbf 1_T^\top(A-\lambda I)^{-1}\mathbf 1_T+\Delta G_d(\lambda)\Big|
\;\le\; C\Big(\rho^{L_n}+(d/\lambda_{\min})^{L_n}/n+\tfrac1n\Big)\;\longrightarrow\;0 .
$$
In particular the convergence holds uniformly on $K$ with probability $\to1$, which is
stronger than the "in probability, uniformly on $K$" asked for in (H).

**Theorem B (limiting eigenvalues).** With $\lambda_f:=2\sqrt{d-1}$ when $\Delta\le 2(d-2)$,
$$
\lambda_1(G'_n)\xrightarrow{\ \mathbb P\ }\max(d,\lambda_f),\qquad
\lambda_2(G'_n)\xrightarrow{\ \mathbb P\ }\min(d,\lambda_f),
$$
and both hold with probability $1-o(1)$. (Both orderings occur: $\lambda_f>d$ iff
$\Delta>d^2(d-2)/(d-1)$.)

**Theorem C (finite-size law; upgrades §2.5 of the dossier from numerics to theorem).**
If $\Delta G_d(d)>d$, i.e. $\Delta>d^2(d-2)/(d-1)$, then
$$
n\big(d-\lambda_2(G'_n)\big)\xrightarrow{\ \mathbb P\ }
\frac{\Delta^2}{\Delta G_d(d)-d}
=\frac{\Delta^2 d(d-2)}{\Delta(d-1)-d^2(d-2)} .
$$

**Proposition D (obstruction: local weak convergence is not enough).** Let $B_R$ be the
ball of radius $R$ in the spiked tree $T(d,\Delta)$ ($\Delta>2(d-1)$) and $T_R=N(o)$ its
$\Delta$ neighbours. Then: (i) the Benjamini--Schramm limit of $B_R$ at a uniform vertex is
the $d$-regular tree; (ii) the empirical spectral measure of $B_R$ tends to
$\mu_{\mathrm{KM},d}$; (iii) nevertheless
$$
\mathbf 1_{T_R}^\top(A_{B_R}-\lambda I)^{-1}\mathbf 1_{T_R}\longrightarrow
\frac{\Delta\lambda r(\lambda)}{\Delta r(\lambda)-\lambda}\neq-\Delta G_d(\lambda)
$$
for $\lambda\in(2\sqrt{d-1},\infty)\setminus\{\lambda_*\}$
(e.g. $(d,\Delta,\lambda)=(3,5,2.95)$: limit $-25.1053$, host value $-3.6600$).
So no argument from local convergence and the limiting spectral measure alone can give
Theorem A; a host-specific spectral input is required.

**Proposition E (the spectral-gap input is necessary).** If (H) holds on a compact $K$ for a
$d$-regular sequence $(G_n)$, then $\limsup_n\lambda_2(G_n)\le\min K$. Hence on a window
below the bulk edge a second-eigenvalue bound of Bordenave/Friedman strength is not a
convenience but a hypothesis that no proof of (H) can drop. Correspondingly the one-sided
branch claim $\mathbf 1_T^\top(A-\lambda I)^{-1}\mathbf 1_T\approx-\Delta r(\lambda)$ is
false wherever $r\neq0$, by the exact factor $G_d/r=1/(1-r^2)\in(1,(d-1)^2/((d-1)^2-1)]$
on $(2\sqrt{d-1},d]$ — at $\lambda=d$, $d=3$: off by $4/3$.

---

## 1. Exact algebra: the Perron splitting and the walk-count identity

Throughout, $A$ is the adjacency matrix of a simple $d$-regular graph on $n\ge2$ vertices,
$J=\mathbf 1\mathbf 1^\top$, $P=J/n$, $Q=I-P$, and
$$
A' := A-dP = QAQ .
$$
($QAQ=A-QA-AQ+QAQ=A-dP-dP+dP$ since $A\mathbf 1=d\mathbf 1$.)

**Lemma 1.** (i) $PA'=A'P=0$ and $A'=QA'Q=A'Q=QA'$; the matrices $dP$ and $A'$ are
symmetric, commute, and are the spectral projections of $A$ onto
$\mathrm{span}\{\mathbf 1\}$ and its orthogonal complement. Consequently
$\|A'\|=\max_{i\ge2}|\lambda_i(A)|$.

(ii) For every $k\ge1$ and all $y,y'\in[n]$,
$$
\boxed{\;(A'^k)_{yy'}=(A^k)_{yy'}-\frac{d^k}{n}\;}
$$

(iii) For $\lambda\notin\sigma(A)$,
$$
(A-\lambda I)^{-1}=\frac{P}{d-\lambda}-\sum_{k\ge0}\frac{A'^k}{\lambda^{k+1}},
$$
and the series converges in operator norm whenever $|\lambda|>\|A'\|$.

*Proof.* (i) $A\mathbf 1=d\mathbf 1$ gives $A'P=(A-dP)P=dP-dP=0$ and $PA'=0$; then
$A'=A'-PA'-A'P+PA'P=QA'Q$. Symmetry is clear, and $\mathrm{im}\,P=\ker Q$ is the
eigenspace of $A$ for $d$, so $A'=A$ on $\mathbf 1^\perp$ and $A'=0$ on
$\mathrm{span}\{\mathbf 1\}$; this also gives the norm formula.

(ii) Induction on $k$. For $k=1$: $A'_{yy'}=A_{yy'}-d/n$ is the identity $A'=A-(d/n)J$.
Assume the formula at $k$. Then
$$
A'^{k+1}=\Big(A-\tfrac dnJ\Big)\Big(A^k-\tfrac{d^k}{n}J\Big)
=A^{k+1}-\tfrac{d^k}{n}AJ-\tfrac dn JA^k+\tfrac{d^{k+1}}{n^2}J^2 .
$$
Now $AJ=A\mathbf 1\mathbf 1^\top=dJ$, $JA^k=\mathbf 1(d^k\mathbf 1)^\top=d^kJ$ and
$J^2=nJ$, so the last three terms equal $-d^{k+1}J/n-d^{k+1}J/n+d^{k+1}J/n=-d^{k+1}J/n$.

(iii) By (i), $A=dP+A'$ is an orthogonal decomposition into two invariant subspaces; on
$\mathrm{span}\{\mathbf 1\}$, $(A-\lambda I)^{-1}=P/(d-\lambda)$, and on
$\mathbf 1^\perp$, $A'-\lambda I$ is invertible with inverse
$-\lambda^{-1}\sum_{k\ge0}(A'/\lambda)^k$, absolutely convergent when
$\|A'\|<|\lambda|$. $\square$

**Lemma 2 (exact decomposition of the secular function).** Let $\lambda>2\sqrt{d-1}$ with
$\lambda>\|A'\|$ and $\lambda\ne d$. For every $L\ge1$,
$$
\mathbf 1_T^\top(A-\lambda I)^{-1}\mathbf 1_T
=\frac{\Delta^2}{n(d-\lambda)}
-\sum_{k=0}^{L}\frac{\mathbf 1_T^\top A'^k\mathbf 1_T}{\lambda^{k+1}}
+R_L(\lambda),\qquad |R_L(\lambda)|\le\frac{\Delta^2\rho^{L+1}}{\lambda(1-\rho)},
$$
with $\rho=\|A'\|/\lambda<1$. Moreover, on the event of Lemma 3 below,
$$
\sum_{k=1}^{L}\mathbf 1_T^\top A'^k\mathbf 1_T\,\lambda^{-k-1}
=\Delta\sum_{k=1}^{L}\frac{(A^k_{T_d})_{oo}}{\lambda^{k+1}}
-\frac{\Delta^2}{n}\sum_{k=1}^{L}\frac{d^k}{\lambda^{k+1}},
$$
where $A_{T_d}$ is the $d$-regular tree and $o$ any vertex of it.

*Proof.* The first display is Lemma 1(iii) plus $\mathbf 1_T^\top P\mathbf 1_T=\Delta^2/n$
and the norm bound on the tail. The second uses Lemma 1(ii) and then
$\mathbf 1_T^\top A^k\mathbf 1_T=\sum_{y,y'\in T}(A^k)_{yy'}=\Delta (A^k_{T_d})_{oo}$:
the diagonal terms $y=y'$ equal the tree walk count because the ball of radius
$\lfloor k/2\rfloor$ around $y$ is a tree (Lemma 4), and the off-diagonal terms vanish
because $\mathrm{dist}(y,y')>L\ge k$ leaves no walk of length $k$ (Lemma 3). $\square$

---

## 2. The two probabilistic inputs

**Lemma 3 (tree balls and separation; proved from the configuration model).**
Fix $d\ge3$ and $r\ge1$ with $(d-1)^{2r}\le n^{1/2}$. For $G_n$ uniform simple $d$-regular,
for any fixed $y\neq y'$,
$$
\mathbb P\big(B_r(y)\text{ is not a tree}\big)\le \frac{C_d(d-1)^{2r}}{n},
\qquad
\mathbb P\big(\mathrm{dist}(y,y')\le r\big)\le \frac{C_d (d-1)^{r}}{n},
$$
with $C_d$ depending on $d$ only. Hence for a fixed finite $T$ and
$L_n=\lfloor c\log_{d-1}n\rfloor$, $c<1/2$, the event
$$
\mathcal E_n=\Big\{\textstyle\bigcap_{y\in T}\{B_{L_n}(y)\text{ is a tree}\}\cap
\bigcap_{y\ne y'\in T}\{\mathrm{dist}(y,y')>L_n\}\Big\}
$$
has $\mathbb P(\mathcal E_n^c)\le C_{d}T^2n^{-1/2}$.

*Proof.* Let $\Gamma_n$ be the configuration model with $d$ half-edges at each of $n$
vertices. Reveal the ball of radius $r$ from $y$ level by level. At level $j$ at most
$(d-1)^j$ vertices are exposed and each contributes at most $d-1$ half-edges, so at most
$N_j\le(d-1)^{j+1}$ unmatched half-edges exist there; the total number of already-used
half-edges after completing level $j$ is at most $2\sum_{i\le j}(d-1)^{i+1}\le
4(d-1)^{j+1}$. In the uniform random perfect matching of the $dn$ half-edges each single
half-edge is matched to a uniform partner among the remaining $dn-1$; a union bound gives
$$
\mathbb P(B_{j+1}\text{ is not obtained from }B_j\text{ by new vertices})
\le \frac{N_j\cdot 4(d-1)^{j+1}}{dn-O((d-1)^{j+1})}
\le \frac{8(d-1)^{2j+2}}{dn}
$$
for $(d-1)^{2r}=o(n)$, and summing over $j<r$ gives the first bound for $\Gamma_n$. The
same computation with a single half-edge path from $y$ to $y'$ gives the second bound
(count non-backtracking paths of length $\le r$: at most $(d-1)^{r-1}d$ of them, each
realised with probability $\le (dn-1)^{-1}(dn-3)^{-1}\cdots\le (dn-1)^{-r}$ in the
matching, times the $(dn)^{r-1}$ possible... — more simply: explore from $y$; reaching the
fixed vertex $y'$ at step $\le r$ has probability $\le\sum_{j\le r}N_j/(dn-O(\cdot))\le
2(d-1)^{r+1}/(dn)$.) Since $\mathbb P_\Gamma(\text{simple})\to e^{-(d^2-1)/4}>0$
(Bollobás, *Random Graphs*, 2nd ed., Theorem 2.16; also McKay--Wormald), and
$\mathbb P_{\text{uniform}}(\mathcal A)\le\mathbb P_\Gamma(\mathcal A)/\mathbb P_\Gamma(\text{simple})$,
the bounds transfer to $G_n$ at the cost of a constant. A union bound over the $O(\Delta^2)$
pairs in $T$ gives $\mathcal E_n$. $\square$

**Lemma 4 (tree walk counts; deterministic).** If $B_{\lfloor k/2\rfloor}(y)$ is a tree
then $(A^k)_{yy}=(A^k_{T_d})_{oo}$. If $\mathrm{dist}(y,y')>k$ then $(A^k)_{yy'}=0$.

*Proof.* A closed walk of length $k$ from $y$ never leaves $B_{\lfloor k/2\rfloor}(y)$
(a vertex at distance $s$ from $y$ on the walk needs $s$ further steps to return, so
$2s\le k$), and the ball is isometric to the tree ball. A walk of length $k$ from $y$ to
$y'$ has length at least the graph distance. $\square$

**Input 1 (Bordenave; = Friedman's theorem).** *Let $d\ge3$ and $nd$ even, and let $G$ be
uniform among simple $d$-regular graphs on $[n]$. For every $\varepsilon>0$,
$\lim_{n\to\infty}\mathbb P(\lambda_2\vee|\lambda_n|\ge 2\sqrt{d-1}+\varepsilon)=0$;
quantitatively, for every $0<a<1$ there is $c=c(d,a)$ with
$\mathbb P(\lambda_2\vee|\lambda_n|\ge2\sqrt{d-1}+c((\log\log n)/\log n)^2)\le n^{-a}$.*
C. Bordenave, *A new proof of Friedman's second eigenvalue theorem and its extension to
random lifts*, arXiv:1502.04482v4, **Theorem 1 and Eq. (2)**, p. 2 (model: "uniform among
simple $d$-regular graphs on $[n]$", exactly ours; the statement is two-sided,
$\lambda_2\vee|\lambda_n|$). Original: J. Friedman, *A proof of Alon's second eigenvalue
conjecture and related problems*, Memoirs AMS **195** (2008), no. 910. Mismatch check:
$d$ **fixed** $\ge3$ (not growing), simple uniform model (not the union of matchings),
conclusion about the **adjacency** spectrum including $|\lambda_n|$ — all three match what
is used below. Nothing else is imported.

**Input 2 (connectivity).** $\mathbb P(G_n\text{ connected})\to1$ for $d\ge3$ fixed
(classical; follows from Lemma 3 by a union bound over pairs). On that event $d$ is a
simple eigenvalue of $A$ with eigenvector $\mathbf 1/\sqrt n$, so Lemma 1 applies with
$A'$ of norm $\lambda_2\vee|\lambda_n|$.

Combining Inputs 1 and 2 with Lemma 3: for every $\delta>0$ there is $\Omega_n$ with
$\mathbb P(\Omega_n)\ge1-o(n^{-1/2})$ on which $G_n$ is connected and
$\|A'\|=\lambda_2\vee|\lambda_n|\le 2\sqrt{d-1}+\delta$.

---

## 3. Proof of Theorem A

Fix a compact $K\subset(2\sqrt{d-1},d)\cup(d,\infty)$ and put
$e=2\sqrt{d-1}$, $2\delta=\min\{\mathrm{dist}(K,e),\,|d-\lambda|:\lambda\in K\}>0$,
$\lambda_{\min}=\min K>e+2\delta$. Take $L=L_n=\lfloor c\log_{d-1}n\rfloor$, $c<1/2$, and
let $\Omega_n$ be as above with $\delta$. On $\Omega_n$, $\rho:=\|A'\|/\lambda\le
(e+\delta)/(e+2\delta)=:\rho_\ast<1$ for all $\lambda\in K$, and
$\rho_0:=e/\lambda\le e/\lambda_{\min}=:\rho_1<1$.

On $\Omega_n\cap\mathcal E_n$, Lemma 2 gives, for every $\lambda\in K$,
$$
\mathbf 1_T^\top(A-\lambda I)^{-1}\mathbf 1_T
-\Big(-\Delta\sum_{k=0}^{\infty}\frac{(A^k_{T_d})_{oo}}{\lambda^{k+1}}\Big)
=\frac{\Delta^2}{n(d-\lambda)}
+\Delta\sum_{k>L}\frac{(A^k_{T_d})_{oo}}{\lambda^{k+1}}
+\frac{\Delta^2}{n\lambda}\sum_{k=1}^{L}\Big(\frac{d}{\lambda}\Big)^{k}
+O\!\Big(\frac{\Delta^2\rho_\ast^{L+1}}{\lambda_{\min}}\Big),
$$
where in the first line we completed the tree series. The four error terms are estimated
uniformly in $\lambda\in K$ as follows.

1. $|\Delta^2/(n(d-\lambda))|\le\Delta^2/(n\cdot 2\delta)\to0$.
2. Tree tail: for $\lambda\in K$, $|(A^k_{T_d})_{oo}|\le\|A_{T_d}\|^k=e^k$, hence
   $\big|\Delta\sum_{k>L}(A^k_{T_d})_{oo}\lambda^{-k-1}\big|
   \le \Delta\sum_{k>L}\rho_0^k/\lambda\le\Delta\rho_1^{L+1}/(\lambda_{\min}(1-\rho_1))
   \to0$ geometrically in $L$.
3. If $K$ lies above $d$ then $d/\lambda\le d/\lambda_{\min}<1$ and
   $0<\frac{\Delta^2}{n\lambda}\sum_{k=1}^{L}(d/\lambda)^{k}\le\frac{\Delta^2}{n\lambda_{\min}}\cdot
   \frac{1}{1-\lambda_{\min}/d}=O(1/n)$. If $K$ lies below $d$ then $d/\lambda>1$ and
   $\frac{\Delta^2}{n\lambda}\sum_{k\le L}(d/\lambda)^k
   \le\frac{\Delta^2}{n}\cdot\frac{(d/\lambda_{\min})^{L}}{\lambda_{\min}(1-\lambda_{\min}/d)}$,
   and $(d/\lambda_{\min})^{L}/n\le\exp\big(-(\log n)\big(1-c\frac{\log d}{\log(d-1)}\big)\big)\to0$
   uniformly in $\lambda\in K$, since $L\le c\log_{d-1}n$ and
   $c\log d<\log(d-1)$ for every $c<1/2$, $d\ge3$
   (worst case $d=3$: $\tfrac12\log 3=0.549<0.693=\log2$).
4. $\Delta^2\rho_\ast^{L+1}/\lambda_{\min}\to0$ geometrically.

Finally
$\sum_{k\ge0}(A^k_{T_d})_{oo}\lambda^{-k+1}\!=\!G_d(\lambda)$; indeed both sides are the
Neumann series of the resolvent of the tree on $\ell^2$, absolutely convergent because
$\lambda>e=\|A_{T_d}\|$, and $\langle\delta_o,(A_{T_d}-\lambda)^{-1}\delta_o\rangle
=-\int\mathrm d\mu_{\mathrm{KM},d}(t)/(\lambda-t)=-G_d(\lambda)$ (equivalently the
classical computation $u_n=c r^n$, $c=-r/(1-r^2)$ of the dossier, Lemma 1). This proves the
display in Theorem A on $\Omega_n\cap\mathcal E_n$ with
$C=C(d,\Delta,K)$; and $\mathbb P((\Omega_n\cap\mathcal E_n)^c)\le Cn^{-1/2}$. $\square$

**Remark (why this is not circular and not the bulk local law).** The whole argument rests
on $\|A'\|<\lambda$: inequality (strict) turns the resolvent into a **geometrically
decaying** operator, which is what makes a fixed-size set $T$ see only the ball of radius
$O(\log n)$. Inside the bulk, $\|A'\|>\lambda$, the Neumann series diverges, the resolvent
is genuinely global, and the fixed-degree warning of Bauerschmidt--Huang--Yau (that
individual Green function entries need not concentrate) applies. So the exterior window is
*easier* than the bulk, for a structural reason, and no complex-$z$ bulk estimate is used
or needed: Theorem A is a statement about real $\lambda$ only, obtained without passing
$\operatorname{Im}z\to0$. It says nothing about $\lambda\in[-e,e]$.

**Remark (no variance is needed).** The random objects entering are only the three
high-probability events (connectedness, the second-eigenvalue bound, and $\mathcal E_n$).
On their intersection the bound is deterministic. This is why bounded local cycles and the
off-diagonal terms can be controlled without any second-moment computation: bounded cycles
are excluded outright on $\mathcal E_n$, and off-diagonal terms vanish by separation. A
variance computation would be needed for the *average over $T$* version, which is a
different and much easier statement (it is $\tfrac1n\operatorname{tr}$, i.e. the Stieltjes
transform of the empirical spectral measure, and does not imply Theorem A).

---

## 4. Proof of Theorem B

Let $p_H(\lambda)=\det(\lambda I-A_H)$. The exact added-vertex identity
(Dossier Prop. B; re-verified here in exact rational arithmetic, see
`out/exact_checks.json`) gives, as rational functions,
$$
p_{G'_n}(\lambda)=p_{G_n}(\lambda)\,\Sigma_n(\lambda).
$$
Hence for $\lambda\notin\sigma(A)$: $\lambda\in\sigma(A_{G'_n})\iff\Sigma_n(\lambda)=0$.
Moreover $\Sigma_n'(\lambda)=1+\mathbf 1_T^\top(A-\lambda I)^{-2}\mathbf 1_T>0$ on
$\mathbb R\setminus\sigma(A)$, so on every spectral gap $\Sigma_n$ is strictly increasing
from $-\infty$ to $+\infty$ wherever the two endpoints are poles; in any case it has **at
most one** zero per gap. Cauchy interlacing for a one-vertex extension
($\lambda_1(G')\ge\lambda_1(G)\ge\lambda_2(G')\ge\lambda_2(G)\ge\cdots$) shows that
$\lambda_2(G')$ is the only eigenvalue of $G'$ in $[\,\lambda_2(G),\,d\,]$, and that
$\lambda_1(G')$ is the only one in $(d,\infty)$; and $d\notin\sigma(G')$ because
$\mathbf 1_T^\top\mathbf 1/\sqrt n=\Delta/\sqrt n\ne0$ kills the Perron eigenvalue
(Dossier Prop. B, corollary 2). Therefore
$$
\lambda_2(G')=\text{the unique zero of }\Sigma_n\text{ in }(\lambda_2(G),d),\qquad
\lambda_1(G')=\text{the unique zero of }\Sigma_n\text{ in }(d,\infty).
$$

Now fix $\delta_0>0$ and work on $\Omega_n$, where
$\lambda_2(G_n)\le e+\delta_0$. By Theorem A, uniformly for $\lambda$ in the compact set
$K_\delta:=(e+\delta_0,\,d-\delta_0]\cup[d+\delta_0,\,\lambda_f+2]$ (for any fixed small
$\delta_0$), $\Sigma_n(\lambda)=\lambda-\Delta G_d(\lambda)+\Delta^2/(n(d-\lambda))+o(1)$
with $o(1)\to0$ uniformly.

*Case $\Delta\le2(d-2)$.* Then $f\ge0$ on $(e,\infty)$ ($f(e)=\sqrt{d-1}(2-\Delta/(d-2))\ge0$
and $f'>0$). At $\lambda=e+2\delta_0$: $\Sigma_n\ge f(e+2\delta_0)-o(1)>0$. Since
$\Sigma_n\to-\infty$ as $\lambda\downarrow\lambda_2(G_n)$, the zero lies in
$(\lambda_2(G_n),e+2\delta_0)$, so $\lambda_2(G')\le e+2\delta_0$; and
$\lambda_2(G')\ge\lambda_2(G_n)$. As $\delta_0$ is arbitrary, $\lambda_2(G')\to e$.
Also $\Sigma_n(d+\delta_0)=f(d+\delta_0)+O(1/n)+o(1)>0$ while $\Sigma_n\to-\infty$ as
$\lambda\downarrow d$, so $\lambda_1(G')\in(d,d+\delta_0]$: $\lambda_1(G')\to d$.

*Case $2(d-2)<\Delta<d^2(d-2)/(d-1)$ (so $e<\lambda_f<d$).* Fix $0<\eta<\min\{(\lambda_f-e)/2,(d-\lambda_f)/2\}$.
Then $f(\lambda_f-\eta)<0<f(\lambda_f+\eta)$, hence for large $n$
$\Sigma_n(\lambda_f-\eta)<0<\Sigma_n(\lambda_f+\eta)$, and
$[\lambda_f-\eta,\lambda_f+\eta]\subset(\lambda_2(G_n),d)\subset K_\delta$. So the unique
zero in the gap lies in $(\lambda_f-\eta,\lambda_f+\eta)$: $\lambda_2(G')\to\lambda_f$. As in
the previous case (using $f(d)>0$) $\lambda_1(G')\to d$.

*Case $\Delta>d^2(d-2)/(d-1)$ (so $\lambda_f>d$).* Fix $0<\eta<(\lambda_f-d)/2$. Then
$f(\lambda_f-\eta)<0<f(\lambda_f+\eta)$ and, uniformly on $[\lambda_f-\eta,\lambda_f+\eta]$,
the Perron term $\Delta^2/(n(d-\lambda))=O(1/n)$; so $\lambda_1(G')\in(\lambda_f-\eta,\lambda_f+\eta)$,
i.e. $\lambda_1(G')\to\lambda_f$. For $\lambda_2$: $f<0$ on $(e,\lambda_f)\supset(e,d]$, so
for fixed $0<\eta<\lambda_f-d$, $\Sigma_n(d-\eta)<0$ for large $n$, while
$\Sigma_n\to+\infty$ as $\lambda\uparrow d$; so the unique zero in $(\lambda_2(G_n),d)$ lies
in $(d-\eta,d)$ and $\lambda_2(G')\to d$.

*Case $\Delta=d^2(d-2)/(d-1)$ exactly* ($f(d)=0$): both limits are $d$; the same
bracketing with $\eta$ around $d$ gives $|\lambda_i(G')-d|\le\eta$ for $i=1,2$.

The three cases assemble into $\lambda_1(G')\to\max(d,\lambda_f)$,
$\lambda_2(G')\to\min(d,\lambda_f)$, and the exceptional set has probability $o(1)$. $\square$

---

## 5. Proof of Theorem C

Assume $\Delta G_d(d)>d$, i.e. $c_1:=\Delta G_d(d)-d>0$; recall
$G_d(d)=(d-1)/(d(d-2))$ and $f'(d)=c_2:=1-\Delta G_d'(d)>0$ (because $G_d'<0$ on $(e,\infty)$).

Let $C_1=2\Delta^2/c_1$ and consider $\lambda=d-s/n$ with $s\in(0,C_1]$; for large $n$,
$\lambda\in(e,d)$ and $\lambda_2(G_n)<\lambda$. In the decomposition of Theorem A the only
error term that is *not* $O(\log n/n)$ or exponentially small is the explicit
$\Delta^2/(n(d-\lambda))=\Delta^2/s$; the term $\frac{\Delta^2}{n}\sum_{k\le L}(d/\lambda)^{k+1}$
is $O(\Delta^2L/n)$ because $(d/\lambda)^k=(1-s/(dn))^{-k}\le e^{2ks/(dn)}\le 1+o(1)$
uniformly for $k\le L$ and $s\le C_1$. Hence, uniformly in $s\in(0,C_1]$,
$$
\Sigma_n(d-s/n)=f(d-s/n)+\frac{\Delta^2}{s}+O_{\Delta,d}\!\Big(\frac{\log n}{n}\Big)
=-c_1-\frac{c_2 s}{n}+\frac{\Delta^2}{s}+O\Big(\frac{\log n}{n}\Big).
$$
The right-hand side is $\ge0$ if and only if $\Delta^2/s\ge c_1+O(\log n/n)$, i.e.
$s\le \Delta^2/c_1\,(1+O(\log n/n))$; so the unique zero of $\Sigma_n$ in $(d-C_1/n,d)$ is
at $d-s_n/n$ with $|s_n-\Delta^2/c_1|=O(\log n/n)\to0$. By §4 that zero is
$\lambda_2(G'_n)$. $\square$

**Numerical confirmation (certified sampler).** Uniform $d$-regular graphs drawn by
*rejection from the configuration model* (conditioned on simplicity this is exactly
uniform), fixed seed; see `scripts/uniform_host.py`, `out/d3D6.json`:
$d=3,\Delta=6$, $\Delta^2/c_1=36$ (dossier's predicted constant, no free parameter) gives
$n(d-\lambda_2)=30.0,\,35.2,\,34.2$ at $n=10^3,2\cdot10^3,4\cdot10^3$, and the dossier's
independent (networkx-based) run reported $36.04$ at $n=1.6\cdot10^4$; the residual
fluctuation is $O(1)$ because $\lambda_2(G')$ inherits the $\Theta(n^{-2/3})$ edge
fluctuation of the host through $\Sigma_n$.

---

## 6. Obstructions: what cannot work (Propositions D and E)

### 6.1 Proof of Proposition D
Let $T(d,\Delta)$ be the spiked tree ($d\ge3$, one vertex $o$ of degree $\Delta>2(d-1)$,
all others of degree $d$), $B_R$ its ball of radius $R$, $T_R=N(o)$. (i) A uniform vertex
of $B_R$ has distance $\sim R$ from $o$ with probability $1-o(1)$, so its $r$-neighbourhood
is the $d$-regular tree for every fixed $r$; hence the Benjamini--Schramm limit is the
$d$-regular tree. (ii) $|B_R|^{-1}\sum_{\lambda\in\sigma(A_{B_R})}\delta_\lambda$ has the
same weak limit as the spectral measure of the tree, i.e. $\mu_{\mathrm{KM},d}$, since
$|N(o)|/|B_R|\to0$ and the defect only moves $O(1)$ eigenvalues. (iii) $B_R$ is spherically
symmetric about $o$, so the vector $h^{(R)}=(A_{B_R}-\lambda I)^{-1}\mathbf 1_{T_R}$
satisfies the radial recursion of `scripts/exact_checks.py`
(`tree_resolvent_BT`); solving it gives, in closed form in the limit $R\to\infty$,
$$
h_1=\frac{\lambda r}{\Delta r-\lambda},\quad h_o=\frac{\Delta r}{\Delta r-\lambda},
\qquad
\mathbf 1^\top_{T_R}(A_{B_R}-\lambda I)^{-1}\mathbf 1_{T_R}=\Delta h_1
=\frac{\Delta\lambda r}{\Delta r-\lambda},
$$
with $r=r(\lambda)$; the recursion is $h_o=\Delta h_1/\lambda$,
$h_o+(d-1)r h_1-\lambda h_1=1$, so $h_1(\Delta/\lambda-1/r)=1$. The exact rational-arithmetic
evaluation of the truncated recursion reproduces this limit to $10^{-8}$ at $R=32$–$64$
(`out/exact_checks.json`): for $(d,\Delta,\lambda)=(3,5,2.95)$ the balls give
$-24.1483,-25.0961,-25.1053,-25.1053$ at $R=8,16,32,64$ vs. the closed form $-25.1053$.
Since $-\Delta G_d(\lambda)=-\Delta r/(1-r^2)=-3.6600$ there, the two limits differ, and
the difference is unbounded near $\lambda_*=\Delta/\sqrt{\Delta+1-d}$ where the tree
expression has a pole. $\square$

**Consequence.** Local weak convergence plus convergence of the empirical spectral measure
do not determine the fixed-$T$ resolvent limit. Therefore the target cannot be obtained by
importing a local law; it needs the host-specific input $\|A'\|<\lambda$. This is the
precise sense in which "tree local weak convergence is not a substitute for a probabilistic
resolvent proof" (README, "does not count" list): and here the gap is not a defect of a
particular argument but a genuine non-implication.

### 6.2 Proof of Proposition E
Suppose $\Sigma$-convergence (H) holds uniformly on $K$ and $\lambda_0\in K$ with
$\lambda_0<d$. If $(\lambda_2(G_n))$ had $\limsup>\lambda_0$, then along a subsequence
$\lambda_2(G_n)\ge\lambda_0+2\eta$ and $\Sigma_n$ would have a pole in
$[\lambda_0,\lambda_0+\eta]$, where (H) forces $|\Sigma_n|$ to stay bounded; a contradiction.
(Equivalently: $\Sigma_n$ cannot converge locally uniformly across a pole.) $\square$

### 6.3 The one-sided branch
$\mathbf 1_T^\top(A-\lambda I)^{-1}\mathbf 1_T\approx-\Delta r(\lambda)$ is exactly the
value of the *diagonal* tree resolvent $(-r)$ times $\Delta$, i.e. it ignores both the
off-diagonal correlations inside $T$ and the $1/(1-r^2)$ normalisation of the full
Kesten--McKay transform. The correct identity is $G_d=r/(1-r^2)$, so the two differ by
$1/(1-r^2)$, e.g. at $d=3,\lambda=2.9$: $-4.9783$ (true) vs $-3.3895$ (one-sided), a $47\%$
error — the same factor that shifts the threshold from $2(d-1)$ to $2(d-2)$. Verified
numerically in `out/d3D6.json`.

---

## 7. What is verified, and what is not

**Verified (exact arithmetic, `scripts/exact_checks.py`, `out/exact_checks.json`).**
Lemma 1(ii) on $C_6,Q_3,K_{3,3}$ for $k\le6$; the added-vertex secular identity on four
instances at $\ge45$ rational points each; the closed forms $G_d(d)=(d-1)/(d(d-2))$ and
$G_d(2\sqrt{d-1})=\sqrt{d-1}/(d-2)$ symbolically for $d=3,4,5,6$; the spiked-tree closed
form of Prop. D.

**Verified numerically (certified-uniform sampler, fixed seeds;
`scripts/uniform_host.py`, `scripts/probe2.py`, `out/*.json`).**
* The secular zero and the actual eigenvalue agree to machine precision:
  $(d,\Delta)=(3,6)$, $n=10^3$: zero in gap $2.9699598572204$ vs
  $\lambda_2(G')=2.9699598572158$; zero above $d$ $3.2097969310166$ vs
  $\lambda_1(G')=3.2097969310486$. Same at $n=2\cdot10^3,4\cdot10^3$ and for
  $(4,7)$ at $n=10^3,3\cdot10^3$.
* Both orderings: $(3,6)$ [$\lambda_f=3.1807>d$] gives
  $\lambda_1=3.2098,3.1902,3.1887\to\lambda_f$ and $\lambda_2=2.96996,2.98240,2.99145\to d$;
  $(4,7)$ [$\lambda_f=3.6284<d$] gives $\lambda_1=4.0350,4.0113\to d$ and
  $\lambda_2=3.6363,3.6046\to\lambda_f$. The spiked-tree prediction $\lambda_*\in\{3.0,3.5\}$
  is off by $0.18$ and $0.13$ at $n=4\cdot10^3,9\cdot10^3$ and does not improve.
* Theorem A's residual $\Sigma_n-f\to0$: $1.3\times10^{-3}$ at $\lambda=5$, $3\times10^{-2}$
  at $\lambda=3.5$ for $(3,6)$, $n=4\cdot10^3$. The rate is $\rho^{L}$ with
  $\rho\to1$ as $\lambda\downarrow2\sqrt{d-1}$; convergence is therefore slow (though
  geometric in $L=c\log n$) near the bulk edge, exactly as the proof predicts, and no
  numerical run at these sizes can "confirm" the limit there. Numerical agreement is
  *corroboration*, not proof.

**Not covered.** (a) The bulk $\lambda\in[-2\sqrt{d-1},2\sqrt{d-1}]$: untouched; nothing
here contradicts the fixed-degree non-concentration warning. (b) Complex $z$. (c) Growing
$d$, or $d=d(n)$. (d) Random or growing $T$ ($\Delta=\Delta(n)$), multiple spikes, and
$\Delta$ comparable to $n$: outside the statement. (e) The claimed multi-spike "census" of
Dossier §3 remains unproved. (f) Sharpness of the rates: the $n^{-1/2}$ failure probability
and $\rho^{c\log n}$ error are far from optimal. (g) Nothing here is formalised in Lean;
no Lean claim is made.

**Honest novelty boundary.** The ingredients are classical (rank-one Perron removal;
$A'^k=A^k-\frac{d^k}{n}J$; walk counting on trees; Friedman's theorem). The content added
here is the assembly: (i) the exact identity of Lemma 1(ii) makes the fixed-$T$ quadratic
form a *local* object in the exterior window, uniformly in $\lambda$ on compacta; (ii) the
root analysis identifies the limiting eigenvalues rigorously through the host Perron pole;
(iii) Prop. D/E delimit what no argument of this type can do. I have not done a
forward-citation audit for "fixed finite
set resolvent limit random regular graph"; if such a statement exists in the
community-detection or spiked-model literature it would supersede Theorem A's novelty,
not its correctness.
