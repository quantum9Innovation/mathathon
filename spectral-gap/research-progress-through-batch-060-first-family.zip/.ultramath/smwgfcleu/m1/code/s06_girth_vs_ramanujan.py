r"""Bounded girth plus bad second eigenvalue, versus logarithmic girth plus
near-Ramanujan second eigenvalue, for the same base graph and the same degree.

Base: the Petersen graph (3-regular, girth 5), all windings 1.
  (i)  the n-fold cyclic covers: 3-regular on 10 n vertices.  A closed walk of
       length L in the base has winding in {-L,...,L}, so for n > 2 diam(B) the
       shortest zero-winding closed walk is n-independent: girth stays bounded.
       lambda_2 tends to the degree 3.
  (ii) uniform random n-lifts: 3-regular on 10 n vertices, girth grows like
       log n, lambda_2 stays close to the Alon-Boppana value 2 sqrt 2.
"""
import sys, os, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
import importlib.util
spec = importlib.util.spec_from_file_location("s05", os.path.join(
    os.path.dirname(os.path.abspath(__file__)), "s05_cyclic.py"))
s05 = importlib.util.module_from_spec(spec); spec.loader.exec_module(s05)

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "out")
PET = [(0, 1), (1, 2), (2, 3), (3, 4), (4, 0), (0, 5), (1, 6), (2, 7),
       (3, 8), (4, 9), (5, 7), (7, 9), (9, 6), (6, 8), (8, 5)]


def random_lift(n, p, edges, rng):
    N = n*p
    A = np.zeros((N, N))
    for (u, v) in edges:
        perm = rng.permutation(n)
        for i in range(n):
            j = perm[i]
            A[i*p+u, j*p+v] += 1
            A[j*p+v, i*p+u] += 1
    return A


def main():
    log = []
    B = s05.CyclicBase("PetersenAll1", 10, [(u, v, 1) for (u, v) in PET])
    C, t1, t2, psi, lam1 = B.constant()
    log.append(f"Petersen, every winding 1: Lambda_1(0) = {lam1:.12f}, "
               f"C = {C:.12f}, M_1 = 4 pi^2 C = {4*np.pi**2*C:.9f}")
    log.append("")
    log.append("(i) cyclic covers (3-regular, 10n vertices)")
    log.append("     n  nverts  girth     lambda_2      gap          C_n")
    cyc = []
    for n in [2, 3, 5, 7, 11, 13, 17, 23]:
        ev = B.spectrum_cyclic(n)
        g = int(B.girth(n))
        gap = ev[0]-ev[1]
        cyc.append(dict(n=n, nverts=10*n, girth=g, lam2=float(ev[1]),
                        gap=float(gap), Cn=float(n*n*gap/(2*np.pi**2))))
        log.append(f"  {n:4d} {10*n:6d} {g:5d}  {ev[1]:.12f}  {gap:.6e}  "
                   f"{n*n*gap/(2*np.pi**2):.9f}")
    log.append("")
    log.append("(ii) uniform random n-lifts (3-regular, 10n vertices, 4 samples)")
    log.append("     n  nverts  girth        lambda_2 values                 mean")
    rng = np.random.default_rng(20261114)
    rl = []
    for n in [5, 10, 20, 40, 80]:
        vals, gs = [], []
        for _ in range(4):
            A = random_lift(n, 10, PET, rng)
            ev = np.sort(np.linalg.eigvalsh(A))[::-1]
            vals.append(ev[1])
            gs.append(int(s05.CyclicBase.girth(
                s05.CyclicBase("t", 10, [(u, v, 0) for (u, v) in PET]), n)
                if False else _girth(A)))
        rl.append(dict(n=n, nverts=10*n, girth=gs, lam2=[float(v) for v in vals],
                       mean=float(np.mean(vals))))
        log.append(f"  {n:4d} {10*n:6d}  {str(sorted(gs)):12s} "
                   f"{np.round(vals, 6).tolist()}  {np.mean(vals):.6f}")
    log.append("")
    log.append(f"Alon-Boppana barrier for degree 3: 2 sqrt 2 = {2*np.sqrt(2):.12f}")
    log.append("cyclic family limit: 3")
    txt = "\n".join(log)
    open(os.path.join(OUT, "s06_girth.log"), "w").write(txt)
    json.dump(dict(cyclic=cyc, random=rl, C=float(C)), open(
        os.path.join(OUT, "s06_girth.json"), "w"), indent=1)
    print(txt)


def _girth(A, cap=10**6):
    A = (A > 0).astype(int)
    N = A.shape[0]
    best = cap
    for s in range(N):
        dist = np.full(N, -1); par = np.full(N, -1)
        dist[s] = 0; frontier = [s]
        while frontier:
            nxt = []
            for u in frontier:
                for v in np.nonzero(A[u])[0]:
                    if dist[v] < 0:
                        dist[v] = dist[u]+1; par[v] = u; nxt.append(v)
                    elif par[u] != v and par[v] != u:
                        best = min(best, dist[u]+dist[v]+1)
            frontier = nxt
        if best <= 5:
            return best
    return best


if __name__ == "__main__":
    main()
