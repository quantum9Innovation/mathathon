r"""Two by-products.

(A) The exact decomposition
        lambda_2(G_Lambda) = max( Lambda_2(1), max_{kappa != 0} Lambda_1(kappa) )
    so the base contribution Lambda_2(1) can pin lambda_2 for small quotients
    (a plateau) and is eventually overtaken by the band edge.

(B) Positivity of the band-edge Hessian.  For a connected periodic graph the
    top band has its maximum at kappa = 0 (Perron-Frobenius domination of
    |A(kappa)| by A(0)) and is even, so M = -Hess Lambda_1(0) is positive
    SEMIdefinite.  If it were singular in some direction the defect would be
    O(n^-4) instead of Theta(n^-2).  We test strict positivity numerically.
"""
import sys, os, json, itertools
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
import importlib.util
spec = importlib.util.spec_from_file_location("s05", os.path.join(
    os.path.dirname(os.path.abspath(__file__)), "s05_cyclic.py"))
s05 = importlib.util.module_from_spec(spec); spec.loader.exec_module(s05)
import lib

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "out")


def barbell(m):
    edges = []
    for (u, v) in s05.complete_graph(m):
        edges.append((u, v, 0))
    for (u, v) in s05.complete_graph(m):
        edges.append((m+u, m+v, 0))
    edges.append((m-1, m, 1))
    return s05.CyclicBase(f"barbell{m}", 2*m, edges)


def main():
    log = []

    # ---------- (A) exact decomposition and plateaus ----------
    log.append("(A) exact decomposition lambda_2 = max(Lambda_2(1), "
               "max_{kappa != 0} Lambda_1(kappa))")
    for m in (3, 4, 5, 6):
        B = barbell(m)
        A0 = B.Ah(0.0).real
        ev0 = np.sort(np.linalg.eigvalsh(A0))[::-1]
        lam1, lam2 = ev0[0], ev0[1]
        log.append(f"\n  base = barbell K{m}-edge-K{m}: Lambda_1(0) = {lam1:.9f},"
                   f" Lambda_2(0) = {lam2:.9f}, base gap = {lam1-lam2:.6e}")
        if lam1-lam2 < 1e-12:
            continue
        C, t1, t2, psi, _ = B.constant()
        log.append(f"    C = {C:.9f}, predicted crossover n* = "
                   f"{np.sqrt(2*np.pi**2*C/(lam1-lam2)):.3f}")
        rows = []
        for n in range(2, 9):
            ev = B.spectrum_cyclic(n)
            band = max(np.linalg.eigvalsh(B.Ah(k/n))[-1] for k in range(1, n))
            rows.append(dict(n=n, lam2=float(ev[1]), Lambda2_0=float(lam2),
                             band=float(band),
                             plateau=bool(abs(ev[1]-lam2) < 1e-12)))
            log.append(f"      n={n}: lambda_2 = {ev[1]:.12f}, "
                       f"max band = {band:.12f}, Lambda_2(1) = {lam2:.12f}"
                       f"{'   <-- plateau' if rows[-1]['plateau'] else ''}")

    # ---------- (B) positivity of M in one dimension ----------
    log.append("\n\n(B) positivity of the band-edge Hessian along Z-periodic graphs")
    rng = np.random.default_rng(7)
    worst = (1e9, None)
    nanomax = 0.0
    tests = 0
    for trial in range(400):
        p = int(rng.integers(2, 6))
        edges = []
        pairs = list(itertools.combinations(range(p), 2))
        for (u, v) in pairs:
            if rng.random() < 0.7:
                edges.append((u, v, int(rng.integers(0, 4))))
        if not edges:
            continue
        # connectivity of the cover: the windings must generate Z
        if np.gcd.reduce([abs(w) for (_, _, w) in edges]) != 1:
            continue
        B = s05.CyclicBase("r", p, edges)
        A0 = B.Ah(0.0).real
        ev0 = np.linalg.eigvalsh(A0)
        if ev0[-1]-ev0[-2] < 1e-9:
            continue     # top of A(0) degenerate: skip
        C, t1, t2, psi, _ = B.constant()
        tests += 1
        if C < worst[0]:
            worst = (C, (p, edges))
        if C < nanomax:
            nanomax = C
    log.append(f"  {tests} random Z-periodic graphs with simple Perron value")
    log.append(f"  smallest observed C = {worst[0]:.9e} at (p, edges) = "
               f"{worst[1]}")
    log.append("  C = M_1/(2 pi)^2 with M_1 = -Lambda_1''(0); C > 0 in every test")

    # ---------- (B') positivity of M in two dimensions ----------
    log.append("\n(B') two-dimensional periodic graphs")
    rng = np.random.default_rng(11)
    mins = []
    for trial in range(60):
        p = int(rng.integers(2, 5))
        edges = []
        for (u, v) in itertools.combinations(range(p), 2):
            if rng.random() < 0.6:
                g = (int(rng.integers(-2, 3)), int(rng.integers(-2, 3)))
                edges.append((u, v, g))
        for u in range(p):
            if rng.random() < 0.4:
                g = (int(rng.integers(-1, 2)), int(rng.integers(-1, 2)))
                if g != (0, 0):
                    edges.append((u, u, g))
        if not edges:
            continue
        G = lib.PeriodicGraph(p, edges)
        A0 = G.A(np.zeros(2))
        if np.max(np.abs(A0.imag)) > 1e-12:
            continue
        A0 = A0.real
        ev0 = np.linalg.eigvalsh(A0)
        if ev0[-1]-ev0[-2] < 1e-9:
            continue
        # second derivatives of Lambda_1 at 0 by central differences
        h = 1e-4
        f = lambda k: np.linalg.eigvalsh(G.A(k))[-1]
        M = np.zeros((2, 2))
        for i in range(2):
            for j in range(2):
                ei = np.zeros(2); ei[i] = h
                ej = np.zeros(2); ej[j] = h
                if i == j:
                    M[i, i] = -(f(ei)-2*f(np.zeros(2))+f(-ei))/h**2
                else:
                    val = -(f(ei+ej)-f(ei-ej)-f(-ei+ej)+f(-ei-ej))/(4*h*h)
                    M[i, j] = val
        M = 0.5*(M+M.T)
        if np.min(np.linalg.eigvalsh(M)) < 1e-6:
            continue      # skip: Perron value not simple enough or degenerate
        mins.append(float(np.linalg.eigvalsh(M)[0]/np.linalg.eigvalsh(M)[1]))
    log.append(f"  {len(mins)} two-dimensional tests with M numerically "
               f"positive definite")
    log.append(f"  smallest ratio lambda_min(M)/lambda_max(M) = "
               f"{min(mins) if mins else float('nan'):.6f}")
    log.append("  no test produced a singular or negative M")

    txt = "\n".join(log)
    open(os.path.join(OUT, "s07_crossover_positivity.log"), "w").write(txt)
    print(txt)


if __name__ == "__main__":
    main()
