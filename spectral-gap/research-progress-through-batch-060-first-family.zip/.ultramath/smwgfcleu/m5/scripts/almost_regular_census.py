"""Almost regular graphs: the nearly-trivial cluster and the defect census.

Prediction to be tested (fixed Delta, n -> infinity, uniform random d-regular host):
  lambda_1 -> max(d, lam_f),  lambda_2 -> min(d, lam_f),
where lam_f is the root in (2 sqrt(d-1), infinity) of

      lam = Delta * G_d(lam),      G_d(lam) = int dmu_KM(x)/(lam - x) = r/(1-r^2),

r the root of (d-1) r^2 - lam r + 1 = 0 with |r| < 1.  A root exists iff
Delta > 2(d-2)  (the edge value: G_d(2 sqrt(d-1)) = sqrt(d-1)/(d-2)).
With k spikes of degrees Delta_1..Delta_k and pairwise far apart the k roots
lam_f(Delta_i) are all present (censoring the trivial cluster at d).
"""
import numpy as np, networkx as nx
from scipy.sparse.linalg import eigsh
from scipy.optimize import brentq

def G(d, lam):
    a, b, c = d - 1.0, -lam, 1.0
    disc = b*b - 4*a*c
    if disc < 0: return None
    r = min([(-b+np.sqrt(disc))/(2*a), (-b-np.sqrt(disc))/(2*a)], key=abs)
    return r/(1-r*r)

def lam_f(d, Delta):
    edge = 2*np.sqrt(d-1.0)
    thr = 2*(d-2)
    if Delta <= thr + 1e-12:
        return edge
    hi = max(np.sqrt(Delta)*3.0, d*1.5) + 10
    f = lambda t: t - Delta*G(d, t)
    return brentq(f, edge*(1+1e-12), hi, xtol=1e-13)

def build(d, degs, n, seed):
    G0 = nx.random_regular_graph(d, n, seed=seed)
    Gp = nx.convert_node_labels_to_integers(G0)
    rng = np.random.default_rng(seed + 1)
    nxt = n
    for Delta in degs:
        T = rng.choice(n, size=Delta, replace=False)   # spike hangs off host vertices
        Gp.add_node(nxt)
        for y in T: Gp.add_edge(nxt, int(y))
        nxt += 1
    return nx.to_scipy_sparse_array(Gp, format='csr', dtype=float)

def topks(A, k):
    return np.sort(eigsh(A, k=k, which='LA', return_eigenvectors=False))[::-1]

print("single spike, n = 4000 and n = 16000")
print(f"{'d':>2} {'Del':>4} {'2(d-2)':>6} {'n':>6} {'lam1':>9} {'lam2':>9} {'lam3':>9} "
      f"{'max(d,lf)':>10} {'min(d,lf)':>10} {'edge':>8} {'lam*':>8}")
for d, Delta, n in [(5,4,4000),(5,6,4000),(5,8,4000),(5,20,4000),
                    (6,9,4000),(6,10,4000),(6,30,4000),
                    (3,6,16000),(4,7,16000),(5,8,16000)]:
    A = build(d, [Delta], n, 1234 + 17*d + Delta)
    t = topks(A, 5)
    lf = lam_f(d, Delta)
    lamstar = Delta/np.sqrt(Delta+1-d) if Delta > 2*(d-1) else float('nan')
    print(f"{d:2d} {Delta:4d} {2*(d-2):6d} {n:6d} {t[0]:9.5f} {t[1]:9.5f} {t[2]:9.5f} "
          f"{max(d,lf):10.5f} {min(d,lf):10.5f} {2*np.sqrt(d-1):8.5f} {lamstar:8.5f}")

print("\ntwo and three spikes (degree census), n = 4000")
print(f"{'d':>2} {'degs':>10} {'lam1':>9} {'lam2':>9} {'lam3':>9} {'lam4':>9} "
      f"{'lf list':>26} {'d':>4}")
for d, degs in [(4,[7,11]),(4,[7,7,11]),(5,[9,14,20]),(3,[5,5])]:
    A = build(d, degs, 4000, 99 + 3*d + sum(degs))
    t = topks(A, 6)
    lfs = sorted((lam_f(d, D) for D in degs), reverse=True)
    print(f"{d:2d} {str(degs):>10} {t[0]:9.5f} {t[1]:9.5f} {t[2]:9.5f} {t[3]:9.5f} "
          f"{str([round(x,4) for x in lfs]):>26} {d:4d}")
