"""One spike on a random d-regular host: where do the new eigenvalues go?

Exact input (Cauchy interlacing + Schur complement).  Let G be d-regular on n
vertices, T a set of Delta vertices, G' = G + one new vertex adjacent to T.
Then for lambda not in spec(A_G), lambda is an eigenvalue of A_{G'} iff

      lambda = - 1_T^T (A_G - lambda)^{-1} 1_T .                      (SE)

Bulk-averaged prediction.  For a random d-regular host and eigenvectors with
|u_i(y)|^2 ~ 1/n, (SE) becomes the scalar fixed point equation

      lambda = -Delta * g_{d}(lambda),                                (KM)

where g_d(lambda) = <delta_v,(A-lambda)^{-1} delta_v> of the d-regular tree
= 1/(-lambda + d r(lambda)), r(lambda) the root of (d-1)r^2 - lambda r + 1 = 0
with |r|<1.  Compare also with the spiked-tree eigenvalue
      lambda* = Delta/sqrt(Delta+1-d)   (exists iff Delta > 2(d-1)).
"""
import numpy as np, networkx as nx
from scipy.sparse.linalg import eigsh
from scipy.optimize import brentq

def r_small(d, lam):
    """root of (d-1) r^2 - lam r + 1 with |r| < 1/sqrt(d-1) (bulk) or |r|<1 outside."""
    a, b, c = d - 1.0, -lam, 1.0
    disc = b * b - 4 * a * c
    if disc < 0:                     # inside the bulk
        return None
    s = np.sqrt(disc)
    roots = [(-b + s) / (2 * a), (-b - s) / (2 * a)]
    return min(roots, key=abs)

def g_tree(d, lam):
    r = r_small(d, lam)
    if r is None:
        raise ValueError("lambda inside the bulk")
    return 1.0 / (-lam + d * r)

def km_roots(d, Delta, lo=None, hi=None):
    """all solutions of lambda = -Delta g_d(lambda) outside the bulk."""
    edge = 2 * np.sqrt(d - 1.0)
    out = []
    # positive side
    lam_hi = max(edge * 1.0000001, np.sqrt(Delta) * 1.5, d * 1.05) + 5.0
    xs = np.linspace(edge + 1e-9, lam_hi, 200001)
    fs = np.array([lam + Delta * g_tree(d, lam) for lam in xs])
    for i in range(len(xs) - 1):
        if fs[i] * fs[i + 1] < 0:
            out.append(brentq(lambda t: t + Delta * g_tree(d, t), xs[i], xs[i + 1], xtol=1e-13))
    # negative side
    xs2 = np.linspace(-lam_hi, -edge - 1e-9, 200001)
    fs2 = np.array([lam + Delta * g_tree(d, lam) for lam in xs2])
    for i in range(len(xs2) - 1):
        if fs2[i] * fs2[i + 1] < 0:
            out.append(brentq(lambda t: t + Delta * g_tree(d, t), xs2[i], xs2[i + 1], xtol=1e-13))
    return sorted(out)

def spike_spectrum(d, Delta, n, seed, k=8):
    G = nx.random_regular_graph(d, n, seed=seed)
    Gp = nx.convert_node_labels_to_integers(G)
    Gp.add_node(n)
    T = list(np.random.default_rng(seed + 777).choice(n, size=Delta, replace=False))
    for y in T:
        Gp.add_edge(n, int(y))
    A = nx.to_scipy_sparse_array(Gp, format='csr', dtype=float)
    nv = A.shape[0]
    if k >= nv - 2:
        w = np.linalg.eigvalsh(A.toarray())
        return w[-k:][::-1], w[:k]
    top = eigsh(A, k=k, which='LA', return_eigenvectors=False)
    bot = eigsh(A, k=k, which='SA', return_eigenvectors=False)
    return np.sort(top)[::-1], np.sort(bot)

print("Random d-regular host + one spike.  n = 4000 (unless stated).")
print(f"{'d':>2} {'Del':>4} {'n':>6} {'lam1':>9} {'lam2':>9} {'3rd':>9} "
      f"{'KM+':>9} {'KM-':>9} {'lam*':>9} {'edge':>8}")
cases = [(3,3,4000),(3,4,4000),(3,5,4000),(3,6,4000),(3,12,4000),
         (4,5,4000),(4,7,4000),(4,20,4000),(5,9,4000),(5,40,4000),
         (3,6,20000),(4,20,20000)]
for d, Delta, n in cases:
    top, bot = spike_spectrum(d, Delta, n, seed=20260101 + 31 * d + Delta)
    rts = km_roots(d, Delta)
    pos = [x for x in rts if x > 0]
    edge = 2 * np.sqrt(d - 1.0)
    lamstar = Delta / np.sqrt(Delta + 1 - d) if Delta > 2 * (d - 1) else float('nan')
    print(f"{d:2d} {Delta:4d} {n:6d} {top[0]:9.5f} {top[1]:9.5f} {top[2]:9.5f} "
          f"{pos[-1] if pos else float('nan'):9.5f} {pos[0] if len(pos)>1 else float('nan'):9.5f} "
          f"{lamstar:9.5f} {edge:8.5f}")
