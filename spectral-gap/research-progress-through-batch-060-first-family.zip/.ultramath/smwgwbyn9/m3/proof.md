# The exterior resolvent limit for fixed-degree random regular graphs, and the finite-defect root law

Member m3, swarm smwgwbyn9, direction d1 (role 3: nonbacktracking exterior resolvent
expansion, summability and tail control). All files in `.ultramath/smwgwbyn9/m3/`.

**Revision (after first review).** Two repairs are incorporated. (1) The domain of
Lemma 4.1 in the proof of Theorem A is now an explicitly bounded rectangle
`Omega_0` with `closure(Omega_0) subset {Re lambda > B_d + eps}`, on which the
resolvent bound `M_0` of (**) is finite, explicit and independent of `n`; the previous
draft applied Lemma 4.1 on the unbounded half-plane `H_eps`, where the bound degenerates.
(2) The `O(1/n)` localisation of the eigenvalue near `d` is **withdrawn** (5.4(b)):
fixed-energy convergence gives no control of `(lambda-d) g_n(lambda)` at a root drifting
to `d`, so only `lambda - d -> 0` is claimed. No rate, no finite-size bound and no exact
`1/n` constant is claimed anywhere. The Perron sign correction
(`Sigma_n` receives `+Delta^2/(n(d-lambda))`) is confirmed, and the raw numerical output
has been regenerated from the current script.

**Fixed throughout:** `d >= 3` integer, `Delta >= 1` integer, both *fixed*. `T` is a
*fixed* set of `Delta` distinct vertices. `G = G_n` is a uniform simple `d`-regular
graph on `[n]`, `A = A_n` its adjacency, `G' = G'_n` the graph obtained by adding one
new vertex adjacent exactly to `T`. Nothing below is a growing-degree statement and
nothing is averaged over `T`.

## 0. Results

Throughout write

* `B_d := 2 sqrt(d-1)` (bulk edge of the `d`-regular tree),
* `r = r(lambda)` for the root of `(d-1) r + 1/r = lambda` with `|r| < 1/sqrt(d-1)`
  (for `lambda > B_d` real it is the small positive root; for `|lambda| > B_d` complex
  it is the root of smaller modulus and the other has modulus `> sqrt(d-1)`),
* `G_d(lambda) := 1/(lambda - d r) = r/(1-r^2)` on `{|lambda| > B_d}`
  (the Stieltjes transform of the Kesten--McKay law, *not* a one-sided tree branch),
* `g_n(lambda) := 1_T^T (A - lambda)^{-1} 1_T + Delta^2/(n(lambda-d)) + Delta G_d(lambda)`.

**Theorem A (exterior resolvent limit; fixed `d >= 3`, fixed `T`).**
For every compact `K` contained in the half-plane `H := {Re lambda > B_d}`,

    sup_{lambda in K} | g_n(lambda) |  ->  0   in probability.

In particular for every compact `K subset (B_d, d) union (d, infinity)`,

    sup_{lambda in K} | 1_T^T (A_n - lambda I)^{-1} 1_T + Delta^2/(n(lambda-d)) + Delta G_d(lambda) |
      -> 0   in probability.

This is hypothesis (H) of the m5 dossier's Proposition D, with the exact Perron term
`Delta^2/(n(lambda-d))` kept. It is uniform in `lambda` on compacts, not pointwise,
and it is a statement about the fixed set `T`.

**Theorem B (finite-defect root law; fixed `d >= 3`, fixed `T`).** Let
`phi(lambda) := lambda - Delta G_d(lambda)` on `(B_d, infinity)`. It is strictly
increasing, so it has at most one zero. If `Delta > 2(d-2)` let `lambda_f` be that
zero; it exists exactly under that condition. Then, in probability,

    lambda_1(G'_n) -> max(d, lambda_f),      lambda_2(G'_n) -> min(d, lambda_f),

and for every `eta > 0` small enough, with probability tending to one `A_{G'_n}` has
exactly one eigenvalue in `(lambda_f - eta, lambda_f + eta)` and exactly one in
`(d - eta, d + eta)`, and no eigenvalues in
`[B_d + eta, 1/eta]` other than those, and the root near `d` satisfies
`lambda - d -> 0` in probability. If `Delta <= 2(d-2)` then `lambda_1(G'_n) -> d` and
`Pr[lambda_2(G'_n) <= B_d + eta] -> 1` for every `eta > 0` (the matching lower bound is
the Alon--Boppana side and is not re-proved here).

**No rate is claimed.** Not `O(1/n)`, not the finite-size law
`lambda_2 = d - Delta^2/(n(Delta G_d(d)-d))`, not any constant. See 5.4(b) and 5.5 for
the precise reason: a fixed-energy resolvent limit gives vanishing errors at each fixed
`lambda`, which does not control `(lambda-d) g_n` at a root that drifts to `d`.

`lambda_f > d` iff `Delta G_d(d) > d` iff `Delta > d^2(d-2)/(d-1)`; then the root near
`lambda_f` is the first eigenvalue and the root near `d` is the second. The sign
`Delta G_d(d) - d` is never zero for integer `Delta` and `d >= 3` (see 5.3), so
`lambda_f = d` does not occur.

**Proposition C (the deterministic form of (H) is false).** For a `d`-regular `G` and
`t, t'` at distance `k` in `G`, if the ball of radius `k` around `t` is a tree then
`(A_G - lambda)^{-1}_{tt'} = -G_d(lambda) r(lambda)^k` exactly. Hence

    1_T^T (A_G - lambda)^{-1} 1_T = - G_d(lambda) sum_{t,t' in T} r(lambda)^{dist(t,t')}

whenever the relevant balls are trees. If two vertices of `T` are adjacent this is
`-G_d(Delta + 2 r + O(r^2))`, which differs from `-Delta G_d` by the nonvanishing
amount `2 G_d r`. So `1_T^T(A-lambda)^{-1}1_T -> -Delta G_d(lambda)` is *not* a
deterministic consequence of local tree structure; it holds only in probability, via
`dist(t,t') -> infinity`. Any per-graph secular law of the form
`lambda = Delta G_d(lambda)` is false. Verified numerically in `out/check_A_D.txt`
(d=3, Delta=2, T={0,1} adjacent: value `-1.33206` vs tree formula `-1.33333` vs false
limit `-0.95238`).

**Notation for the two windows.** `(B_d, d)` is the interior window where
`lambda_f` lives for `2(d-2) < Delta <= d^2(d-2)/(d-1)`; `(d, infinity)` contains the
Perron value `d` and the `lambda_f` for larger `Delta`.

---

## 1. The tree resolvent: one prefactor at every distance

**Lemma 1.1.** Let `d >= 3` and `lambda in C` with `|lambda| > d`. For the infinite
`d`-regular tree `T_d` (rooted anywhere) and vertices `x, y` at distance `k`,

    ((lambda - A_{T_d})^{-1})_{xy} = G_d(lambda) r(lambda)^k,
    G_d(lambda) = 1/(lambda - d r) = r/(1-r^2).

*Proof.* Fix `x`. Let `phi(y) := alpha r^{dist(x,y)}` with `alpha := 1/(lambda - d r)`
and let `psi(y) := ((lambda - A_{T_d})^{-1})_{x y}`, which exists because
`|lambda| > d > B_d = ||A_{T_d}||`. Both are bounded: `|phi| <= |alpha|` and
`|psi(y)| <= sum_k |lambda|^{-k-1} d^k = 1/(|lambda| - d) < infinity` (a walk of
length `k` from `x` is one of at most `d^k`).

Both satisfy `(lambda - A) u = e_x` entrywise. For `psi` this is the resolvent
equation. For `phi`, take `y != x` with `k = dist(x,y) >= 1`: exactly one neighbour of
`y` lies on the geodesic to `x`, at distance `k-1`, and the other `d-1` at distance
`k+1`, so

    (lambda phi)(y) - (A phi)(y) = alpha r^k [ lambda - r^{-1} - (d-1) r ]
                                = alpha r^k [ lambda - ( (d-1) r + 1/r ) ] = 0,

using `(d-1) r + 1/r = lambda`. At `y = x`,
`lambda phi(x) - (A phi)(x) = alpha lambda - d alpha r = alpha (lambda - d r) = 1`.
So `h := psi - phi` is bounded and `(lambda - A) h = 0`; at every vertex
`|h(y)| <= |lambda|^{-1} sum_{z ~ y} |h(z)| <= (d/|lambda|) ||h||_infty`, and
`d/|lambda| < 1`, so `||h||_infty <= (d/|lambda|) ||h||_infty` forces `h = 0`.
Finally `1/(lambda - dr) = r/(1-r^2)` because
`r(lambda - dr) = lambda r - d r^2 = ((d-1) r + 1/r) r - d r^2 = 1 - r^2`.  QED

Two consequences used below: `G_d` is holomorphic on `{|lambda| > B_d}`; and on
`lambda > B_d` real, `r in (0, 1/sqrt(d-1))` is strictly decreasing and
`G_d > 0`, `G_d(d) = (d-1)/(d(d-2))`, `r(d) = 1/(d-1)`.

Numerical check of Lemma 1.1 (`scripts/check_theorem.py`, section B): maximum of
`|((lambda-A)^{-1})_{xy} - G_d r^{dist}|` over all `y` at distance `<= R-2` in a genuine
(d-regular) truncated tree with up to `27306` vertices: `1.0e-5` (d=3, lambda=3.30),
`3.4e-4` (d=3, lambda=2.95, R=12), `2.0e-6` (d=4), `5.0e-7` (d=5). The residual is
truncation error, not a discrepancy.

## 2. Exact removal of the Perron eigenvalue

**Lemma 2.1.** Let `A` be the adjacency of a `d`-regular graph on `n` vertices,
`J = 1 1^T`, `Ahat := A - (d/n) J`, and `lambda notin sigma(A)`. Then
`sigma(Ahat) = {0} union (sigma(A) \ {d})` and

    1_T^T (A - lambda)^{-1} 1_T  =  1_T^T (Ahat - lambda)^{-1} 1_T
                                     + Delta^2/(n lambda) - Delta^2/(n(lambda - d)).

Consequently `g_n = 1_T^T (Ahat - lambda)^{-1} 1_T + Delta^2/(n lambda) + Delta G_d`.

*Proof.* `A 1 = d 1`, so `Ahat 1 = 0` and `Ahat = A` on `1^perp`; this gives the
spectrum. Sherman--Morrison with `A - lambda = (Ahat - lambda) + (d/n) 1 1^T`,
`(Ahat-lambda)^{-1} 1 = -1/lambda` and `1^T (Ahat - lambda)^{-1} 1 = -n/lambda`:

    (A - lambda)^{-1} = (Ahat-lambda)^{-1} - (d/n) (Ahat-lambda)^{-1} 1 1^T (Ahat-lambda)^{-1}
                                        / (1 + (d/n) 1^T (Ahat-lambda)^{-1} 1)
                      = (Ahat-lambda)^{-1} - (d/(n lambda (lambda - d))) 1 1^T,

since `1 - d/lambda = (lambda-d)/lambda` and the numerator matrix is
`(d/n) lambda^{-2} 1 1^T`. Sandwiching with `1_T` gives the claim because
`(d/(n lambda (lambda-d))) Delta^2 = Delta^2/(n lambda) - Delta^2/(n(lambda-d))`.  QED

Checked exactly, in rational arithmetic with no floating point, on `K_4`, `Q_3`, the
Petersen graph, `K_5` and `C_5 x K_2`, for `Delta in {1,2,3}` and
`lambda in {7/3, 11/5, -13/4}` (`out/check_A.txt`, all `True`).

*Remark* (sign erratum in the accepted dossier). The m5 dossier writes
`Sigma ~ (lambda - Delta G_d(lambda)) + Delta^2/(n(lambda-d))`. The last term must be
`Delta^2/(n(d-lambda))`; note `-Delta G_d` already carries the minus sign of the
resolvent. The dossier's conclusions (existence of the interior root, sign of
`Delta G_d(d)-d`, and the finite size law `epsilon = Delta^2/(n(Delta G_d(d)-d))`) are
derived from the correct sign and are unaffected.

## 3. The ray above the Perron value: an elementary walk expansion

For `lambda` with `|lambda| > d` we have `||A/lambda|| < 1`, so

    -(A - lambda)^{-1} = (lambda - A)^{-1} = sum_{k>=0} lambda^{-k-1} A^k,

the series converging geometrically with ratio `rho := d/|lambda| < 1`. Hence

    -1_T^T (A - lambda)^{-1} 1_T = sum_{k>=0} lambda^{-k-1} W_k,
    W_k := 1_T^T A^k 1_T = number of walks of length k with both endpoints in T.

Two crude bounds are used repeatedly:

    |W_k| <= Delta d^k   and   |w_k(x,y)| <= d^k

where `w_k(x,y)` is the number of walks of length `k` from `x` to `y`.

**Lemma 3.1 (walk counts see only the ball).** Let `H` be `d`-regular, `t in V(H)`,
`L >= 0`, and suppose the ball `B_L(t)` induces a tree in `H`. Then the rooted trees
`(B_L(t), t)` and `(B_L^{T_d}(x), x)` are isomorphic, and for every `k <= L` and every
`y`: the number of walks of length `k` from `t` to `y` in `H` equals the number in
`T_d`. In particular for `t' in T` and `k <= L`,

    (A^k)_{t t'} = w_k(dist_H(t,t'))

with `w_k(delta) := (A_{T_d}^k)_{xy}` for `dist(x,y) = delta` (`0` if `delta > k`).

*Proof.* Any walk of length `k <= L` from `t` stays in `B_k(t) subset B_L(t)`. Every
vertex of `H` at distance `< L` from `t` has all `d` neighbours at distance `<= L`,
hence inside `B_L(t)`; since `B_L(t)` is a tree, induction on the radius gives that
`B_L(t)` is isomorphic, as a rooted graph, to the radius-`L` ball of `T_d`. Walk counts
are invariant under rooted isomorphism.  QED

**Lemma 3.2 (tree balls are typical).** Fix `d >= 3`, `L < infinity` and a fixed
finite `T`. Then for uniform simple `d`-regular `G_n`,

    Pr[ B_L(t) induces a tree for every t in T ]  >=  1 - C(d,L,Delta)/n .

*Proof sketch* (standard; the configuration model argument). Expose `B_L(t)`
breadth-first in the configuration model. The ball has at most
`N_L := 1 + d((d-1)^L - 1)/(d-2) = O_{d,L}(1)` vertices and at most `d N_L` stubs.
Each free stub is matched to a uniformly random unused stub among at least `dn - dN_L`
of them; a bad match (creating a repeated vertex, a cycle, or a multiple edge inside
the ball) has conditional probability at most `d N_L/(dn - dN_L)`. There are at most
`d N_L` matches, so the failure probability is `O_{d,L}(N_L^2/n)`. Conditioning the
configuration model on simplicity gives the uniform simple `d`-regular graph, and
`Pr[simple] -> exp(-(d^2-1)/4) > 0`, which only changes the constant.  QED

**Proposition 3.3 (limit on the exterior of the disc).** Fix `d >= 3`, fixed `T`, and
a compact `K` with `K subset {|lambda| > d}` and `dist(K, d) > 0`. Then
`sup_{lambda in K} |g_n(lambda)| -> 0` in probability.

*Proof.* Let `eps > 0`. Fix `L` with

    (Delta^2 + Delta) rho^{L+1} / (|lambda| (1-rho)) < eps/3     for all lambda in K,
    Delta^2 (1/(|lambda|-d)) |r|^{L+1} < eps/3                   for all lambda in K,

possible because `rho = d/|lambda|` and `|r| < 1/sqrt(d-1) < 1` are bounded away from
`1` on `K` (note `|r(lambda)| -> 0` as `|lambda| -> infinity` and `|r| < 1/sqrt(d-1)`
always). Let `E` be the event of Lemma 3.2 for this `L`, and let `D` be the event that
`dist(t,t') > L` for all distinct `t,t' in T`; `Pr[D^c] = O_{d,L}(1/n)` by the same
argument (a pair at distance `<= L` means a repeated vertex in the two balls).

On `E`, Lemma 3.1 applies for every `k <= L`. Splitting the series at `L`:

    -1_T^T(A-lambda)^{-1}1_T = sum_{k<=L} lambda^{-k-1} W_k + sum_{k>L} lambda^{-k-1}W_k.

The second sum has modulus at most `Delta rho^{L+1}/(|lambda|(1-rho)) < eps/3`. On `E`,
`W_k = sum_{t,t'} w_k(dist(t,t'))` for `k <= L`, and by Lemma 1.1
`sum_{k>=0} lambda^{-k-1} w_k(delta) = G_d(lambda) r^delta` (absolutely convergent,
Lemma 1.1 and `|w_k| <= d^k`), so

    | sum_{k<=L} lambda^{-k-1}W_k - sum_{t,t'} G_d(lambda) r^{dist(t,t')} |
      <= sum_{t,t'} sum_{k>L} |lambda|^{-k-1} d^k
      <= Delta^2 rho^{L+1}/(|lambda|(1-rho)) < eps/3.

On `D`, `|sum_{t!=t'} G_d r^{dist}| <= Delta^2 |G_d| |r|^{L+1} < eps/3`, and
`sum_{t} G_d r^0 = Delta G_d`. So on `E cap D`,

    | -1_T^T(A-lambda)^{-1}1_T - Delta G_d(lambda) | < eps,

uniformly in `lambda in K`. Adding the Perron term, which is at most
`Delta^2/(n dist(K,d))` in modulus, gives `|g_n| < eps` on `E cap D` and
`Pr[(E cap D)^c] -> 0`.  QED

Observe what Proposition 3.3 does *not* need: no spectral gap, no delocalisation, no
self-energy, no estimate on the resolvent of the complement. Only the exact tree
resolvent (Lemma 1.1) and the fact that a fixed-radius ball is a tree with probability
`1-O(1/n)`. The exponential decay of `r^dist` is what replaces the missing
summability of nonbacktracking path counts: the number of nonbacktracking paths grows
like `(d-1)^k`, and `(d-1)|r|^2 < 1`; the entrywise decay `|r|^k` is *not* summable
against the `d(d-1)^{k-1}` vertices at distance `k` once `|r| > 1/d` (and near the bulk
edge `|r| -> 1/sqrt(d-1)`, so it never is), which is exactly the failure of the naive
nonbacktracking path sum. The expansion is therefore used *entrywise*, per pair
`(t,t')`, and never summed over the graph; the sum over pairs is then controlled by
`dist(t,t') -> infinity`, i.e. in probability. That is why the limit is `Delta G_d` and
not `0`.

## 4. Analytic continuation into the interior window

The passage from the ray `(d, infinity)` to `(B_d, d)` uses two inputs: the exact
Perron subtraction (Lemma 2.1), which makes `g_n` holomorphic where the graph's
spectrum is absent, and the classical second-eigenvalue theorem, which supplies a
region free of spectrum with probability tending to one.

**Import F (Friedman; and Bordenave).** Fix `d > 2` and `eps > 0`. Then the
probability that a uniform random `d`-regular graph on `n` vertices has second
eigenvalue greater than `2 sqrt(d-1) + eps` tends to zero as `n -> infinity`.
Source: J. Friedman, *A proof of Alon's second eigenvalue conjecture and related
problems*, arXiv:cs/0405020v1 (5 May 2004; to appear in Mem. Amer. Math. Soc., 118
pp.); statement taken verbatim from the arXiv abstract of v1. The same fact is
recorded, with attribution to Friedman, in Bauerschmidt--Huang--Yau
arXiv:1609.09052v3, Section 1.1, item (iii) on PDF page 6 ("for any fixed `eps > 0`,
the nontrivial eigenvalues of `A` are contained in `[-2 sqrt(d-1) - eps,
2 sqrt(d-1) + eps]` ... proved in [42]"), which is the copy in
`results/spectral-research/batch-050/sources/`. A modern two-sided proof is
C. Bordenave, arXiv:1502.04482v4 (Ann. Sci. ENS), abstract: "the largest absolute
value of the non-trivial eigenvalues of its adjacency matrix is at most
`2 sqrt(d-1) + o(1)` with probability tending to one".

*Verified hypotheses.* Fixed `d >= 3` (Friedman's abstract: `d > 2`); uniform simple
`d`-regular ensemble (the conjecture's statement; Bordenave states it for "a random
`d`-regular graph"); real spectral parameter, no complex extension needed; one-sided
upper bound on the second largest eigenvalue, which is what is used.
*Not verified.* The theorem *number* inside Friedman's 118-page memoir (only the
abstract was read here); and Friedman's abstract says the conjecture is proved "for a
number of notions of random `d`-regular graph", so the reader should confirm that the
uniform simple model is among them -- Bordenave's abstract is unambiguous for that
model and can be used instead.

**Lemma 4.1 (propagation of smallness).** Let `Omega` be a domain, `U subset Omega`
open and nonempty, `K subset Omega` compact, `M < infinity`. Then there is
`theta in (0,1)` such that every `g` holomorphic on `Omega` with `|g| <= M` on
`Omega` satisfies

    sup_K |g| <= M^{1-theta} (sup_U |g|)^theta .

*Proof.* Two elementary steps.

*(i) Three-circles.* If `g` is holomorphic on `D(w,R)` with `|g| <= M` there, and
`A(rho) := max_{|z-w|=rho} log|g(z)|`, then Hadamard's three-circles theorem gives,
for `r_1 < r_2 < r_3 < R`,

    A(r_2) <= ((log(r_3/r_2))/(log(r_3/r_1))) A(r_1)
            + ((log(r_2/r_1))/(log(r_3/r_1))) A(r_3).

With `r_1 = r`, `r_2 = 2r`, `r_3 = 4r` the two coefficients are both `1/2`.

*(ii) Moving the centre keeps the radius and square-roots the quality.* Suppose
`|g| <= m` on `D(w,r)` and `|g| <= M` on `D(w, 5r)`. Let `|w' - w| <= r/2`. Then
`D(w', r/2) subset D(w, r)`, so `A_{w'}(r/2) <= log m`; and `D(w', 4r) subset D(w, 5r)`,
so `A_{w'}(4r) <= log M`. Applying (i) at centre `w'` with `r_1 = r/2`, `r_2 = r`,
`r_3 = 4r` (coefficients `log 8 / log 8 = 1` and ... use `r_2 = r`, `r_3 = 4r`):

    A_{w'}(r) <= (log(4)/log(8)) log m + (log(2)/log(8)) log M
              <= (1/2) log m + (1/2) log M,

so `|g| <= (m M)^{1/2}` on `D(w', r)`: the radius `r` is preserved, the centre may move
by `r/2`, and the exponent on `m` is halved.

*(iii) Chain.* Fix `R > 0` with the `R`-neighbourhood of a compact path from a point of
`U` to `K` inside `Omega`, and put `r := R/5`. Choose `w_0 in U` with
`|g| <= m_0 := sup_U |g|` on `D(w_0, r)`, and `w_1, ..., w_N` with `|w_{j+1}-w_j| <= r/2`
and `K` contained in the `r`-neighbourhood of `w_N`. Iterating (ii) gives
`|g| <= m_N` on `D(w_N, r)` with `log m_N <= 2^{-N} log m_0 + (1-2^{-N}) log M`, and
then `sup_K|g| <= m_N`. Since `N` is finite and fixed, the claim holds with
`theta = 2^{-N}`.  QED

(Equivalently, Nevanlinna's two-constants theorem applied to `Omega` with the "small"
set `D(w_0,r)` removed. Note that smallness on an **open** set is essential; a bound
at a single interior point propagates only additively, the extremal being the
Schwarz--Pick function `z -> M(z + m/M)/(1 + (m/M) z)`.)

**Proof of Theorem A.** Let `K` be a compact subset of `H = {Re lambda > B_d}`. Choose
`eps > 0` and `delta > 0` with

    K' := {lambda : dist(lambda, K) <= delta} subset {Re lambda > B_d + 2 eps},
    U  := {lambda : |lambda| > d + delta, Re lambda > B_d + eps},

so `U` is open, `U subset H`, `U` meets the ray and `K' cup U` is compactly contained
in `H`. Let

    F_n := { lambda_2(A_n) <= B_d + eps },

so `Pr[F_n] -> 1` by Import F. On `F_n`, `sigma(A_n) subset {d} cup [-d, B_d + eps]`
and therefore `sigma(Ahat_n) = {0} cup (sigma(A_n)\{d})` avoids the half-plane
`{Re lambda > B_d + eps}`. Hence by Lemma 2.1, on `F_n`,

    g_n(lambda) = 1_T^T (Ahat_n - lambda)^{-1} 1_T + Delta^2/(n lambda) + Delta G_d(lambda)

is holomorphic on the half-plane `H_eps := {Re lambda > B_d + eps}`, and for every
`lambda in H_eps`

    |g_n(lambda)| <= Delta/ (Re lambda - B_d - eps) + Delta^2/(n |lambda|) + Delta |G_d(lambda)|
                                                                                  (*)

(use `|(Ahat - lambda)^{-1}| <= dist(lambda, sigma(Ahat))^{-1} <=
(Re lambda - B_d - eps)^{-1}`, valid because `sigma(Ahat)` is real and `<= B_d + eps`
on `F_n`). Note that (*) is *not* bounded on `H_eps`: it degenerates as
`Re lambda downarrow B_d + eps`. Lemma 4.1 needs a finite `M` on its whole domain, so
we now restrict the domain explicitly.

Choose `0 < eps_1 < eps/2` and `R_0 < infinity` and put

    Omega_0 := { lambda : B_d + eps + 2 eps_1 < Re lambda < R_0,  |Im lambda| < R_0 },

a bounded open rectangle, hence a bounded domain. Take `R_0` so large and `eps_1` so
small that `K subset Omega_0` (possible since `K subset {Re lambda > B_d + 2 eps}` is
bounded), and let `U_0` be any nonempty open disc contained in `U cap Omega_0`.
Then `closure(Omega_0)` is a compact subset of `H_eps` and
`Re lambda - B_d - eps >= 2 eps_1` on it. Hence by (*), on `F_n`,

    |g_n(lambda)| <= M_0 := Delta/(2 eps_1) + Delta^2/(n (B_d+eps+2eps_1))
                             + Delta max_{closure(Omega_0)} |G_d|                (**)

for all `lambda in closure(Omega_0)` and every `n`, with
`M_0 = M_0(d, Delta, eps, eps_1, R_0) < infinity`: no dependence on `n`, on the random
graph, or on `omega`. (This is the step where boundedness must be arranged by hand:
`H_eps` itself is unbounded in the direction in which the spectral margin shrinks, so
(*)-(**) is a statement about `Omega_0`, not about all of `H_eps`.)

By Proposition 3.3, `sup_{U_0} |g_n| -> 0` in probability (`closure(U_0)` is a compact
subset of `{|lambda| > d}` with `dist(closure(U_0), d) > 0`). Combining (**) with Lemma 4.1 applied on
the domain `Omega_0` (with `M = M_0`, the open set `U_0` and the compact `K`):

    sup_K |g_n| <= M_0^{1-theta} (sup_{U_0} |g_n|)^theta   on F_n,

so

    Pr[ sup_K |g_n| > eta ] <= Pr[F_n^c]
                              + Pr[ sup_{U_0} |g_n| > (eta/M_0^{1-theta})^{1/theta} ] -> 0 .

As `K subset H` was an arbitrary compact, Theorem A follows.  QED

*Why this is not the forbidden "bulk complex-z" import.* No complex local law is
used. The only external probabilistic input (Import F) is a real spectral statement;
the complex variable enters only through the elementary identity of Lemma 2.1 and the
elementary estimate (*), and the identity is transported from the ray `(d, infinity)`
(where it is proved directly) to the rest of the half-plane by the Harnack chain. In
particular no limit `Im z -> 0` is taken and no bulk estimate is evaluated on the real
axis.

## 5. From the resolvent limit to the eigenvalue law

**5.1 The secular function.** By the accepted exact added-vertex identity
(`p_{G'} = p_G (lambda + 1_T^T (A_G - lambda)^{-1} 1_T)` as rational functions), for
`lambda notin sigma(A_G)`, `lambda` is an eigenvalue of `A_{G'}` iff
`Sigma_n(lambda) := lambda + 1_T^T (A_G - lambda)^{-1} 1_T = 0`; and eigenvalues of
`A_G` survive according to the mass of `1_T` on their eigenspace.

**5.2 Monotonicity.** Write `1_T^T (A-lambda)^{-1}1_T = sum_i (1_T^T u_i)^2/(lambda_i - lambda)`
in an orthonormal eigenbasis. Every summand is strictly increasing in `lambda` on
`(lambda_i, infinity)`. On `F_n` all `lambda_i <= B_d + eps` for `i >= 2`, so
`Sigma_n` is strictly increasing on `(B_d + eps, d)` and on `(d, infinity). Hence it
has at most one zero in each of the two windows, and:

    Sigma_n(lambda) = phi(lambda) - Delta^2/(n(lambda-d)) + g_n(lambda) + O(1/n)
                    = phi(lambda) - Delta^2/(n(lambda-d)) + o(1),

uniformly on compacts of `(B_d, d) union (d, infinity)` (`O(1/n)` absorbed, since
`g_n` already contains `+Delta^2/(n(lambda-d))` and `phi = lambda - Delta G_d`).

**5.3 The reference function.** `phi(lambda) = lambda - Delta G_d(lambda)` on
`(B_d, infinity)`. `G_d' < 0` (Stieltjes transform off the support), so
`phi' = 1 + Delta |G_d'| > 0`: strictly increasing, hence at most one zero. As
`lambda downarrow B_d`, `r uparrow 1/sqrt(d-1)` and
`G_d -> sqrt(d-1)/(d-2)`, so `phi(B_d^+) = sqrt(d-1) (2 - Delta/(d-2))`, negative
exactly when `Delta > 2(d-2)`; and `phi(lambda) ~ lambda -> infinity`. Hence the zero
`lambda_f` exists exactly when `Delta > 2(d-2)`, and it is unique. At `lambda = d`,
`G_d(d) = (d-1)/(d(d-2))` and `phi(d) = d - Delta (d-1)/(d(d-2))`, so `lambda_f > d`
iff `Delta G_d(d) > d`. `Delta G_d(d) = d` would force
`Delta = d^2(d-2)/(d-1)`; but `d^2 (d-2) = (d-1) q + r` with `r = -1` mod `(d-1)`
(check: `d equiv 1`, so `d^2(d-2) equiv 1*(1-2) = -1`), so `d-1` divides
`d^2(d-2)` only if `d-1` divides `1`, i.e. `d = 2`, excluded. Hence
`lambda_f != d` for every integer `Delta >= 1` and `d >= 3`.

**5.4 Location of the roots.** Fix `eta > 0` small, `eta < |lambda_f - d|` when
`lambda_f` exists.

*(a) Window around `lambda_f`.* `phi` is strictly increasing with
`phi(lambda_f) = 0`, so on `[lambda_f - eta, lambda_f + eta]`,
`inf{|phi| : |lambda - lambda_f| = eta} =: m_eta > 0`. The uniform convergence of 5.2
and the fact that `Delta^2/(n(lambda-d))` is at most `Delta^2/(n(|lambda_f-d|-eta))`
there give `Sigma_n(lambda_f +- eta) = phi(lambda_f +- eta) + o(1)` with the sign of
`phi`, so by the intermediate value theorem `Sigma_n` has a zero in the window, and by
5.2 at most one. Also `Sigma_n` has no zero in
`[(B_d + eta) , (1/eta)] \\ (lambda_f - eta, lambda_f + eta)` for large `n`, because
`phi` is bounded away from zero there.

*(b) Window around `d`.* Here only the *existence of a root converging to `d`* is
claimed; no rate is claimed (see the warning below).

Fix `eta > 0` with `eta < |lambda_f - d|` (when `lambda_f` exists; otherwise any small
`eta`). On the compact window `[d - eta, d + eta] subset H`, Theorem A gives
`Sigma_n = phi(lambda) - Delta^2/(n(lambda-d)) + o_1(n)` with `o_1(n) -> 0` *uniformly
on the window*. Multiplying by `(lambda - d)`, the equation `Sigma_n(lambda) = 0` is
equivalent to

    Psi_n(lambda) := (lambda - d) phi(lambda) - Delta^2/n + (lambda - d) o_1(n) = 0.   (5.1)

Evaluate at the two endpoints. `phi(d) != 0` by 5.3, so for `eta` small,
`phi(d - eta) -> phi(d)` and `phi(d + eta) -> phi(d)`, and

    Psi_n(d - eta) = -eta phi(d - eta) - Delta^2/n - eta o_1(n),
    Psi_n(d + eta) = +eta phi(d + eta) - Delta^2/n + eta o_1(n).

Because `eta |phi(d)|` is a *fixed* positive number while `Delta^2/n -> 0` and
`eta o_1(n) -> 0` (fixed `eta`!), we get, for all large `n`,

    Psi_n(d - eta) < 0    and    Psi_n(d + eta) > 0      if phi(d) > 0,
    Psi_n(d - eta) > 0    and    Psi_n(d + eta) < 0      if phi(d) < 0.

By the intermediate value theorem `Sigma_n` has a root in `(d - eta, d + eta)` for all
large `n`, and it is unique there by monotonicity (5.2). As `eta > 0` was arbitrary,
that root — the eigenvalue of `G'` near `d` — converges to `d` in probability.

**Warning (what is *not* licensed).** One is tempted to divide (5.1) by `n^{-1}` and
conclude `lambda - d = -(Delta^2/n)/phi(d) + o(1/n)`, hence an `O(1/n)` localisation
with the explicit constant `2Delta^2/(n|phi(d)|)`. That inference is **invalid**, and
it is withdrawn. The reason is exactly the missing uniformity: Theorem A controls
`g_n` uniformly on each *fixed* compact of `H`, i.e. it gives
`sup_{[d-eta,d+eta]}|g_n| -> 0` for each fixed `eta`, which is `o_1(n) -> 0` at fixed
`eta` but carries no information about `(lambda-d)o_1(n)` when the root
`lambda = lambda_n` approaches `d` at an unknown rate between `1/n` and, say,
`n^{-1/2}`, or at any other rate. A vanishing error at every *fixed* `lambda` away
from `d` does not imply `(lambda-d) g_n(lambda) -> 0` along a root that drifts to `d`.
The `O(1/n)` bound needs either a rate-uniform neighbourhood estimate
`sup_{|lambda-d|<=rho_n}|g_n| = o(rho_n)` for some `rho_n -> 0`, or a different
argument entirely (see 5.5). None is supplied here, and **no rate, no finite-size
bound, and no exact `1/n` constant is claimed anywhere in this document.**

Adding the host eigenvalues, which on `F_n` all lie in `[-d, B_d + eps]`, gives
Theorem B: the only eigenvalues of `A_{G'}` in `[B_d + eta, 1/eta]` are the two roots
above, so `lambda_1(G') -> max(d, lambda_f)` and `lambda_2(G') -> min(d, lambda_f)`,
with the ordering determined by the sign of `Delta G_d(d) - d`. If
`Delta <= 2(d-2)` there is no root of `phi`, hence no root of `Sigma_n` away from `d`
inside the window; the only root there is the one near `d`, so
`lambda_1(G') -> d` and `Pr[lambda_2(G') <= B_d + eps] -> 1` for every `eps > 0`
(the lower bound `lambda_2(G') >= B_d - o(1)` is the Alon--Boppana side and is *not*
re-proved here; it is not needed for the `Delta > 2(d-2)` case).

**5.5 No rate, no finite-size constant, and why.** Everything in 5.4(b) beyond
"the root tends to `d`" is withdrawn; there is no `O(1/n)` statement here. Two separate
reasons, both structural.

*(i) The scaled error is not controlled.* Theorem A gives
`sup_{[d-eta,d+eta]}|g_n| -> 0` for each **fixed** `eta`; the near-`d` analysis of
(5.1) needs the scaled quantity `(lambda-d) g_n(lambda)` at a point `lambda = lambda_n`
that itself drifts to `d`. A limit at fixed `lambda` says nothing about that, whatever
the drift rate.

*(ii) Even the natural candidate correction is of the same order as the effect.*
The deviation of `1_T^T(A-lambda)^{-1}1_T` from `-Delta G_d(lambda)` has leading term
`-G_d sum_{t != t'} r^{dist(t,t')}`, of typical size `|r|^{Theta(log_{d-1} n)}
= n^{-alpha}` with `alpha = log(1/|r|)/log(d-1)`. Near `lambda = d` we have
`|r| ~ 1/(d-1)`, so `alpha ~ 1`: the random off-diagonal contribution is of order
`1/n`, the *same* order as the Perron correction `Delta^2/(n(Delta G_d(d)-d))`. Any
proof of the exact `1/n` constant must therefore separate two contributions of equal
size, which needs a rate-and-fluctuation theorem for the resolvent entry, not merely
convergence. Consequently the finite-size law
`lambda_2 = d - Delta^2/(n(Delta G_d(d)-d))` of the dossier is *consistent with* but
not implied by Theorem A, and no exact constant, finite-size bound or rate is claimed
in this submission. This is a second-order question, not an obstruction to the limit
law itself.

**Next unavoidable step.** A quantitative form of Theorem A:
`sup_{lambda in K} |g_n(lambda)| <= C_K n^{-gamma}` with high probability, uniformly
also in a shrinking neighbourhood `|lambda - d| <= rho_n` in the scaled sense
`|g_n| = o(rho_n)`; equivalently a rate for the walk-count comparison with the
off-diagonal sum `sum_{t!=t'} r^{dist(t,t')}` controlled in probability at scale
`1/n`. Proposition 3.3 is already quantitative in `L`
(error `<= (Delta^2+Delta) rho^{L+1}/(|lambda|(1-rho)) + Delta^2|G_d||r|^{L+1}` off an
event of probability `O_{d,L}(1/n)`), so the missing input is a bound `O(n^{-gamma})`
on the probability that some pair of vertices of the *fixed* set `T` is at distance
`<= L`, together with the analytic propagation of that rate to the window
`(B_d, d)`.

## 6. What is proved, what is imported, what is not proved

Proved here, completely: Lemma 1.1 (tree resolvent, all distances, one prefactor);
Lemma 2.1 (exact Perron removal, with exact-arithmetic verification); Lemma 3.1 (walk
counts on a tree ball); Proposition 3.3 (the limit on `{|lambda| > d}`); Lemma 4.1
(Harnack chain); Theorem A modulo Import F and Lemma 3.2; Theorem B modulo Theorem A;
Proposition C.

Imported: Import F (Friedman, Bordenave) with the hypotheses checked above; Lemma 3.2
(standard configuration-model counting, proof sketched); Sherman--Morrison and the
Cauchy interlacing/resolvent orthogonality used in 5.1--5.2 (classical).

Not proved here and not claimed: any statement with a rate; the exact `1/n` constant in
5.4(b); absence of eigenvalues embedded in the bulk of the spiked tree (irrelevant
here); behaviour for growing `d`; the multi-defect census; anything about `T` chosen
*after* seeing the graph (Theorem A is for a fixed set, uniform in `lambda`, and the
`O(1/n)`-probability exceptional event is exactly the one on which `T` is not spread
out, see 5.6).

**5.6 The exceptional event is unavoidable, not an artefact.** By Proposition C, on
the event that `T` is "close" (two vertices adjacent, or at distance `O(1)`) the value
of `1_T^T(A-lambda)^{-1}1_T` differs from `-Delta G_d(lambda)` by a constant. That
event has probability `O(1/n)`, and on it the defect eigenvalues of `G'` are those of a
*different* secular equation, e.g. `lambda = G_d(lambda)(2 + 2r(lambda))` for an
adjacent pair with `Delta = 2`. For `d = 3` that equation does have a solution above
`B_d`, whereas the "independent `T`" threshold `Delta > 2(d-2)` excludes `Delta = 2`.
So the limiting law is genuinely a statement about the random graph and cannot be
upgraded to a per-graph statement by improving the proof.

## 7. Numerical corroboration (not a proof)

`scripts/check_theorem.py` (sha256 `88f44a777c4c214cf08f285a4ae59d7550d92d1331e8b7ec7857d4fd4a6d513f`);
`out/check_theorem.txt` was regenerated in full from that exact script, including the
header line with the hash and the timestamp (`out/check_A.txt` and
`out/check_A_D.txt` are earlier partial runs and are superseded). An earlier stored
copy of `check_theorem.txt` had been produced by a script version whose check A
compared floating-point sympy expressions and printed `False` spuriously; that stale
copy is replaced, and in the current output check A is `True` for all five graphs.
Seeds: `np.random.default_rng(7)` (limit), `(11)` (Proposition C), `(20261114)` reserved. Graphs are drawn from the configuration model *conditioned on
simplicity* by rejection, which is exactly uniform on simple `d`-regular graphs; the
only idealisation is the pseudo-random source (numpy PCG64). This is deliberately not
`networkx.random_regular_graph`, which is a pairing heuristic and is not certified
uniform.

Main test (`out/check_theorem.txt`, section C), error
`|1_T^T(A-lambda)^{-1}1_T + Delta^2/(n(lambda-d)) + Delta G_d(lambda)|`, max over 5
independent graphs:

    d=3 Delta=2 lambda=3.30 : 5.5e-2 (n=1000)  2.6e-2 (4000)  7.9e-4 (16000)
    d=3 Delta=2 lambda=2.95 : 7.2e-1          9.8e-3          5.1e-3
    d=3 Delta=6 lambda=3.30 : 3.4e-1          2.6e-2          6.6e-3
    d=3 Delta=6 lambda=2.95 : 3.9e-1          8.6e-2          2.9e-2
    d=4 Delta=8 lambda=4.40 : 1.0e-1          2.5e-2          6.9e-3
    (bulk edges: d=3 -> 2.8284, d=4 -> 3.4641)

The error is small and, with one honest exception, decreases with `n`; the exception is
`d=4, lambda=3.60` (`2.3e-1 -> 3.1e-1 -> 7.9e-2`), where `lambda` is only `0.14` above
the bulk edge `3.4641`, so the required radius `L` is the largest and the five-graph
maximum is noisy. The error is larger for `lambda` closer to `B_d`, as predicted (the decay rate `|r|` approaches `1/sqrt(d-1)` and the required radius
`L` grows). The `lambda = 2.95` rows at `d = 3` are the ones where the required `L` is
largest, so truncation hurts most there. Note also that for `|lambda| < d` the walk
expansion is *not* available (`rho = d/|lambda| > 1`); those rows test the *conclusion*
of Theorem A, which reaches the window only through the analytic continuation, so no
geometric rate is predicted there and the observed slowdown is expected.

Two further honest limitations. (i) These are finite-`n` numbers at five graphs per
point; they cannot establish an asymptotic statement, and they say nothing about the
exceptional event of 5.6. (ii) The last block of section D (max eigenvalue of `G'`) is
*uninformative* and is not used for anything: for `Delta = 2` the top eigenvalue of
`G'` is the near-trivial one at `d - O(1/n)`, so adjacent and non-adjacent `T` are not
distinguished there, and the printed values just above `3` are `eigsh` tolerance, not
an eigenvalue exceeding the maximal degree. The discriminating quantity in section D
is the resolvent value, where the tree formula matches to `1.3e-3` at `n=8000` while
the false `(H)` limit is off by `0.38`.
