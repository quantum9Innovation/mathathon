# m5 direction d3: almost regular graphs and single degree defects

Entry point: [DOSSIER.md](DOSSIER.md).

Contents of this directory.

| path | what it is |
|---|---|
| `DOSSIER.md` | the full research dossier, sections 0 to 11 |
| `scripts/spiked_tree_jacobi.py` | truncated radial Jacobi matrix of the spiked regular tree, tests Theorem A |
| `scripts/verify_tree_balls.py` | genuine balls of the spiked tree up to 1.3e6 vertices, independent test of Theorem A and of the eigenvector decay rate |
| `scripts/exact_secular.py` | exact rational verification of the finite secular identity, Proposition B |
| `scripts/one_spike_finite.py` | random d-regular host plus one spike, first pass |
| `scripts/almost_regular_census.py` | one, two and three spikes, threshold scan at 2(d-2) |
| `scripts/convergence.py` | convergence in n, discriminates lambda_f from lambda_* |
| `scripts/diag_secular.py` | direct evaluation of the secular function against the exact spectrum |
| `scripts/arxiv_q.py`, `scripts/arxiv_abs.py` | arXiv API helpers used for the literature section |
| `out/*.txt` | raw outputs, one file per script, plus literature metadata |
| `out/blm.pdf`, `out/blm.txt` | Bordenave-Lelarge-Massoulié arXiv:1501.06087v2 and its extracted text, source of the quoted definition in Section 6, L5 |

Reproduction commands are in Section 11 of the dossier.

Claim categories used in the dossier: (L) checked literature statement, (C) exact
calculation, (P) proof supplied here, (N) numerical experiment, (S) conjecture or
speculation. Nothing here is formally verified, and no numerical experiment is
treated as a proof of an asymptotic statement.
