"""Numerical verification for the adjacent-pair (T={c,u}) clustered secular law.

Sampler: configuration (pairing) model with rejection on simplicity.  By Lemma 1 of
.ultramath/smwgwbyn9/m6/THEOREM.md (each simple d-regular graph has exactly (d!)^n
pairings) the accepted graph is EXACTLY uniform on simple d-regular graphs.

Model: fixed centre label c=0; u = the smallest-labelled neighbour of c (a deterministic
function of the labelled radius-1 neighbourhood); T={c,u}; G' = G + new vertex x adjacent
to exactly c and u.  All seeds are fixed and printed.

Outputs: raw json + a readable table on stdout.
"""
import numpy as np, json, time, sys
from scipy.sparse import csr_matrix, lil_matrix, identity
from scipy.sparse.linalg import eigsh, spsolve

def uniform_regular(n, d, rng, max_tries=200000):
    stubs_base = np.repeat(np.arange(n), d)
    for _ in range(max_tries):
        stubs = rng.permutation(stubs_base)
        pairs = stubs.reshape(-1, 2)
        a, b = pairs[:, 0], pairs[:, 1]
        if np.any(a == b):
            continue
        key = np.sort(pairs, axis=1)
        if len(np.unique(key[:, 0] * n + key[:, 1])) != len(pairs):
            continue
        return pairs
    raise RuntimeError("sampler failed")

def to_csr(n, pairs):
    a = np.concatenate([pairs[:, 0], pairs[:, 1]])
    b = np.concatenate([pairs[:, 1], pairs[:, 0]])
    data = np.ones(len(a))
    return csr_matrix((data, (a, b)), shape=(n, n))

def adj_added(A, T):
    """A_{G'} with one new vertex (index n) adjacent exactly to T."""
    n = A.shape[0]
    A2 = lil_matrix((n + 1, n + 1))
    A2[:n, :n] = A
    for t in T:
        A2[n, t] = 1.0; A2[t, n] = 1.0
    return csr_matrix(A2)

def top_eigs(A, k):
    return np.sort(eigsh(A, k=k, which='LA', return_eigenvectors=False, tol=0, maxiter=100000))[::-1]

def secular(A, T, lam):
    """Sigma_n(lam) = lam - 1_T^T (lam I - A)^{-1} 1_T  (dense-ish sparse solve)."""
    n = A.shape[0]
    M = (lam * identity(n, format='csr') - A).tocsc()
    rhs = np.zeros(n)
    for t in T: rhs[t] = 1.0
    x = spsolve(M, rhs)
    return lam - x[list(T)].sum(), x[list(T)].sum()

def secular_zero(A, T, lo, hi, tol=1e-13):
    f_lo, _ = secular(A, T, lo); f_hi, _ = secular(A, T, hi)
    assert f_lo < 0 < f_hi, (f_lo, f_hi)
    for _ in range(200):
        mid = 0.5*(lo+hi)
        f, _ = secular(A, T, mid)
        if f < 0: lo = mid
        else: hi = mid
        if hi - lo < tol*max(1.0, abs(hi)): break
    return 0.5*(lo+hi)

def rKM(lam, d):
    return (lam - np.sqrt(lam*lam - 4*(d-1)))/(2*(d-1))
def Gd(lam, d):
    r = rKM(lam, d); return r/(1-r*r)
def Kadj(lam, d):
    r = rKM(lam, d); return 2*r/(1-r)

if __name__ == "__main__":
    out = {"runs": [], "model": "pairing-with-rejection (exactly uniform), fixed centre 0, "
           "u = min neighbour of 0, added vertex adjacent to {0,u}"}
    print("= fixed-seed direct-eigensolver comparisons, T={c,u} adjacent =")
    print("%-3s %-6s %-4s | %-12s %-12s %-12s %-10s %-12s %-9s"
          % ("d","n","seed","lam_1(G')","lam_2(G')","sec-zero","|diff|","pred lam_2","n(lam_1-d)"))
    CASES = []
    for d, ns, seeds in [(3,[1000,2000,4000,8000],[11,12]), (4,[1000,2000,4000],[11,12])]:
        for n in ns:
            for s in seeds:
                CASES.append((d,n,s))
    for (d,n,seed) in CASES:
        t0=time.time()
        rng = np.random.default_rng(seed*1000+n)
        pairs = uniform_regular(n, d, rng)
        A = to_csr(n, pairs)
        nbrs = sorted(A[0].indices.tolist())
        u = nbrs[0]
        T = [0, u]
        A2 = adj_added(A, T)
        ev2 = top_eigs(A2, 3)
        evh = top_eigs(A, 3)
        lam1, lam2 = ev2[0], ev2[1]
        # secular zero in the band (lam_2(G), d)
        lo = evh[1] + 1e-7; hi = d - 1e-7
        try:
            z = secular_zero(A, T, lo, hi)
        except AssertionError:
            z = float('nan')
        pred = 2.875129794162778 if d == 3 else 2*np.sqrt(d-1)
        print("%-3d %-6d %-4d | %-12.8f %-12.8f %-12.8f %-10.2e %-12.8f %-9.4f"
              % (d,n,seed,lam1,lam2,z,abs(z-lam2),pred,n*(lam1-d)))
        out["runs"].append(dict(d=d,n=n,seed=seed,u=int(u),lam1=float(lam1),lam2=float(lam2),
            host_lam2=float(evh[1]), sec_zero=float(z), absdiff=float(abs(z-lam2)),
            pred_lam2=float(pred), n_lam1_minus_d=float(n*(lam1-d)),
            sec_band=[float(lo),float(hi)], seconds=round(time.time()-t0,2)))
    with open('out/numerics_eig.json','w') as f: json.dump(out,f,indent=1)

    print(); print("= resolvent-limit values: F_n(lam)=1_T^T(lam I-A)^{-1}1_T, n=8000 d=3 =")
    out2 = {"resolvent": []}
    for d,n,seed in [(3,8000,11),(3,8000,12)]:
        rng = np.random.default_rng(seed*1000+n)
        pairs = uniform_regular(n, d, rng); A = to_csr(n,pairs)
        u = sorted(A[0].indices.tolist())[0]; T=[0,u]
        # a far pair (distance >= 8) for the separated-limit recovery
        import collections
        dist = {0:0}; q=collections.deque([0])
        while q:
            v=q.popleft()
            for w in A[v].indices:
                if w not in dist: dist[w]=dist[v]+1; q.append(w)
        far = [w for w in range(1,n) if dist.get(w,99) >= 8]
        w_far = far[0]
        print("  seed %d: adjacent pair (0,%d), far pair (0,%d) at distance %d"
              % (seed,u,w_far,dist[w_far]))
        for lam in [2.95, 3.2, 3.5]:
            fa,_ = secular(A,[0,u],lam); fs,_ = secular(A,[0,w_far],lam)
            print("   lam=%-4.2f  F_adj=%12.7f  [K_adj+4/(n(lam-d))]=%12.7f  F_far=%12.7f  [2G_d+4/(n(lam-d))]=%12.7f"
                  % (lam, fa, Kadj(lam,d)+4/(n*(lam-d)), fs, 2*Gd(lam,d)+4/(n*(lam-d))))
            out2["resolvent"].append(dict(d=d,n=n,seed=seed,lam=lam,adj=float(fa),
                adj_pred=float(Kadj(lam,d)+4/(n*(lam-d))), far=float(fs),
                far_pred=float(2*Gd(lam,d)+4/(n*(lam-d))), dist_far=int(dist[w_far])))
    with open('out/numerics_resolvent.json','w') as f: json.dump(out2,f,indent=1)
    print("\nraw json: out/numerics_eig.json, out/numerics_resolvent.json")
