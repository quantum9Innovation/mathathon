# The fixed-host exterior resolvent limit: a complete fixed-energy proof, its rate, and its edge obstruction

Member m1 (direction d3: source applicability / closest existing proof) — swarm `smwgwbyn9`, batch 050.
Status: **proved here** (Theorems 1 and 2, Corollary 3) with one imported input, Friedman's theorem,
cited and verified in Section 8. Numerical material in Section 12 is evidence only.

---

## 0. What is settled here, in one paragraph

Hypothesis (H) of the m5 dossier (Proposition D) asks for
$\mathbf 1_T^\top(A_{G_n}-\lambda I)^{-1}\mathbf 1_T\to-\Delta G_d(\lambda)$ in probability, uniformly
on compacts of $(2\sqrt{d-1},d)\cup(d,\infty)$, for $d\ge3$ fixed and $T$ a fixed finite set.
**This is proved here at fixed energy, and uniformly on compacts, with an explicit power rate.**
The route is *not* a local law, *not* a nonbacktracking walk sum, and *not* a complex-$z$ bulk estimate.
It is a **moment** argument: outside the bulk the resolvent is determined, to $O(\varrho^{-2L})$, by the
$2L$ lowest moments of the spectral measure of $\mathbf 1_T$, and those moments are *exactly* the
Kesten–McKay moments as soon as the radius-$L$ balls around $T$ are trees separated pairwise by more
than $2L$. The only probabilistic inputs are (i) tree-likeness and separation out to radius
$L=c\log_{d-1}n$ (first moment, proved) and (ii) spectral control
$\lambda_i\le2\sqrt{d-1}+\varepsilon$ for $i\ge2$ (Friedman, Section 8).
The proved error exponent is $\theta(\lambda)=\log\varrho(\lambda)/\log(d-1)$, with $\varrho>1$ the
Chebyshev parameter of the bulk interval; **$\theta(\lambda)\to0$ as $\lambda\downarrow2\sqrt{d-1}$**,
so the limit is *not* uniform up to the edge, and no $1/n$-accurate asymptotics follows (Section 10).
Those are the two genuine obstructions that remain.

---

## 1. Setting and notation

* $d\ge3$ integer, $n\to\infty$ with $dn$ even. $G_n$ is the **uniform random simple $d$-regular graph**
  on $[n]$. $A=A_{G_n}$.
* $T\subseteq[n]$ a **fixed** set of $\Delta=|T|\ge1$ distinct vertices (deterministic; not random, not
  averaged over). $\mathbf 1_T=\sum_{y\in T}e_y$, $\|\mathbf 1_T\|^2=\Delta$.
* $\mathrm{bulk}_d=[-2\sqrt{d-1},2\sqrt{d-1}]$; $\mu_{\mathrm{KM},d}$ the Kesten–McKay law (the spectral
  measure of $\delta_{\text{root}}$ in the infinite $d$-regular tree $\mathbb T_d$).
* For $\lambda\notin\mathrm{bulk}_d$: $r=r(\lambda)$ is the root of $(d-1)r+r^{-1}=\lambda$ with
  $|r|<1/\sqrt{d-1}$, and $G_d(\lambda)=\int\frac{d\mu_{\mathrm{KM},d}(x)}{\lambda-x}=\frac{r}{1-r^{2}}$.
* $m_k=\int x^{k}\,d\mu_{\mathrm{KM},d}(x)$, so $m_0=1$, $m_1=0$, $m_2=d$, and $m_k=0$ for odd $k$
  (the tree is bipartite). Exact values cross-checked two ways: `out/verify_moments.txt`.
* $B(y,L)$ is the ball of radius $L$ around $y$ in $G_n$.
* For a symmetric matrix with spectral decomposition $A=\sum_i\lambda_iu_iu_i^\top$, the measure
  $\nu_T:=\sum_i\lvert\langle u_i,\mathbf 1_T\rangle\rvert^2\delta_{\lambda_i}$ has total mass $\Delta$ and
  $\mathbf 1_T^\top(A-\lambda I)^{-1}\mathbf 1_T=\int\frac{d\nu_T(x)}{x-\lambda}$ for $\lambda\notin\sigma(A)$.

---

## 2. Lemma 1 (walk confinement)

Let $y$ be a vertex and $k\ge0$. Every walk $y=v_0,v_1,\dots,v_k=y$ of length $k$ satisfies
$\operatorname{dist}(y,v_i)\le\min(i,k-i)\le\lfloor k/2\rfloor$ for every $i$.

*Proof.* $\operatorname{dist}(y,v_i)\le i$ (prefix) and $\operatorname{dist}(v_i,y)\le k-i$ (suffix). $\square$

Consequently, if $B(y,L)$ is a tree and $k\le2L$, every closed walk of length $k$ at $y$ lies inside that
tree.

---

## 3. Lemma 2 (Kesten–McKay moments = tree closed-walk counts)

For every $k\ge0$, $m_k=(A_{\mathbb T_d}^{k})_{oo}$, the number of closed walks of length $k$ from a fixed
vertex $o$ of $\mathbb T_d$.

*Proof.* $\mu_{\mathrm{KM},d}=\langle\delta_o,E_{\mathbb T_d}(\cdot)\delta_o\rangle$, hence
$m_k=\langle\delta_o,A_{\mathbb T_d}^{k}\delta_o\rangle$, which counts the closed walks of length $k$
at $o$. $\square$

Independent exact check (`scripts/verify_moments.py`, output `out/verify_moments.txt`): moments obtained
from the spectral series $G_d=\beta/(1-\beta^{2})$, $\beta=\frac{w}{(d-1)\epsilon}$,
$w=\sum_{n\ge1}C_{n-1}(d-1)^{n}\epsilon^{2n}$ (coefficient of $\epsilon^{k+1}$, exact rationals) agree
with brute-force closed-walk counts on a truncated $\mathbb T_d$ for $d=3,4,5,6$ and all $k\le12$.

---

## 4. Lemma 3 (moment identity on tree-like balls)

Let $L\ge0$ and suppose

* **(T1)** $B(y,L)$ is a tree for every $y\in T$, and
* **(T2)** $\operatorname{dist}(y,y')>2L$ for all distinct $y,y'\in T$.

Then for every polynomial $p$ of degree $\le2L$,
$$\mathbf 1_T^\top p(A)\,\mathbf 1_T=\Delta\int p\,d\mu_{\mathrm{KM},d}.$$

*Proof.* Write $p=\sum_{j\le2L}c_jx^{j}$, so $p(A)=\sum_jc_jA^{j}$ and
$\mathbf 1_T^\top p(A)\mathbf 1_T=\sum_{y,y'\in T}\sum_jc_j(A^{j})_{yy'}$.
If $y=y'$ and $j\le2L$: Lemma 1 confines the closed walks to $B(y,L)$, which by (T1) is a tree, so
$(A^{j})_{yy}=m_j$ by Lemma 2. If $y\ne y'$ and $j\le2L$: a walk of length $j$ from $y$ to $y'$ forces
$\operatorname{dist}(y,y')\le j\le2L$, contradicting (T2); hence $(A^{j})_{yy'}=0$. Therefore
$\mathbf 1_T^\top p(A)\mathbf 1_T=\Delta\sum_jc_jm_j=\Delta\int p\,d\mu_{\mathrm{KM},d}$. $\square$

*(T1) and (T2) are indispensable, not cosmetic: if $y\ne y'$ are at distance $2$ then $(A^{2})_{yy'}=1$
and the identity already fails at $k=2$. This is the precise sense in which "bounded local pattern"
cannot be dropped, and why averaging over a random $T$ is a different theorem.)*

---

## 5. Lemma 4 (tree-likeness and separation hold with probability $1-O_\Delta((d-1)^{2L}/n)$)

In the **pairing (configuration) model** $\mathcal P_{n,d}$ (vertices $[n]$ of degree $d$, $dn$ half-edges
uniformly paired), for fixed $\Delta$ and $L=L(n)\ge1$ with $(d-1)^{L}\le n^{1/4}$,
$$\Pr\big[\lnot(\mathrm{T1})\ \text{or}\ \lnot(\mathrm{T2})\big]\;\le\;C_{d,\Delta}\,\frac{(d-1)^{2L}}{n}.$$

*Proof.* **Tree-likeness.** Explore $B(y,L)$ breadth-first, revealing partners half-edge by half-edge. Let
$M_j$ be the number of half-edges at level $j$ whose partners are unrevealed; $M_0=d$ and
$M_j\le d(d-1)^{j-1}$. Conditionally on the revealed structure, each unrevealed half-edge is uniformly
matched to one of the remaining ones. The ball fails to be a tree at level $j$ iff some revealed partner
lies at an already-visited vertex or at another frontier half-edge of the current batch; the number of
such "bad" half-edges is at most $d\,|B(y,j-1)|\le2d(d-1)^{j}$, while at least $dn/2$ half-edges are
unrevealed. Hence $\Pr[\text{collision at level }j]\le\frac{2d(d-1)^{j}M_j}{dn/2}
\le\frac{4d^{2}(d-1)^{2j-1}}{n}$, and summing over $j\le L$ gives
$\Pr[\lnot(\mathrm{T1})\text{ at }y]\le C_d(d-1)^{2L}/n$. A collision of this kind also covers self-loops
and parallel edges, which do make $B(y,1)$ a non-tree. **Separation.** For fixed $y\ne y'$, a
first-moment (Markov) bound on the number of walks of length $j$ from $y$ to $y'$ — each a sequence of
$j$ pairings with conditional probability at most $(dn/2)^{-j}$ times $(d-1)^{j}$ choices — gives
$\Pr[\operatorname{dist}(y,y')\le2L]\le\sum_{j\le2L}C(d-1)^{j}/n\le C(d-1)^{2L}/n$. Union bound over
$\Delta$ vertices and $\binom\Delta2$ pairs. $\square$

**Transfer to the uniform simple model.** $\mathcal P_{n,d}$ conditioned on simplicity *is* the uniform
simple $d$-regular graph, and $\Pr_{\mathcal P}[\text{simple}]\to e^{-(d^{2}-1)/4}>0$ (Bollobás,
*Random Graphs*, 2nd ed., §2.4; McKay 1985 — only positivity is used). Hence for any event $E$,
$\Pr_{\text{simple}}[E]\le\Pr_{\mathcal P}[E]/\Pr_{\mathcal P}[\text{simple}]\le2\Pr_{\mathcal P}[E]$
for $n$ large. This is the only place the sampler question enters, and it enters explicitly.

---

## 6. Lemma 5 (Chebyshev expansion of the Cauchy kernel)

Let $\lambda>\alpha>0$, $\tau=\lambda/\alpha>1$, $\varrho=\tau+\sqrt{\tau^{2}-1}>1$. Then for every
$m\ge0$ there is a polynomial $q_m$ of degree $\le m$ with
$$\sup_{x\in[-\alpha,\alpha]}\Big|\frac{1}{x-\lambda}-q_m(x)\Big|\;\le\;C_\lambda\,\varrho^{-m}.$$

Moreover the truncants satisfy, for $y>\alpha$, writing $\varrho_y=\frac{y}{\alpha}+\sqrt{\frac{y^{2}}{\alpha^{2}}-1}$,
$$\big|q_m(y)\big|\;\le\;C_\lambda\Big(\frac{\varrho_y}{\varrho}\Big)^{m}\quad(\varrho_y>\varrho),
\qquad\big|q_m(y)\big|\le C_\lambda\,m\quad(\varrho_y\le\varrho),$$
because $T_k(y/\alpha)=\frac12(\varrho_y^{k}+\varrho_y^{-k})\le\varrho_y^{k}$ for $y>\alpha$ and $|T_k|\le1$ on $[-\alpha,\alpha]$.
In particular, for $y=d$ one has $\varrho_d=\frac{d}{\alpha}+\sqrt{\frac{d^{2}}{\alpha^{2}}-1}=\sqrt{d-1}$
**exactly** when $\alpha=2\sqrt{d-1}$, since $1-\frac{4(d-1)}{d^{2}}=\frac{(d-2)^{2}}{d^{2}}$; and with
$\alpha\ge2\sqrt{d-1}$ one gets $\varrho_d\le\sqrt{d-1}$.

*Proof.* The exact Chebyshev expansion of the Cauchy kernel, valid for $t>1$, $x\in[-1,1]$:
$$\frac{1}{t-x}=\frac{2}{\sqrt{t^{2}-1}}\Big[\tfrac12+\sum_{k\ge1}\frac{T_k(x)}{\varrho^{k}}\Big],
\qquad \varrho=t+\sqrt{t^{2}-1}.$$
*Derivation:* put $t=\frac12(\varrho+\varrho^{-1})$, $x=\cos\theta$; then
$\frac{1}{t-x}=\frac{2\varrho}{(\varrho-e^{i\theta})(\varrho-e^{-i\theta})}$, expand both geometric
series and collect $T_k(x)=\frac{e^{ik\theta}+e^{-ik\theta}}{2}$. (Checked at $x=1$, where the identity
reduces to $\frac{1}{t-1}=\frac{2\varrho}{(\varrho-1)^{2}}$.) Since $\varrho>1$ the series converges
absolutely and uniformly on $[-1,1]$; truncating after $k=m$ leaves
$\frac{2}{\sqrt{t^{2}-1}}\cdot\frac{\varrho^{-m}}{1-\varrho^{-1}}$. Rescale $x\mapsto x/\alpha$,
$t\mapsto\lambda/\alpha$, using $\sqrt{t^{2}-1}=\frac{\varrho-\varrho^{-1}}{2}$. $\square$

---

## 7. Theorem 1 (fixed-energy exterior limit, with rate)

Fix $d\ge3$, $\Delta\ge1$ and $\lambda\in(2\sqrt{d-1},d)\cup(d,\infty)$. Fix $\varepsilon\ge0$ with
$2\sqrt{d-1}+\varepsilon<\lambda$, let $\alpha=2\sqrt{d-1}+\varepsilon$ and
$$\varrho(\lambda,\varepsilon)=\tau+\sqrt{\tau^{2}-1},\qquad \tau=\frac{\lambda}{2\sqrt{d-1}+\varepsilon}>1 .$$
Then for every $\gamma\in(0,1)$, with probability at least $1-n^{-\gamma}-o(1)$,
$$\Big|\,\mathbf 1_T^\top(A_{G_n}-\lambda I)^{-1}\mathbf 1_T+\Delta\,G_d(\lambda)\Big|
\;\le\;C_{\lambda,\varepsilon,\Delta,\gamma}\,n^{-\min(\theta,1)},\qquad
\theta=(1-\gamma)\,\frac{\log\varrho(\lambda,\varepsilon)}{\log(d-1)},$$
with $C_{\lambda,\varepsilon,\Delta,\gamma}<\infty$ depending only on the displayed parameters. (The cap
at exponent $1$ comes from the exact Perron term $\frac{\Delta^{2}}{n(d-\lambda)}=O(1/n)$; for $\lambda$
near $2\sqrt{d-1}$ one has $\theta<1$ and the cap is inactive.) In
particular $\mathbf 1_T^\top(A_{G_n}-\lambda I)^{-1}\mathbf 1_T\to-\Delta G_d(\lambda)$ **in probability**.
For $\lambda>d$ the trivial bound $\sigma(A_{G_n})\subseteq[-d,d]$ suffices: take $\alpha=d$ and **no**
imported spectral input is needed. For $\lambda<d$ Friedman's theorem is used exactly once (the support
bound $\lambda_i\le2\sqrt{d-1}+\varepsilon$ for $i\ge2$).

*Proof.* Put $2L=\big\lfloor(1-\gamma)\log n/\log(d-1)\big\rfloor$, so $(d-1)^{2L}\le n^{1-\gamma}$ and
$\varrho^{-2L}\le n^{-\theta}$.

*Step 1 (good event).* Let $E_n$ be the intersection of (T1)+(T2) with Friedman's event
$\mathcal F_n=\{\lambda_1=d,\ |\lambda_i(A)|\le2\sqrt{d-1}+\varepsilon\ \text{for}\ 2\le i\le n\}$. By
Lemma 4, Section 5 and Section 8, $\Pr[E_n]\ge1-n^{-\gamma}-o(1)$.

*Step 2 (decomposition).* On $E_n$, with $u_1=n^{-1/2}\mathbf 1$ and
$\langle u_1,\mathbf 1_T\rangle^{2}=\Delta^{2}/n$, write
$\nu_T=\frac{\Delta^{2}}{n}\delta_d+\nu_T^{\flat}$. Then $\nu_T^{\flat}$ has mass
$\Delta-\Delta^{2}/n$ and is supported in $J_\varepsilon=[-\alpha,\alpha]$, as is
$\Delta\mu_{\mathrm{KM},d}$.

*Step 3 (moment matching).* By Lemma 3, for every polynomial $p$ of degree $\le2L$,
$\int p\,d\nu_T=\Delta\int p\,d\mu_{\mathrm{KM},d}$; subtracting the Perron atom,
$$\int p\,d\big(\nu_T^{\flat}-\Delta\mu_{\mathrm{KM},d}\big)=-\frac{\Delta^{2}}{n}\,p(d).$$

*Step 4 (approximation and assembly).* Let $f(x)=(x-\lambda)^{-1}$ and let $q=q_{2L}$ be as in Lemma 5,
so $\|f-q\|_{\infty,J_\varepsilon}\le C_\lambda\varrho^{-2L}$. Then
$$\mathbf 1_T^\top(A-\lambda)^{-1}\mathbf 1_T=\int f\,d\nu_T
=\frac{\Delta^{2}}{n}\cdot\frac{1}{d-\lambda}+\int f\,d\nu_T^{\flat},$$
and
$$\int f\,d\nu_T^{\flat}
=\underbrace{\int q\,d\big(\nu_T^{\flat}-\Delta\mu_{\mathrm{KM},d}\big)}_{-\,\Delta^{2}q(d)/n}
+\int(f-q)\,d\nu_T^{\flat}
+\Delta\!\int\! f\,d\mu_{\mathrm{KM},d}
-\Delta\!\int\!(f-q)\,d\mu_{\mathrm{KM},d}.$$
Now $\Delta\int f\,d\mu_{\mathrm{KM},d}=-\Delta G_d(\lambda)$, and
$|\int(f-q)d\nu_T^\flat|\le\Delta\|f-q\|_\infty$, $|\Delta\int(f-q)d\mu_{\mathrm{KM}}|\le\Delta\|f-q\|_\infty$.
So everything is bounded by $2\Delta C_\lambda\varrho^{-2L}$, **except** the Perron term
$$\frac{\Delta^{2}}{n}\Big(\frac{1}{d-\lambda}-q(d)\Big),$$
and this is where the growth bound of Lemma 5 is needed. By that lemma, $\varrho_d\le\sqrt{d-1}$ and
$\varrho>1$, so
$$\frac{\Delta^{2}}{n}\big|q(d)\big|\;\le\;\frac{\Delta^{2}}{n}\,C_\lambda
\max\Big\{\Big(\frac{\varrho_d}{\varrho}\Big)^{2L},\,2L\Big\}.$$
Since $2L\le(1-\gamma)\log n/\log(d-1)$ and $\varrho_d/\varrho$ is a fixed number,
$\big(\varrho_d/\varrho\big)^{2L}=n^{(1-\gamma)\frac{\log\varrho_d-\log\varrho}{\log(d-1)}}
=n^{-(1-\gamma)(\theta_0-\frac12)}$ with $\theta_0=\log\varrho/\log(d-1)$, so this term is
$O_\gamma\big(\Delta^{2}n^{-\frac12-\theta_0+\gamma(\theta_0-\frac12)}\big)$; the exponent satisfies
$\frac12+\theta_0-\gamma\big(\theta_0-\frac12\big)\ge\theta_0$ whenever $\theta_0\le\frac12$ (and is
larger than $\theta_0$ for $\theta_0>\frac12$). Hence the Perron term is never the bottleneck, and
$$\Big|\mathbf 1_T^\top(A-\lambda)^{-1}\mathbf 1_T+\Delta G_d(\lambda)\Big|
\;\le\;C_{\lambda,\varepsilon,\Delta,\gamma}\Big(n^{-(1-\gamma)\theta_0}
+\frac{\Delta^{2}}{n\,|d-\lambda|}\Big),$$
which is the claim (the last term is $O_{\Delta,\lambda}(1/n)$ and is the exact Perron contribution). $\square$

**Theorem 2 (uniformity on compacts).** Fix a compact $K\subset(2\sqrt{d-1},d)$ (or
$K\subset(d,\infty)$) and $\varepsilon<\min K-2\sqrt{d-1}$. The events $E_n$ of Step 1 **do not depend on
$\lambda$**, and on $E_n$ the Step-4 bound holds for all $\lambda\in K$ simultaneously, because
$\tau\mapsto\tau+\sqrt{\tau^{2}-1}$ and $\lambda\mapsto\lambda/\alpha$ are increasing:
$$\varrho_K:=\min_{\lambda\in K}\varrho(\lambda,\varepsilon)=\varrho(\min K,\varepsilon)>1,
\qquad
\sup_{\lambda\in K}\Big|\mathbf 1_T^\top(A-\lambda)^{-1}\mathbf 1_T+\Delta G_d(\lambda)\Big|
\le C_{K,\Delta,\gamma}\,n^{-\min\big((1-\gamma)\log\varrho_K/\log(d-1),\,1\big)}.$$
This is the uniformity argument the README demands ("its own argument, such as equicontinuity or
monotonicity with endpoint control"): monotonicity of the Chebyshev parameter in $\lambda$, with endpoint
control at $\min K$.

---

## 8. The one imported theorem: version, number, hypotheses checked

**J. Friedman, *A proof of Alon's second eigenvalue conjecture and related problems*,
arXiv:cs/0405020v1 (Memoirs AMS 195 (2008), no. 910).** Read from the arXiv v1 PDF.

* **Theorem 1.1** (p. 2 of the PDF): *Fix a real $\epsilon>0$ and an even positive integer $d$. Then
  there is a constant $c$ such that for a random graph $G$ in $G_{n,d}$, with probability at least
  $1-c/n^{\tau}$, for all $i>1$, $|\lambda_i(G)|\le2\sqrt{d-1}+\epsilon$, where
  $\tau=\tau_{\mathrm{fund}}=\lceil\sqrt{d-1}+1/2\rceil-1$.* ($G_{n,d}$ is the permutation model; it may
  have multi-edges and self-loops.)
* **Corollary 1.4** (p. 4): *Fix $\epsilon>0$ and an integer $d\ge2$. Let $L_n$ be any family of
  probability spaces of $d$-regular graphs on $n$ vertices dominated by $G_{n,d}$, $H_{n,d}$, $I_{n,d}$ or
  $J_{n,d}$. Then for $G\in L_n$, with probability $1-o(1)$, for all $2\le i\le n$,
  $|\lambda_i(G)|\le2\sqrt{d-1}+\epsilon$.*

**Hypotheses verified.**
(a) *Ensemble.* The PDF states (p. 4) that $G_{n,d}$ is contiguous with the pairing/configuration model,
and the pairing model dominates the uniform simple graph since simplicity has probability
$\to e^{-(d^{2}-1)/4}>0$; the paper records the conclusion for "the uniform measure on all $d$-regular
(simple) graphs". Domination transfers null events, which is all we use.
(b) *Degree.* $d\ge3$ fixed; no growing-degree step is used anywhere. Corollary 1.4 covers every integer
$d\ge2$, so odd $d$ is covered too.
(c) *Statement used.* Only the upper tail $\lambda_i\le2\sqrt{d-1}+\varepsilon$ for $i\ge2$, and only the
$1-o(1)$ failure probability of Corollary 1.4. The explicit $c/n^{\tau}$ of Theorem 1.1 is available if a
rate is wanted ($\tau\ge1$ for all $d\ge3$).
(d) *Energy.* Friedman's statement is about eigenvalues; the energy $\lambda$ enters its hypotheses
nowhere. This avoids exactly the import `source-baseline.md` forbids: a bulk complex-$z$ local law passed
to real exterior energy.

### Why the obvious alternatives cannot be imported (source audit, my assigned role)

* **Bauerschmidt–Huang–Yau, arXiv:1609.09052v3** (local PDF and text in
  `results/spectral-research/batch-050/sources/`), **Theorem 1.1** and **Theorem 2.4 / Theorem 1.2**:
  bulk only. In their rescaled variable $H=A/\sqrt{d-1}$ the domain is
  $D=\{z\in\mathbb C_+:\operatorname{Im}z\ge(\log N)^{48\alpha+1}/N,\ |z\pm2|\ge(\log N)^{-\alpha/2+1}\}$
  and the abstract says explicitly "in the bulk of the spectrum $[-2\sqrt{d-1}+\varepsilon,2\sqrt{d-1}-\varepsilon]$".
  The window needed here is $\lambda>2\sqrt{d-1}$ (i.e. $z>2$, outside the bulk). HBY's $|z\pm2|$
  condition does not by itself exclude $z>2$, but (i) Theorem 1.1 is about the **trace** $m(z)$, not
  entrywise Green functions; (ii) Theorem 1.2 (delocalization) is about eigenvectors; (iii) neither gives
  $\mathbf 1_T^\top(A-z)^{-1}\mathbf 1_T$ as $\operatorname{Im}z\to0$ with $\operatorname{Re}z>2\sqrt{d-1}$;
  and (iv) HBY warn after Theorem 1.1 that *individual* Green-function entries do not concentrate at fixed
  degree. **Not importable.**
* **Bauerschmidt–Knowles–Yau, arXiv:1503.08702v5, Theorem 1.1**: growing degree ($D\gg\xi^{2}$), operator
  $(d-1)^{-1/2}A-dee^{\ast}$. Model mismatch. Not used.
* **Quantum-ergodicity results** (the framework HBY cite for "the $\ell^2$-mass of a local vector is
  equidistributed over eigenvectors", morally the same statement as (H)): the published QE theorems need
  girth $\to\infty$ or vanishing local injectivity, hypotheses that a uniform random regular graph fails
  *globally* (expected number of $k$-cycles is $\asymp(d-1)^{k}/2k$, i.e. $\Theta(1)$). They hold
  "at a fixed vertex" only, which is precisely what Sections 4–7 exploit without any girth hypothesis.
  **No novelty claim** is made: the moment/Chebyshev route is elementary and may be folklore; the
  forward–backward citation audit demanded by `source-baseline.md` was not completed.

---

## 9. Corollary 3 (root location: what (H) does give)

Let $\Sigma_n(\lambda)=\lambda+\mathbf 1_T^\top(A_{G_n}-\lambda I)^{-1}\mathbf 1_T$ and
$\Sigma_\infty(\lambda)=\lambda-\Delta G_d(\lambda)$. By Proposition B of the dossier,
$p_{G_n'}(\lambda)=p_{G_n}(\lambda)\Sigma_n(\lambda)$ as polynomials, where $G_n'$ is $G_n$ plus one new
vertex adjacent exactly to $T$.

**Corollary 3.** Let $K\subset(2\sqrt{d-1},d)$ be compact and suppose $\Sigma_\infty$ has exactly one
zero $\lambda_\ast\in K$, and that this zero is simple. Then
$\Pr[\,G_n'\text{ has exactly one eigenvalue in }K\,]\to1$, and that eigenvalue tends to
$\lambda_\ast$ in probability.

*Proof.* On Friedman's event $\sigma(A_{G_n})\cap K=\emptyset$, so the zeros of $\Sigma_n$ in $K$
coincide with the zeros of $p_{G_n'}$ in $K$, i.e. with $\sigma(A_{G_n'})\cap K$. By Theorem 2,
$\sup_K|\Sigma_n-\Sigma_\infty|\to0$ in probability; a simple zero is stable under uniformly small
perturbations, and uniqueness plus a sign change forces exactly one zero for $\Sigma_n$ in $K$ for large
$n$. $\square$

Hence, when $\Delta>2(d-2)$ and $\lambda_f\in(2\sqrt{d-1},d)$ is the (unique, by
$\Sigma_\infty'(\lambda)=1+\Delta|G_d'(\lambda)|>0$) root of $\lambda=\Delta G_d(\lambda)$, the "inner"
defect eigenvalue exists and converges in probability to $\lambda_f$: this part of the conjecture in
Proposition D is now a theorem. The ordering of the two largest eigenvalues, and everything at distance
$O(1/n)$ from $d$, is **not** covered; see Section 10.

---

## 10. What this does *not* give: three obstructions

**(O1) The limit is not uniform up to the bulk edge, and cannot be made so by this route.**
With $\tau=\lambda/(2\sqrt{d-1}+\varepsilon)$, $\varrho=\tau+\sqrt{\tau^{2}-1}\downarrow1$ as
$\lambda\downarrow2\sqrt{d-1}+\varepsilon$, so $\theta(\lambda)\to0$. The mechanism is visible twice: in
the proof (the test function has a pole approaching the support), and in the cycle heuristic — a cycle at
distance $\ell$ from $y$ perturbs the message by $\asymp\rho^{\ell}$ with $\rho=(d-1)r(\lambda)^{2}$,
which also rises to $1$ at the edge, while $\lambda$-independent cycles at distances up to
$c\log_{d-1}n$ occur with probability bounded below. Any claim of uniformity on $[2\sqrt{d-1},d)$, or of
agreement with the $n^{-2/3}$ edge fluctuation of $\lambda_2$, needs a different argument. **Do not state
(H) with a $\lambda$-uniform rate.**

**(O2) No $1/n$-accurate asymptotics.** The rate proved is $n^{-\theta}$ with
$\theta=\log\varrho/\log(d-1)$, and in the interesting window $\theta<1$ ($d=3$, $\lambda\in[2.95,3.0]$
gives $\theta\approx0.42$–$0.50$). The finite-size law of dossier §2.5,
$d-\lambda_2\sim\Delta^{2}/(n(\Delta G_d(d)-d))$, needs the resolvent to accuracy $o(1/n)$, i.e.
$\theta\ge1$, which is not available near the edge. The $1/n$ correction therefore stays **conjectural**;
it is not claimed here.

**(O3) Growing or clustered defect sets.** Lemma 3 is a joint statement for all of $T$, so Corollary 3
covers $|T|=\Delta$ fixed, with the cross terms $2(A_{G_n}-\lambda)^{-1}_{yy'}$ killed by (T2). Pairs of
defects at distance $o(\log n)$, or $\Delta=\Delta(n)\to\infty$, are not covered, and the census
prediction remains open there.

---

## 11. What survives of the old overclaim

* Numerical or "local" convergence is used nowhere.
* Expectation is not substituted for convergence in probability: the bound holds on a single event of
  probability $1-n^{-\gamma}-o(1)$.
* Random $T$ is not substituted for fixed $T$: $T$ is deterministic and fixed.
* The one-sided tree branch is not substituted for the Kesten–McKay transform: the constant is
  $G_d(\lambda)=r/(1-r^{2})$, the full transform; and the off-diagonal tree entries
  $-G_d(\lambda)r^{\operatorname{dist}}$ are correctly absent, because (T2) kills them.
* Complex-$z$ bulk estimates are not passed to real exterior energy: the only spectral input is a
  statement about eigenvalues, and $\lambda$ is real and fixed throughout.

---

## 12. Numerical corroboration (evidence only, not proof)

*Sampler.* Configuration model with rejection of non-simple pairings (`scripts/exterior_check2.py`,
`scripts/edge_rate.py`), i.e. the uniform simple model up to the conditioning of Section 5; fixed seeds via
`numpy.random.default_rng`. Sizes $n\le8000$ only. `networkx.random_regular_graph` is **not** used.

`out/edge_rate.json`: median over 6 seeds of
$\big|\mathbf 1_{\{0\}}^\top(A-\lambda)^{-1}\mathbf 1_{\{0\}}+G_d(\lambda)\big|$, $d=3$,
$n=500,1000,2000,4000,8000$:

| $\lambda$ | 2.85 | 2.90 | 2.95 | 3.20 | 3.60 |
|---|---|---|---|---|---|
| fitted slope of $\log$ median vs $\log n$ | $-0.66$ | $-0.85$ | $-0.94$ | $-1.28$ | $-1.69$ |
| proved exponent $\theta(\lambda,\varepsilon\downarrow0)$ | 0.18 | 0.32 | 0.42 | 0.73 | 1.04 |

The deviation decays to $0$ — so (H) is not refuted: the worry that bounded local cycles produce an
$O(1)$ non-concentrating correction is **false**, because the number of cycles through a *fixed* vertex is
$O(1/n)$ (by exchangeability $\mathbb{E}[(A^{k})_{yy}]=\frac1n\mathbb{E}[\operatorname{tr}A^{k}]$, and
$\mathbb{E}[\operatorname{tr}A^{k}]\asymp(d-1)^{k}$ for fixed $k$), unlike through a uniform random vertex
— and in every case the fitted exponent exceeds the proved one, with both increasing in $\lambda$ exactly
as predicted. (The proved exponent is quoted as $\varepsilon\downarrow0$ because Friedman's theorem is
available for every $\varepsilon>0$ but not for $\varepsilon=0$; each $\varepsilon>0$ gives a slightly
smaller valid exponent.)

`out/verify_moments.txt`: exact agreement of the two computations of $m_k$, $k\le12$, $d=3,4,5,6$.

*Honest limits.* $n\le8000$; fitted slopes are not proof of any exponent; the proved rate is far from
sharp (observed decay is faster, plausibly $\asymp n^{-(\theta+1/2)}$).
