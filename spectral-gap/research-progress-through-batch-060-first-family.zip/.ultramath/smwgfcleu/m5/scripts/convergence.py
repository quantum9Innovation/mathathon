"""Convergence of lambda_2 of a random d-regular host plus one spike."""
import numpy as np, networkx as nx
from scipy.sparse.linalg import eigsh
from scipy.optimize import brentq

def Gst(d, lam):
    a, b, c = d-1.0, -lam, 1.0
    disc = b*b-4*a*c
    if disc < 0: return None
    r = min([(-b+np.sqrt(disc))/(2*a), (-b-np.sqrt(disc))/(2*a)], key=abs)
    return r/(1-r*r)

def lam_f(d, Delta):
    edge = 2*np.sqrt(d-1.0)
    if Delta <= 2*(d-2)+1e-12: return edge
    return brentq(lambda t: t - Delta*Gst(d, t), edge*(1+1e-12), 3*np.sqrt(Delta)+d+10, xtol=1e-14)

print(f"{'d':>2} {'Del':>4} {'n':>7} {'lam1':>10} {'lam2':>10} {'lam*=tree':>10} {'lamf':>9} "
      f"{'d-lam2':>9} {'n*(d-lam2)':>11} {'|lam1-lamf|':>11}")
for d, Delta in [(3,6),(4,7),(5,8)]:
    lf = lam_f(d, Delta); ls = Delta/np.sqrt(Delta+1-d) if Delta > 2*(d-1) else float('nan')
    for n in [1000, 2000, 4000, 8000, 16000]:
        G0 = nx.random_regular_graph(d, n, seed=7)
        Gp = nx.convert_node_labels_to_integers(G0); Gp.add_node(n)
        T = np.random.default_rng(11).choice(n, size=Delta, replace=False)
        for y in T: Gp.add_edge(n, int(y))
        A = nx.to_scipy_sparse_array(Gp, format='csr', dtype=float)
        t = np.sort(eigsh(A, k=3, which='LA', return_eigenvectors=False))[::-1]
        print(f"{d:2d} {Delta:4d} {n:7d} {t[0]:10.6f} {t[1]:10.6f} {ls:10.6f} {lf:9.6f} "
              f"{d-t[1]:9.6f} {n*(d-t[1]):11.4f} {abs(t[0]-max(d,lf)):11.6f}")
