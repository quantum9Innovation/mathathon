"""Exact verification of the Cayley/code dictionary for elementary abelian 2-groups.

Model.  G = F_2^rho, S subset G minus {0} with |S| = d, A = adjacency of Cay(G,S).
Claim (Theorem 1 of the dossier).  For a in F_2^rho put phi(a) = (a.s)_{s in S} in F_2^d.
Then the spectrum of A is the multiset {d - 2*wt(phi(a)) : a in F_2^rho}.
Consequently lambda_2 = d - 2*d_min(C) with C = rowspace of the rho x d matrix
whose columns are the elements of S, and the multiplicity of lambda_2 equals
2^(rho - rank S) * #{c in C : wt(c) = d_min(C)}.

Everything here is integer arithmetic.  The adjacency spectrum is recomputed
independently from the characteristic polynomial of the 0/1 matrix (sympy, exact).
"""
import json
import random
from sympy import Matrix, Poly, symbols

x = symbols('x')


def popcount(v):
    return bin(v).count('1')


def charpoly(rows):
    n = len(rows)
    M = Matrix(n, n, lambda i, j: rows[i][j])
    return Poly(M.charpoly(x).as_expr(), x)


def cayley_adjacency(rho, S):
    N = 1 << rho
    rows = [[0] * N for _ in range(N)]
    for g in range(N):
        for s in S:
            rows[g][g ^ s] += 1
    return rows


def column_code(rho, S):
    """Row space of the rho x d matrix with columns S, as a sorted list of d-bit ints.

    Coordinate j of a codeword corresponds to the j-th element of S.  For each
    basis direction i of F_2^rho we build the d-bit mask of the columns s in S
    whose i-th bit is 1.  The code is the span of those rho masks.
    """
    d = len(S)
    rows = []
    for i in range(rho):
        m = 0
        for j, s in enumerate(S):
            if (s >> i) & 1:
                m |= 1 << j
        rows.append(m)
    basis = []
    for v in rows:
        for b in basis:
            v = min(v, v ^ b)
        if v:
            basis.append(v)
            basis.sort(reverse=True)
    code = {0}
    for b in basis:
        code |= {c ^ b for c in code}
    return sorted(code), len(basis)


def predicted_mults(rho, S):
    d = len(S)
    code, rank = column_code(rho, S)
    weights = {}
    for c in code:
        w = popcount(c)
        weights[w] = weights.get(w, 0) + 1
    mult = {}
    for w, cnt in weights.items():
        mult[d - 2 * w] = mult.get(d - 2 * w, 0) + cnt * (1 << (rho - rank))
    return mult, rank, weights


def poly_from_mults(mult):
    expr = 1
    for lam, m in mult.items():
        expr *= (x - lam) ** m
    return Poly(expr, x)


def main():
    rng = random.Random(20261114)
    checks = 0
    failures = []
    disconnected = 0
    for rho in range(2, 6):
        N = (1 << rho) - 1
        for d in range(1, min(N, 12) + 1):
            for _ in range(6):
                S = rng.sample(range(1, 1 << rho), d)
                actual = charpoly(cayley_adjacency(rho, S))
                mult, rank, weights = predicted_mults(rho, S)
                predicted = poly_from_mults(mult)
                checks += 1
                if rank < rho:
                    disconnected += 1
                if actual != predicted:
                    failures.append({"rho": rho, "d": d, "S": S, "rank": rank})
    for rho, d, S in [(4, 6, [1, 2, 3, 4, 5, 6]), (4, 5, [1, 2, 4, 8, 15]),
                      (3, 7, [1, 2, 3, 4, 5, 6, 7]), (5, 3, [3, 6, 9])]:
        actual = charpoly(cayley_adjacency(rho, S))
        mult, rank, weights = predicted_mults(rho, S)
        predicted = poly_from_mults(mult)
        checks += 1
        if rank < rho:
            disconnected += 1
        if actual != predicted:
            failures.append({"rho": rho, "d": d, "S": S, "rank": rank})
    print(json.dumps({"checks": checks, "failures": failures,
                      "cases_with_rank_below_rho": disconnected}, indent=1))


if __name__ == "__main__":
    main()
