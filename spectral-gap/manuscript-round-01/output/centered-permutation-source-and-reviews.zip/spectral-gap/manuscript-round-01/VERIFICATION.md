# Verification and acceptance record

Date: November 14, 2026 Pacific. Scope: problem 21 manuscript round. Mathematical proof, source attribution, computation and document integrity are distinct evidence types.

## Mathematical evidence

| Result | Proof revision | Review |
| --- | --- | --- |
| Core mixed estimate, cubic criterion and bounded critical limits | Frozen input files recorded in inputs/MANIFEST.json | [Fresh core reconstruction](proof/core-audit-v1.md) |
| Exact factorial correction and optimal sqrt(e) prefactor | [Mixed proof v3](proof/permutation-proof-v3.md) | [Integrator reconstruction](reviews/mixed-v3-integrator-review.md) |
| Relative hyperbolic window and square-root correction | [Extension v1](extensions/hyperbolic-window-v1.md) | [Independent extension review](reviews/extension-review-v1.md) |

Mixed proof SHA256: `8b96bff0a030142682bd3b77bd33924c27f03512f0f5f9a10a222de40075a61f`.

Extension proof SHA256: `73de96b41b7fba59454795f14bf1fe6160f8eee1391553bf980f3f29f4eba68a`.

Extension review SHA256: `85300732089208d4fc745b5e6b6c973aa767a64f0dc0c481a243d19dc9508b91`.

The extension review explicitly reconstructs both availability normalizations, the aggregate tail of all larger blocks, the pair-depletion logarithm, parity-weighted convergence in mean and the compactness argument for uniformity. The [fresh assembled-source review](reviews/manuscript-referee-v1.md) and [final revision-4 acceptance](reviews/manuscript-referee-v4.md) separately check the complete manuscript and guide. All five referee findings are closed. No blocking proof or explanation gap remains in the reviewed scope.

## Executed corroboration

- [Core exact checks](proof/core-checks-v1.json): 77,378 rational or integer cases covering the depleted recurrence, affine weights, factorial merging and threshold bounds.
- [Extension investigator checks](extensions/extension-checks-v1.json): 1,061 exact formula cases, 33 directly enumerated moments over 5,912 permutations, 4,471 numerical envelope cases, 508 logarithmic-bound cases and 18 square-root examples.
- [Independent extension checks](reviews/extension-review-checks.json): 1,196 exact polynomial identities, 7,193 rational availability identities, 7,875 numerical bound cases and 18 boundary examples.
- [Fresh referee checks](reviews/manuscript-referee-checks.json): independently reconstructed moments, partition coefficients, availability identities, lower bounds and the two conditioning events.

These programs were executed during their respective investigations. Their written outputs preserve domains and arithmetic. They are corroboration, not a proof of an unrestricted statement. No formal proof checker was used in this round.

## Source and priority evidence

The [primary-source audit](priority/PRIORITY_AUDIT_V1.md) and its [manifest](priority/MANIFEST-v1.json) verify the exact published question, prior recurrences, leading terms, mixed estimate and classical Laguerre identity. The audit also reconciles preprint and published lemma numbering. Its bounded negative search result supports cautious contribution language, not exhaustive historical priority.

The official problem page was read in the browser on November 14. Its requested outcome is an intuitive proof of Proposition 28 together with explanation of the surrounding spectral-gap theory. The manuscript directly addresses that estimate and distinguishes it from the remainder of the graph proof.

## Compilation and visual checks

The maintained [build script](build_artifacts.py) regenerated both scientific figures and their saved data, then compiled each document three times with the installed typesetter. Both final logs contain no unresolved references or overflowing text warnings. The manuscript has 19 A4 pages. The guide has five A4 pages.

Every manuscript page and all five guide pages were rendered and visually inspected. After later wording changes, the changed pages were re-rendered and inspected again. Raster comparisons confirmed that the other page images were unchanged. There is no clipped text, overlapping formula, broken table, orphaned contents page or unreadable figure label in the final reading copies.

The six recorded manuscript issues concern a plotting label, the contents layout, two boundary conventions, pair-depletion wording, the leading odd partition description and parallel-edge walk semantics. Their corrections are preserved through frozen document revisions rather than overwriting reviewed sources.

## Integrity

The [package checker](checks/verify_package.py) verifies frozen source hashes, final-source and PDF identity against [frozen revision 4](frozen-manuscript-v4/MANIFEST.json), page counts, final build logs, selected local links and prose style. All 97 frozen-hash comparisons passed. Its [machine-readable output](checks/package-verification.json) records the final local-link count and zero build warnings.

No integrity check alone establishes mathematical correctness. The authoritative [claim ledger](../CLAIM_LEDGER.md) separately records each exact statement, proof dependency and review scope.
