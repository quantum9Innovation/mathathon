# Derivations and reproducibility notes

Companion to `main.md`. Every statement here is either a full proof of a claim in `main.md` or a
record of how a computational claim was produced.

## A. Environment and how to rerun

All scripts are plain Python 3 with numpy, sympy and networkx. The versions used were numpy 2.5.3,
sympy 1.14.0, networkx 3.7. The nauty enumeration scripts call the `nauty-geng` binary, which is
installed at `/usr/bin/nauty-geng`.

Run from the directory that contains `code/` and `out/`:

```
python3 code/seidel_core.py      # Paley conference matrices, relative bound, multiplicity bound
python3 code/mult_bound.py       # graph corollary, stability identity, equality cases
python3 code/fold_and_equi.py    # Ihara-Bass fold check and equiangular extraction
python3 code/defect_count.py     # Cartesian product spectra and defect counts
python3 code/three_eig.py        # three distinct eigenvalues implies diameter at most two
python3 code/srg_families.py     # Paley, rook, hypercube spectra
python3 code/extremal_cubic.py   # all connected cubic graphs, n <= 18, exact max multiplicity
python3 code/extremal_more.py    # cubic 12 to 18, quartic 6 to 14, quintic 6 to 12
```

Observed runtimes in this VM: the first five scripts under 3 seconds each, `srg_families.py` under 1
second, `extremal_cubic.py` about 40 seconds, `extremal_more.py` about 82 seconds. Total under three
minutes.

`code/fold_and_equi.py` performs two jobs. It checks the Ihara-Bass fold as an exact spectral multiset
identity on six graphs, and it extracts explicit equiangular systems from five two-eigenvalue Seidel
matrices (Paley $q=5,13,17$, the rook graph, and $K_5$), writing `out/equiangular.json`.

Floating point caveats. All eigenvalue computations are float64. Every claim that can be checked in
exact integer arithmetic was checked that way: the Paley identity $S^2=qI$ is an integer matrix
identity with zero residual, $S_{ii}=0$ and $|S_{ij}|=1$ are exact, and the trace identities are
exact. Multiplicities were read off with a tolerance of $10^{-7}$ or $10^{-8}$ in the eigenvalue
value, and every reported multiplicity was cross checked against the trace.

## B. Full proofs

### B.1 Theorem 3.1, with all steps

Let $S\in\mathbb R^{n\times n}$ be symmetric with zero diagonal and $\pm1$ off the diagonal. The two
exact trace identities are
$$\operatorname{tr}S=\sum_i S_{ii}=0,\qquad
\operatorname{tr}S^2=\sum_{i,j}S_{ij}^2=\sum_{i\ne j}1=n(n-1).$$
Let $\theta$ have multiplicity $k$ and let $\theta_1,\dots,\theta_{n-k}$ be the other eigenvalues,
counted with multiplicity. Comparing traces,
$$\sum_{i=1}^{n-k}\theta_i=-k\theta,\qquad
\sum_{i=1}^{n-k}\theta_i^2=n(n-1)-k\theta^2 .$$
Cauchy-Schwarz in the form $(\sum a_i)^2\le (n-k)\sum a_i^2$ gives
$$k^2\theta^2\le(n-k)\big(n(n-1)-k\theta^2\big).$$
Expanding the right side and moving $-(n-k)k\theta^2$ to the left,
$$k^2\theta^2+(n-k)k\theta^2=kn\theta^2\le (n-k)n(n-1).$$
Divide by $n>0$ and rearrange: $k\theta^2\le (n-k)(n-1)=n(n-1)-k(n-1)$, hence
$k(\theta^2+n-1)\le n(n-1)$, which is the claim. Equality in Cauchy-Schwarz holds exactly when all
$\theta_i$ are equal, and then the common value is $-k\theta/(n-k)$ by the trace identity. So $S$
has at most two distinct eigenvalues. Conversely if $S$ has two eigenvalues then the
$\theta_i$ are equal and equality holds, so the characterisation is exact.

### B.2 Corollary 3.2

Take $n=m$ and $k=m-d$ and $\theta=-1/\alpha$ in Theorem 3.1. Since $\alpha>0$,
$\theta^2=\alpha^{-2}$ and
$$m-d\le\frac{m(m-1)}{m-1+\alpha^{-2}}.$$
The denominator is positive, so
$$(m-d)(m-1)+(m-d)\alpha^{-2}\le m(m-1).$$
Subtracting $(m-d)(m-1)$ from both sides leaves $(m-d)\alpha^{-2}\le d(m-1)$, and multiplying by
$\alpha^2$ gives $m-d\le d\alpha^2(m-1)$. Rearranged, $m(1-d\alpha^2)\le d(1-\alpha^2)$. If
$d\alpha^2<1$ the factor $1-d\alpha^2$ is positive and the division is legitimate.

### B.3 Corollary 3.3, including the eigenvalue at the all-ones vector

Let $x\perp\mathbf 1$ be a $\lambda$-eigenvector of $A$. Then $Jx=0$, so
$$Sx=(J-I-2A)x=0-x-2\lambda x=-(1+2\lambda)x.$$
The map $x\mapsto x$ is an injection of the $\lambda$-eigenspace of $A$ restricted to
$\mathbf 1^\perp$ into the $-(1+2\lambda)$-eigenspace of $S$. If $\mathbf 1$ is not a
$\lambda$-eigenvector, the whole $\lambda$-eigenspace lies in $\mathbf 1^\perp$ and
$\operatorname{mult}_A(\lambda)\le\operatorname{mult}_S(-(1+2\lambda))$. Otherwise
$\operatorname{mult}_A(\lambda)\le\operatorname{mult}_S(-(1+2\lambda))+1$, and the extra $1$ is
exactly the loss observed for $K_{3,3}$ and $K_{4,4}$ in Section 4.3 of `main.md`.

For a $d$-regular graph, $\mathbf 1$ is a $d$-eigenvector and $d$ is simple when $G$ is connected,
so the hypothesis holds for every $\lambda\ne d$.

### B.4 Theorem 3.4

Let $\mu=-k\theta/(n-k)$ be the mean of the remaining eigenvalues. Then
$$\sum_i(\theta_i-\mu)^2=\sum_i\theta_i^2-2\mu\sum_i\theta_i+(n-k)\mu^2 .$$
Substituting $\sum_i\theta_i=-k\theta$, $\sum_i\theta_i^2=n(n-1)-k\theta^2$ and
$\mu=-k\theta/(n-k)$,
$$-2\mu\sum_i\theta_i=-2\cdot\frac{-k\theta}{n-k}\cdot(-k\theta)=-\frac{2k^2\theta^2}{n-k},
\qquad (n-k)\mu^2=\frac{k^2\theta^2}{n-k}.$$
The two last terms combine to $-k^2\theta^2/(n-k)$, which is the definition of the slack.
Therefore the slack is nonnegative, and it vanishes exactly when all the remaining eigenvalues are
equal. This also gives an alternative proof of the equality case of Theorem 3.1 and makes the
quantitative content explicit: the deficit is a variance, so it is stable under perturbations that
spread the remaining eigenvalues, and it does not see a spectral gap.

### B.5 Theorem 3.5

Suppose equality holds in Corollary 3.3 for a connected $d$-regular $G$ and an eigenvalue
$\lambda\ne d$. Then equality holds in Theorem 3.1 for $S=S(G)$, so $S$ has at most two distinct
eigenvalues. Set $M=(I+S)/2$, which also has at most two distinct eigenvalues. Then
$$A=\frac{J-I-S}{2}=\frac{J}{2}-M,$$
so $A$ is a rank-one perturbation of the symmetric matrix $-M$. By Weyl's interlacing inequality for
rank-one perturbations, the eigenvalues of $A$ and of $-M$ interlace with a shift of at most the
operator norm of $J/2$ in rank one, which implies that the number of distinct eigenvalues of $A$ is
at most the number of distinct eigenvalues of $M$ plus one. So $A$ has at most three distinct
eigenvalues.

Let $\mathcal A$ be the algebra generated by $A$. Because the minimal polynomial of $A$ has degree
at most three, $\dim\mathcal A\le3$ and $\mathcal A$ is spanned by $\{I,A,A^2\}$. Because $G$ is
connected and $d$-regular, $\mathbf 1$ spans the Perron eigenspace and the projector onto it is
$(1/n)J$, which is a polynomial in $A$. Hence $J\in\mathcal A$, and therefore
$\mathcal A$ is also spanned by $\{I,A,J\}$. So there are real $a,b,c$ with
$$A^2=aI+bA+cJ .$$
For distinct vertices $i,j$ this gives $(A^2)_{ij}=aA_{ij}+c$. If $i$ and $j$ are non-adjacent then
$A_{ij}=0$ and $(A^2)_{ij}=c$, and $(A^2)_{ij}$ is by definition the number of common neighbours of
$i$ and $j$.

If $G$ is complete then $n=d+1\le d^2+1$ for $d\ge1$. Otherwise $G$ is connected and not complete,
so there is a pair of vertices at distance exactly two: take a shortest path between a non-adjacent
pair and look at its first three vertices. For that pair $(A^2)_{ij}\ge1$, so $c\ge1$. Then every
non-adjacent pair has exactly $c\ge1$ common neighbours, so every pair is at distance at most two
and the diameter is at most two. The Moore bound for a $d$-regular graph of diameter two is
$n\le1+d+d(d-1)=d^2+1$, which is the claim.

The Moore bound input is classical: from a vertex there are $1$ vertex at distance zero, at most $d$
at distance one, and at most $d(d-1)$ at distance two, and a graph of diameter two is covered by
these three layers.

### B.6 Proposition 4.6

The spectrum formula for Cartesian products is standard: $A(G\square H)=A(G)\otimes I+I\otimes A(H)$
and the eigenvectors are tensor products. It was verified numerically for the Petersen graph with
$k=4,7,12$ to maximum deviation $7.2\times10^{-15}$.

For the count, restrict to the $k$ eigenvalues coming from the Perron eigenvalue $d$ of $R$. They are
$d+2\cos(2\pi j/k)$ for $j=0,\dots,k-1$. The graph $G$ is $(d+2)$-regular, so its Alon-Boppana
threshold is $2\sqrt{d+1}$. The inequality
$$d+2\cos\frac{2\pi j}{k}\ \ge\ d-2\ >\ 2\sqrt{d+1}$$
holds for the middle term when $d-2>0$ and $(d-2)^2>4(d+1)$, that is $d^2-8d>0$, that is $d>8$. So
for $d\ge9$ all $k$ of these eigenvalues are above the threshold.

For $R=K_4$ the same computation with $d=3$ and threshold $4$ asks for $3+2\cos(2\pi j/k)>4$, that
is $\cos(2\pi j/k)>1/2$, that is $2\pi j/k\in(-\pi/3,\pi/3)$ modulo $2\pi$. For $1\le j\le k-1$ this
holds exactly for $j<k/6$ or $j>5k/6$, giving
$$1+2\Big(\Big\lceil\frac{k}{6}\Big\rceil-1\Big)$$
eigenvalues above $4$, where the leading $1$ is the Perron eigenvalue $5$. For $k=160$ this is
$1+2(27-1)=53$, which matches the computed value in Section 4.6 of `main.md`.

Similar computation for the Petersen graph block: $d=3$, $k=12$ and $k=7$ both give 3 eigenvalues
above 4, matching the computed values.

### B.7 Paley conference matrices

Let $q\equiv1\pmod4$ be a prime and let $\chi$ be the Legendre symbol mod $q$. Define $C\in
\mathbb Z^{q\times q}$ by $C_{ij}=\chi(i-j)$ for $i\ne j$ and $C_{ii}=0$, and let
$$S=\begin{pmatrix}0&\mathbf 1^T\\ \mathbf 1&C\end{pmatrix}\in\mathbb Z^{(q+1)\times(q+1)} .$$
Two classical facts about the Paley matrix $C$ are imported: $C$ is symmetric and $C^2=qI-J$. Also
$C\mathbf 1=0$ because every nonzero residue has $q-1$ translates and the Legendre symbols in each
row sum to zero. Then
$$S^2=\begin{pmatrix}\mathbf 1^T\mathbf 1&\mathbf 1^TC\\ C\mathbf 1&\mathbf 1\mathbf 1^T+C^2\end{pmatrix}
=\begin{pmatrix}q&0\\0&J+qI-J\end{pmatrix}=qI .$$
So $S$ has eigenvalues $\pm\sqrt q$, each with multiplicity $(q+1)/2$ because $\operatorname{tr}S=0$.
The integer identity $S^2=qI$ was checked with exact integer matrix multiplication for $q=5,13,17$
and had zero residual in every case.

### B.8 Switching invariance

If $D$ is a diagonal matrix with entries $\pm1$ then $(DSD)^2=DS^2D$ and $DSD$ is orthogonally
similar to $S$ through $D$ itself, since $D^{-1}=D$. So the spectrum is unchanged. This is the
elementary reason the two-graph, and not the graph, is the right carrier of the Seidel spectrum.

### B.9 The Seidel spectrum of a regular graph

Let $G$ be $d$-regular. Then $S\mathbf 1=(J-I-2A)\mathbf 1=(n-1-2d)\mathbf 1$, and on
$\mathbf 1^\perp$ we have $J=0$, so $S=-I-2A$ there. Therefore
$$\operatorname{spec}(S)=\{n-1-2d\}\cup\{-1-2\lambda:\ \lambda\in\operatorname{spec}(A),\ \lambda\ne d\}.$$
This is the exact translation used in Corollary 3.3 and in the two-eigenvalue computations of
Section 4.2. It also shows why a strongly regular graph can have three Seidel eigenvalues: the
degree eigenvalue $n-1-2d$ need not coincide with any $-1-2\lambda$.

### B.10 Equiangular extraction

Given a Seidel matrix $S$ of order $m$ with least eigenvalue $-1/\alpha$ of multiplicity $m-d$ and
no eigenvalue below $-1/\alpha$, the matrix $G_{\mathrm{gram}}=I+\alpha S$ is positive semidefinite
with rank $d$, and it has unit diagonal. Let $U$ be an $m\times d$ matrix whose columns are an
orthonormal basis of the column space. Then $G_{\mathrm{gram}}=(m/d)UU^T$ when equality holds in the
relative bound, and the $m$ columns of
$$X=\sqrt{\frac md}\,U^T\in\mathbb R^{d\times m}$$
are unit vectors with Gram matrix $X^TX=G_{\mathrm{gram}}$. The extraction was run for the Paley
matrices $q=5,13,17$, for the rook graph and for $K_5$, and in every case the column norms were $1$
to $10^{-15}$ and every off-diagonal inner product had modulus equal to $\alpha$ to at most
$10^{-10}$.

### B.11 The three eigenvalue enumeration

`code/three_eig.py` enumerates all connected graphs with $n\le8$ vertices with `nauty-geng`, keeps
those with exactly three distinct adjacency eigenvalues, and computes the diameter with networkx.
There were 18 such graphs, the maximum diameter was 2, no graph had diameter above 2, and no regular
graph among them violated $n\le d^2+1$. This is a consistency check of Theorem 3.5, not a substitute
for its proof.

### B.12 The extremal enumeration

`code/extremal_cubic.py` and `code/extremal_more.py` call
`nauty-geng -c -q -d<d> -D<d> <n>`, decode each graph6 string into an adjacency matrix, compute the
adjacency spectrum with numpy, identify the second largest distinct eigenvalue and its
multiplicity, and keep the record. In every reported case the record holder was unique. The graph
counts reported in Section 4.7 of `main.md` agree with the standard counts of connected regular
graphs: 1, 2, 5, 19, 85, 509, 4060, 41301 for connected cubic graphs with $n=4,6,\dots,18$.

## C. What the four dossiers supply, in their own terms

This section records the exact local statements used for the common ground section of `main.md`, so
that the comparison can be checked without reopening the dossiers.

1. `alon-second-eigenvalue` (Friedman, arXiv cs/0405020v1). The quantified Theorem 1.1 for the
   permutation model has failure exponent
   $\tau_{\mathrm{fund}}=\lceil(\sqrt{d-1}+1)/2\rceil-1$. Theorem 3.13 in that paper is the tree
   completion threshold $\lambda_1(\operatorname{Tree}_d(\psi))=2\sqrt{d-1}$ if and only if
   $\lambda_{\mathrm{Irred}}(\psi)\le\sqrt{d-1}$. Theorem 10.3 rewrites strongly irreducible traces
   as power sums of $\mu_{1,2}$ solving $\mu^2-\lambda\mu+(d-1)=0$, which is the fold used here.
2. `biregular-spectral-gap` (Brito, Dumitriu, Decker Harris, arXiv 1804.07808v6). The Ihara-Bass
   statement on page 6 is
   $\det(B-\lambda I)=(\lambda^2-1)^{|E|-|V|}\det(D-\lambda A+\lambda^2I)$ with $D_{vv}=d_v-1$. The
   singular value transfer on page 8 is
   $\lambda^4-(\xi^2-d_1-d_2+2)\lambda^2+(d_1-1)(d_2-1)=0$, which gives
   $\lambda_2\le\sqrt{d_1-1}+\sqrt{d_2-1}+o(1)$.
3. `friedman-second-eigenvalue-lifts` (Bordenave, arXiv 1502.04482v4). Theorem 23 gives the new
   nonbacktracking eigenvalues at most $\sqrt{\rho_1}+o(1)$ for random lifts, and Corollary 24
   converts this to $2\sqrt{d-1}+o(1)$ for regular bases.
4. `relativized-second-eigenvalue` (Friedman, Kohler, arXiv 1403.3462v1). Theorem 0.1.1 gives
   failure probability $O(n^{-1})$ at threshold $2\sqrt{d-1}+\epsilon$ for random covers of a
   $d$-regular base. Theorem 0.1.3 gives the two-sided exponent $\eta_{\mathrm{fund}}(B)$, the least
   order of a strict feasible tangle. The abstract's claim that
   $\eta_{\mathrm{fund}}(B)>\sqrt{d-1}$ is flagged as inconsistent in the local dossier and is not
   used here.

## D. Negative and boundary results recorded for honesty

1. The relative bound is not an optimality criterion. The rook graph attains it in $\mathbb R^{10}$
   with 16 lines, while the maximum is 28 (OEIS A002853).
2. Attaining the relative bound does not require $m=2d$: the rook graph has $m=16$ and $d=10$.
3. The Seidel bound is not tight at fixed degree: at fixed $d$ it is $n(1-o(1))$, and its equality
   family is confined to $n\le d^2+1$ by Theorem 3.5.
4. The count of eigenvalues above a fixed margin above $2\sqrt{d-1}$ is $\Theta(n)$ by Proposition
   4.6, so no multiplicity defect count in $(d,\varepsilon)$ exists.
5. The moment method cannot prove sublinear second eigenvalue multiplicity at fixed degree. This is
   the content of Obstruction O1 in `main.md` and it is a limitation of a method, not of the truth.
6. The nauty data at small $n$ has record holders that are complete bipartite graphs, so small $n$
   extremal data must not be extrapolated to fixed degree asymptotics.
