"""How many eigenvalues can sit above the Alon-Boppana edge 2 sqrt(d-1)?
Exact Cartesian-product construction."""
import numpy as np, json
import networkx as nx

def counts(G):
    A=nx.to_numpy_array(G,dtype=float)
    return A.shape[0], sorted(set(dict(G.degree()).values())), np.linalg.eigvalsh(A)

rows=[]
for k in [5,10,20,40,80,160]:
    R=nx.complete_graph(4)
    G=nx.convert_node_labels_to_integers(nx.cartesian_product(R,nx.cycle_graph(k)))
    n,deg,ev=counts(G); d=max(deg); thr=2*np.sqrt(d-1)
    tops=[float(x) for x in ev[::-1][:5]]
    rows.append(dict(R="K4",k=k,n=n,deg=d,thr=round(thr,6),n_above=int(np.sum(ev>thr)),
        top5=[round(x,8) for x in tops],
        d_minus_l2=round(d-tops[1],10), d_minus_l3=round(d-tops[2],10),
        l2_eq_l3=bool(abs(tops[1]-tops[2])<1e-9)))
for k in [4,7,12]:
    R=nx.petersen_graph(); G=nx.convert_node_labels_to_integers(nx.cartesian_product(R,nx.cycle_graph(k)))
    n,deg,ev=counts(G); d=max(deg)
    mu=np.linalg.eigvalsh(nx.to_numpy_array(R,dtype=float))
    pred=np.sort([m+2*np.cos(2*np.pi*j/k) for m in mu for j in range(k)])
    rows.append(dict(R="Petersen",k=k,n=n,deg=d,
        max_abs_dev=float(np.max(np.abs(np.sort(ev)-pred))),
        n_above=int(np.sum(ev>2*np.sqrt(d-1)))))
json.dump(rows,open("out/defect_count.json","w"),indent=1)
print(json.dumps(rows,indent=1))
