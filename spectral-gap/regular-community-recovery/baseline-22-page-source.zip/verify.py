"""Verify packet integrity, source bindings, TeX references, and PDF builds."""
from pathlib import Path
import hashlib
import json
import re
import shutil
import subprocess
import sys

PACKET = Path(__file__).resolve().parent
WORKSPACE = PACKET.parents[1]
POPP = Path("/nix/store/q0ld5mmjh89nar306jb0izrcf8phy5v9-poppler-utils-26.10.0/bin")


def check_manifest(path, base):
    checked = 0
    for line in path.read_text().splitlines():
        if not line or line.startswith("#"):
            continue
        expected, relative = line.split("  ", 1)
        actual = hashlib.sha256((base / relative).read_bytes()).hexdigest()
        assert actual == expected, f"Hash mismatch: {relative}"
        checked += 1
    return checked


def main():
    internal = check_manifest(PACKET / "SHA256SUMS.txt", PACKET)
    sources = check_manifest(PACKET / "SOURCE-HASHES.txt", WORKSPACE)
    tex_files = [PACKET / "main.tex", PACKET / "references.tex"]
    tex_files += sorted((PACKET / "sections").glob("*.tex"))
    source = "\n".join(path.read_text() for path in tex_files)
    labels = re.findall(r"\\label\{([^}]+)\}", source)
    references = re.findall(r"\\(?:eqref|ref)\{([^}]+)\}", source)
    assert len(labels) == len(set(labels)), "Duplicate labels"
    assert set(references) <= set(labels), "Unbound references"
    bibliography = set(re.findall(r"\\bibitem\{([^}]+)\}", source))
    citations = set()
    for group in re.findall(r"\\cite(?:\[[^]]*\])?\{([^}]+)\}", source):
        citations.update(group.split(","))
    assert citations <= bibliography, "Unbound citations"
    for included in re.findall(r"\\input\{([^}]+)\}", (PACKET / "main.tex").read_text()):
        assert (PACKET / (included + ".tex")).exists(), f"Missing input {included}"
    pages = {}
    for name, expected_pages in [("regular-community-recovery", 22), ("reading-guide", 2)]:
        log = (PACKET / "build" / (name + ".log")).read_text()
        assert not re.search(r"Warning:|Overfull|undefined|Rerun to get", log), name + " log issue"
        tool = shutil.which("pdfinfo") or str(POPP / "pdfinfo")
        info = subprocess.check_output([tool, str(PACKET / (name + ".pdf"))], text=True)
        count = int(re.search(r"^Pages:\s+(\d+)", info, re.M).group(1))
        assert count == expected_pages, (name, count)
        pages[name] = count
    subprocess.run([sys.executable, str(PACKET / "verification" / "check_fibers.py")],
                   check=True, stdout=subprocess.DEVNULL)
    report = {"status": "PASS", "packet_hashes": internal, "source_bindings": sources,
              "labels": len(labels), "references": len(references),
              "bibliography_entries": len(bibliography), "pages": pages,
              "exact_fiber_configuration_cases": 5}
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
