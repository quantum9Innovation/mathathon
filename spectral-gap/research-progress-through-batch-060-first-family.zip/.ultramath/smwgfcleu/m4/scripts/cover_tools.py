"""
cover_tools.py -- universal covers and random lifts of a finite base multigraph.

A base is given as (r, edges) where `edges` is a list of edge *occurrences*, so
parallel edges are distinct entries and loops are (u,u) entries.

* universal_cover_ball(r, edges, root, depth): ball of radius `depth` around a
  lift of `root` in the universal cover.  Vertices of the cover are
  non-backtracking walks in edge occurrences.  Requires min degree >= 2 so that
  homotopy classes of paths coincide with non-backtracking walks.
* random_lift(r, edges, n, rng): Broder-Shamir / permutation model, one
  independent uniform permutation per edge occurrence.
* new_spectrum(A_base, A_lift, n): exact "new" spectrum, i.e. the restriction of
  A_lift to the orthogonal complement of the fiber-constant functions.
"""
import numpy as np
import scipy.sparse as ss
from scipy.sparse.linalg import eigsh


def incident(edges, r):
    inc = [[] for _ in range(r)]
    for k, (u, v) in enumerate(edges):
        inc[u].append((k, v))
        if v != u:
            inc[v].append((k, u))
    return inc


def _walk(r, edges, root, p):
    """Vertices visited by the edge-occurrence path p starting at root (loopless bases)."""
    cur = root
    vs = [cur]
    for k in p:
        u, v = edges[k]
        if cur == u:
            cur = v
        elif cur == v:
            cur = u
        else:
            return None
        vs.append(cur)
    return vs


def universal_cover_ball(r, edges, root=0, depth=8):
    """Adjacency (sparse) of the radius-`depth` ball of the universal cover.
    Node = (root, tuple of edge occurrences); loopless multigraphs only."""
    inc = incident(edges, r)
    index = {(): 0}
    paths = [()]
    rows, cols = [], []
    frontier = [()]
    for _ in range(depth):
        newf = []
        for p in frontier:
            cur = _walk(r, edges, root, p)[-1]
            for (k, w) in inc[cur]:
                if p and k == p[-1]:
                    continue
                q = p + (k,)
                if q not in index:
                    index[q] = len(paths)
                    paths.append(q)
                    newf.append(q)
                rows.append(index[p]); cols.append(index[q])
        frontier = newf
    n = len(paths)
    M = ss.coo_matrix((np.ones(len(rows)), (rows, cols)), shape=(n, n)).tocsr()
    return (M + M.T).tocsr()


def random_lift(r, edges, n, rng):
    """Adjacency (dense) of a random n-lift: vertices (v,i), one permutation per edge."""
    rows, cols = [], []
    for (u, v) in edges:
        perm = rng.permutation(n)
        if u == v:
            for i in range(n):
                rows.append(u*n+i); cols.append(v*n+perm[i])
        else:
            for i in range(n):
                rows.append(u*n+i); cols.append(v*n+perm[i])
    N = r*n
    M = np.zeros((N, N))
    for a, b in zip(rows, cols):
        if a == b:
            continue
        M[a, b] += 1.0; M[b, a] += 1.0
    return M


def base_adjacency(r, edges):
    A = np.zeros((r, r))
    for (u, v) in edges:
        if u != v:
            A[u, v] += 1; A[v, u] += 1
    return A


def top_eigs(M, k=3, sparse=True):
    n = M.shape[0]
    k = min(k, n-2)
    if sparse:
        t = eigsh(M.tocsc(), k=k, which='LA', return_eigenvectors=False)
        b = eigsh(M.tocsc(), k=k, which='SA', return_eigenvectors=False)
    else:
        ev = np.linalg.eigvalsh(np.asarray(M))
        return ev[-k:][::-1], ev[:k]
    return np.sort(t)[::-1], np.sort(b)


def new_spectrum(A_base, A_lift, n, tol=1e-6):
    """Exact 'new' spectrum: spec(A_lift) with one copy of each base eigenvalue removed.
    The fiber-constant functions form an invariant subspace on which A_lift acts as
    A_base, so spec(A_lift) = spec(A_base) disjoint-union spec(new) with the same
    multiplicities for the old part."""
    eb = sorted(np.linalg.eigvalsh(A_base))
    el = sorted(np.linalg.eigvalsh(A_lift))
    keep = list(el)
    for lam in eb:
        j = int(np.argmin([abs(x - lam) for x in keep]))
        if abs(keep[j] - lam) > tol:
            raise RuntimeError("old eigenvalue not found")
        keep.pop(j)
    return np.array(keep)
