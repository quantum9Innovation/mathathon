"""Exact rational verification of the finite secular identity (Theorem B).

G is d-regular on n vertices, T a Delta-subset of vertices, G' = G plus one new
vertex adjacent exactly to T.  Exact identity (Schur complement of the spike):

    charpoly(A_{G'})(lam) = charpoly(A_G)(lam) * S(lam),
    S(lam) = -lam - 1_T^T (A_G - lam)^{-1} 1_T .

Consequences checked exactly here:
  * the eigenvalues of A_{G'} are exactly the zeros of the polynomial p_G * S;
  * a host eigenvalue lam_i survives in G' iff 1_T is orthogonal to its
    eigenvector (otherwise the pole of S cancels the zero of p_G);
  * the eigenvalues of A_{G'} interlace with those of A_G.
"""
import sympy as sp

lam = sp.symbols('lam')

def analyze(name, A, T):
    A = sp.Matrix(A); n = A.shape[0]
    degs = [sum(A[i, j] for j in range(n)) for i in range(n)]
    B = sp.zeros(n + 1, n + 1)
    for i in range(n):
        for j in range(n): B[i, j] = A[i, j]
    for y in T: B[n, y] = B[y, n] = 1
    pG = sp.Poly(A.charpoly(lam).as_expr(), lam)
    pB = sp.Poly(B.charpoly(lam).as_expr(), lam)
    C = A - lam * sp.eye(n)   # so C^{-1} = (A_G - lam)^{-1}
    q = sp.simplify((sp.ones(1, len(T)) *
                     C.adjugate().extract(T, T) * sp.ones(len(T), 1))[0, 0])
    S = sp.simplify(-lam - q / C.det())
    lhs = sp.simplify(sp.expand(pG.as_expr() * S + pB.as_expr()))  # sympy charpoly = det(lam I - A)
    import numpy as np
    evG = sorted(np.round(np.linalg.eigvalsh(np.array(A.tolist(), dtype=float)), 10))
    evB = sorted(np.round(np.linalg.eigvalsh(np.array(B.tolist(), dtype=float)), 10))
    # survival test for host eigenvalues
    surv = []
    for r in sp.roots(pG.as_expr()).items():
        r0, m = r
        u = (A - r0 * sp.eye(n)).nullspace()
        orth = all(sum(uu[y] for y in T) == 0 for uu in u) if u else True
        surv.append((sp.nsimplify(r0), m, orth))
    print("=" * 92)
    print(name, "| degrees:", degs, "| spike degree:", len(T))
    print("  charpoly(A_G)   =", sp.factor(pG.as_expr()))
    print("  charpoly(A_G')  =", sp.factor(pB.as_expr()))
    print("  S(lam)          =", sp.factor(S))
    print("  p_G * S + p_G'  =", lhs, "   [0 confirms p_G'(lam) = p_G(lam) S(lam) in det(lam I - A) convention]")
    print("  spec(A_G)  =", evG)
    print("  spec(A_G') =", evB)
    print("  host eigenvalue (mult, is 1_T orthogonal to its eigenspace):", surv)

E33 = [(i, 3 + j) for i in range(3) for j in range(3)]
A33 = sp.zeros(6, 6)
for (i, j) in E33: A33[i, j] = A33[j, i] = 1
analyze("K_{3,3} + spike on one side (Delta = d = 3), G' = K_{3,4}", A33, [0, 1, 2])

E = []
for v in range(8):
    for b in (1, 2, 4):
        u = v ^ b
        if v < u: E.append((v, u))
AQ = sp.zeros(8, 8)
for (i, j) in E: AQ[i, j] = AQ[j, i] = 1
analyze("Q3 cube + spike of degree 5", AQ, [0, 1, 2, 3, 4])

# a 4-regular example: K_5 minus a perfect matching (the Clebsch-like 4-regular on 5? use K_5 itself)
A5 = sp.ones(5, 5) - sp.eye(5)
analyze("K_5 (d = 4) + spike of degree 2, i.e. a pendant path start", A5, [0, 1])
