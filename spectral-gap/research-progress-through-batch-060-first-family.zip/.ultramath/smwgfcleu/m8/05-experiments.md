# 5. Computations: what was run, what it shows, what it does not show

Everything is Python 3 with numpy 2.5.3, scipy 1.18.1, sympy 1.14.0, matplotlib. All scripts live in
`scripts/` and are run from that directory (`cd scripts && python3 exp1_exact_structure.py`). Raw
outputs are in `outputs/`. Nothing here runs a formal verifier. The eigenvalue computations are
double-precision LAPACK (`numpy.linalg.eigvalsh`, `scipy.linalg.eigh` with driver `evr`), and
statements labelled "exact" are exact modulo the `1e-8` to `1e-12` tolerances asserted in the scripts.

## The random hypergraph generator, and its honest status

`hyp.config_model_hypergraph(n, d, k, rng)` builds a `d`-regular `k`-uniform hypergraph with
`n d / k` edges. It uses the configuration model on the incidence structure (a uniform random
pairing of `n d` vertex stubs with `n d` edge slots) and then repairs the `O(d(k-1)/2)` expected
duplicate (vertex, edge) incidences by random 2-switches. Repeated vertex *sets* (multi-hyperedges)
are allowed and are counted with multiplicity by the Feng-Li operator.

What this is: a random regular hypergraph with the correct configuration-model local structure.
What this is not: an exactly uniform sample from the simple `(d,k)`-regular hypergraphs. For fixed
`d,k` the number of repaired duplicates is `O(1)` in expectation and the local structure is the
configuration-model one, so asymptotically it should be contiguous with the uniform model. The
numerical results in `exp2` and `exp2b` are therefore evidence about the model computed, and the
asymptotic statements they illustrate are the literature theorems L1 and L5, not consequences of the
numerics.

## exp1. Exact structural checks (`outputs/exp1_exact_structure.txt`)

31 explicit hypergraphs: complete `k`-partite with part sizes 1,2,3 for `k = 3,4,5`, 1 to 4 disjoint
copies, a single `k`-set repeated `d` times for `d = 1,2,7` and `k = 3,4,5`, and random regular
instances with `d < k` and with `d > k`. For each one the script asserts

* `lambda_max = d(k-1)` and `mult(Perron) = number of components`,
* `mult(-d) = n - rank(X)`, with `rank(X)` exact over `Q` (sympy) for small matrices and the maximum
  of three `GF(p)` ranks with `p` near `2^31` for larger ones,
* `lambda_min >= -d`,
* `mult(-d) >= max(0, n-m)`,
* `mult(-d) >= k-1` for the `k`-partite rows.

All 31 rows pass. Examples: complete 4-partite with part size 2 has `spec = {24, 0,0,0,0, -8,-8,-8}`
and `mult(-d) = 3 = k-1`. Random `(2,5)` with `n = 40` has `mult(-2) = 24 = n - m`.

Section B verifies the two square identities of T6 symbolically for 25 pairs `(d,k)`, and section C
verifies the naive-tree deficit formula of T6(3) numerically for 30 pairs.

## exp2 and exp2b. Where `lambda_2` actually sits (`outputs/exp2_random_regular.txt`, `.json`, `outputs/exp2b_random_regular.txt`, `.json`)

34 runs: `(d,k)` in `(2,3),(3,3),(2,4),(3,4),(4,3),(5,3),(6,4),(2,5)`, `n` from 250 to 3000, 3 or 4
trials each, `lambda_2` and `lambda_min` from `scipy.linalg.eigh`.

* In every one of the 34 runs, `lambda_2 > 2 sqrt((k-1)d - 1)`. The minimum margin is `0.3387`,
  attained at `(d,k) = (3,3)`, `n = 250`. This is the numerical falsification of the naive tree
  benchmark (T7). It is consistent with, and predicted by, T7 plus the Feng-Li lower bound.
* In every family the distance `k-2+2t - lambda_2` decreases with `n` except one step, which is the
  behaviour expected if `lambda_2` tends to the true edge from below.
* `lambda_min` approaches the window bottom `k-2-2t` from above in the non-partite random cases, and
  equals `-d` exactly in the `d < k` cases (`(2,3)`, `(2,4)`, `(2,5)`), matching T5(1) and T12.
* `comps = 1` in every run, so the Perron value is simple and the numbers above are `lambda_2` and
  not a repeated top value.

The figure `outputs/fig1_thresholds_and_periodic_gap.png` (left panel) shows the measured `lambda_2`
against the two horizontal references.

Not shown by this: any rate of convergence. A single `n` sequence cannot establish an asymptotic
statement. The observed behaviour is checked against the published theorem, not used to prove it.

## exp3, exp3b. The cyclic interval family (`outputs/exp3_cyclic_interval.txt`, `outputs/exp3b_fejer_and_gcd.txt`)

`exp3` computes the circulant symbol `p(theta)`, its expansion at `0` (`c2 = k^2(k^2-1)/12`,
`c4 = S4/12`), the gap of the `q`-cyclic quotient for `k = 3,4,5,6` and `q = 60,120,240,480`, and
exact characteristic polynomials over `Q` for small `q`. The scaled ratio
`(d(k-1) - lambda_2) q^2 / (pi^2 k^2 (k^2-1)/3)` is `0.9973, 0.9993, 0.9998, 0.99996` for `k = 3`,
and the residual ratio to the predicted `q^-4` term is `0.9987, 0.9997, 0.9999, 0.99998`. Exact
characteristic polynomials: `k=3,q=9` gives `(x-6)(x+3)^2(x^3-9x-9)^2`, `k=4,q=12` gives
`(x-12)(x+1)^2(x+3)^2(x+4)^3(x^2-4x-23)^2`.

`exp3b` verifies the Fejer identity `spec = {|D_k(2 pi m/q)|^2 - k}` to `2e-13` for `k = 2,...,6` and
four values of `q`, and verifies `mult(-k) = gcd(k,q) - 1` with no mismatch over `k = 3,4,5,6` and
every `q` from `2k+1` to `2k+39`. The right panel of the figure shows the `Theta(q^-2)` law.

Not shown by this: anything about non-cyclic periodic hypergraphs, or about periodic hypergraphs in
dimension 2 and higher. The general Bloch band-edge question for lattices is the direction registered
by another member of this swarm (see `06-common-ground.md`).

## exp4. Hashimoto operator of the incidence structure (`outputs/exp4_biregular_nb.txt`)

Six instances with `(d,k) = (2,3),(3,4),(4,3),(3,3),(2,5),(3,5)`. For each:

* `max|mu| = sqrt(ab)` to five decimals and exactly two eigenvalues at modulus `sqrt(ab)`,
* the second largest modulus equals `(ab)^(1/4)` to five decimals,
* the biregular Ihara-Bass determinant identity
  `det(lam I - Hash) = (lam^2-1)^(|E|-|V|) det(lam^2 I - lam A + (D-I))` holds at three complex
  values of `lam` with relative error below `1e-13`,
* `singvals(X) = sqrt(d + lambda_i(A_H))` entrywise to `8.9e-16`, and `lambda_i(A_H) = -d` for all
  `i > min(n,m)`.

The `(d,k) = (3,4)` instance is printed in full: singular values
`3.4641, 2.7762, 2.4795, 1.9183, 1.7460, 1.3015, 0.9034, 0.7419, 0.5967` matched to `16` digits by
`sqrt(d + lambda_i)`, and `lambda_max = 9 = d(k-1)`, `sigma_max = sqrt12 = sqrt(dk)`.

Not shown by this: that the bulk bound `(ab)^(1/4)` holds with high probability. That is the
published theorem of Brito-Dumitriu-Decker Harris in Hashimoto form. The computation confirms the
trivial spectrum and the exact identities only.

## exp6, exp7, exp8. Covers (`outputs/exp6_two_lifts.txt`, `outputs/exp7_lift_obstruction.txt`, `outputs/exp8_signed_gram.txt`)

`exp6` parameterises all `Z_2`-covers of a base by the cycle space of the incidence graph
(`2^rank` covers, `rank = nd - (n+m) + 1`), splits the cover spectrum into the inherited part and the
incidence-signed part `S`, and verifies the splitting identity `spec(A_cover) = spec(A_base) + spec(S)`
for a random signing on every base before trusting the rest. It then reports, for each base, the
smallest top and the largest bottom of `spec(S)` over all covers (exhaustive when `2^rank <= 20000`,
otherwise 300 random samples).

`exp7` separates the two sides of the window and counts how many covers satisfy each.

Key numbers:

* right-sided (`lambda <= k-2+2t`): some cover always exists in every base tested, as Song-Fan-Miao
  Theorem 1.6 requires. 109/128 for `H(6,3)`, 878/1024 for `H(9,3)`, 7441/8192 for a random `(3,3)`
  base, 31/32 for a random `(2,3)` base.
* for `d < k`: the left-sided condition fails for **every** cover tested, and the minimum
  multiplicity of `-d` in the new spectrum equals `n - m` exactly (4 for `(2,3)` with `n = 12` and 32
  covers, 8 for `(2,4)` with 512 covers, 12 for `(2,5)` with 8192 covers). This is T12.
* for `d = k`: the left-sided condition holds for every cover tested (128/128, 1024/1024, 8192/8192,
  1024/1024). This is T10 and T15.
* for `d > k`: mixed. The `(4,3)` base with `n = 12` has 243 of 300 random covers inside the full
  window, and its worst sampled cover reaches bottom `-3.9594`, below the window bottom `-3.8990`.

`exp8` verifies the signed Gram identity `S + d I = Xtilde Xtilde^T` of T15 to `1e-12` for 40 random
signings on each of 11 bases (440 signings), and records `lambda_min(S) >= -d` in all of them.

What the exhaustive counts do and do not establish: when `2^rank <= 20000` the enumeration is over
all covers up to gauge, so a count of 0 is a proof for that base (modulo the model and the tolerance).
When the enumeration is random, a count of 0 is not a proof. Every "0 of N" claim above is
exhaustive except the two explicitly marked random ones (`(3,4)` with `2^rank = 65536` and `(4,4)`
with `2^rank = 131072`), and in those two the exact theorem T12 supplies the proof independently.

## What is not here

* No formal verification of any statement.
* No attempt at the tangle computation of O2, no computation of the Godsil-Mohar edge exponent of O3,
  no random `N`-fold lift for `N > 2`.
* No verification of Bordenave's Theorem 23 against its primary source.
* The `(2,2)` case (`d = k = 2`, unions of cycles) is degenerate throughout (`t = 1`, all gaps zero)
  and is excluded from the asymptotic statements.
