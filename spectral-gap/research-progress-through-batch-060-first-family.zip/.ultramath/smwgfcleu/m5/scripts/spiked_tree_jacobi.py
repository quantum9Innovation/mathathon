"""Truncated radial Jacobi matrix of the spiked d-regular tree T(d,Delta).

The tree T(d,Delta) has one vertex o of degree Delta, every other vertex of
degree d.  Its adjacency operator restricted to radially symmetric functions
is unitarily equivalent to the Jacobi matrix J on l^2(N) with

    (J g)_0 = sqrt(Delta) g_1
    (J g)_1 = sqrt(Delta) g_0 + sqrt(d-1) g_2
    (J g)_n = sqrt(d-1)(g_{n-1} + g_{n+1}),  n >= 2

Claim under test (Theorem A of the dossier):
  spec(A_{T(d,Delta)}) = [-2 sqrt(d-1), 2 sqrt(d-1)]  if Delta <= 2(d-1)
                       = that interval  union  {+/- Delta/sqrt(Delta+1-d)}
                                                       if Delta >  2(d-1).
"""
import numpy as np
from scipy.linalg import eigh_tridiagonal

def jacobi(d, Delta, N):
    n = np.arange(1, N)                      # sub-diagonal index k couples k-1,k
    off = np.full(N - 1, np.sqrt(d - 1.0))
    off[0] = np.sqrt(Delta)                  # (0,1) entry is sqrt(Delta)
    return off

def outliers(d, Delta, N=4000):
    off = jacobi(d, Delta, N)
    w = eigh_tridiagonal(np.zeros(N), off, select='i',
                         select_range=(0, 0), eigvals_only=True)
    w2 = eigh_tridiagonal(np.zeros(N), off, select='i',
                          select_range=(N - 1, N - 1), eigvals_only=True)
    edge = 2 * np.sqrt(d - 1.0)
    return w[0], w2[0], edge

print("Truncated radial Jacobi, N = 4000.  bulk edge e = 2 sqrt(d-1).")
print(f"{'d':>3} {'Delta':>6} {'2(d-1)':>7} {'lam_max':>12} {'lam_min':>12} "
      f"{'pred +':>10} {'pred -':>10} {'edge':>9}")
for d, Delta in [(3,3),(3,4),(3,5),(3,6),(3,12),(4,4),(4,5),(4,6),(4,7),(4,20),
                 (5,8),(5,9),(5,10),(5,40),(6,10),(6,11),(6,12)]:
    lmax, lmin, edge = outliers(d, Delta)
    pred = Delta / np.sqrt(Delta + 1 - d) if Delta > 2*(d-1) else float('nan')
    print(f"{d:3d} {Delta:6d} {2*(d-1):7d} {lmax:12.6f} {lmin:12.6f} "
          f"{pred:10.6f} {-pred:10.6f} {edge:9.6f}")
