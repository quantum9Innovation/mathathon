# Cayley graphs at fixed degree: exact extremal landscapes, block laws, and the
# one-vertex-base case of the X-Ramanujan problem

Research dossier, member m7 of swarm smwgfcleu. Written for a reader who knows
spectral graph theory and wants to referee the claims.

## Outcome in one paragraph

The question studied is the Cayley (vertex-transitive) case of the
$X$-Ramanujan problem for $X = T_d$: for a finite group $G$ and a symmetric
generating set $S$ of size $d$, how small can
$\lambda(\mathrm{Cay}(G,S)) = \max_{2\le i\le n}|\lambda_i|$ be, and what
forces it above $2\sqrt{d-1}$. Four things are established. (1) An exact
Fourier block law, $\mathrm{spec}(A) = \bigcup_\rho
\mathrm{spec}(\sum_S \rho(s))$ with each root repeated $f_\rho$ times, which
makes the quasi-index $\#\{i\ge2: |\lambda_i|>\theta\}$ a sum of irreducible
degrees and makes "$\lambda_2$ versus $\lambda_3$ versus $\lambda_4$" a
representation theoretic question. (2) Two exact structural certificates, a
coset Rayleigh bound and an abelian pigeonhole bound with the sharp exponent
$|G|^{-2/k}$, plus an exact prism computation in which a *non-abelian* group
with abelianization of order two still fails the Ramanujan bound for every
$m > 7$, because of blocks induced from characters of an index two subgroup.
(3) Exhaustive exact landscapes for $S_4$, $A_5$, $S_5$ at $d = 3,4,5,6$, with
closed-form extremal eigenvalues such as $\tfrac{1+\sqrt{17}}{2}$,
$\sqrt7$, $\tfrac{3+\sqrt5}{2}$, $\sqrt{10}$, all confirmed by exact integer
characteristic polynomials, together with the irreducible block that carries
each extremum. (4) A falsification: at degree 3 the failures of the Ramanujan
bound are *not* explained by subgroups (all 240 failures in the simple group
$A_5$ have no coset certificate at all) and are *not* explained by girth
(girth 4 and girth 6 populations split both ways), so the correct obstruction is
the individual irreducible block. The dossier ends with a precise conjecture, a
named missing estimate (a per-block, uniform-in-$\rho$ trace bound), and a
proof that no global moment method can supply it, because the offending
eigenvectors are delocalised character vectors whose contribution to
$\mathrm{tr}(A^{2k})$ is exponentially smaller than the bulk.

## What is claimed at which level of confidence

Following the required labelling:

* **(1) checked literature statements**: listed in `02-literature.md` with URLs,
  versions and verbatim quotes. The key ones are Mohanty-O'Donnell
  arXiv:1904.03500v2 (Definitions 2.10, 2.11, 2.16, Theorem 2.9 on Greenberg's
  theorem, Feng-Li's biregular threshold, the LPS-Margulis-Morgenstern
  existence summary), Hermon-Huang arXiv:2403.12355v1 (gap equals the
  abelianization gap for nilpotent groups), Hermon-Olesker-Taylor (Annals of
  Applied Probability 33, 2023, abelian gap of order $|G|^{-2/k}$), and the
  four local dossiers for Friedman, Bordenave, Friedman-Kohler and
  Brito-Dumitriu-Decker Harris.
* **(2) exact calculations**: the tables of `04-computations.md`, obtained by
  exhaustive enumeration and exact integer characteristic polynomials, with
  scripts and raw outputs in `src/` and `out/`.
* **(3) proofs supplied here**: Propositions 1 to 7 of `03-theory.md` (block
  law, quasi-index as a sum of degrees, bipartite barrier, coset certificate,
  abelian pigeonhole bound, exact prism spectrum and exact Ramanujan set).
  Nothing in this dossier is formally verified in Lean or any other verifier.
* **(4) numerical experiments**: the random sampling of `04-computations.md`
  section 8, run with fixed seeds, reported as finite-size data only.
* **(5) conjectures**: Conjectures T and T' of `05-targets.md`, and the
  "monomial trap" picture in section 5 of the same file.

## The single most useful negative result

At degree 3, for all 2196 connected symmetric generating sets of $S_4$, $A_5$
and $S_5$:

* the coset certificate never exceeds the true $\lambda$ (so it is a valid
  lower bound), and it certifies exactly the bipartite cases,
* the 240 non-Ramanujan sets in the simple group $A_5$ have no coset
  certificate at all, the largest certificate over all 58 subgroups and all 560
  connected sets being $1.947$ against a threshold of $2.828$,
* girth does not decide: in $A_5$ girth 4 splits as 60 Ramanujan and 120 not,
  and girth 6 as 120 Ramanujan and 60 not.

So any proposed structural criterion of the form "large $\lambda$ means the
connection set concentrates on a subgroup" or "large $\lambda$ means short
cycles" is false as stated. The correct criterion is the block spectrum.

## Files

| file | contents |
| --- | --- |
| `01-model.md` | precise model, normalisation, the two regimes, why it matters |
| `02-literature.md` | verified literature with URLs, versions, verbatim quotes, and what is only reported |
| `03-theory.md` | Propositions 1 to 7 with complete proofs |
| `04-computations.md` | exact tables, closed forms, block identifications, certificate analysis, contrast experiments, reproduction instructions |
| `05-targets.md` | Conjecture T and T', the obstruction analysis, the missing estimate, smaller reachable targets, prioritised next steps |
| `06-connections.md` | common ground with the four dossiers and with board directions d1 to d8 |
| `src/*.py` | all code, from group arithmetic to Murnaghan-Nakayama characters to exhaustive enumeration |
| `out/*.txt` | raw outputs for every table in `04-computations.md` |
| `lit/modonn.txt` | extracted text of arXiv:1904.03500v2 used for the verbatim quotations |

## How to check the central claims quickly

```
cd .ultramath/smwgfcleu/m7
python3 dossier/src/algebraic_ids.py     # closed forms and prism table, ~10 s
python3 dossier/src/main_tables.py       # block decomposition, ~70 s
python3 dossier/src/certificates.py      # failures vs certificates, ~5 min
```

The first reproduces the exact factorisations such as
$x^5(x-3)(x-2)^5(x+1)^4(x+2)^3(x^2+x-4)^3$ for the cubic minimiser on $S_4$,
the second reproduces the multiset-law check (agreement to $10^{-15}$) and the
block that carries each extremum, the third reproduces the certificate table.

## Honest limitations

* Nothing here is formally verified. The proofs in `03-theory.md` are
  hand-checked and the computations are exact integer or high precision
  floating point as labelled.
* The literature statement that random fixed-degree Cayley graphs of $S_N$ are
  not even known to have a gap is taken from an aggregator page
  (`02-literature.md`, section 5) and its primary source was not identified in
  this run. It should be re-verified before being used as a citation.
* The claim that the Lubotzky-Phillips-Sarnak graphs are Cayley graphs is
  standard but was not verified against the 1988 paper here, and nothing in
  the argument depends on it.
* The asymptotic question is open. No amount of exact data at $|G| \le 720$ can
  settle it, and this dossier does not pretend otherwise.
