# Proofs (revision 2, after first review)

Standing notation. $D$ is a finite digraph, loops and multiple arcs allowed, $n=|V|$, every vertex
has exactly $k$ outgoing and $k$ incoming arcs, $A=A_D$, $k\ge2$ unless stated. Eigenvalues are
complex, ordered by decreasing modulus. The period $m$ is the gcd of the lengths of directed cycles,
equivalently the number of classes in the cyclic block decomposition, equivalently the number of
eigenvalues of modulus $k$ when $A$ is irreducible (Proposition 2). $L_0^2$ is the orthogonal
complement of the span of the trivial eigenfunctions and $\rho(D)=\rho(A|_{L_0^2})$. "Connected"
means strongly connected. All "$o(1)$" statements are as $n\to\infty$ with $k$, $m$, $r$ fixed.
External inputs are marked **(literature)** and listed in `literature.md`.

---

## Proposition 1 (double cover), revised statement

**Statement.** Let $A\in\mathbb C^{n\times n}$ have singular values $\sigma_1\ge\dots\ge\sigma_n\ge0$
and let $r=\operatorname{rank}A$, so $\sigma_i>0$ for $i\le r$ and $\sigma_i=0$ for $i>r$. Put
$\widetilde A=\begin{pmatrix}0&A\\A^{\mathsf T}&0\end{pmatrix}$.

(i) If $A$ is $0/1$ with all row sums and all column sums equal to $k$, then the bipartite graph
$\widetilde D$ with adjacency $\widetilde A$ is $(k,k)$-biregular and simple.

(ii) (Multiset, stated over the nonzero singular values only)
$$\mathrm{Spec}(\widetilde A)=\{\sigma_1,\dots,\sigma_r,-\sigma_1,\dots,-\sigma_r\}\cup\{0\}^{2n-2r},$$
where the $\sigma_i$ are counted with multiplicity. The bracket is a multiset with $2r$ elements,
so the total is $2n$.

(iii) Consequently, with $\sigma_2$ the second largest singular value counted with multiplicity
($\sigma_2=0$ if $r\le1$), the second largest element of $\mathrm{Spec}(\widetilde A)$ in the usual
decreasing order equals $\sigma_2$. The same holds for the second largest element of the absolute
spectrum.

(iv) If $D$ is strongly connected then $\widetilde D$ is connected.

**Proof.** (ii) By block multiplication
$\widetilde A^2=\begin{pmatrix}AA^{\mathsf T}&0\\0&A^{\mathsf T}A\end{pmatrix}$, and for any matrix
the nonzero spectra of $AA^{\mathsf T}$ and $A^{\mathsf T}A$ coincide and equal the squares of the
nonzero singular values. Since $\widetilde A$ is symmetric, it is diagonalizable, so the multiset of
its eigenvalues is determined by $\widetilde A^2$ together with the sign symmetry
$S\widetilde A S=-\widetilde A$ for $S=\operatorname{diag}(I_n,-I_n)$, which forces the eigenvalues
to be symmetric about $0$. Counting: $2r$ nonzero values and $2n-2r$ zeros. (iii) The eigenvalue
multiset of $\widetilde A$ is symmetric about $0$, so its largest element is $\sigma_1$ and its
second largest element is $\sigma_2$ (if $\sigma_1=\sigma_2$ the two top elements both equal
$\sigma_1=\sigma_2$, which is consistent). (i) and (iv) are as before: row and column sums $k$ give
the degrees, and a path in the underlying undirected graph of $D$ lifts to a path in $\widetilde D$.
$\square$

**Correction note (first review, point 3).** The earlier display $\{\pm\sigma_i(A)\}\cup\{0\}^{2n-2\operatorname{rank}A}$
double counted the zero singular values, since the $\pm$ sign runs only over the nonzero ones. Also,
the earlier sentence "$\sigma_2(A)=\lambda_2(G)$ for symmetric digraphs" was wrong for the ordinary
signed ordering: for $K_4$ one has $\sigma_2=1$ while $\lambda_2=-1$ in decreasing order. The correct
identity is $\sigma_2(A)=\max_{j\ge2}|\lambda_j(A)|$ for symmetric $A$, that is, the second largest
element of the absolute spectrum.

---

## Proposition 2 (peripheral spectrum of an irreducible regular digraph)

**Statement.** Let $D$ be strongly connected, $k$-regular, of period $m$. Then the eigenvalues of
$A$ of modulus $k$ are exactly $k\zeta_m^j$, $j=0,\dots,m-1$, each simple.

**Proof.** Strong connectivity makes $A$ irreducible, so Perron-Frobenius applies: the peripheral
spectrum is a cyclic group of order equal to the index of imprimitivity, which equals the gcd of the
cycle lengths, and the cyclic class decomposition gives the eigenvectors
$f_j=\sum_{i<m}\zeta_m^{ij}\mathbf 1_{V_i}$ with $Af_j=k\zeta_m^jf_j$. $\square$

**Corollary (index of the first informative gap).** With the trivial eigenvalues ordered first,
$\lambda_1,\dots,\lambda_m$ have modulus $k$, hence $k-\lambda_2=0$ for $m\ge2$ and
$k-|\lambda_{m+1}|=\rho(D)$. For $m=2$ the first informative gap is $k-\lambda_3$, for $m=3$ it is
$k-\lambda_4$.

**Warning (this is where revision 1 went wrong).** The count $m$ in this proposition is the period of
the digraph at hand. It is *not* stable under the cyclic-cover construction, see Proposition 6.

---

## Theorem A (universal singular value threshold)

**Statement.** Let $k\ge2$ and let $(D_n)$ be strongly connected $k$-regular digraphs with
$n\to\infty$. Then $\liminf\sigma_2(A_{D_n})\ge2\sqrt{k-1}$.

**External input (literature).** Biregular Alon-Boppana: for fixed $d_1,d_2\ge2$ and every
$\varepsilon>0$ there is $N$ such that every connected $(d_1,d_2)$-biregular graph on at least $N$
vertices has its second largest eigenvalue in absolute value at least
$\sqrt{d_1-1}+\sqrt{d_2-1}-\varepsilon$. Equation (2) of Brito-Dumitriu-Decker Harris, attributed
there to Feng 1996 and Li 1996.

**Proof.** By Proposition 1 the double cover $\widetilde D_n$ is connected $(k,k)$-biregular on $2n$
vertices and the second largest element of its absolute spectrum equals $\sigma_2(A_{D_n})$. Apply
the external input with $d_1=d_2=k$. $\square$

**Sharpness, corrected.** Let $G$ be a $k$-regular graph with
$\max_{j\ge2}|\lambda_j(G)|\to2\sqrt{k-1}$ (random $k$-regular graphs by Friedman, in the two-sided
form) and let $D$ be its bidirected digraph. Then $A=A^{\mathsf T}$, so by Proposition 1(iii)
$\sigma_2(A)=\max_{j\ge2}|\lambda_j(G)|\to2\sqrt{k-1}$. Ordinary $\lambda_2(G)$ in decreasing order
would not do here: $K_4$ has $\lambda_2=-1$ and $\sigma_2=1$. $\square$

---

## Theorem B (normal, period one: the two-sided constant, sharply)

**Statement.** Let $k\ge2$ and let $(D_n)$ be strongly connected, aperiodic, normal $k$-regular
digraphs with $n\to\infty$. Then
$$\rho(D_n)=\max_{j\ge2}|\lambda_j(A_{D_n})|\ \ge\ 2\sqrt{k-1}-o(1).$$
The constant is sharp.

**Proof.** Step 1: $A$ normal implies unitarily diagonalizable, so the multiset of singular values
equals the multiset of eigenvalue moduli, hence $\sigma_2(A)=\max_{j\ge2}|\lambda_j(A)|$ (the top
singular value is $\sigma_1=k=|\lambda_1|$ since row sums are $k$). Step 2: by strong connectivity
and aperiodicity $k$ is a simple eigenvalue with eigenspace spanned by $\mathbf 1$, so
$\rho(D_n)=\sigma_2(A)$ by Proposition 2. Step 3: Theorem A. Sharpness: bidirected digraphs of
$k$-regular graphs with $\max_{j\ge2}|\lambda_j|\to2\sqrt{k-1}$, which are normal, aperiodic and
strongly connected, and for which $\rho(D)=\max_{j\ge2}|\lambda_j|$. $\square$

**Corollary.** If in addition $\rho(D_n)\le\sqrt k$ (Ramanujan in the sense of the digraph
literature), then $2\sqrt{k-1}-o(1)\le\sqrt k$, which is impossible for $k\ge2$ because
$2\sqrt{k-1}>\sqrt k$. So strongly connected aperiodic normal Ramanujan digraphs have bounded size.
**(3)**

---

## Proposition 6 (cyclic covers: the correct period bookkeeping)

**Statement.** Let $D_0$ be a strongly connected $k$-regular digraph with period $m_0$, adjacency
$A_0$, on $N$ vertices. Let $P_m$ be the $m\times m$ cyclic permutation matrix and
$A=P_m\otimes A_0$, that is, the digraph on $V(D_0)\times\mathbb Z_m$ with arcs
$(v,j)\to(w,j+1)$ for each arc $v\to w$ of $D_0$. Then

(i) $\mathrm{Spec}(A)=\{\zeta\mu:\zeta^m=1,\ \mu\in\mathrm{Spec}(A_0)\}$ with multiplicity, and $A$ is
unitarily equivalent to the direct sum of $m$ copies of $A_0$,

(ii) the eigenvalues of $A$ of modulus $k$ are $k$ times the $\operatorname{lcm}(m,m_0)$-th roots of
unity, each with multiplicity $\gcd(m,m_0)$,

(iii) $A$ is strongly connected if and only if $\gcd(m,m_0)=1$,

(iv) consequently, if $D_0$ is aperiodic and strongly connected then $A$ is strongly connected with
period exactly $m$ for every $m\ge1$, and $\rho$ is unchanged.

**Proof.** (i) The Fourier matrix $F$ diagonalizes $P_m$, so $(F\otimes I)A(F\otimes I)^{-1}$ is the
direct sum of $m$ copies of $A_0$, giving the spectrum as a multiset. (ii) By Proposition 2 the
eigenvalues of $A_0$ of modulus $k$ are $k\zeta_{m_0}^l$, $l<m_0$, and by (i) the eigenvalues of $A$
of modulus $k$ are $\zeta_m^j\zeta_{m_0}^l k$. The set $\{\zeta_m^j\zeta_{m_0}^l\}$ is the group of
$\operatorname{lcm}(m,m_0)$-th roots of unity, each occurring $\gcd(m,m_0)$ times. (iii) A walk of
length $\ell$ in $D_0$ from $v$ to $w$ exists only for $\ell$ in one residue class $r(v,w)$ modulo
$m_0$, and it lifts to a walk in $A$ from $(v,j)$ to $(w,j+\ell \bmod m)$. So $(v,j)$ reaches
$(w,j')$ if and only if there is $\ell$ with $\ell\equiv j'-j\pmod m$ and $\ell\equiv r(v,w)\pmod{m_0}$
and $\ell$ large enough. By the Chinese remainder theorem this is solvable for every $j,j'$ if and
only if $\gcd(m,m_0)=1$. (iv) is (iii) with $m_0=1$, and the spectrum is unchanged by (i). $\square$

**Counterexample to revision 1 (this is review point 1, reproduced).** Take $D_0=DL(K_{3,3})$, which
is $2$-regular with period $m_0=2$, and $m=3$. Proposition 6(ii) predicts
$\operatorname{lcm}(2,3)=6$ eigenvalues of modulus $k=2$, and the computation in
`experiments/period_check.py` finds $6$. Revision 1 asserted period $3$, which was false. The
hypothesis that makes the construction usable is $m_0=1$, that is, an aperiodic base.

---

## Theorem C (constant exactly sqrt(k) for r at least 2, all periods)

**Statement.** Fix $k\ge2$, $m\ge1$, $r\ge2$.

(i) For every $\varepsilon>0$ there is no infinite family of strongly connected $r$-normal
$k$-regular $m$-periodic digraphs with $\rho\le\sqrt k-\varepsilon$.

(ii) There is an infinite family of strongly connected $2$-normal $k$-regular $m$-periodic digraphs
with $\limsup\rho\le\sqrt k$.

**External inputs (literature).** (a) Parzanchevski Theorem 4.3: for $k\ge2$, $m\ge1$ and
$\varepsilon>0$ there is no infinite almost-normal family of $k$-regular $m$-periodic digraphs with
$\rho\le\sqrt k-\varepsilon$. (b) His equations (3.1) and (3.2): for a $(k+1)$-regular graph $G$ the
line digraph $DL(G)$ is $k$-regular with
$\mathrm{Spec}(DL(G))=\{(\lambda\pm\sqrt{\lambda^2-4k})/2\}\cup\{\pm1\}^{|E|-|V|}$, and every
nontrivial eigenvalue of a Ramanujan $G$ maps to a value of modulus exactly $\sqrt k$. (c) Line
digraphs are $2$-normal (Lubetzky-Peres, quoted in the same source). (d) Friedman: random
$(k+1)$-regular graphs satisfy $\max_{j\ge2}|\lambda_j|\le2\sqrt k+o(1)$ and are non-bipartite and
connected with probability tending to one.

**Proof of (i).** Immediate from (a). $\square$

**Proof of (ii).** Let $G_n$ be random $(k+1)$-regular graphs on $n$ vertices. By (d) they are
aperiodic and connected, and their nontrivial eigenvalue moduli are at most $2\sqrt k+o(1)$. By (b),
each nontrivial $\lambda$ of $G_n$ maps to roots of $\mu^2-\lambda\mu+k=0$. If $|\lambda|\le2\sqrt k$
the two roots are complex conjugates with product $k$, so both have modulus exactly $\sqrt k$. If
$|\lambda|>2\sqrt k$ the larger root has modulus
$\le(|\lambda|+\sqrt{\lambda^2-4k})/2\le k$ with equality only at $|\lambda|=k+1$, and for
$|\lambda|\le k+1$ the larger root is at most $k$, with the value $k$ occurring only for
$\lambda=k+1$ (the trivial Perron eigenvalue). Since $\max_{j\ge2}|\lambda_j(G_n)|\le2\sqrt k+o(1)$,
the nontrivial eigenvalues of $DL(G_n)$ all have modulus $\sqrt k+o(1)$, and the trivial eigenvalue
$k$ is simple because $G_n$ is non-bipartite (a bipartite $G$ would contribute $-k$). Hence $DL(G_n)$
is strongly connected, aperiodic, $2$-normal, $k$-regular, and $\rho(DL(G_n))=\sqrt k+o(1)$.

Now apply Proposition 6 with $m_0=1$: $A=P_m\otimes A_{DL(G_n)}$ is strongly connected, has period
exactly $m$, is $2$-normal (Proposition 6(i) exhibits it as unitarily equivalent to a direct sum of
copies of a $2$-normal matrix), is $k$-regular, has $n\cdot 2|E(G_n)|\cdot m$ vertices, and has the
same $\rho$ as $DL(G_n)$. Since $n\to\infty$ this gives the required family. $\square$

**What changed from revision 1, and what is new.** Revision 1 asserted period exactly $m$ for
$P_m\otimes A_{D_0}$ with $D_0$ a line digraph, which fails when $D_0$ is bipartite (Proposition 6).
The repair uses an aperiodic base, which is available for every $k$ because random $(k+1)$-regular
graphs are aperiodic and almost Ramanujan. Note also that the source's Section 5.3 already records
that line digraphs of Ramanujan graphs are Ramanujan digraphs, so the line-digraph mechanism is not
new. What is new here is (alpha) the sharp constant $2\sqrt{k-1}$ on the normal locus (Theorem B),
(beta) the resulting statement that the sharp constant takes exactly two values $2\sqrt{k-1}$ and
$\sqrt k$ with the jump between $r=1$ and $r=2$, uniformly in the period, and (gamma) the
identification of the period bookkeeping (Proposition 6) that makes the period-indexed statement
well posed.

---

## Proposition 7 (normal families, every period: the upper end of the table)

**Statement.** For every $k\ge2$ and every $m\ge1$ there is an infinite family of strongly connected
normal $k$-regular $m$-periodic digraphs with $\rho\to2\sqrt{k-1}$.

**Proof.** Take a random $k$-regular graph $G_n$, which is aperiodic and connected with probability
tending to one and has $\max_{j\ge2}|\lambda_j|\to2\sqrt{k-1}$ (Alon-Boppana lower bound plus
Friedman). Let $D_0$ be its bidirected digraph, which is symmetric, hence normal, aperiodic,
strongly connected, with $\rho(D_0)=\max_{j\ge2}|\lambda_j(G_n)$. Apply Proposition 6 with $m_0=1$.
$\square$

**Lower bound for $m\ge2$ (unchanged).** Apply Theorem B to the $m$ aperiodic normal $k^m$-regular
blocks of $A^m$, whose spectral radius is $\rho(D)^m$, obtaining
$\rho(D)\ge(2\sqrt{k^m-1}-o(1))^{1/m}\approx\sqrt{2k}$, strictly weaker than $2\sqrt{k-1}$ for every
$k\ge2$. So $(2\sqrt{k^m-1})^{1/m}\le c(1,m)\le2\sqrt{k-1}$ and the value is open for $m\ge2$.

---

## Proposition 8 (Ihara-Bass dictionary, real form)

**Statement.** Let $k\ge1$ and $\lambda\in\mathbb R$. Let $\mu$ be a root of $\mu^2-\lambda\mu+k=0$.
Then
$$|\lambda|\le2\sqrt k\iff|\mu|=\sqrt k,$$
and explicitly $\lambda=2\sqrt k\cos\theta$ gives $\mu=\sqrt k\,e^{\pm i\theta}$.

**Proof.** For real $\lambda$ with $|\lambda|\le2\sqrt k$, the discriminant $\lambda^2-4k\le0$ and the
roots are complex conjugates with product $k$, hence both have modulus $\sqrt k$. Conversely if
$|\mu|=\sqrt k$ then $k/\mu=\overline\mu$, so $\lambda=\mu+k/\mu=2\operatorname{Re}\mu$ is real and
lies in $[-2\sqrt k,2\sqrt k]$. $\square$

**Correction note (review point 2).** Revision 1 stated the equivalence for complex $\lambda$, which
is false. Counterexample: $k=1$, $\lambda=2i$, roots $\mu=i(1\pm\sqrt2)$ with moduli $\sqrt2+1$ and
$\sqrt2-1$, neither equal to $1$. Over $\mathbb C$ the correct statement is one-directional at best,
and the real form above is what the spectral application uses (adjacency eigenvalues of a
$(k+1)$-regular graph are real).

---

## Proposition 9 (closed walks on the k-regular tree, corrected)

**Statement.** Let $T$ be the infinite $k$-regular tree, $k\ge2$, rooted at $o$, and let
$m_{2t}$ be the number of closed walks of length $2t$ from $o$. Then $m_0=1$,
$m_2=k$, $m_4=2k^2-k$, and in general $m_{2t}$ is the $t$-th coefficient of the generating function
$R(x)=\sum_t m_{2t}x^t$ determined by
$$R(x)=\frac{1}{1-kxF(x)},\qquad F(x)=\frac{1-\sqrt{1-4(k-1)x}}{2(k-1)x},$$
equivalently $G(z)=\sum_t m_t z^{-t-1}=1/(z-kH(z))$ with $H=1/(z-(k-1)H)$. Asymptotically
$$m_{2t}=\Theta_k(t^{-3/2})\bigl(2\sqrt{k-1}\bigr)^{2t}\quad(k\ge3),\qquad
m_{2t}=\binom{2t}{t}=\Theta(t^{-1/2})4^t\quad(k=2).$$

**Proof of the exact values.** $m_2=k$ (step out and back). For $m_4$: a closed $4$-walk from $o$
either returns to $o$ at time $2$, giving $k\cdot k$ walks, or is at distance $2$ at time $2$, giving
$k(k-1)$ walks, so $m_4=k^2+k(k-1)=2k^2-k$. The generating function comes from the standard
first-return decomposition: $R=1/(1-kxF)$ where $k x F$ is the generating function of first-return
excursions, and $F$ satisfies $F=1+(k-1)xF^2$. The asymptotic follows from the square-root branch
point of $F$ at $x=1/(4(k-1))$, and the branch point survives in $R$ unless the prefactor vanishes,
which happens exactly at $k=2$, where $R(x)=1/\sqrt{1-4x}$ and $m_{2t}=\binom{2t}{t}$. $\square$

**Correction note (review point 4).** Revision 1 asserted $m_{2t}=(k-1)^t\mathrm{Cat}_t$, which gives
$m_2=k-1$ and fails already at $t=1$, $k=2$ (the true value is $2$). The Catalan expression counts
non-backtracking excursions in a related normalization, not closed walks. The corresponding
statement for the $(k,k)$-biregular tree is the same computation, since its spectral measure is the
Kesten-McKay measure of the $k$-regular tree up to the bipartite doubling, and it has the same
edge exponent.

---

## Proposition 10 (kappa, attained extremes)

**Statement.** Let $D$ be a strongly connected $k$-regular digraph with $\rho(D)>0$ and
$\kappa(D)=\sigma_2(A_D)/\rho(D)$.

(i) If $D$ is normal and aperiodic then $\kappa(D)=1$.
(ii) For $D=DL(G)$ with $G$ a $(k+1)$-regular Ramanujan graph, $\kappa(D)=\sqrt k$.
(iii) For $D=DB(k,s)$ (De Bruijn), $\rho(D)=0$ and $\sigma_2(D)=k$.

**Proof.** (i) is Step 1 of Theorem B. (ii) $\rho=\sqrt k$ by Theorem C's computation, and $\sigma_2=k$
because the singular value $k$ repeats $|V_G|$ times (literature, Parzanchevski Section 3.5).
(iii) is literature for $\rho$ and verified numerically for $\sigma_2$ in `raw/exact_examples.json`.
$\square$

---

## What is *not* proved here

1. The sharp constant for normal families of period $m\ge2$ (open cells).
2. Any quantitative finite-$n$ version of Theorem A or B (Target T1 in the main dossier).
3. The asymptotic $\sigma_2\to2\sqrt{k-1}$ for random digraphs (numerical only here).
4. Any statement about trivial-spectrum multiplicities of hypergraph non-backtracking operators
   beyond the three-sample negative experiment of the main dossier.
