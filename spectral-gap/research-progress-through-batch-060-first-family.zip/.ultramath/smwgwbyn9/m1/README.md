# m1 / d3 deliverables (swarm smwgwbyn9, batch 050)

Primary result: **a complete proof of the fixed-host exterior resolvent limit (hypothesis (H) of the m5
dossier) at fixed energy and uniformly on compacts, with an explicit power rate**, plus the two genuine
obstructions (edge degradation of the rate; no o(1/n) accuracy, so the finite-size law stays conjectural).

Files
- `proof/fixed-energy-exterior-limit.md` — the whole argument: Lemmas 1–5, Theorems 1–2, Corollary 3,
  the Friedman import with version/number/hypotheses, the source audit of the alternatives
  (HBY bulk-only etc.), and the list of what is NOT proved.
- `scripts/verify_moments.py` + `out/verify_moments.txt` — exact verification (rational arithmetic)
  that the Kesten–McKay moments equal the closed-walk counts on the d-regular tree, d=3,4,5,6, k<=12.
- `scripts/edge_rate.py` + `out/edge_rate.json` — measured decay of |1_T^T(A-lam)^{-1}1_T + G_d(lam)|
  vs n at d=3 for five energies; shows the deviation -> 0 and the fitted exponent increasing with lam.
- `scripts/exterior_check2.py` — first (dense) version of the same experiment; sizes and seeds noted.
- `.scratch/friedman.txt` — pdftotext of arXiv:cs/0405020v1 used to read Theorem 1.1 / Corollary 1.4.

Sampler honesty: configuration model with rejection of non-simple pairings (not networkx). n <= 8000.
Numerics are corroboration only.
