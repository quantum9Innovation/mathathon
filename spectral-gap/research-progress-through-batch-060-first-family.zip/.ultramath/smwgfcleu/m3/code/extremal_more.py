import subprocess, json
import numpy as np
import networkx as nx

def decode_g6(s):
    data=bytes(s.strip(),'ascii'); n=data[0]-63; bits=[]
    for ch in data[1:]:
        b=ch-63
        for k in range(5,-1,-1): bits.append((b>>k)&1)
    A=np.zeros((n,n),dtype=np.int8); idx=0
    for j in range(1,n):
        for i in range(j):
            if bits[idx]: A[i,j]=A[j,i]=1
            idx+=1
    return A

def specs(A,tol=1e-8):
    ev=np.linalg.eigvalsh(A.astype(float)); out=[]
    for x in ev:
        if out and abs(x-out[-1][0])<tol: out[-1][1]+=1
        else: out.append([round(float(x),8),1])
    return out

def record(d,n):
    out=subprocess.run(["nauty-geng","-c","-q","-d"+str(d),"-D"+str(d),str(n)],capture_output=True,text=True)
    lines=[l for l in out.stdout.split("\n") if l.strip()]
    best=(-1,0,None,None); count=0
    for s in lines:
        A=decode_g6(s); count+=1
        ev=np.linalg.eigvalsh(A.astype(float)); n_=len(ev)
        top=ev[-1]; pos=ev[n_-int(np.sum(ev>top-1e-8))-1] if np.sum(ev>top-1e-8)<n_ else None
        if pos is None: continue
        mult=int(np.sum(np.abs(ev-pos)<1e-8))
        if mult>best[1]: best=(pos,mult,s,count)
    lam,mult,s,_=best
    A=decode_g6(s); G=nx.from_numpy_array(A)
    vt=nx.algorithms.isomorphism.GraphMatcher(G,G).is_isomorphic()
    return dict(d=d,n=n,count=count,max_mult=mult,lam2=round(float(lam),8),ratio=round(mult/n,4),
                spectrum=specs(A),g6=s)

res=[]
for (d,ns) in [(3,[12,16,18]),(4,[6,8,9,10,11,12,13,14]),(5,[6,8,10,12])]:
    for n in ns:
        r=record(d,n); res.append(r); print(r,flush=True)
json.dump(res,open("out/extremal_more.json","w"),indent=1)
