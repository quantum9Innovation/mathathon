"""
checks_extra.py -- produces outputs/checks_extra.txt

(a) exactness of the old/new decomposition: spec(A_G) = spec(A_B) disjoint-union new
(b) certified lower bounds for rho(A_T) of two spherically homogeneous trees,
    one of which has its top eigenvalue strictly outside the radial Floquet set
"""
import numpy as np
from cover_tools import random_lift, new_spectrum, base_adjacency
from floquet_bands import build_tree_sparse, floquet_margin


def main():
    import os
    os.makedirs("outputs", exist_ok=True)
    out = open("outputs/checks_extra.txt", "w")
    out.write("CHECK A: old/new decomposition is exact (spec A_G = spec A_B disjoint-union new)\n")
    K4 = [(i, j) for i in range(4) for j in range(i+1, 4)]
    e32 = [(u, 4+v) for (u, v) in [(i, e) for e, (i, j) in enumerate(K4)] +
                             [(j, e) for e, (i, j) in enumerate(K4)]]
    rng = np.random.default_rng(3)
    A = base_adjacency(10, e32)
    for n in (4, 7):
        G = random_lift(10, e32, n, rng)
        new = new_spectrum(A, G, n)
        tot = np.sort(np.concatenate([np.linalg.eigvalsh(A), new]))
        dev = np.max(np.abs(np.sort(np.linalg.eigvalsh(G)) - tot))
        out.write(f"  n={n}: #{len(new)} new (expected {10*(n-1)}); max abs deviation = {dev:.2e}\n")
    out.write("\nCHECK B: radial Floquet edge vs certified lower bounds for rho(A_T)\n")
    for (n0, tail, label, radial) in [
            (3, [1, 2], "(3,2)-biregular: root degree 3, children counts 1,2", np.sqrt(2)+1),
            (3, [2, 1], "spherically homogeneous: root 3, children counts 2,1", np.sqrt(2)+1)]:
        out.write(f"  {label}, radial Floquet edge = {radial:.6f}\n")
        for D in (6, 9, 12, 15):
            M, n = build_tree_sparse(n0, tail, D)
            ev = np.linalg.eigvalsh(M.toarray())
            out.write(f"    depth={D} verts={n} top={ev[-1]:.10f}  "
                      f"Floquet margin at top={floquet_margin(tail, ev[-1]):.3e}\n")
    out.close()
    print(open("outputs/checks_extra.txt").read())


if __name__ == "__main__":
    main()
