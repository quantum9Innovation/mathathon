# Centering, cancellation and the cubic transition

The [illustrated reading guide](manuscript-round-01/output/pdf/reading-guide.pdf) explains the direct proof and the later extension in five pages. The [manuscript](manuscript-round-01/output/pdf/centered-permutation-products.pdf) includes complete proofs, source qualifications and a graph-application map. This text preserves the earlier entry point and adds the wider window below.

A uniform permutation matrix has exactly one entry equal to one in each row and column. Its entries are dependent. Centering an entry means subtracting its mean 1/N. The useful cancellation concerns the expectation of a product of these centered entries.

## A two-entry example

For two distinct diagonal cells,

$$
\mathbb E[(M_{11}-1/N)(M_{22}-1/N)]
=\frac1{N(N-1)}-\frac1{N^2}
=\frac1{N^2(N-1)}.
$$

For two different cells in the same row, the product of their uncentered indicators is always zero, and the centered expectation is instead -1/N^2. The row and column pattern matters.

Taking absolute values before using cancellation would lose the much smaller first quantity. The [direct proof](audit-2026-11-14/permutation-proof-v2.md) therefore keeps consistent centered singletons together. It conditions only on compatible prescribed matches, uses the remaining row-sum identity to obtain a positive recurrence, and expands the other factors afterward. Inconsistent singletons and repeated cells have explicit separate costs. This is the bookkeeping that makes the general bound valid.

## Why k cubed divided by N matters

For the centered product of k distinct diagonal entries, write a_k(N) for the expectation. Its known leading terms are

$$
L_{2m}=(2m-1)!!N^{-3m},\qquad
L_{2m+1}=\frac{4m}{3}(2m+1)!!N^{-3m-2}.
$$

Set R_k=a_k/L_k for k>=2. The exact positive recurrence allows errors to accumulate without cancellations hiding them. The [threshold proof](audit-2026-11-14/sharp-scaling-v2.md) traps this ratio between 1+2k^3/(27N) and exp(3k^3/N), using the stated parameter ranges. Thus k of order N^(1/3) is the transition scale.

One checkable example is

$$
a_4(N)=\frac{3(N+6)}{N^4(N-1)(N-2)(N-3)},
\qquad
R_4(N)=\frac{N^2(N+6)}{(N-1)(N-2)(N-3)}.
$$

The ratio equals 1+12/N+O(N^(-2)). This fixed-order example illustrates the correction. The general cubic threshold needs the uniform argument, not a fixed-k expansion.

## What happens at the transition

The even and odd normalized recurrences form a coupled system. A smooth comparison gives

$$
E'(x)=\frac{16x^2}{3N}O(x),\qquad
O'(x)=\frac3{2x}(E(x)-O(x)).
$$

The apparent singularity at zero is removable. The comparison functions are a hyperbolic cosine and a normalized hyperbolic sine. A residual estimate proves that the discrete recurrence stays within C_T M^2/N of them when M^3/N<=T.

Consequently, if k^3/N tends to 9/4, the even ratio tends to cosh(1), approximately 1.543, and the odd ratio tends to sinh(1), approximately 1.175. Both differ from one, and they differ from each other. At a vanishing critical parameter both return to one. This explains the transition and its parity dependence.

The [critical-scale proof](audit-2026-11-14/critical-scale-v1.md) and [independent review](cross-review-2026-11-14/critical-scale-by-algebra.md) justify the comparison uniformly on bounded critical parameters. The later extension goes further.

## Beyond the first transition

After clearing denominators, the diagonal moment has a positive weighted partition formula. Pairs give the leading coefficient. Extra triples sum to the hyperbolic functions, with an even or odd parity restriction. Blocks of four and pair depletion become significant at the next scale.

The [new proof](manuscript-round-01/extensions/hyperbolic-window-v1.md) and its [independent review](manuscript-round-01/reviews/extension-review-v1.md) establish relative hyperbolic accuracy throughout k=o(sqrt N). At k^2/N tending to d>0, the missing multiplicative factor is exp(d/4). The corrected approximation is uniformly relatively accurate for bounded k/sqrt N. It does not claim a result for unbounded k/sqrt N.

The [claim ledger](CLAIM_LEDGER.md) separates these results from the larger random-graph argument and the imported finite-defect work. The [priority audit](manuscript-round-01/priority/PRIORITY_AUDIT_V1.md) credits the recurrence and classical generating function and records the limits of the novelty search.
