"""Identify the extremal eigenvalues as exact algebraic numbers, and the dihedral family."""
import sys
sys.path.insert(0, 'dossier/src')
import numpy as np, sympy as sp
from cayley import *

import builtins
def pp(*a, **k):
    k.setdefault('flush', True)
    builtins.print(*a, **k)


def identify(G, S, target=None):
    A = G.adjacency(S).astype(int)
    x = sp.Symbol('x')
    cp = sp.Matrix(A.tolist()).charpoly(x)
    facs = sp.factor_list(cp)[1]
    out = []
    for f, e in facs:
        deg = sp.degree(f, x)
        if deg == 1:
            r = sp.solve(f, x)[0]
            out.append((str(f), e, [sp.nsimplify(r)]))
        elif deg <= 5:
            roots = sp.nroots(f, n=30, maxsteps=200)
            out.append((str(f), e, [complex(r) for r in roots]))
        else:
            out.append((str(f), e, None))
    return out, cp


def dihedral_exact():
    pp("### exact spectrum of the prism Cay(D_m, {r, r^-1, t})")
    for m in [4, 5, 6, 7, 8, 9, 10, 11, 12, 13]:
        G = dihedral_group(m)
        rot = G.pos[tuple((i + 1) % m for i in range(m)) + tuple(m + (i + 1) % m for i in range(m))]
        ref = G.pos[tuple((m - i) % m for i in range(m)) + tuple(m + (m - i) % m for i in range(m))]
        S = tuple(sorted({rot, int(G.inv[rot]), ref}))
        lam = G.lambda_two_sided(S)
        pred = max(1 + 2 * np.cos(2 * np.pi / m) if m > 1 else 0,
                   abs(-1 + 2 * np.cos(2 * np.pi * (m // 2) / m)) if m % 2 == 0 else 1 + 2 * np.cos(np.pi / m))
        pp("   m=%2d : lambda=%.12f  closed form %.12f   Ramanujan=%s   2sqrt2=%.9f"
           % (m, lam, pred, lam <= 2 * np.sqrt(2) + 1e-12, 2 * np.sqrt(2)))


if __name__ == '__main__':
    cases = []
    S4 = sym_group(4); A5 = alt_group(5); S5 = sym_group(5)
    for G, d in [(S4, 3), (S4, 4), (A5, 3), (A5, 4), (A5, 5), (S5, 3)]:
        rows = []
        for S in G.symmetric_sets(d):
            if not G.connected(S):
                continue
            lam = G.lambda_two_sided(S)
            rows.append((lam, S))
        rows.sort()
        for tag, (lam, S) in [('min', rows[0]), ('max', rows[-1])]:
            pp("### %s d=%d %s lambda=%.12f S=%s" % (G.name, d, tag, lam,
               [cycle_type(G.els[s]) for s in S]))
            out, cp = identify(G, S)
            for f, e, roots in out:
                if roots is None:
                    pp("   factor %s ^%d  (degree %d, roots not listed)" % (f, e, sp.degree(sp.sympify(f))))
                    continue
                rs = ', '.join('%.9f' % complex(r).real if abs(complex(r).imag) < 1e-9
                               else '%.4f%+.4fi' % (complex(r).real, complex(r).imag) for r in roots)
                pp("   factor %-40s ^%d   roots %s" % (f, e, rs))
    pp()
    dihedral_exact()
