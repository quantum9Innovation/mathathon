# Proofs and exact statements supplied by this dossier

All items in this file are my own proofs unless marked otherwise. They are
elementary, but each is stated with a complete proof so that a referee can
check the dossier without reading any code.

## 0. Notation and conventions

$G$ is a finite group, $n = |G|$, $S \subseteq G \setminus \{1\}$ satisfies
$S^{-1} = S$, $d = |S|$. The Cayley graph $X = \mathrm{Cay}(G,S)$ has vertex set
$G$ and edge multiset $\{\{x, xs\} : x \in G, s \in S\}$. $A = A_X$ is its
adjacency operator on $\mathbb{C}G$ (functions on $G$), so that
$(Af)(x) = \sum_{s \in S} f(xs)$, equivalently $A = \sum_{s \in S} P_s$ where
$P_s f(x) = f(xs)$.

Since $S = S^{-1}$, $A$ is self-adjoint for the standard inner product, and
$A$ is $d$-regular, so $d$ is an eigenvalue with eigenvector $\mathbf{1}$.

Eigenvalues are listed
$$\lambda_1 = d > \lambda_2 \ge \lambda_3 \ge \dots \ge \lambda_n .$$
If $S$ generates $G$ then $X$ is connected and Perron-Frobenius makes $d$
simple, that is $\lambda_2 < d$. When $S$ does not generate $G$ the graph is
disconnected and we say nothing about it. Throughout, "$\mathrm{Cay}(G,S)$"
means a connected Cayley graph.

The two spectral parameters used are
$$\lambda(X) := \max_{2 \le i \le n} |\lambda_i|, \qquad
\lambda^+_2(X) := \lambda_2, \qquad \lambda^-(X) := -\lambda_n .$$
$\lambda(X)$ is the quantity compared with the Ramanujan threshold. This
two-sided convention is the one used by Alon-Boppana, by Friedman and by
Bordenave. The one-sided convention differs only for bipartite graphs, see
Proposition 4.

The *quasi-index* of $X$ at level $\theta \ge 0$ is
$$N(\theta, X) := \#\{i \ge 2 : |\lambda_i| > \theta\} .$$
This is the index used in the definition of $k$-quasi-$X$-Ramanujan graphs of
Mohanty and O'Donnell (their Definition 2.16: infinitely many $G \in
\mathrm{FinQuo}(X)$ with $\lambda_{k+1}(G) \le \rho(X)$).

## 1. Proposition (Fourier block law)

Let $\mathrm{Irr}(G)$ be a complete set of unitary irreducible representations
of $G$, with degrees $f_\rho$, and for $\rho \in \mathrm{Irr}(G)$ put
$$M_\rho := \sum_{s \in S} \rho(s) \in \mathbb{C}^{f_\rho \times f_\rho} .$$
Then:

(i) $M_\rho$ is Hermitian, because $M_\rho^* = \sum_s \rho(s)^* = \sum_s
\rho(s^{-1}) = \sum_{s \in S}\rho(s) = M_\rho$.

(ii) The spectrum of $A$ (as a multiset with multiplicities) equals the
disjoint union over $\rho \in \mathrm{Irr}(G)$ of the spectrum of $M_\rho$,
each eigenvalue of $M_\rho$ repeated exactly $f_\rho$ times.

(iii) Consequently
$$\lambda(X) = \max_{\rho \ne \mathbf{1}} \|M_\rho\|_{\mathrm{op}},
\qquad \lambda_2^+(X) = \max_{\rho \ne \mathbf{1}} \lambda_{\max}(M_\rho).$$

*Proof.* By the Peter-Weyl theorem the left regular representation decomposes
as $\mathbb{C}G \cong \bigoplus_{\rho} \mathbb{C}^{f_\rho} \otimes
\mathbb{C}^{f_\rho}$, in such a way that left multiplication by $g$ acts on
the $\rho$-summand as $\rho(g) \otimes I_{f_\rho}$. Summing over $s \in S$
gives that $A$ acts on the $\rho$-summand as $M_\rho \otimes I_{f_\rho}$. The
spectrum of a Kronecker product $M \otimes I_f$ is the spectrum of $M$ with
each eigenvalue repeated $f$ times. Summing over $\rho$ gives (ii), and (iii)
follows because the trivial representation contributes the single eigenvalue
$M_{\mathbf{1}} = d$. $\square$

Remark. Part (ii) is classical. It is the Cayley special case of the
"isotypic decomposition" used in the relativized covering theory, where the
same formula reads $\mathrm{spec}(G) = \bigcup_\rho \mathrm{spec}(A_\rho)$ for
a voltage graph. What I use below is the combination with the quasi-index.

## 2. Corollary (quasi-index is a sum of irreducible degrees)

For every $\theta \ge 0$,
$$N(\theta, X) = \sum_{\rho \ne \mathbf{1}} f_\rho \cdot \#\{\mu \in
\mathrm{spec}(M_\rho) : |\mu| > \theta\} .$$
In particular $N(\theta, X)$ is a sum of irreducible degrees of $G$, so it is
never an arbitrary integer, and each summand is a nonzero multiple of some
$f_\rho$ that actually has an eigenvalue outside the window.

*Proof.* Immediate from Proposition 1(ii). $\square$

The corollary is what turns the "beyond $\lambda_2$" question into a
representation theoretic question: the block sizes force the multiplicities.

## 3. Corollary (the upper edge is a block maximum)

$\lambda(X) = 2\sqrt{d-1} + \varepsilon$ holds if and only if *every*
nontrivial irreducible block satisfies $\|M_\rho\| \le 2\sqrt{d-1} +
\varepsilon$. There is therefore no loss in analysing one block at a time, and
no gain either: the difficulty of the Cayley Ramanujan problem is entirely in
the uniformity over $\mathrm{Irr}(G)$.

## 4. Proposition (bipartite barrier)

Suppose $H \le G$ has index $2$ and $S \subseteq G \setminus H$. Then $X$ is
bipartite with parts $H$ and $G \setminus H$, hence $-d \in \mathrm{spec}(A)$
and $\lambda(X) = d$. Since $d \ge 2\sqrt{d-1}$ with equality only at $d = 2$,
no such Cayley graph with $d \ge 3$ is Ramanujan in the two-sided sense.

*Proof.* $S$ meets only the nontrivial coset, so every edge joins $H$ to
$G \setminus H$: bipartite. In a $d$-regular bipartite graph the vector which
is $1$ on $H$ and $-1$ on $G \setminus H$ is an eigenvector with eigenvalue
$-d$. Finally $d^2 - 4(d-1) = (d-2)^2 \ge 0$. $\square$

This is the Cayley shadow of the standard bipartite convention in the
biregular theory: in a $(\Delta_1,\Delta_2)$-biregular graph the trivial pair
is $\pm\sqrt{\Delta_1 \Delta_2}$, and the Ramanujan condition has to be stated
on the nontrivial eigenvalues only.

## 5. Proposition (coset Rayleigh certificate)

Let $H \le G$, $m = [G:H] \ge 2$, and $d_H = |S \cap H|$. Then
$$\lambda(X) \ge \left| d_H\frac{m-1}{m} - \frac{2(d-d_H)}{m}
+ \frac{(m-1)d - (d-d_H)}{m(m-1)} \right| .$$
Moreover, as $m \to \infty$ with $d_H$ fixed the right side tends to $d_H$.

*Proof.* Let $U = H$ (a coset of itself), $u = |H|$, $\alpha = u/n = 1/m$, and
$f = \mathbf{1}_U - \alpha \mathbf{1}_G$. Then $\sum_x f(x) = u - \alpha n = 0$,
so $f \perp \mathbf{1}$ and the Rayleigh quotient of $f$ is at most
$\lambda(X)$ in absolute value. Compute
$$\langle f, f\rangle = u(1-\alpha)^2 + (n-u)\alpha^2 = u(1-\alpha).$$
Every vertex of $U$ has exactly $d_H$ neighbours in $U$, so $e(U) = u d_H/2$
and $e(U, U^c) = u(d - d_H)$. Hence
$$\langle f, Af\rangle = u d_H (1-\alpha)^2 - 2u(d-d_H)(1-\alpha)\alpha
+ \bigl((n-u)d - u(d-d_H)\bigr)\alpha^2 .$$
Dividing by $u(1-\alpha)$ and substituting $\alpha = 1/m$ gives the displayed
expression, in which the first term is $d_H(m-1)/m$, the second is
$-2(d-d_H)/m$ and the third is $\bigl((m-1)d - (d-d_H)\bigr)/(m(m-1))$.
$\square$

Two checks. If $d_H = d$ (so $S \subseteq H$ and $X$ is disconnected) the
formula returns $d$. If $m = 2$ and $d_H = 0$ (the bipartite case) the formula
returns $-d$. Both agree with Proposition 4 and with the eigenvalues of the
corresponding graphs.

Consequence (non-Ramanujan certificates). If $d_H = d-1$ and $m \to \infty$
then $\lambda(X) \ge d - 1 - O(1/m)$. Since $d-1 > 2\sqrt{d-1}$ if and only if
$d > 5$, every Cayley graph of degree $d \ge 6$ whose connection set has all
but one element inside a subgroup of large index is non-Ramanujan with margin
$(\sqrt{d-1}-2)\sqrt{d-1}$ minus $O(1/m)$. For $d = 5$ the two numbers
coincide and the certificate is inconclusive, and for $d \in \{3,4\}$ the
group-theoretic certificate of this shape cannot certify anything.

Numerical check: over the $76 + 560 + 1560$ connected connection sets of
degree $3$ in $S_4$, $A_5$, $S_5$ (file `out/certificates.txt`) the certificate
never exceeded the true $\lambda$, as it must not, and no violation occurred.

## 6. Proposition (abelian pigeonhole bound)

Let $G$ be abelian of order $n$, and let $S = S^{-1}$ generate $G$ with
$|S| = d$.

(a) If $d = 2k$ is even, write $S = \{\pm s_1, \dots, \pm s_k\}$. Then
$$\lambda(X) \ge d \cos\!\left(2\pi n^{-1/k}\right)
= d - O\!\left(d\, n^{-2/k}\right).$$

(b) If $d$ is odd, put $k = (d+1)/2$. Then
$\lambda(X) \ge (d-1) - O(d\, n^{-2/k})$.

*Proof.* (a) Consider the homomorphism $\varphi : \widehat{G} \to
\mathbb{T}^k$, $\chi \mapsto (\chi(s_1), \dots, \chi(s_k))$. Because $S$
generates $G$, $\varphi$ is injective, so $|\varphi(\widehat G)| = n$. Split
$\mathbb{T}^k$ into $n$ half-open boxes of side $n^{-1/k}$. Two of the $n$
distinct points $\varphi(\chi)$ lie in the same box, and their ratio
$\chi_0 = \chi_1 \chi_2^{-1}$ is a *nontrivial* character with
$|\chi_0(s_j) - 1| \le 2\pi n^{-1/k}$ for every $j$, hence
$\mathrm{Re}\,\chi_0(s_j) \ge 1 - \tfrac12 (2\pi)^2 n^{-2/k}$. Since $S$ is
symmetric, $\chi_0(S) = \sum_{s \in S}\chi_0(s) = 2\sum_j
\mathrm{Re}\,\chi_0(s_j) \ge d(1 - 2\pi^2 n^{-2/k})$, and $\chi_0(S)$ is a real
eigenvalue of $A$ in a one-dimensional (hence nontrivial) block.
(b) If $d$ is odd then $S$ contains an involution $t$. Apply the same argument
to the $\pm$ pairs in $S \setminus \{t\}$ inside the annihilator subgroup
$\{\chi : \chi(t) = 1\}$, which has order at least $n/2$, and add
$\chi(t) \ge -1$. $\square$

Consequence. For abelian $G$ with $|G| \to \infty$ and $d$ fixed, every
connected Cayley graph satisfies $\lambda(X) \to d$. Hence fixed degree abelian
Cayley graph families never beat the Ramanujan threshold beyond a bounded
order, and the rate $n^{-2/k}$ matches the order of the spectral gap proved for
random abelian Cayley graphs by Hermon and Olesker-Taylor (gap of order
$|G|^{-2/k}$ when $k - d(G) \asymp k$). The bound is exponent sharp and its
constant is not.

## 7. Proposition (dihedral prisms, exact spectrum and exact Ramanujan set)

Let $m \ge 3$, $D_m = \langle r, t \mid r^m = t^2 = 1, trt = r^{-1}\rangle$ of
order $2m$, and $S = \{r, r^{-1}, t\}$. Then
$$\mathrm{spec}\,\mathrm{Cay}(D_m, S) = \{2\cos(2\pi j/m) + 1 : j\} \cup
\{2\cos(2\pi j/m) - 1 : j\}$$
as a multiset of size $2m$, and therefore
$$\lambda = \begin{cases} 3, & m \text{ even},\\ 1 + 2\cos(\pi/m), & m \text{ odd}.\end{cases}$$
Consequently $\mathrm{Cay}(D_m,S)$ is Ramanujan if and only if $m \in \{5,7\}$.

*Proof.* In the presentation above $D_m \cong \mathbb{Z}_m \rtimes
\mathbb{Z}_2$ and the graph $\mathrm{Cay}(D_m,\{r,r^{-1},t\})$ is a prism: the
cosets of $\langle r \rangle$ are the cycles and $t$ matches each coset to
itself with a reflection, $x \mapsto xt$. The proof below does not use this
geometric description, it computes the spectrum from the irreducible
representations. For the
$(m-1)/2$ or $(m-2)/2$ two-dimensional irreducible representations
$\rho_j(r) = \mathrm{diag}(\omega^j, \omega^{-j})$ with $\omega = e^{2\pi i/m}$
and $\rho_j(t) = \left(\begin{smallmatrix}0&1\\1&0\end{smallmatrix}\right)$ we get
$$M_{\rho_j} = \begin{pmatrix} \omega^j + \omega^{-j} & 1\\ 1 & \omega^j +
\omega^{-j}\end{pmatrix},$$
whose eigenvalues are $2\cos(2\pi j/m) \pm 1$, each with multiplicity
$f_{\rho_j} = 2$ by Proposition 1. The four (respectively two) linear
characters give $2(\pm 1) + (\pm 1) \in \{3, 1, -1, -3\}$, where $-3$ occurs
exactly when $m$ is even, since only then is $r \mapsto -1$ a character. The
multiset count matches $2m$. For odd $m$ the maximum of $|2\cos\theta - 1|$
over $\theta = 2\pi j/m$, $j \ne 0$, is attained at $j = (m-1)/2$ and equals
$1 + 2\cos(\pi/m)$, which dominates $|2\cos\theta + 1| < 3$ and $3$. For even
$m$, $j = m/2$ gives $-3$. Finally $1 + 2\cos(\pi/m) \le 2\sqrt2$ if and only
if $\cos(\pi/m) \le \sqrt2 - 1/2$, that is $m \le 7.52$, and for even $m$ the
value is $3 > 2\sqrt2$. $\square$

The numerical check in `out/algebraic_ids.txt` confirms this formula for
$m = 4, \dots, 13$ to twelve digits, including the value $3$ for every even $m$.

Why this example matters: $D_m$ has abelianization of order $2$ (for odd $m$)
and yet the family fails the Ramanujan bound for all $m > 7$. The obstruction
is not the abelianization of the group but the *character of the index two
subgroup* $\langle r\rangle$: the two-dimensional representations $\rho_j$ of
$D_m$ are induced from characters of $\langle r \rangle$, and at $j$ near
$m/2$ the block $M_{\rho_j}$ degenerates to a two by two matrix with a large
eigenvalue. Monomial (induced) representations of bounded-index subgroups are
therefore a second obstruction mechanism, distinct from characters of the
whole group.

## 8. Remark (why the second moment is not enough)

For any connected $d$-regular graph on $n$ vertices,
$\sum_{i \ge 2}\lambda_i^2 = nd - d^2$, so
$\lambda(X) \ge \sqrt{(nd-d^2)/(n-1)} = \sqrt d \,(1 + o(1))$ for $d \ll n$.
This "cheap benchmark" is far below $2\sqrt{d-1}$ for $d \ge 3$ and does not
detect the tree threshold. The tree threshold itself is not an easy benchmark:
it is attained by explicit families (Lubotzky-Phillips-Sarnak, Margulis,
Morgenstern) and is a lower bound for every family by Alon-Boppana, so the
question studied here is genuinely the sharp one.
