# Exact computations and numerical experiments

Everything here is reproducible from the scripts in `src/` and the raw outputs
in `out/`. Every script is run from the member directory
`.ultramath/smwgfcleu/m7` (the scripts insert `dossier/src` on `sys.path`).

| script | output | what it does |
| --- | --- | --- |
| `src/cayley.py` | library | finite groups from permutations or by presentation, multiplication table, symmetric connection sets, adjacency matrix, spectra, girth |
| `src/characters.py` | library | Murnaghan-Nakayama characters of $S_n$, hardcoded $A_5$ table, orthogonality check |
| `src/blocks.py` | library | isotypic projectors and block spectra, multiset-law verification |
| `src/enumerate_groups.py` | `out/enum_small.txt` | exhaustive $\lambda$ over all symmetric generating sets, $d = 3,4,5,6$ |
| `src/main_tables.py` | `out/main_tables.txt` | extremal sets, block decomposition, exact characteristic polynomials |
| `src/extremal_exact.py` | `out/extremal_exact.txt` | extremal data for nine $(G,d)$ pairs |
| `src/algebraic_ids.py` | `out/algebraic_ids.txt` | factorisation of the exact characteristic polynomial, identification of extremal eigenvalues, prism table |
| `src/structural_checks.py` | `out/structural_checks.txt` | subgroups, coset bounds, bipartite test, girth correlations |
| `src/certificates.py` | `out/certificates.txt` | final certificate analysis at degree 3 |
| `src/asymptotics.py` | `out/asymptotics.txt` | abelian contrast, dihedral contrast, random sampling in larger groups |
| `src/local_tree_likeness.py`, `src/tree_walks.py` | printed | exact closed-walk counts versus the tree |

Reproduce, for example, with

```
cd .ultramath/smwgfcleu/m7
python3 dossier/src/certificates.py          # about 5 minutes
python3 dossier/src/algebraic_ids.py        # about 10 seconds
python3 dossier/src/asymptotics.py          # about 5 seconds
```

## 1. Consistency checks passed before any claim is made

* Murnaghan-Nakayama character tables satisfy the first orthogonality relation
  exactly for $n = 3,4,5,6$ (`characters.py`, printed check).
* The $A_5$ character table satisfies orthogonality with class sizes
  $1, 15, 20, 12, 12$ (`characters.py`).
* The block decomposition reproduces the full spectrum of $A$: the maximum
  absolute deviation between the union of the block spectra and the spectrum of
  $A$ is at most $7.6 \cdot 10^{-15}$ in every case computed
  (`out/main_tables.txt`). This verifies Proposition 1 numerically, including
  the multiplicities $f_\rho$.
* All extremal values are confirmed by exact integer characteristic
  polynomials (SymPy) and, where the value is a quadratic surd, by the
  factorisation.
* Closed-walk counts are exact integers (integer matrix powers of a $0$-$1$
  matrix).

## 2. The exhaustive landscape

$n = |G|$, $d$ = degree, "sets" = symmetric subsets of size $d$ not containing
the identity, "conn" = those that generate $G$. $\theta = 2\sqrt{d-1}$.
"Raman" counts connected sets with $\lambda \le \theta$.

| $G$ | $n$ | $d$ | sets | conn | Raman | distinct spectra | $\lambda_{\min}$ | $\lambda_{\max}$ |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| $S_4$ | 24 | 3 | 147 | 76 | 48 | 5 | 2.5615528 | 3 |
| $S_4$ | 24 | 4 | 399 | 324 | 252 | 18 | 2.6457513 | 4 |
| $S_4$ | 24 | 5 | 903 | 844 | 736 | 42 | 3 | 5 |
| $S_4$ | 24 | 6 | 1757 | 1720 | 1424 | 80 | 3 | 6 |
| $A_5$ | 60 | 3 | 785 | 560 | 320 | 9 | 2.6180340 | 2.9021130 |
| $A_5$ | 60 | 4 | 3906 | 3630 | 1830 | 48 | 2.9032119 | 3.8422357 |
| $A_5$ | 60 | 5 | 16478 | 16202 | 9627 | 174 | 3.1622777 | 4.6377683 |
| $S_5$ | 120 | 3 | 3475 | 1560 | 840 | 16 | 2.7092754 | 3 |
| $S_5$ | 120 | 4 | 27831 | 20910 | 7760 | 203 | 3 | 4 |

For $S_4$ at $d = 3$ the five spectra occur with multiplicities
$24, 24, 12, 12, 4$ over the 76 connected sets. Since isomorphic graphs have
equal spectra, five is a lower bound for the number of isomorphism classes of
connected cubic Cayley graphs on $S_4$ (I did not compute the exact number of
classes).

## 3. Closed forms for the extremal eigenvalues (exact, from the
characteristic polynomial)

| $G$ | $d$ | $\lambda_{\min}$ | exact value | extremum at | girth | $\lambda_{\max}$ | exact value |
| --- | --- | --- | --- | --- | --- | --- | --- |
| $S_4$ | 3 | 2.5615528128 | $\tfrac{1+\sqrt{17}}{2}$ | negative end, mult. 3 | 6 | 3 | $-3$ (bipartite) |
| $S_4$ | 4 | 2.6457513111 | $\sqrt7$ | positive end, mult. 3 | 3 | 4 | $-4$ (bipartite) |
| $S_4$ | 5 | 3 | $3$ | negative end, mult. 2 | 3 | 5 | $-5$ (bipartite) |
| $S_4$ | 6 | 3 | $3$ | negative end, mult. 2 | 3 | 6 | $-6$ (bipartite) |
| $A_5$ | 3 | 2.6180339887 | $\tfrac{3+\sqrt5}{2}$ | negative end, mult. 6 | 9 | 2.9021130326 | $-$root of $x^4+4x^3+x^2-6x+1$ |
| $A_5$ | 4 | 2.9032119259 | root of $x^3-2x^2-4x+4$ | positive end, mult. 9 | 3 | 3.8422356793 | $-$root of $x^4+6x^3+7x^2-6x-4$ |
| $A_5$ | 5 | 3.1622776602 | $\sqrt{10}$ | negative end, mult. 4 | 3 | 4.6377682672 | root of the degree 6 factor |
| $S_5$ | 3 | 2.7092753594 | $-$root of $x^3+x^2-5x-1$ | negative end, mult. 6 | 8 | 3 | $-3$ (bipartite) |
| $S_5$ | 4 | 3 | $3$ | negative end, mult. 4 | 5 | 4 | $-4$ (bipartite) |

Sample exact characteristic polynomials (all verified by SymPy):

* $S_4$, $d=3$, minimiser $S = \{(23), (02), (03)(12)\}$ (cycle types
  $2,2,2^2$, with the four points labelled $0,1,2,3$):
  $x^5 (x-3)(x-2)^5 (x+1)^4 (x+2)^3 (x^2+x-4)^3$.
* $A_5$, $d=3$, minimiser $S$ = three double transpositions:
  $x^4(x-3)(x-1)^{13}(x+2)^4(x^2-5)^3(x^2-x-3)^{10}(x^2+3x+1)^6$.
* $S_5$, $d=3$, minimiser:
  $x^{10}(x-3)(x-1)^{17}(x+2)^{12}(x^2-5)^5(x^2-x-4)^{10}
  (x^2-x-3)^4(x^2-x-1)^8(x^2+3x+1)^4(x^3+x^2-5x-1)^6$.

Note that in seven of the nine cases the extremal nontrivial eigenvalue is a
*negative* eigenvalue, and that $\lambda_{\max} = d$ exactly when a bipartite
connection set exists (always for $S_n$, never for $A_5$).

## 4. Which block carries the extremum (Proposition 1 in action)

$S_4$, $d=3$, minimiser: the value $\pm\tfrac{\sqrt{17}-1}{2}$ sits in the
irrep $(2,1,1)$ of degree $3$, and its multiplicity is exactly $3$. The
$(3,1)$ and $(2,2)$ blocks contribute $2$ and the sign block contributes $-1$.

$A_5$, $d=3$, minimiser: $-\tfrac{3+\sqrt5}{2}$ sits in a degree $3$ block with
multiplicity $6 = 2 \cdot 3$, and the other degree $3$ block contributes
$\pm\sqrt5$.

$A_5$, $d=3$, maximiser: the value $-2.9021\ldots$ sits in a degree $3$ block
with multiplicity $3$, hence the quasi-index is $3$.

$S_4$, $d=3$, maximiser: the value $-3$ sits in the sign block (degree $1$),
multiplicity $1$.

## 5. The quasi-index is a sum of irreducible degrees (Corollary 2 in action)

Distribution of $N(\theta,X)$ over connected sets, $\theta = 2\sqrt{d-1}$:

| $G$ | $d$ | distribution of $N(\theta,\cdot)$ |
| --- | --- | --- |
| $S_4$ | 3 | $0$: 48, $1$: 28 |
| $A_5$ | 3 | $0$: 320, $3$: 240 |
| $S_5$ | 3 | $0$: 840, $1$: 120, $4$: 360, $6$: 240 |

Every nonzero value is a sum of irreducible degrees of the group
($S_4$: $1,2,3,3$, and $A_5$: $1,3,3,4,5$, and $S_5$: $1,4,4,5,5,6,6$). No value
inconsistent with Corollary 2 occurs in 2196 connected graphs.

### The quasi-index determines the degree of the offending block

Because of Corollary 2 the quasi-index is a sum of irreducible degrees, so at
degree 3 the observed values force the degree of the block that crosses the
threshold.

* $S_4$ has degrees $1,1,2,3,3$. The $28$ non-Ramanujan sets have
  $N(	heta,\cdot) = 1$, which forces the offending block to be one of the two
  linear characters. It is the sign character, and indeed all $28$ sets are
  bipartite.
* $A_5$ has degrees $1,3,3,4,5$. All $240$ non-Ramanujan sets have
  $N = 3$, which forces the offending block to be one of the two
  three-dimensional irreducibles. No block of degree $4$ or $5$ crosses the
  threshold for any of the $560$ connected sets.
* $S_5$ has degrees $1,4,5,5,6,6,1$. The observed quasi-indices are $1$, $4$
  and $6$: linear (the $120$ bipartite sets), four-dimensional, and
  six-dimensional respectively. The value $5$ never occurs, so no
  five-dimensional block carries a failure at degree 3.

This is a derivation, not a pattern: the multiplicities are computed exactly
and Corollary 2 is proved.

## 6. Two failure mechanisms, and what does *not* explain them

For all 2196 connected degree 3 sets in $S_4$, $A_5$, $S_5$:

* the coset certificate of Proposition 5 never exceeds $\lambda$
  (0 violations),
* for $S_4$ the non-Ramanujan sets are **exactly** the bipartite ones
  (28 of 28, certified by the index two subgroup $A_4$ with certificate $3$),
* for $A_5$, which is simple, there is no index two subgroup and **no** coset
  certificate at all: the largest certificate over all 58 subgroups is
  $1.947$, while 240 sets are non-Ramanujan. Those failures are caused by short
  relations: their girths are $3$ (60 sets), $4$ (120 sets) and $6$ (60 sets),
* for $S_5$, 120 of the 720 failures are bipartite and certified, the other 600
  are not certified by any subgroup,
* girth does not decide the question: in $S_4$ at $d=3$, girth $4$ occurs with
  24 Ramanujan and 24 non-Ramanujan sets, and girth $6$ occurs with 12
  Ramanujan and 4 non-Ramanujan sets. In $A_5$ at $d=3$, girth $4$ occurs with
  60 Ramanujan and 120 non-Ramanujan sets, and girth $6$ with 120 Ramanujan and
  60 non-Ramanujan sets.

Conclusion (verified exhaustively at degree 3): the Ramanujan property for
Cayley graphs is *not* a function of the subgroup structure, and it is *not* a
function of the girth. It is a property of the individual irreducible blocks.

## 7. Local tree-likeness and girth from exact closed-walk counts

For a $d$-regular vertex-transitive graph $X$ on $n$ vertices, let
$A_\ell$ be the number of closed walks of length $\ell$ from a fixed vertex of
$T_d$. Then $\mathrm{tr}(A^\ell) = n A_\ell$ for every $\ell$ strictly smaller
than the girth, and $\mathrm{tr}(A^g) > n A_g$ at $\ell = g$, because
vertex-transitivity puts every vertex on a shortest cycle. So the first length
at which the exact integer $\mathrm{tr}(A^\ell)$ exceeds $nA_\ell$ is the
girth.

Closed walks of length $\ell$ from the root of $T_3$:
$1, 0, 3, 0, 15, 0, 87, 0, 543, 0, 3543$ for $\ell = 0,\dots,10$.

Per vertex, $\mathrm{tr}(A^\ell)/n$ for the degree 3 minimisers, with the
first deviation:

| group | $\mathrm{tr}(A^\ell)/n$ for $\ell = 0,\dots$ | first deviation | girth |
| --- | --- | --- | --- |
| $S_4$ | $1,0,3,0,15,0,89,14,595,\dots$ | $\ell = 6$ | 6 |
| $A_5$ | $1,0,3,0,15,0,87,0,543,0,3579,\dots$ | $\ell = 9$ | 9 |
| $S_5$ | $1,0,3,0,15,0,87,0,547,\dots$ | $\ell = 8$ | 8 |

Raw output: `out/local_tree_likeness.txt`. The $A_5$ example is therefore a
cubic Cayley graph on $60$ vertices with girth $9$ and with
$\lambda = \tfrac{3+\sqrt5}{2} = 2.6180$, well below $2\sqrt2 = 2.8284$.
(The cage bound for degree 3 and girth 9 is 58 vertices according to the
standard tables, which I did not re-verify in this run.)

## 8. Contrast experiments

**Abelian groups.** $\mathbb{Z}_n$ with $S = \{\pm1, \dots, \pm k\}$ (and one
involution when $d$ is odd): $\lambda = 2.9021$ at $n=20$, and
$3 - 3.9\cdot10^{-5}$ at $n = 1000$ for $d = 3$, and $4 - 2.0\cdot10^{-4}$ at
$n=1000$ for $d=4$, and $6 - 5.5\cdot10^{-4}$ at $n=1000$ for $d=6$
(`out/asymptotics.txt`). This is Proposition 6 numerically, and the observed
gaps are $\Theta(n^{-2})$ for $d = 4$, matching the exponent $-2/k$ with
$k = 2$.

**Dihedral prisms.** $\mathrm{Cay}(D_m, \{r, r^{-1}, t\})$: computed values
$2.6180$ ($m=5$), $3$ ($m=6$), $2.8019$ ($m=7$), $3$ ($m=8$), $2.8794$
($m=9$), $3$ ($m=10$), $2.9190$ ($m=11$), $3$ ($m=12$), $2.9419$ ($m=13$),
in exact agreement with Proposition 7. Only $m = 5$ and $m = 7$ are Ramanujan.

**Random sets in larger groups** (60 samples each, exact dense eigenvalues for
$n \le 120$, sparse Lanczos for larger $n$, seed fixed in `asymptotics.py`):

| group | order | $d$ | mean $\lambda$ | min | max | $\theta$ | fraction $>\theta$ |
| --- | --- | --- | --- | --- | --- | --- | --- |
| $S_4$ | 24 | 3 | 2.7515 | 2.5616 | 3 | 2.8284 | 0.43 |
| $A_5$ | 60 | 3 | 2.7324 | 2.6180 | 2.8422 | 2.8284 | 0.28 |
| $S_5$ | 120 | 3 | 2.8496 | 2.7093 | 3 | 2.8284 | 0.48 |
| $A_6$ | 360 | 3 | 2.8527 | 2.8142 | 2.9021 | 2.8284 | 0.62 |
| $S_6$ | 720 | 3 | 2.8775 | 2.8214 | 3 | 2.8284 | 0.80 |

Interpretation, with the caveat that no numerical experiment can establish an
asymptotic claim: at these sizes $\lambda$ sits within about $0.05$ of
$2\sqrt2$, and the known finite-size error scale in Friedman-type theorems is
of order $(\log\log n/\log n)^2$, which is $0.08$ at $n = 720$. The data are
therefore consistent with the conjectured asymptotic behaviour and are *not*
evidence against it. The observed minima below $\theta$ (for $A_6$ and $S_6$)
are consistent with Alon-Boppana being asymptotic, since $n \le 720$.

## 9. What the experiments do not establish

No computation here decides the asymptotic question, and none is presented as
evidence for a statement about $|G| \to \infty$. The computations decide
exactly: (a) the exhaustive finite landscapes listed above, (b) the exact
extremal eigenvalues and their blocks, (c) the failure of the coset and girth
criteria at degree 3, (d) the exact behaviour of the dihedral and abelian
families.
