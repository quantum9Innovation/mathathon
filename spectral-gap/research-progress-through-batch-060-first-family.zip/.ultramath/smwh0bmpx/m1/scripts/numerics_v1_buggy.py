#!/usr/bin/env python3
"""Direction 4 (m1, swarm smwh0bmpx): fixed-seed numerical verification of the
clustered-attachment secular law for T_adj={c,u} and T_N=N(c).

Sampler: configuration model with rejection on multiple edges/loops.  By the exact
counting identity (each simple d-regular graph has exactly (d!)^n realisations) the
accepted graph is EXACTLY uniform on simple d-regular graphs.  Seeds are fixed and
printed.  No conclusion is drawn from numerics alone; every number below is compared
against an exact closed form.

Outputs: out/numerics_<d>.txt (tables) and out/numerics_raw.json (all numbers).
"""
import json
import sys

import numpy as np
import scipy.sparse as sp
import scipy.sparse.linalg as spla
from sympy import N as SN, sqrt as ssqrt, Rational

rng_global = np.random.default_rng


def sample_regular(n, d, seed, max_attempts=400):
    """Uniform simple d-regular graph on [n] by rejection from the pairing model."""
    rng = rng_global(seed)
    nstub = n * d
    if nstub % 2:
        raise ValueError("nd must be even")
    for att in range(max_attempts):
        stubs = np.repeat(np.arange(n), d)
        perm = rng.permutation(nstub)
        a = stubs[perm[0::2]]
        b = stubs[perm[1::2]]
        if np.any(a == b):
            continue
        key = np.minimum(a, b).astype(np.int64) * n + np.maximum(a, b)
        if np.unique(key).size != nstub // 2:
            continue
        return a, b, att + 1
    raise RuntimeError("sampler failed")


def build_adj(n, a, b, extra_edges=()):
    rows = list(a) + list(b)
    cols = list(b) + list(a)
    for (i, j) in extra_edges:
        rows += [i, j]
        cols += [j, i]
    data = np.ones(len(rows))
    nn = max(max(rows), max(cols)) + 1
    return sp.csr_matrix((data, (rows, cols)), shape=(nn, nn))


def km_data(d, lam):
    """exact r(lambda) and G_d(lambda) on the exterior branch, float64"""
    lam = float(lam)
    disc = lam * lam - 4 * (d - 1)
    r = (lam - np.sqrt(disc)) / (2 * (d - 1))
    G = r / (1 - r * r)
    return r, G


def resolvent_quadform(A, T, lam):
    """1_T^T (lam I - A)^{-1} 1_T  for lam outside spec(A)"""
    n = A.shape[0]
    e = np.zeros(n)
    e[np.array(T)] = 1.0
    M = sp.csc_matrix(lam * sp.identity(n) - A)
    x = spla.spsolve(M, e)
    return float(e @ x)


def secular(A, T, lam):
    return lam + resolvent_quadform(A, T, lam)


def top_eigs(A, k=8):
    vals = spla.eigsh(A, k=k, which='LA', return_eigenvectors=False,
                      tol=1e-12, maxiter=20000)
    vals = np.sort(vals)[::-1]
    return vals


def bisect_secular(A, T, lo, hi, iters=60):
    """zero of the strictly increasing Sigma_n in (lo,hi); requires sign change"""
    flo = secular(A, T, lo)
    for _ in range(iters):
        mid = 0.5 * (lo + hi)
        fm = secular(A, T, mid)
        if np.sign(fm) == np.sign(flo):
            lo, flo = mid, fm
        else:
            hi = mid
    return 0.5 * (lo + hi)


def predictions(d):
    """exact closed forms, high precision string + float"""
    b = 2 * np.sqrt(d - 1)
    if d == 3:
        rstar = 2.0 ** (-1.0 / 3.0)  # placeholder, replaced below
    # adjacent pair: root of 2 r^3 + r - 1 = 0 only for d = 3
    out = {}
    out['b'] = b
    # N(c) root
    lamN = 2.0 * d / np.sqrt(d + 1)
    out['lamN'] = lamN
    out['PhiNprime'] = 2.0 * (d + 1)
    # adjacent pair
    if d == 3:
        import numpy.polynomial as P
        c = np.array([-1.0, 1.0, 0.0, 2.0])  # -1 + r + 2 r^3
        rr = np.roots(c[::-1])
        real = [z.real for z in rr if abs(z.imag) < 1e-12 and z.real > 0][0]
        out['radj'] = real
        out['lamadj'] = 2 * real / (1 - real)
        out['Phiadjprime'] = None
    else:
        out['radj'] = None
        out['lamadj'] = None
    return out


def main():
    runs = []
    for d in (3, 4):
        ns = (1000, 2000, 4000, 8000) if d == 3 else (1000, 2000, 4000)
        for n in ns:
            if (n * d) % 2:
                continue
            runs.append((d, n))

    pred = {d: predictions(d) for d in (3, 4)}
    lines = []
    raw = {"predictions": {str(d): {k: (None if v is None else float(v))
                                   for k, v in pred[d].items()} for d in pred},
           "runs": []}

    for (d, n) in runs:
        seed = 1000000 + 1000 * d + n
        a, b, att = sample_regular(n, d, seed)
        A = build_adj(n, a, b)
        deg = np.asarray(A.sum(axis=1)).ravel()
        assert np.all(deg == d), "not regular"
        nbrs0 = sorted(A[0].indices.tolist())
        assert len(nbrs0) == d

        hostspec = top_eigs(A, k=6)
        lam2A = hostspec[1]

        pats = {
            'adj': [0, nbrs0[0]],
            'N': [0] + nbrs0,
        }
        for pname, T in pats.items():
            extra = [(j, n) for j in T]
            A2 = build_adj(n, a, b, extra_edges=extra)
            spec = top_eigs(A2, k=8)
            lam1, lam2 = spec[0], spec[1]

            # exact finite-n secular roots, bracketed
            lo = lam2A + 2e-4
            hi = d - 2e-4
            root_gap = None
            if hi > lo:
                try:
                    root_gap = bisect_secular(A, T, lo, hi, iters=55)
                except Exception:
                    root_gap = None
            lo2, hi2 = d + 5e-4, d + 1.0
            root_top = None
            try:
                root_top = bisect_secular(A, T, lo2, hi2, iters=55)
            except Exception:
                root_top = None

            # resolvent-value test at a fixed exterior lambda
            lam_test = 3.2 if d == 3 else 3.6
            r, G = km_data(d, lam_test)
            rho = {(0, T[1]): 1} if pname == 'adj' else {tuple(sorted((s, t))): 2
                                                          for i, s in enumerate(T)
                                                          for t in T[i + 1:]}
            Sig = 0.0
            for i, s in enumerate(T):
                for t in T[i:]:
                    dist = 0 if s == t else (1 if pname == 'adj' else 2)
                    Sig += r ** dist
            pred_res = G * Sig
            meas_res = resolvent_quadform(A, T, lam_test)
            perron = len(T) ** 2 / (n * (lam_test - d))

            rec = {
                "d": d, "n": n, "seed": seed, "pattern": pname, "T": list(T),
                "attempts": att, "lam2_host": float(lam2A),
                "lambda_1": float(lam1), "lambda_2": float(lam2),
                "secular_root_gap": None if root_gap is None else float(root_gap),
                "secular_root_top": None if root_top is None else float(root_top),
                "lam_test": lam_test,
                "resolvent_measured": float(meas_res),
                "resolvent_pattern_pred": float(pred_res),
                "resolvent_pattern_plus_perron": float(pred_res + perron),
                "resolvent_separated_pred": float(len(T) * G),
            }
            raw["runs"].append(rec)

            lines.append(
                f"d={d} n={n} seed={seed} T={pname} |T|={len(T)} att={att} "
                f"lam2(host)={lam2A:.6f}")
            lines.append(
                f"   eigensolver: lambda_1={lam1:.10f} lambda_2={lam2:.10f}"
                f" ; secular roots: gap={root_gap if root_gap is None else round(root_gap,10)}"
                f" top={root_top if root_top is None else round(root_top,10)}")
            if root_gap is not None:
                lines.append(f"   |lambda_2 - secular_gap_root| = {abs(lam2-root_gap):.3e}")
            if root_top is not None:
                lines.append(f"   |lambda_1 - secular_top_root| = {abs(lam1-root_top):.3e}")
            lines.append(
                f"   resolvent(lam={lam_test}): measured={meas_res:.6f} "
                f"pattern={pred_res:.6f} pattern+Perron={pred_res+perron:.6f} "
                f"separated={len(T)*G:.6f}")

        # limit-level tables
        p = pred[d]
        lines.append("")
        lines.append(f"--- limit predictions at d={d}: b={p['b']:.10f}, "
                     f"lambda*_N=2d/sqrt(d+1)={p['lamN']:.10f}, "
                     f"Phi_N'(lambda*)={p['PhiNprime']:.6f}")
        if p['lamadj'] is not None:
            lines.append(f"    adjacent pair: lambda*_adj={p['lamadj']:.10f} "
                         f"(root of lambda^3-lambda^2-4lambda-4)")
        else:
            lines.append("    adjacent pair: NO exterior root (d>=4); lambda_2 -> b")
        lines.append("")

    # eigenvalue-limit summary
    lines.append("")
    lines.append("=" * 78)
    lines.append("EIGENVALUE LIMIT SUMMARY")
    lines.append("=" * 78)
    for d in (3, 4):
        p = pred[d]
        lines.append(f"d={d}")
        for pname in ('adj', 'N'):
            rs = [rec for rec in raw["runs"] if rec["d"] == d and rec["pattern"] == pname]
            rs.sort(key=lambda z: z["n"])
            tgt = p['lamadj'] if pname == 'adj' else p['lamN']
            lines.append(f"  T={pname}: target lambda_2={tgt if tgt else p['b']:.10f}"
                         f"  target lambda_1={3.0 if pname=='adj' and d==3 else float(d):.6f}")
            for rec in rs:
                lines.append(f"     n={rec['n']:5d}  lambda_2={rec['lambda_2']:.8f}"
                             f"  lambda_1={rec['lambda_1']:.8f}"
                             + (f"  sqrt(n)*(3-lambda_2)={np.sqrt(rec['n'])*(3-rec['lambda_2']):.6f}"
                                if d == 3 and pname == 'N' else "")
                             + (f"  sqrt(n)*(lambda_1-3)={np.sqrt(rec['n'])*(rec['lambda_1']-3):.6f}"
                                if d == 3 and pname == 'N' else ""))
    txt = "\n".join(lines)
    print(txt)
    with open(f"out/numerics_all.txt", "w") as f:
        f.write(txt + "\n")
    with open("out/numerics_raw.json", "w") as f:
        json.dump(raw, f, indent=1)


if __name__ == "__main__":
    main()
