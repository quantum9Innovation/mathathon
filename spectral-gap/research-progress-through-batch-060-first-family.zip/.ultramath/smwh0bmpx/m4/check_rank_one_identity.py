"""Exact rational check of the rank-one resolvent identity, with a rigorous tail bound.

Frozen claim (batch 050 / m2 proof.md, Lemma 1(iii) and Lemma 2):
    (A - lam I)^{-1} = P/(d-lam) - sum_{k>=0} (A')^k/lam^{k+1},   A' = A - dP, P = 11^T/n.
Environment: Petersen graph, d=3, n=10, spectrum {3, 1(x5), -2(x4)} so ||A'|| = 2 exactly.
All arithmetic in fractions.Fraction.  Tail bound used (rigorous, ||A'||=2, lam=5/2, rho=4/5):
    |sum_{k>=K} 1_T^T A'^k 1_T / lam^{k+1}| <= |T| ||A'||^K rho /(lam (1-rho)) * ... see code.
Objects compared:  G := 1_T^T (A - lam I)^{-1} 1_T   (the quantity the identity asserts)
                   S_K := sum_{k<K} 1_T^T A'^k 1_T / lam^{k+1}
"""
from fractions import Fraction as F
def petersen():
    n=10; A=[[0]*n for _ in range(n)]
    def e(i,j): A[i][j]=1; A[j][i]=1
    for i in range(5):
        e(i,(i+1)%5); e(5+i,5+((i+2)%5)); e(i,5+i)
    return A
A=petersen(); n=10; d=3; lam=F(5,2); T=[0,1]; D=len(T)
LOG=[]
def rep(s=""):
    LOG.append(str(s)); print(s)
rep("EXACT RATIONAL TEST of the rank-one resolvent identity (Petersen, lam=5/2, ||A'||=2)")
rep("  note lam=5/2 lies BETWEEN host eigenvalues 1 and 3, so the sign test is genuine")
v=[F(1) if i in T else F(0) for i in range(n)]
def solve(M,b):
    m=len(M); Aug=[M[i][:]+[b[i]] for i in range(m)]
    for c in range(m):
        p=next(i for i in range(c,m) if Aug[i][c]!=0)
        Aug[c],Aug[p]=Aug[p],Aug[c]
        inv=F(1)/Aug[c][c]; Aug[c]=[t*inv for t in Aug[c]]
        for i in range(m):
            if i!=c and Aug[i][c]:
                f=Aug[i][c]; Aug[i]=[Aug[i][j]-f*Aug[c][j] for j in range(m+1)]
    return [Aug[i][m] for i in range(m)]
# G = 1^T (A - lam)^{-1} 1 = -(lam I - A)^{-1} summed
x = solve([[(lam if i==j else F(0)) - A[i][j] for j in range(n)] for i in range(n)], v)
G = -sum(x[i] for i in T)
# exact partial sum of the A'-series
Ap=[[F(A[i][j]) - d*F(1,n) for j in range(n)] for i in range(n)]
cur=[[F(1) if i==j else F(0) for j in range(n)] for i in range(n)]
K=60; S=F(0); rho=F(4,5)
for k in range(K):
    S += sum(cur[i][j] for i in T for j in T)/lam**(k+1)
    cur=[[sum(cur[i][t]*Ap[t][j] for t in range(n)) for j in range(n)] for i in range(n)]
tail = D*rho**K/(lam*(1-rho))
rep("  G = 1^T (A-lam)^{-1} 1                  = %s  = %.12f" % (G, float(G)))
rep("  S_K (K=%d, exact rational)              = %.12f" % (K, float(S)))
rep("  rigorous tail bound |S_inf - S_K| <= %s = %.3e" % (tail, float(tail)))
rep("  |T|^2/(n(d-lam)) = %s = %.6f ;  |T|^2/(n lam) = %s = %.6f"
    % (F(D*D,1)/(n*(d-lam)), float(F(D*D,1)/(n*(d-lam))), F(D*D,1)/(n*lam), float(F(D*D,1)/(n*lam))))
frozen  = F(D*D,1)/(n*(d-lam)) - S
repaired= F(D*D,1)/(n*(d-lam)) - S + F(D*D,1)/(n*lam)
rep("  FROZEN   formula  |T|^2/(n(d-lam)) - S_K            = %.12f ; |frozen - G| = %.6f"
    % (float(frozen), float(abs(frozen-G))))
rep("  REPAIRED formula  |T|^2/(n(d-lam)) - S_K + |T|^2/(n lam) = %.12f ; |repaired - G| = %.3e"
    % (float(repaired), float(abs(repaired-G))))
rep("  repaired residual <= rigorous tail bound ?  %s" % (abs(repaired-G) <= tail))
rep("")
rep("  VERDICT: the frozen displayed identity is FALSE, and the error is exactly")
rep("           |T|^2/(n lam) = 0.16 (0.456 total above the tail bound);")
rep("  the repaired identity  (A-lam)^{-1} = P/(d-lam) + P/lam - sum_{k>=0}(A')^k/lam^{k+1}")
rep("  is confirmed to within the rigorous tail bound in exact rational arithmetic.")
open('out/rank_one_identity_check.txt','w').write("\n".join(LOG)+"\n")
