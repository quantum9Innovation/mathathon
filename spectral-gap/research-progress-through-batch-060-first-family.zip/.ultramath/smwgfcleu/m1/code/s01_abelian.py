r"""Exact second-order law for finite abelian quotients of Z^d-Cayley graphs.

Setting.  S a symmetric generating set of Z^d, G = sum_{s in S} s s^T,
Lambda_1(kappa) = sum_{s in S} cos(2 pi <kappa,s>) = |S| - 2 pi^2 kappa^T G kappa
+ O(|kappa|^4).  For an index-N sublattice Lambda <= Z^d,

    Spec(Cay(Z^d/Lambda, S)) = { Lambda_1(kappa) : kappa in Lambda^*/Z^d },

hence   |S| - lambda_2 = 2 pi^2 * min_{0 != kappa in Lambda^*/Z^d} kappa^T G kappa
                         + O(mu^2).

All quantities except the cosines are exact rationals.
"""
import sys, os, json, itertools
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
from fractions import Fraction
import lib

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "out")


def band(S, kappa):
    return float(sum(np.cos(2*np.pi*float(sum(Fraction(s[i])*kappa[i]
                                                 for i in range(len(s))))
                             ) for s in S))


def form(S, kappa):
    t = Fraction(0)
    for s in S:
        a = sum(Fraction(s[i])*kappa[i] for i in range(len(s)))
        t += a*a
    return t


def sublattice_scan(S, N):
    rows = []
    for (a, b, d) in lib.sublattices_2d(N):
        pts = lib.dual_points_2d(a, b, d)
        vals = sorted((band(S, k) for k in pts))[::-1]
        zero = (Fraction(0), Fraction(0))
        mu = min(form(S, k) for k in pts if k != zero)
        rows.append(dict(a=a, b=b, d=d, N=N, gap=len(S)-vals[1],
                         muG=float(mu), pred=2*np.pi**2*float(mu),
                         ratio=(len(S)-vals[1])/(2*np.pi**2*float(mu))))
    return rows


def main():
    log = []
    data = {}
    cases = {
        "square": [(1, 0), (-1, 0), (0, 1), (0, -1)],
        "triangular": [(1, 0), (-1, 0), (0, 1), (0, -1), (1, 1), (-1, -1)],
        "phi2": [(1, 0), (-1, 0), (0, 1), (0, -1), (1, 1), (-1, -1), (1, 2), (-1, -2)],
    }

    log.append("# 1. cubic quotients n x n: exact gap and its second-order prediction")
    for name, S in cases.items():
        Gm = sum(np.outer(np.array(s), np.array(s)) for s in S)
        mG = min(int(z @ Gm @ z) for z in itertools.product(range(-6, 7), repeat=2)
                 if z != (0, 0))
        log.append(f"\n{name}: degree {len(S)}, G = {Gm.tolist()}, "
                   f"arithmetic minimum m(G) = {mG}, "
                   f"lambda_min(G) = {np.linalg.eigvalsh(Gm)[0]:.9f}")
        rows = []
        for n in [2, 3, 4, 5, 6, 8, 10, 12, 16, 20, 25, 30, 40, 60, 80]:
            pts = lib.dual_points_2d(n, 0, n)
            vals = sorted((band(S, k) for k in pts))[::-1]
            mu = float(min(form(S, k) for k in pts
                           if k != (Fraction(0), Fraction(0))))
            gap = len(S)-vals[1]
            rows.append(dict(n=n, N=n*n, gap=gap, muG=mu,
                             leading=2*np.pi**2*mG/n**2,
                             ratio=gap/(2*np.pi**2*mG/n**2)))
            log.append(f"  n={n:3d}  N={n*n:5d}  gap={gap:.12e}  "
                       f"2 pi^2 m(G)/n^2={2*np.pi**2*mG/n**2:.12e}  "
                       f"ratio={gap/(2*np.pi**2*mG/n**2):.10f}")
        data[name] = dict(G=Gm.tolist(), mG=mG, cubic=rows)

    log.append("\n\n# 2. range of the gap over all index-N sublattices of Z^2")
    for name, S in cases.items():
        Gm = sum(np.outer(np.array(s), np.array(s)) for s in S)
        mG = data[name]["mG"]
        detG = float(np.linalg.det(Gm))
        gamma2 = 2/np.sqrt(3)
        log.append(f"\n{name}: G={Gm.tolist()}, m(G)={mG}, det G={detG:.6f}, "
                   f"gamma_2={gamma2:.9f}")
        log.append("   N   #sub   gap_min      gap_max     "
                   "min*N^2/(2pi^2 mG)   max*N/(2pi^2 gamma_2 sqrt(detG))")
        rows = []
        for N in [4, 6, 8, 12, 16, 25, 36, 49, 64, 100, 144, 196, 256]:
            r = sublattice_scan(S, N)
            gmin = min(x["gap"] for x in r)
            gmax = max(x["gap"] for x in r)
            ub = 2*np.pi**2*gamma2*np.sqrt(detG)/N
            rows.append(dict(N=N, nsub=len(r), gap_min=gmin, gap_max=gmax,
                             lower=2*np.pi**2*mG/N**2, upper=ub,
                             ratio_min=gmin/(2*np.pi**2*mG/N**2),
                             ratio_max=gmax/ub))
            log.append(f"  {N:4d} {len(r):5d}  {gmin:.6e}  {gmax:.6e}   "
                       f"{gmin/(2*np.pi**2*mG/N**2):.9f}          "
                       f"{gmax/ub:.9f}")
        data[name]["range"] = rows

    log.append("\n\n# 3. d = 3: exponent 2/d = 2/3 and the N^-2 extreme")
    S3 = [(1, 0, 0), (-1, 0, 0), (0, 1, 0), (0, -1, 0), (0, 0, 1), (0, 0, -1)]
    rows3 = []
    for n in [2, 3, 4, 6, 8, 12, 16, 24, 32]:
        pts = np.array(list(itertools.product(range(n), repeat=3)), dtype=float)/n
        vals = np.sort(np.cos(2*np.pi*pts).sum(axis=1))[::-1]
        gap = 6 - vals[1]
        rows3.append(dict(n=n, N=n**3, gap=gap, gapN23=gap*n**2,
                          leading=2*np.pi**2*2/n**2))
        log.append(f"  n={n:3d} N={n**3:6d} gap={gap:.12e} gap*n^2="
                   f"{gap*n*n:.9f}  2pi^2*2={2*np.pi**2*2:.9f}")
    data["d3_cubic"] = rows3

    log.append("\n\n# 4. arithmetic minimum vs analytic minimum of G")
    for name, S in cases.items():
        Gm = sum(np.outer(np.array(s), np.array(s)) for s in S)
        mG = data[name]["mG"]
        lmin = float(np.linalg.eigvalsh(Gm)[0])
        log.append(f"  {name}: m(G)/lambda_min(G) = {mG/lmin:.9f}"
                   f"   (1 if the soft eigenspace is rational)")

    json.dump(data, open(os.path.join(OUT, "s01_abelian.json"), "w"), indent=1)
    txt = "\n".join(log)
    open(os.path.join(OUT, "s01_abelian.log"), "w").write(txt)
    print(txt)


if __name__ == "__main__":
    main()
