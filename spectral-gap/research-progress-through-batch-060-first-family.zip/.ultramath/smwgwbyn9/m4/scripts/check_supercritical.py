import numpy as np, json
exec(open('scripts/check_secular.py').read().split('if __name__')[0])

def run2(n, d, Delta, seed):
    rng = np.random.default_rng(seed)
    A, tries = reg_config(n, d, rng)
    T = np.arange(Delta); ones = np.zeros(n); ones[T] = 1.0
    w, V = np.linalg.eigh(A)
    s = (V.T @ ones)**2
    M = np.zeros((n+1,n+1)); M[:n,:n] = A; M[T,n] = 1; M[n,T] = 1
    wM = np.linalg.eigvalsh(M)
    # all roots of secular function above bulk edge: scan
    def F(l): return l - np.sum(s/(l-w))
    edges = np.concatenate(([w[-1]*(1+1e-12)], (w[:-1]+w[1:])/2, [w[-1]+5]))
    roots=[]
    for a,b in zip(edges[:-1],edges[1:]):
        if b-a<1e-9: continue
        fa,fb = F(a),F(b)
        if fa*fb<0:
            lo,hi=a,b
            for _ in range(200):
                m=0.5*(lo+hi)
                if F(m)*(1 if fb>0 else -1)<0: lo=m
                else: hi=m
            roots.append(0.5*(lo+hi))
    Lp = np.linalg.pinv(d*np.eye(n)-A)
    Gam = ones@Lp@ones
    return dict(n=n,d=d,Delta=Delta,seed=seed,rej=tries,
        lam1=float(wM[-1]), lam2=float(wM[-2]), lam3=float(wM[-3]),
        n_shift_top=float(n*(wM[-1]-d)), n_shift_second=float(n*(d-wM[-2])),
        pred_top=float(Delta**2/(Delta*G_km(d,d)-d)),
        pred_second=float(Delta**2/(Delta*G_km(d,d)-d)),
        Gamma=float(Gam), Delta_G=float(Delta*G_km(d,d)),
        roots=[round(float(r),8) for r in roots],
        lamstar=root_lambda(d,Delta), lam2host=float(w[-2]))

for n in (1000,2000,4000):
    for seed in (11,12):
        print(json.dumps(run2(n,3,6,100*n+seed)))
