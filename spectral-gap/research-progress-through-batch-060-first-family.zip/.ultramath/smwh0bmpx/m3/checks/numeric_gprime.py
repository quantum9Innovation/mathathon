"""Direct eigensolver / resolvent verification for the T=N(c) clustered family.

Model: G_n uniform simple d-regular (pairing model with rejection conditional on
simplicity -- exactly uniform, each simple graph has (d!)^n pairings); c = 0;
T = N(c) (exactly d vertices); G' = G_n plus one new vertex x adjacent exactly to T.

Predictions (Phi = lam - G_d[d+d(d-1)r^2], lambda_* = 2d/sqrt(d+1)):
  resolvent: 1_T^T (A-lam)^-1 1_T = -K(lam) + d^2/(n(d-lam)) + o(1)
  lambda_1(G') -> d,  lambda_2(G') -> lambda_*
  d>=4: n(lambda_1-d) -> d^2/Phi(d) = d(d-2)/(d-3)
  d=3 : sqrt(n)(lambda_1-3) -> 3/sqrt(Phi'(3)) = 3/sqrt8, sqrt(n)(3-lambda_2) -> 3/sqrt8
  secular zero in the gap = lambda_2(G') exactly.
Usage: python3 numeric_gprime.py <d> <n> <seed>
"""
import sys, json, numpy as np
from scipy.sparse import csr_matrix, identity
from scipy.sparse.linalg import eigsh, spsolve

def pairing_graph(n, d, rng):
    """random simple d-regular graph via pairing model, conditioned on simplicity"""
    stubs = np.repeat(np.arange(n), d)
    tries = 0
    while True:
        tries += 1
        perm = rng.permutation(stubs.size)
        p = stubs[perm].reshape(-1, 2)
        a, b = p[:, 0], p[:, 1]
        if np.any(a == b):
            continue
        lo = np.minimum(a, b).astype(np.int64); hi = np.maximum(a, b).astype(np.int64)
        key = lo * n + hi
        if np.unique(key).size != key.size:
            continue
        return lo, hi, tries

def r_of_lam(lam, d):
    disc = lam * lam - 4 * (d - 1)
    return (lam - np.sqrt(disc)) / (2 * (d - 1))

def K_of_lam(lam, d):
    r = r_of_lam(lam, d)
    return r / (1 - r * r) * (d + d * (d - 1) * r * r)

def Phi(lam, d):
    return lam - K_of_lam(lam, d)

def main(d, n, seed):
    rng = np.random.default_rng(seed)
    lo, hi, tries = pairing_graph(n, d, rng)
    edges = np.concatenate([lo, hi]); edges2 = np.concatenate([hi, lo])
    A = csr_matrix((np.ones(edges.size), (edges, edges2)), shape=(n, n))
    deg = np.asarray(A.sum(axis=1)).ravel()
    assert np.all(deg == d), (deg[:5], d)
    T = np.where(A[0].toarray().ravel() > 0)[0]
    assert T.size == d and 0 not in T
    # G' : n+1 vertices, vertex n adjacent exactly to T
    rows = np.concatenate([edges, T, np.full(T.size, n)])
    cols = np.concatenate([edges2, np.full(T.size, n), T])
    Ap = csr_matrix((np.ones(rows.size), (rows, cols)), shape=(n + 1, n + 1))
    # host eigenvalues (top)
    ev_host = np.sort(eigsh(A.astype(float), k=4, which='LA', tol=0)[0])[::-1]
    # G' eigenvalues (top)
    ev_g = np.sort(eigsh(Ap.astype(float), k=4, which='LA', tol=0)[0])[::-1]
    # secular function and its zero in the gap (A - lam I) x = 1_T
    oneT = np.zeros(n); oneT[T] = 1.0
    Aminus = (A - identity(n)).tocsr()
    def Sigma(lam):
        x = spsolve((A - lam * identity(n)).tocsc(), oneT)
        return lam + x[T].sum()
    lam_lo = ev_host[1] + 1e-3      # just above the host's second eigenvalue
    lam_hi = d - 1e-4
    # bisect; Sigma is strictly increasing and continuous on the host gap
    a, b = lam_lo, lam_hi
    fa, fb = Sigma(a), Sigma(b)
    assert fa * fb < 0, (fa, fb, ev_host)
    for _ in range(80):
        m = 0.5 * (a + b); fm = Sigma(m)
        if fa * fm <= 0: b, fb = m, fm
        else: a, fa = m, fm
    zero = 0.5 * (a + b)
    # resolvent kernel check at points away from the spectrum
    lams = [1.0 + x for x in ev_host[1:2]] if False else []
    res = []
    for lam in ([3.2, 4.0, 5.0, 6.0] if d == 3 else [4.5, 5.5, 6.5]):
        x = spsolve((A - lam * identity(n)).tocsc(), oneT)
        measured = x[T].sum()
        pred = -K_of_lam(lam, d) + d ** 2 / (n * (d - lam))
        res.append(dict(lam=lam, measured=float(measured), predicted=float(pred),
                        diff=float(measured - pred),
                        naive_minus_dGd=float(-d * r_of_lam(lam, d) / (1 - r_of_lam(lam, d) ** 2))))
    out = dict(d=d, n=n, seed=seed, tries=tries, acceptance=1.0 / tries,
               pred_accept=float(np.exp(-(d * d - 1) / 4)),
               T=list(map(int, T)), ev_host=list(map(float, ev_host)),
               ev_g=list(map(float, ev_g)),
               lambda_star=2 * d / np.sqrt(d + 1), edge=2 * np.sqrt(d - 1),
               secular_zero=float(zero), zero_minus_lambda2Gp=float(zero - ev_g[1]),
               resolvent=res,
               lam2_pred=float(np.sqrt(2 * d / np.sqrt(d + 1) ** 0)),
               Phi_at_d=float(Phi(d, d)))
    # finite-size laws
    if d >= 4:
        out['n_times_lambda1_minus_d'] = float(n * (ev_g[0] - d))
        out['pred_n_lambda1'] = float(d * (d - 2) / (d - 3))
    else:
        out['sqrtn_lambda1_minus_d'] = float(np.sqrt(n) * (ev_g[0] - d))
        out['sqrtn_d_minus_lambda2'] = float(np.sqrt(n) * (d - ev_g[1]))
        out['pred_sqrtn'] = float(d / np.sqrt(2 * (d + 1)))
    out['lambda2_minus_star'] = float(ev_g[1] - 2 * d / np.sqrt(d + 1))
    print(json.dumps(out))
    return out

if __name__ == '__main__':
    d, n, seed = int(sys.argv[1]), int(sys.argv[2]), int(sys.argv[3])
    main(d, n, seed)
