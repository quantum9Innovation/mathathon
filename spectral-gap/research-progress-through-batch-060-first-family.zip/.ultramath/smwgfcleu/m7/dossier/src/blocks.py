"""Isotypic block decomposition of Cayley graph spectra, verified numerically."""
import sys
sys.path.insert(0, 'dossier/src')
import numpy as np
from cayley import *
from characters import chi, partitions, a5_character_table, A5_CLASSES


def class_sum_matrices(G):
    """C[c] = sum_{g in class c} P_g as a dense matrix."""
    n = G.n
    out = []
    for C in G.classes:
        M = np.zeros((n, n))
        for g in C:
            M[np.arange(n), G.T[g]] += 1.0
        out.append(M)
    return out


def sn_data(G, n):
    """Return list of (label, degree, character vector on G.classes)."""
    # G.classes for S_n are conjugacy classes; identify the cycle type of each class
    parts = list(partitions(n))
    data = []
    for lam in parts:
        deg = chi(lam, tuple([1] * n))
        chars = []
        for C in G.classes:
            mu = cycle_type(G.els[C[0]])
            chars.append(chi(lam, mu))
        data.append((str(lam), deg, chars))
    return data


def a5_data(G):
    degrees, chars = a5_character_table()
    # need the ordering of G.classes for A5 to match [1,(2,2),(3),(5)A,(5)B]
    # identify by cycle type and size; the two 5-classes are distinguished arbitrarily
    labels = []
    idx = []
    remaining = list(range(len(G.classes)))
    order = []
    for want_ct, want_size in [((1, 1, 1, 1, 1), 1), ((2, 2, 1), 15), ((3, 1, 1), 20)]:
        for c in remaining:
            C = G.classes[c]
            if len(C) == want_size and cycle_type(G.els[C[0]]) == want_ct:
                order.append(c)
                remaining.remove(c)
                break
    fives = [c for c in remaining if len(G.classes[c]) == 12]
    assert len(fives) == 2
    order += fives
    out = []
    for r in range(5):
        out.append(('chi%d' % r, degrees[r], [chars[r][order.index(c)] for c in range(len(G.classes))]))
    return out


def iso_projector(G, chars, deg, Csum):
    n = G.n
    P = np.zeros((n, n), dtype=complex)
    for c in range(len(G.classes)):
        P += np.conj(chars[c]) * Csum[c]
    P *= deg / n
    return P


def basis_of_image(P, tol=1e-8):
    w, V = np.linalg.eigh(P)
    sel = np.where(np.abs(w - 1.0) < tol)[0]
    return V[:, sel]


def block_spectra(G, S, data, tol=1e-7, verbose=True):
    n = G.n
    Csum = class_sum_matrices(G)
    A = G.adjacency(S)
    ev = np.linalg.eigvalsh(A)
    allblocks = []
    rows = []
    for (label, deg, chars) in data:
        P = iso_projector(G, chars, deg, Csum)
        Q = basis_of_image(P)
        assert Q.shape[1] == deg * deg, (label, Q.shape, deg)
        M = Q.conj().T @ A @ Q
        M = (M + M.conj().T) / 2
        bev = np.linalg.eigvalsh(M)
        rows.append((label, deg, float(np.max(np.abs(bev))), bev))
        allblocks.append(bev)
    uni = np.sort(np.concatenate(allblocks))
    err = np.max(np.abs(uni - ev))
    if verbose:
        print("  multiset-law check: max |union(blocks) - spec(A)| = %.3e" % err)
        for (label, deg, mx, bev) in rows:
            mult = []
            for x in np.round(bev, 7):
                mult.append(int(np.sum(np.abs(np.round(bev, 7) - x) < 1e-6)))
            print("    irrep %-10s deg=%2d  block max|lambda|=%9.6f  block spec=%s"
                  % (label, deg, mx, np.round(bev, 6)))
    return rows, ev, uni
