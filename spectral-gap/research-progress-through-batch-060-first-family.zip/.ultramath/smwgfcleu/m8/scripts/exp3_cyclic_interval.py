"""The cyclic interval hypergraph H(q,k): a periodic (hence 'almost regular') family
whose Feng-Li gap is Theta(1/n^2), in sharp contrast with the random case.

H(q,k): vertex set Z_q, edges {i,i+1,...,i+k-1} mod q for i in Z_q.  Then d = k, k-uniform,
and A_H is circulant with first row A_{0,j} = k - |j| for 1 <= |j| <= k-1 (cyclic distance).
Symbol p(theta) = 2 sum_{j=1}^{k-1} (k-j) cos(j theta).
"""
import numpy as np
import sympy as sp
from hyp import cyclic_interval_hypergraph, fengli, spec, window

print("=== A. exact symbol and its expansion near theta = 0 ===")
th = sp.symbols("theta", real=True)
for k in (2, 3, 4, 5, 6):
    p = 2 * sum((k - j) * sp.cos(j * th) for j in range(1, k))
    p0 = sp.simplify(p.subs(th, 0))
    c2 = sp.simplify(-sp.diff(p, th, 2).subs(th, 0) / 2)
    c4 = sp.simplify(sp.diff(p, th, 4).subs(th, 0) / 24)
    pred_c2 = sp.Rational(k * k * (k * k - 1), 12)
    assert sp.simplify(c2 - pred_c2) == 0, (k, c2, pred_c2)
    print(f"k={k}: p(0)={p0} (= k(k-1) = d(k-1)), deficit = {c2} theta^2 - {sp.simplify(-c4)} theta^4 + O(theta^6)")
    print(f"      c2 = k^2(k^2-1)/12 = {pred_c2},  S4 = sum j^4 (k-j) = {sp.simplify(c4*12)}")

print("\n=== B. gap of the q-cyclic quotient vs pi^2 k^2 (k^2-1) / (3 q^2) ===")
print("prediction  d(k-1) - lambda_2 = pi^2 k^2 (k^2-1)/(3 q^2) + O(q^-4)")
print(f"{'k':>2} {'q':>6} {'lambda_2':>14} {'gap':>14} {'gap*q^2/coef':>14} {'S4 correction ratio':>22}")
for k in (3, 4, 5, 6):
    coef = np.pi ** 2 * k ** 2 * (k ** 2 - 1) / 3
    S4 = int(sp.simplify(sum(j ** 4 * (k - j) for j in range(1, k))))
    for q in (60, 120, 240, 480):
        E, n = cyclic_interval_hypergraph(q, k)
        A, X = fengli(E, n)
        w = spec(A)
        d = k
        gap = d * (k - 1) - w[1]
        lead = coef / q ** 2
        corr = 4 * np.pi ** 4 * S4 / (3 * q ** 4)
        print(f"{k:2d} {q:6d} {w[1]:14.10f} {gap:14.8e} {gap*q*q/coef:14.8f} {(gap-lead)/(-corr):22.8f}")
    print()

print("=== C. pariteness: -d is an eigenvalue with multiplicity >= k-1 when k | q ===")
for k in (3, 4, 5):
    for q in (k, 2 * k, 3 * k):
        if q < k + 1:
            continue
        E, n = cyclic_interval_hypergraph(q, k)
        A, X = fengli(E, n)
        w = spec(A)
        mult = int(np.sum(np.abs(w + k) < 1e-9))
        lo, hi = window(k, k)
        print(f"k={k} q={q:3d}: mult(-d) = {mult} (k-1 = {k-1}), lambda_min={w[-1]:9.5f}, "
              f"window=({lo:.5f},{hi:.5f}), d(k-1)-lambda_2={k*(k-1)-w[1]:.8f}")
        assert mult >= k - 1

print("\n=== D. exact rational check for small q (sympy) ===")
for k in (3, 4):
    for q in (k + 2, k + 5, 2 * k, 2 * k + 1, 3 * k):
        E, n = cyclic_interval_hypergraph(q, k)
        A, _ = fengli(E, n)
        M = sp.Matrix(A.tolist())
        cp = sp.factor(M.charpoly().as_expr())
        print(f"k={k} q={q}: char poly factors over Q as {cp}")
