"""Exact checks (rational arithmetic, no floating point where it matters) for:
 (1) rank-one Perron splitting: A' = A - dP,  (A'^k)_{yy'} = (A^k)_{yy'} - d^k/n  for k>=1.
 (2) the added-vertex secular identity p_{G'} = p_G * (lam + 1_T^T (A_G-lam)^{-1} 1_T).
 (3) truncated spiked tree: fixed-T resolvent limit -Delta*r(lam) vs -Delta*G_d(lam).
 (4) closed forms G_d(d), G_d(2 sqrt(d-1)); thresholds.
"""
from fractions import Fraction as F
import json

def matmul(A, B):
    n = len(A); m = len(B[0]); k = len(B)
    return [[sum(A[i][t]*B[t][j] for t in range(k)) for j in range(m)] for i in range(n)]

def ident(n):
    return [[F(1) if i == j else F(0) for j in range(n)] for i in range(n)]

def addmul(A, B, c=F(1)):
    n = len(A); m = len(A[0])
    return [[A[i][j] + c*B[i][j] for j in range(m)] for i in range(n)]

def det(M):
    n = len(M); A = [row[:] for row in M]; d = F(1)
    for i in range(n):
        p = None
        for r in range(i, n):
            if A[r][i] != 0:
                p = r; break
        if p is None: return F(0)
        if p != i:
            A[i], A[p] = A[p], A[i]; d = -d
        d *= A[i][i]; inv = F(1)/A[i][i]
        for r in range(i+1, n):
            f = A[r][i]*inv
            if f != 0:
                for c in range(i, n):
                    A[r][c] -= f*A[i][c]
    return d

def charpoly_coeffs(A):
    """p_0..p_n with det(lam I - A) = sum p_k lam^k, exact by interpolation."""
    n = len(A); pts = list(range(-n, n+1)); vals = []
    for x in pts:
        M = [[F(x) if i == j else F(0) for j in range(n)] for i in range(n)]
        vals.append(det(addmul(M, A, F(-1))))
    coeffs = [F(0)]*len(pts)
    for idx, x0 in enumerate(pts):
        num = [F(1)]; den = F(1)
        for j, xj in enumerate(pts):
            if j == idx: continue
            num = [F(0)] + num
            for i in range(len(num)-1):
                num[i] -= xj*num[i+1]
            den *= (x0 - xj)
        f = vals[idx]/den
        for i in range(len(num)):
            coeffs[i] += f*num[i]
    while len(coeffs) > 1 and coeffs[-1] == 0:
        coeffs.pop()
    return coeffs

def peval(p, x):
    s = F(0)
    for c in reversed(p): s = s*x + c
    return s

def cycle(n):
    A = [[0]*n for _ in range(n)]
    for i in range(n):
        A[i][(i+1) % n] = A[(i+1) % n][i] = 1
    return A

def cube():
    A = [[0]*8 for _ in range(8)]
    for v in range(8):
        for b in range(3):
            w = v ^ (1 << b); A[v][w] = 1
    return A

def k33():
    A = [[0]*6 for _ in range(6)]
    for i in range(3):
        for j in range(3, 6): A[i][j] = A[j][i] = 1
    return A

report = {}

# (1) rank-one identity, exact over Q
checks1 = []
for name, d, A in [("C6", 2, cycle(6)), ("Q3", 3, cube()), ("K33", 3, k33())]:
    n = len(A)
    P = [[F(1, n)]*n for _ in range(n)]
    Ap = [[F(A[i][j]) - d*P[i][j] for j in range(n)] for i in range(n)]
    ok = True; Pk = ident(n); Apk = ident(n)
    Af = [[F(x) for x in row] for row in A]
    for k in range(1, 7):
        Pk = matmul(Pk, Af); Apk = matmul(Apk, Ap)
        pred = [[Pk[i][j] - F(d**k, n) for j in range(n)] for i in range(n)]
        ok = ok and (pred == Apk)
    checks1.append({"graph": name, "d": d, "n": n,
                    "identity (A'^k)_yy'=(A^k)_yy'-d^k/n checked k=1..6": ok})
report["rank_one_identity"] = checks1

# (2) secular identity, exact.  We verify  p_A(x)*x + p_A(x)*quad_A(x) == p_B(x)
#     at enough points;  p_A(x)*quad_A(x) = p_A(x) * 1_T^T(xI-A)^{-1}1_T = 1_T^T adj(xI-A) 1_T.
def adj_quad(A, T, x):
    n = len(A)
    M = addmul([[F(x) if i == j else F(0) for j in range(n)] for i in range(n)], A, F(-1))
    aug = [M[i][:] + [F(1) if i in T else F(0)] for i in range(n)]
    for i in range(n):
        p = None
        for r in range(i, n):
            if aug[r][i] != 0: p = r; break
        if p is None: return None
        aug[i], aug[p] = aug[p], aug[i]
        inv = F(1)/aug[i][i]; aug[i] = [y*inv for y in aug[i]]
        for r in range(n):
            if r != i and aug[r][i] != 0:
                f = aug[r][i]
                aug[r] = [aug[r][c] - f*aug[i][c] for c in range(n+1)]
    X = [aug[i][n] for i in range(n)]
    return sum(X[y] for y in T)

def add_vertex(A, T):
    n = len(A)
    B = [[F(x) for x in row] + [F(0)] for row in A] + [[F(0)]*(n+1)]
    for y in T: B[y][n] = B[n][y] = F(1)
    return B

checks2 = []
for name, A, T in [("C6 + spike (T=2 opposite)", cycle(6), [0, 3]),
                   ("Q3 + spike (T=5 vertices)", cube(), [0, 1, 2, 4, 7]),
                   ("K33 + spike (T=one side)", k33(), [0, 1, 2]),
                   ("C5 + spike (T=3)", cycle(5), [0, 1, 2])]:
    n = len(A); B = add_vertex(A, T)
    pA = charpoly_coeffs(A); pB = charpoly_coeffs(B)
    ok = True; npts = 0
    for x in [F(v) for v in range(-24, 25)]:
        q = adj_quad(A, T, x)
        if q is None: continue
        npts += 1
        if peval(pA, x)*x - peval(pA, x)*q != peval(pB, x):
            ok = False
    checks2.append({"instance": name, "exact identity at": npts, "points": ok})
report["secular_identity"] = checks2

# (3) truncated spiked tree: fixed-T quadratic form on the ball
import sympy as sp
lam = sp.symbols('lam', positive=True)

def r_of(d, L):
    return (L - sp.sqrt(L**2 - 4*(d-1)))/(2*(d-1))

def G_of(d, L):
    r = r_of(d, L)
    return sp.simplify(r/(1 - r**2))

def tree_resolvent_BT(d, D, R, Lv):
    """Exact rational-function evaluation of 1_T^T (A_{B_R}-Lv)^{-1} 1_T for the ball B_R
    of radius R about the degree-D vertex o of T(d,D), with T = N(o) (D neighbours).
    Evaluated with high-precision floats via tridiagonal (radial) reduction:
    the graph is a spherically symmetric tree, so we solve level by level."""
    import mpmath as mp
    mp.mp.dps = 40
    L = mp.mpf(Lv)
    # spherical symmetry: u_n = value at each vertex of level n (n=1..R), u_0 at o.
    # Resolvent equations:  (A z)_v  with RHS = 1 on level 1, 0 elsewhere.
    # level n>=1 has children count (d-1) except level R (leaves) : 0 children.
    #   -L z_n + z_{n-1} + (d-1) z_{n+1} = rhs_n   for 1<=n<=R-1,  z_0 = z^{(0)}
    #   -L z_0 + D z_1 = 0      (RHS on o is 0)
    #   -L z_R + z_{R-1} = 0    (leaves)
    # Solve by backward elimination: z_n = a_n z_{n-1} + b_n
    a = [None]*(R+1); b = [None]*(R+1)
    a[R] = mp.mpf(1)/L; b[R] = mp.mpf(0)
    for n in range(R-1, 0, -1):
        # -L z_n + z_{n-1} + (d-1) z_{n+1} = rhs_n, rhs_1 = 1, else 0
        rhs = mp.mpf(1) if n == 1 else mp.mpf(0)
        # substitute z_{n+1} = a_{n+1} z_n + b_{n+1}
        den = -L + (d-1)*a[n+1]
        a[n] = -mp.mpf(1)/den
        b[n] = (rhs - (d-1)*b[n+1])/den
    # at o: -L z_0 + D z_1 = 0, z_1 = a_1 z_0 + b_1
    z0 = D*b[1]/(L - D*a[1])
    z1 = a[1]*z0 + b[1]
    quad = D*z1           # sum over the D neighbours of o
    return z0, quad

tree_checks = []
import mpmath as mp
mp.mp.dps = 40
for d, D, Lv in [(3, 5, "2.95"), (3, 6, "3.18"), (4, 7, "3.60"), (5, 9, "4.10")]:
    edge = 2*(d-1)**0.5
    assert float(Lv) > edge, (Lv, edge)
    Ls = sp.Rational(Lv)
    G = float(G_of(d, Ls)); r = float(r_of(d, Ls))
    row = {"d": d, "Delta": D, "lam": Lv, "2sqrt(d-1)": round(edge, 6),
           "-Delta*G_d (host prediction)": round(-D*G, 8),
           "-Delta*r (one-sided tree branch)": round(-D*r, 8),
           "ratio G_d/r = 1/(1-r^2)": round(G/r, 8),
           "spiked tree limit Delta*lam*r/(Delta*r-lam)": round(D*float(Ls)*r/(D*r-float(Ls)), 8),
           "lambda_* = Delta/sqrt(Delta+1-d)": round(D/((D+1-d)**0.5), 8),
           "ball radii": {}}
    for R in [8, 16, 32, 64]:
        z0, quad = tree_resolvent_BT(d, D, R, Lv)
        row["ball radii"][R] = round(float(quad), 8)
    tree_checks.append(row)
report["truncated_spiked_tree_fixedT_resolvent"] = tree_checks

# (4) closed forms and thresholds
closed = {}
for d in [3, 4, 5, 6]:
    G1 = sp.simplify(G_of(d, sp.Integer(d)))
    assert sp.simplify(G1 - sp.Rational(d-1, d*(d-2))) == 0
    G2 = sp.simplify(G_of(d, 2*sp.sqrt(d-1)))
    assert sp.simplify(G2 - sp.sqrt(d-1)/(d-2)) == 0
    closed[d] = {"G_d(d)": str(G1), "G_d(2sqrt(d-1))": str(G2)}
report["closed_forms"] = closed

# lambda_f via bisection
lams = {}
for d, D in [(3,3),(3,4),(3,5),(3,6),(4,7),(5,8),(5,9)]:
    if D <= 2*(d-2):
        lams[f"{d},{D}"] = {"lambda_f": None, "note": "Delta<=2(d-2): no root"}
        continue
    def Fh(x):
        xx = sp.Float(x, 40)
        return float(xx - D*G_of(d, xx))
    a, b = 2*(d-1)**0.5 + 1e-12, 1e3
    for _ in range(300):
        m = 0.5*(a+b)
        if Fh(m) < 0: a = m
        else: b = m
    lams[f"{d},{D}"] = {"lambda_f": round(0.5*(a+b), 9),
                        "2sqrt(d-1)": round(2*(d-1)**0.5, 6), "d": d,
                        "Delta*G_d(d)-d": round(D*(d-1)/(d*(d-2)) - d, 9),
                        "d^2(d-2)/(d-1)": round(d*d*(d-2)/(d-1), 4)}
report["lambda_f"] = lams

print(json.dumps(report, indent=2, default=str))
