"""Symbolic verification of the T = N(c) clustered secular law.

Conventions (identical to results/050-finite-defect.md and to the frozen
separated-case proof .ultramath/smwgwbyn9/m2/proof.md):
  lambda > 2 sqrt(d-1), r = r(lambda) the SMALL root of (d-1) r + 1/r = lambda,
  0 < r < 1/sqrt(d-1);   G_d = r/(1-r^2) = 1/(lambda - d r).
We treat r as the parameter and lambda = (d-1) r + 1/r.
"""
import sympy as sp

d, r, lam, s = sp.symbols('d r lambda s', positive=True)

lam_of_r = (d - 1) * r + 1 / r          # lambda as a function of r
Gsym = r / (1 - r**2)                    # G_d expressed in r

def sub(x):
    """Express a rational function of lambda and r in terms of r only."""
    return sp.simplify(sp.expand(x.subs(lam, lam_of_r)))

out = {}

# ---- 1. basic identities -------------------------------------------------
# G_d = 1/(lambda - d r)
e1 = sp.simplify(sub(1 / (lam - d * r)) - Gsym)
out['Gd_eq_inv_lambda_minus_dr'] = e1

# ---- 2. the three kernel forms ------------------------------------------
K_pos  = Gsym * (d + d * (d - 1) * r**2)                     # positive coordinates
K_alg  = d * lam * r / (lam - d * r)                         # algebraic form
K_split = d * r + d**2 * r**2 / (lam - d * r)                # diagonal + rank-one
e2 = sp.simplify(sub(K_alg) - K_pos)
e3 = sp.simplify(sub(K_split) - K_pos)
# and the separated / adjacent specialisations
K_adj   = Gsym * (2 + 2 * r)
K_adj2  = 2 * r / (1 - r)
e4 = sp.simplify(sub(K_adj) - K_adj2)
K_pair  = Gsym * (2 + 2 * r**2)     # two vertices at distance 2 (unused cross-check)
e5 = sp.simplify(sub(Gsym * (2 + 2 * r)) - 2*r/(1-r))
out['K_three_forms_equal (alg, split)'] = (e2, e3)
out['K_adj_forms_equal'] = e4

# ---- 3. reduced (d+1) x (d+1) tree matrix inverse ------------------------
# Eliminate the d-1 pendant branches of each neighbour u of o.  Each pendant
# branch (an infinite d-regular tree hanging from a neighbour of u) has root
# self-energy r, i.e. contributes  -r  to the (u,u) entry of the resolvent.
# Hence on {o} u T the reduced matrix of (lambda - A_{T_d}) is
#   D = diag(lambda, 1/r, ..., 1/r)  (since lambda - (d-1) r = 1/r)
# with 1's between o and every u in T.  Its inverse restricted to T gives
#   G_{uu} = a, G_{uv} = b (u != v)  with the Sherman-Morrison structure.
a_uu, b_uv = sp.symbols('a_uu b_uv')
Delta = d                                  # |T| = |N(o)| = d
# Woodbury for D + 1o^T + o1^T with D = diag(lam, 1/r,...,1/r) on {o} u T
# work with exact matrices of size (Delta+1)
n_ = 3   # placeholder; do the general case by symbolic block algebra instead
# Shermann-Morrison: M = diag(lam, q I) + (e_0 1^T + 1 e_0^T), q = 1/r.
# Inverse on the T-block = q^{-1} I + (q^{-1})^2 1 (lam - Delta q^{-1})^{-1} 1^T ... derive below.
q = 1 / r
# Schur complement of the centre (scalar) block:  q I - (1/lam) 1 1^T,
# whose Sherman-Morrison inverse is  q^-1 I + q^-2/(lam - Delta q^-1) 1 1^T
lam_minus = lam - Delta / q          # = lam - Delta*r
G_uu = q**-1 + q**-2 / lam_minus
G_uv = q**-2 / lam_minus
e6 = sp.simplify(sub(G_uu) - r * (lam - d * r + r) / (lam - d * r))   # m6's formula
e7 = sp.simplify(sub(G_uv) - r**2 / (lam - d * r))
out['reduced_inverse_diag'] = e6
out['reduced_inverse_offdiag'] = e7
sum_ = Delta * G_uu + Delta * (Delta - 1) * G_uv
e8 = sp.simplify(sub(sum_) - K_pos)
out['Tblock_sum_equals_K'] = e8

# ---- 4. secular polynomial in r -----------------------------------------
f = sp.simplify(sub(lam - K_pos))            # Phi_{N(c)}
# clear denominators
num = sp.simplify(sp.numer(sp.together(f)))
den = sp.simplify(sp.denom(sp.together(f)))
P = sp.expand(sp.simplify(num * r * (1 - r**2) / 1))
P = sp.expand(sp.simplify(sp.together(f) * r * (1 - r**2)))
out['Phi_times_r(1-r^2)'] = sp.expand(P)
# claimed: P = 1 - 2 r^2 - (d^2-1) r^4
out['Phi_factorization_residual'] = sp.expand(P - (1 - 2*r**2 - (d**2 - 1)*r**4))

# ---- 5. roots -----------------------------------------------------------
svar = sp.symbols('s', positive=True)
Pq = sp.expand((1 - 2*svar - (d**2 - 1)*svar**2))
roots_s = sp.solve(sp.Eq(Pq, 0), svar)
out['roots_in_s=r^2'] = [sp.simplify(x) for x in roots_s]
rstar2 = sp.Rational(1, 1) / (d + 1)
lam_star = sp.simplify((d - 1) * sp.sqrt(rstar2) + 1 / sp.sqrt(rstar2))
out['lambda_star'] = sp.simplify(lam_star)
out['lambda_star_equals_2d_over_sqrt(d+1)'] = sp.simplify(lam_star - 2*d/sp.sqrt(d+1))
out['rstar2_below_1/(d-1)'] = sp.simplify(rstar2 - 1/(d-1))    # should be negative

# derivative of Phi at the root:  Phi = lam - K, dK/dr etc.
K_of_r = sp.simplify(sub(K_pos))
dKdr = sp.diff(K_of_r, r)
dlamdr = sp.diff(lam_of_r, r)
dPhidlam = sp.simplify(1 - dKdr / dlamdr)
out['Phi_prime_at_rstar'] = sp.simplify(dPhidlam.subs(r, sp.sqrt(rstar2)))
out['Phi_prime_minus_2(d+1)'] = sp.simplify(dPhidlam.subs(r, sp.sqrt(rstar2)) - 2*(d+1))

# ---- 6. endpoint values -------------------------------------------------
b = 2 * sp.sqrt(d - 1)
r_b = 1 / sp.sqrt(d - 1)
K_at_b = sp.simplify(K_of_r.subs(r, r_b))
Phi_at_b = sp.simplify(b - K_at_b)
out['K_at_edge'] = sp.simplify(K_at_b)
out['K_at_edge_expected'] = sp.simplify(2*d*sp.sqrt(d-1)/(d-2))
out['Phi_at_edge'] = Phi_at_b
out['Phi_at_edge_expected'] = sp.simplify(-4*sp.sqrt(d-1)/(d-2))

# value and derivative at lambda = d  (r = 1/(d-1))
r_d = 1 / (d - 1)
out['Phi_at_d'] = sp.simplify((lam_of_r - K_of_r).subs(r, r_d))
out['Phi_at_d_expected'] = sp.simplify(d*(d-3)/(d-2))
out['Phi_prime_at_d'] = sp.simplify(dPhidlam.subs(r, r_d))
out['Gd_at_d'] = sp.simplify(Gsym.subs(r, r_d))
out['Gd_at_d_expected'] = sp.simplify((d-1)/(d*(d-2)))
out['Gd_at_edge'] = sp.simplify(Gsym.subs(r, r_b))
out['lambda_star_eq_d_iff'] = sp.solve(sp.Eq(2*d/sp.sqrt(d+1), d), d)

# ---- 7. lambda - d r never vanishes on the physical branch -------------
out['lambda_minus_dr_over_r'] = sp.simplify(sub(lam - d*r) - (1 - r**2)/r)

# ---- 8. threshold: sum_{s,t} r^{rho} at the edge vs 2(d-2) -------------
out['Sigma_at_edge_minus_2(d-2)'] = sp.simplify(2*d - 2*(d-2))

# ---- 9. adjacent-pair cubic (cross-check of the recovery statement) -----
Kadj_of_r = sp.simplify(sub(Gsym*(2 + 2*r)))
fadj = sp.simplify((lam_of_r - Kadj_of_r) * r * (1 - r))
out['adj_cubic'] = sp.expand(sp.simplify(fadj))
out['adj_at_d'] = sp.simplify((lam_of_r - Kadj_of_r).subs(r, r_d))
out['adj_at_d_expected'] = sp.simplify((d**2 - 2*d - 2)/(d - 2))
# two vertices at distance ell: K = G_d (2 + 2 r^ell) -> 2 G_d as ell -> inf
out['pair_dist1_matches_adj'] = sp.simplify(sub(Gsym*(2 + 2*r**1)) - Kadj_of_r)

for k, v in out.items():
    print(f"{k}:\n    {v}\n")
