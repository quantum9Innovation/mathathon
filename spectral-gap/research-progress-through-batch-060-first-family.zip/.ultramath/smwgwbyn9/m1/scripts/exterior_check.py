"""Numerical check of the moment route to the exterior resolvent limit.
  (1) exact moment identity  (A^k)_{yy} = m_k(KM)  for k <= 2*L(y), L(y)= tree radius at y
  (2) deviation |1_T^T (A-lam)^{-1} 1_T + Delta G_d(lam)| vs n, with predicted power rate
Fixed seeds; honest sampler (configuration model + rejection of non-simple)."""
import numpy as np, json, sys

def config_regular(n, d, rng):
    while True:
        stubs = np.repeat(np.arange(n), d)
        rng.shuffle(stubs)
        a = stubs[0::2]; b = stubs[1::2]
        if np.any(a == b):
            continue
        lo = np.minimum(a, b); hi = np.maximum(a, b)
        key = lo.astype(np.int64) * n + hi
        if len(np.unique(key)) != len(key):
            continue            # multi-edge
        A = np.zeros((n, n), dtype=np.int8)
        A[a, b] = 1; A[b, a] = 1
        return A

def km_moments(d, K):
    a=np.zeros(K+1,dtype=object); b=np.zeros(K+1,dtype=object)
    a[0]=1; b[0]=0
    for j in range(1,K+1):
        a[j]=d*b[j-1]; b[j]=a[j-1]+(d-1)*b[j-1]
    return a

def tree_radius(A, y, Lmax):
    """largest L with B(y,L) a tree (checked up to Lmax); returns L in [0,Lmax]"""
    n = A.shape[0]; seen = np.zeros(n, bool)
    frontier = [y]; seen[y]=True; depth=0; edges=0; verts=1
    while depth < Lmax:
        nf=[]
        for u in frontier:
            for w in np.nonzero(A[u])[0]:
                if not seen[w]:
                    seen[w]=True; verts+=1; nf.append(w)
                else:
                    edges+=1
        edges += 0
        # count edges inside ball after adding level: recount
        frontier = nf; depth+=1
        if len(frontier)==0: break
        # ball of radius depth induces edges; tree iff #edges = verts-1 (connected)
    # recompute induced edge count exactly
    verts_idx = np.nonzero(seen)[0]
    e = A[np.ix_(verts_idx, verts_idx)].sum()//2
    if e != len(verts_idx)-1:
        return -1   # not a tree within Lmax
    return depth

def g_d(lam, d):
    """G_d(lam) = r/(1-r^2), r the root of (d-1)r+1/r=lam with |r|<1"""
    # (d-1)r^2 - lam r + 1 = 0
    disc = lam*lam - 4*(d-1)
    r = (lam - np.sqrt(disc))/(2*(d-1))
    return r/(1-r*r), r

d = 3
K = 14
m = km_moments(d, K)
print("KM moments d=3:", [int(x) for x in m[:13]])

# ---------- (1) moment identity ----------
rng = np.random.default_rng(2026050)
n = 3000
A = config_regular(n, d, rng).astype(np.int64)
Pk = np.eye(n, dtype=np.int64)
viol = 0; checked = 0; maxk_ok = True
rows=[]
for k in range(1, K+1):
    Pk = Pk @ A
    # for each vertex, tree radius
    for y in rng.choice(n, 60, replace=False):
        L = tree_radius(A, y, 8)
        if L >= 0 and 2*L >= k:
            checked += 1
            val = int(Pk[y, y])
            if val != int(m[k]):
                viol += 1; print("VIOLATION", k, y, val, int(m[k]))
print(f"moment identity: checked {checked} (y,k) pairs with k<=2L(y); violations = {viol}")

# ---------- (2) deviation vs n ----------
def deviation(n, d, lam, Delta, T_choice, nseed=6, Lmax=12):
    vals=[]
    for s in range(nseed):
        rng = np.random.default_rng(10_000+s)
        A = config_regular(n, d, rng).astype(float)
        T = np.arange(Delta) if T_choice=='fixed' else rng.choice(n, Delta, replace=False)
        x = np.zeros(n); x[T]=1.0
        rhs = x.copy()
        # solve (A - lam I) z = x
        try:
            z = np.linalg.solve(A - lam*np.eye(n), rhs)
        except np.linalg.LinAlgError:
            continue
        vals.append(float(x @ z))
    G,r = g_d(lam,d)
    dev = np.abs(np.array(vals) + Delta*G)
    return G, r, dev

for lam in (2.95, 3.3):
    G,r = g_d(lam,d)
    print(f"\n--- lam={lam}  r={r:.6f}  G_d={G:.6f}  -Delta*G_d for Delta=1: {-G:.6f}")
    for Delta in (1,2):
        print(f"  Delta={Delta}, T fixed = {{1..{Delta}}}")
        for n in (250, 500, 1000, 2000, 4000, 8000):
            if n*d % 2: continue
            G,r,dev = deviation(n,d,lam,Delta,'fixed',nseed=6)
            print(f"    n={n:6d}  median dev={np.median(dev):.3e}  max dev={dev.max():.3e}  n^0.5*med={np.median(dev)*np.sqrt(n):.4f}")
