# Finite defect on a fixed-degree regular host: exact secular structure, the 1/n law at the Perron point, and the corrected finite-root target

Direction d6 (m4). Deterministic analysis plus one precisely named probabilistic input.
Every claim below is labelled **[proved]**, **[conditional on X]** or **[numerical only]**.

Setting throughout: `d >= 3` fixed. `G_n` a `d`-regular simple graph on `[n] = {1..n}`,
`A_n` its adjacency matrix, and `T_n ⊂ [n]` a **fixed deterministic** set of `Δ = |T_n| >= 1`
distinct vertices. `M_n` is the `(n+1) x (n+1)` adjacency matrix obtained by adjoining one new
vertex adjacent exactly to `T_n`; `1_T ∈ R^n` is the indicator of `T_n`. Write
`p_X(λ) = det(λI - X)`.

The *Kesten-McKay transform of the host at a vertex* is, for `λ ∉ [-2√(d-1), 2√(d-1)]`,

  G_d(λ) = ∫ dμ_KM(x)/(λ - x),    satisfies   G_d = 1/(λ - d·h),  h = (λ - √(λ²-4(d-1)))/(2(d-1)),

equivalently the rationalised form

  **G_d(λ) = 2(d-1) / ( (d-2)λ + d√(λ²-4(d-1)) ).**

Two exact special values are used constantly:

  **G_d(d) = (d-1)/(d(d-2))**,      **G_d(2√(d-1)) = √(d-1)/(d-2)**.

`G_d` is real analytic on `(2√(d-1), ∞)`, positive there, strictly decreasing, and
`G_d'(λ) → -∞` as `λ ↓ 2√(d-1)`.  [proved by the displayed formula; verified symbolically in
`scripts/check_identities.py` → `raw/identities.txt`: the rationalised form equals `1/(λ-dh)`; the
large-λ expansion reproduces the number of closed walks at the root of the infinite d-regular tree —
d=3,4,5 give `[1, d, 15|28|45, 87|232|485, 543|2092|5725]` from both sides — the transform matches
the Kesten-McKay density by quadrature to 1e-11, and both special values hold exactly
(symbolically; direct floating-point evaluation at the edge loses all digits to cancellation).]

---

## 0. Results and their status

| # | statement | status |
|---|---|---|
| L1 | exact Schur factor `p_{M_n}(λ) = p_{A_n}(λ)(λ + 1_T^T(A_n-λI)⁻¹1_T)` | proved (symbolic check) |
| L2 | Perron decomposition: second factor `= F_n(λ) = λ - (Δ²/n)/(λ-d) - Γ_n(λ)` | proved |
| L3 | exactly one eigenvalue of `M_n` exceeds `d`; it equals `d + t_n/n`, `t_n > 0` the unique root of an explicit scalar equation | proved |
| L4 | exactly one eigenvalue of `M_n` in `(λ₂(A_n), d)` | proved (interlacing) |
| L5 | rescaled **exact** equation for `t_n` and its two-sided bounds | proved |
| L6 | root structure of the limit function `λ - ΔG_d(λ)`; thresholds `Δ_e = 2(d-2)`, `Δ_x = d²(d-2)/(d-1)`; quadratic edge law | proved |
| **T1** | **1/n law**: `n(λ₁(M_n) - d) → Δ²/(d - ΔG_d(d))` in probability, and this holds **iff** the single scalar `Γ_n(d) → ΔG_d(d)` | proved as an equivalence; the scalar is *not* proved |
| T2 | gap eigenvalue → unique exterior root `λ*(Δ)` (exists iff `Δ > 2(d-2)`) | conditional on exterior convergence `H_ext` at fixed real energies |
| T3 | ensemble-averaged limit `n⁻¹ tr L_n⁺ → G_d(d)` in probability | conditional on two classical named inputs I1, I2 |
| **C1** | **correction**: the batch's "limiting top eigenvalue is a root of `λ = ΔG_d(λ)`" is **false for `Δ < Δ_x`**; then `λ₁ → d` with the 1/n law of T1 | proved |

The upshot for the batch: the fixed-degree finite-root problem for the defect **does not** need a
uniform-in-`z` exterior resolvent limit. The top eigenvalue needs **one scalar at one real energy**,
`Γ_n(d) = 1_T^T L_n⁺ 1_T` (the Perron-orthogonal Green function of `T` at energy exactly `d`), and the
two eigenvalues the batch calls "the top two" are `{d, λ*(Δ)}` with the assignment fixed by
`Δ ≷ Δ_x`. Everything else in the reduction is deterministic.

---

## 1. Lemma L1 (exact Schur factor) [proved]

For all `λ ∈ C` (the identity of polynomials, hence all λ):

  **p_{M_n}(λ) = p_{A_n}(λ) · ( λ - 1_T^T(λI - A_n)⁻¹ 1_T ) = p_{A_n}(λ) · ( λ + 1_T^T(A_n - λI)⁻¹ 1_T ).**

*Proof.* `λI - M_n = [[λI - A_n, -1_T],[-1_T^T, λ]]`. The Schur complement with respect to the
invertible top-left block is `λ - 1_T^T(λI-A_n)⁻¹1_T`, so for `λ ∉ spec(A_n)` the identity holds;
both sides are polynomials in λ, so it holds identically. ∎
[Symbolic check on `C_4` with `T = {0,2}` in `scripts/check_identities.py` output: both forms True.]

## 2. Lemma L2 (Perron decomposition) [proved]

Assume `G_n` is connected. Then `d` is a simple eigenvalue of `A_n` with eigenvector
`φ₁ = n^{-1/2} 1`. Let `φ₂..φ_n` be an orthonormal basis of `1^⊥` of eigenvectors, `A_nφ_j = λ_jφ_j`,
and put `s_j := (1_T · φ_j)² >= 0`. Then `Σ_{j>=2} s_j = Δ - Δ²/n` and for `λ ∉ spec(A_n)`

  `λ - 1_T^T(λI-A_n)⁻¹1_T = F_n(λ) := λ - (Δ²/n)/(λ - d) - Γ_n(λ)`,
  `Γ_n(λ) := Σ_{j>=2} s_j/(λ - λ_j)`.

At `λ = d` the series is finite and equals the Perron-orthogonal quadratic form

  **Γ_n(d) = 1_T^T L_n⁺ 1_T**,   `L_n = dI - A_n` the Laplacian, `L_n⁺` its Moore-Penrose inverse.

*Proof.* `φ₁ = n^{-1/2}1` because `A_n1 = d1`. Expand in the eigenbasis:
`1_T = Σ_j (1_T·φ_j)φ_j`, so `1_T^T(λI-A_n)⁻¹1_T = Σ_j s_j/(λ-λ_j)`, and the `j=1` term is
`(Δ/√n)²/(λ-d) = (Δ²/n)/(λ-d)`. For `Γ_n(d)`: since `d` is a simple eigenvalue and
`L_n = Σ_j (d-λ_j)φ_jφ_j^T`, the pseudo-inverse is `L_n⁺ = Σ_{j>=2}(d-λ_j)⁻¹φ_jφ_j^T`. ∎
[`s_j` all non-negative, so every `Γ_n` is decreasing and convex in `λ`.]

## 3. Lemma L3 (the top eigenvalue, exactly) [proved]

Let `G_n` be connected `d`-regular and let `ρ_n := λ₁(M_n)`. Then

1. `ρ_n > d`, and `ρ_n` is the **only** eigenvalue of `M_n` in `(d, ∞)`;
2. on `(d,∞)`, `F_n` is real analytic and strictly increasing, with `F_n(d⁺) = -∞`, `F_n(∞) = +∞`;
   hence `F_n` has a unique zero `ρ_n` there and `ρ_n = ` that zero;
3. `t_n := n(ρ_n - d) ∈ (0, ∞)` is the unique positive solution of

  **t·(d - Γ_n(d + t/n)) + t²/n = Δ².**   (★)

*Proof.* 1. Cauchy interlacing for `M_n = [[A_n, 1_T],[1_T^T, 0]]` gives
`λ₁(M_n) >= λ₁(A_n) = d >= λ₂(M_n) >= λ₂(A_n) >= ...`. So at most one eigenvalue exceeds `d`.
Strictness: for `w = (n^{-1/2}1, t)` and `t > 0`,
`⟨w, M_n w⟩/‖w‖² = (d + 2tΔ/√n)/(1 + t²) > d` for small `t`, so `λ₁(M_n) > d`.
2. `F_n = λ - (Δ²/n)/(λ-d) - Γ_n`; on `(d,∞)`, `Γ_n' = -Σ s_j/(λ-λ_j)² <= 0` and every term of
`λ - (Δ²/n)/(λ-d)` is strictly increasing, so `F_n' > 0`; limits as stated. By L1 the zeros of
`p_{M_n}` on `(d,∞)` are `d` (from `p_{A_n}`, and it is a simple root of `p_{A_n}`; for `d`-regular
`A_n`, `spec(A_n) ⊂ [-d,d]`, so no other root of `p_{A_n}` lies in `(d,∞)`) together with the zeros
of `F_n`. Hence exactly one eigenvalue in `(d,∞)` and it is `F_n`'s zero. But by part 1 that
eigenvalue is `ρ_n`.
3. Substituting `λ = d + t/n` into `F_n(λ) = 0` and multiplying by `t > 0` gives (★), and
`t ↦ t(d - Γ_n(d+t/n))` is strictly increasing on `t>0` (each factor is non-decreasing, one
strictly), so the positive solution is unique. ∎

## 4. Lemma L4 (the gap eigenvalue) [proved]

`M_n` has exactly one eigenvalue `η_n` in the closed interval `[λ₂(A_n), d]`, namely `λ₂(M_n)`
(in every case `λ₂(M_n) ∈ [λ₂(A_n), d]`, and `λ₃(M_n) <= λ₂(A_n)`). `F_n` is strictly increasing on
`(λ₂(A_n), d)` (no host eigenvalue lies there), so it has at most one zero there; if `s₂ > 0` then
`F_n(λ₂⁺) = -∞` and `F_n(d⁻) = +∞`, so a zero exists and `λ₂(M_n)` is that zero.

*Proof.* Interlacing gives `λ₂(M_n) <= λ₁(A_n) = d` and `λ₃(M_n) <= λ₂(A_n)`, which is the
counting statement. For `F_n`: same computation as L3, `Γ_n` blowing up at `λ₂` when `s₂ > 0`, and
`-(Δ²/n)/(λ-d) → +∞` as `λ ↑ d`. ∎

## 5. Lemma L5 (two-sided bounds, with the spectral gap) [proved]

Assume `λ₂(A_n) <= d - c` for some `c ∈ (0, d]`. Then for all `t > 0`

  `0 <= Γ_n(d) - Γ_n(d + t/n) <= (Δ/c²)·t/n`,

and consequently, with `g_n := d - Γ_n(d)` and `t_n` from (★),

  `t_n g_n + t_n²/n <= Δ²`,  and   `t_n g_n >= Δ² - (t_n²/n)(1 + Δ/c²)`.

In particular if `g_n > 0` then `t_n <= Δ²/g_n`.

*Proof.* `Γ_n(d) - Γ_n(d+t/n) = Σ_{j>=2} s_j[1/(d-λ_j) - 1/(d+t/n-λ_j)]`, each bracket
equals `t/(n(d-λ_j)(d+t/n-λ_j)) ∈ [0, t/(n c²)]` when `λ_j <= d - c` and `t>0`; summing against
`s_j` with total `<= Δ` gives the bound. Monotonicity of `Γ_n` gives `d - Γ_n(d+t/n) >= g_n`, i.e.
the first inequality of (★) rearranged; the bound on `Γ_n` difference gives the second. ∎

## 6. Theorem T1 (the 1/n law at the Perron point, and its exact character) [proved as an equivalence]

Fix `d >= 3` and `Δ >= 1`. Suppose `λ₂(A_n) <= d - c` eventually (`c>0` fixed) and define
`g_n = d - Γ_n(d)`, `G := ΔG_d(d) = Δ(d-1)/(d(d-2))`, `δ := d - G`.

(a) **[sufficient]** If `Γ_n(d) → G` in probability and `δ ≠ 0` (equivalently `Δ ≠ Δ_x`,
`Δ_x = d²(d-2)/(d-1)`), then

  **n(λ₁(M_n) - d) = t_n → Δ²/δ = Δ² / ( d - Δ(d-1)/(d(d-2)) )**   in probability,

with the explicit (deterministic) error bound, valid whenever `g_n > 0`:

  `|t_n - Δ²/g_n| <= (Δ⁴/g_n³)(1 + Δ/c²)/n`.

(b) **[necessary]** If in addition `t_n = n(λ₁(M_n)-d) = O(1)` and `t_n → t*`, then
`Γ_n(d) → d - Δ²/t*` (in probability), i.e. `t_n → Δ²/δ` forces `Γ_n(d) → G`.

Hence, under the a priori gap `λ₂(A_n) <= d-c`,
`t_n → Δ²/δ` **iff** `Γ_n(d) → ΔG_d(d)`.

*Proof.* (a) By L5, `t_n g_n <= Δ²`, so `t_n <= Δ²/g_n` and `{t_n}` is bounded; and
`t_n g_n >= Δ² - (t_n²/n)(1 + Δ/c²)`. Hence `|Δ² - t_n g_n| <= (t_n²/n)(1+Δ/c²)`, and dividing by
`g_n > 0`, with `t_n <= Δ²/g_n`:
`|t_n - Δ²/g_n| <= (Δ⁴/g_n³)(1+Δ/c²)/n`. Since `g_n → δ ≠ 0`, `t_n → Δ²/δ`.
(b) From (★), `g_n = (Δ² - t_n²/n)/t_n + [Γ_n(d+t_n/n) - Γ_n(d)]`; the bracket is
`<= (Δ/c²)t_n/n → 0` by L5, and `t_n²/n → 0`. So `g_n → Δ²/t*`. ∎

**Reading.** (b) says the scalar convergence is *necessary*: no argument that fails to control
`1_T^T L_n⁺ 1_T` at energy `d` can give the top eigenvalue. (a) says it is *sufficient*, and no
uniformity in λ, no complex `z`, no exterior window is needed. This is the weakest adequate
input for `λ₁`, and it is strictly weaker than the batch's target
`1_T^T(A_n-λI)⁻¹1_T → -ΔG_d(λ)` uniformly on compact exterior intervals.

## 7. Lemma L6 (root structure of the limit function; the two thresholds) [proved]

Let `F(λ) := λ - Δ G_d(λ)` on `(2√(d-1), ∞)` and `Δ_e := 2(d-2)`.

1. `F` is real analytic and strictly increasing, `F' >= 1` (since `G_d' < 0`); roots are simple.
2. `F(2√(d-1)) = 2√(d-1) - Δ√(d-1)/(d-2) > 0 ⟺ Δ < Δ_e`. Hence
   **`F` has a root in `(2√(d-1), ∞)` iff `Δ > 2(d-2)`; the root `λ*(Δ)` is then unique**, and
   `λ*(Δ_e) = 2√(d-1)` (root sits exactly at the bulk edge).
3. `λ*` is strictly increasing in `Δ`, and as `Δ → ∞`, `λ*(Δ)² = Δ + d + O(1/Δ)` (so
   `λ*(Δ) = √Δ(1+o(1))`), and
   **`λ*(Δ) = d` iff `Δ = Δ_x := d²(d-2)/(d-1)`** (since `F(d) = d - ΔG_d(d) = 0 ⟺ Δ = d/G_d(d)`).
   For `2(d-2) < Δ < Δ_x`: `2√(d-1) < λ*(Δ) < d`. For `Δ > Δ_x`: `λ*(Δ) > d`.
   (Large-Δ expansion: `Δ = λ/G_d(λ)` and `G_d(λ) = 1/λ + d/λ³ + O(λ^{-5})`.)
4. Near the edge the root is only Hölder-1/2 in the threshold parameter:
   `λ*(Δ) - 2√(d-1) = (√(d-1)/(4d²))·(Δ - 2(d-2))²·(1+o(1))` as `Δ ↓ 2(d-2)`.

*Proof.* 1: `G_d' < 0` on the exterior (from the displayed formula), so `F' = 1 - ΔG_d' > 1`.
2: the value of `G_d` at the edge is `√(d-1)/(d-2)`; combined with strict monotonicity and
`F(∞) = ∞`. 3: `F(d) = d - Δ(d-1)/(d(d-2))`, monotone in Δ; `λ*` increasing because
`∂F/∂Δ = -G_d < 0`. 4: write `λ = 2√(d-1) + δ`, `Δ = 2(d-2) + η`; expanding the closed form,
`G_d(λ) = G_d(2√(d-1)) - K√δ(1+o(1))` with `K = d(d-1)^{1/4}/(d-2)²`; the equation
`λ = ΔG_d(λ)` gives `ΔK√δ = η√(d-1)/(d-2) + O(δ)`, hence the claim. ∎

[Numerical check of 2-4, `raw/limit_roots.txt`: d=3: Δ=1,2 no root; Δ=3,4 roots 2.86289232,
2.94697446 (< d=3); Δ=6 root 3.18069866 (> d); Δ_x(3)=4.5. d=4: no root for Δ<=4, roots for
Δ=6,10 below d=4, Δ_x(4)=10.667, Δ=20 root 4.9659 > 4. Quadratic law: d=3, η=0.01 →
3.924e-6 vs predicted 3.928e-6.]

## 8. Theorem T2 (the two exterior eigenvalues, conditionally) [conditional on H_ext]

Let `G_n` be random `d`-regular (or any connected `d`-regular sequence) with
`λ₂(A_n) <= 2√(d-1)+o(1)` and suppose the fixed-energy exterior limit

  **(H_ext)** for every `λ` in a compact `J ⊂ (2√(d-1), d)`: `1_T^T(λI - A_n)⁻¹1_T → -Δ G_d(λ)`
  in probability, uniformly on `J` (equicontinuity or monotonicity with endpoint control suffice).

Then, in probability:

  (i) if `Δ <= 2(d-2)`: the gap eigenvalue `η_n → 2√(d-1)` and there is no other eigenvalue of
      `M_n` in the exterior below `d`;
  (ii) if `2(d-2) < Δ < Δ_x`: `η_n = λ₂(M_n) → λ*(Δ) ∈ (2√(d-1), d)`, while
      `λ₁(M_n) = d + t_n/n → d` (T1);
  (iii) if `Δ > Δ_x`: `λ₂(M_n) → d` from below at scale `1/n` — with `n(d - λ₂(M_n)) →
      Δ²/(ΔG_d(d) - d)`, which needs only the scalar `Γ_n(d) → ΔG_d(d)` of T1, not (H_ext) —
      while the top eigenvalue `λ₁(M_n) → λ*(Δ) > d`, which needs the fixed-energy exterior
      limit at the *energy* `λ*(Δ)` (this is the batch's unproved target, at one real energy).

*Proof.* (i),(ii): `η_n` is `F_n`'s unique zero in `(λ₂(A_n), d)` (L4), `F_n → F` locally uniformly
on `(2√(d-1), d)` under (H_ext) plus `λ₂(A_n) → 2√(d-1)`, and `F` is strictly increasing. If `F` has
a root `λ* ∈ J`, the zeros converge to it; if `F > 0` on all of `(2√(d-1),d)` (`Δ <= 2(d-2)`, L6.2)
the zero cannot have an interior limit point, so it exits at the edge. (iii): the mirror of L5 with
`λ = d - t/n`, giving `t(Γ_n(d) - d) + t²/n = Δ² + o(1)`, i.e. `t → Δ²/(ΔG_d(d)-d) > 0`; the
separation `λ*(Δ) - d > 0` is L6.3. ∎

## 9. Theorem T3 (unconditional, but only averaged) [conditional on two classical inputs]

The scalar that T1 needs is a *single fixed vertex's* Perron-orthogonal Green function at energy `d`.
What can be proved without new probability is its **vertex average**:

  `(1/n) tr L_n⁺ = (1/n)Σ_{j>=2} 1/(d-λ_j) → G_d(d) = (d-1)/(d(d-2))` in probability.

*Proof, given two inputs.*
**I1** (edge gap) For fixed `d>=3`, `λ₂(A_n) <= 2√(d-1)+ε` w.h.p. for every `ε>0`
[Friedman, *A proof of Alon's second eigenvalue conjecture and related problems*, Mem. AMS 195
(2008) — theorem number to be confirmed by the source role; note `d-2√(d-1) = (√(d-1)-1)² > 0`
for `d>=3`, so `c := ½(√(d-1)-1)²` is a valid explicit gap].
**I2** (Kesten-McKay moments in probability) for each fixed `k`, `n⁻¹tr A_n^k → m_k^{KM}`
in probability, `m_k^{KM}` the k-th moment of `μ_KM` [McKay, Linear Algebra Appl. 40 (1981) for the
expectation; the in-probability form is standard — **citation to be confirmed by m1**].
*Argument.* Under I1 the numbers `λ_j, j>=2`, lie in `I := [-2√(d-1)-ε, 2√(d-1)+ε]`, `d ∉ I`, and
`x ↦ 1/(d-x)` is analytic on a neighbourhood of `I`. Choose a polynomial `p` with
`sup_I |p - 1/(d-·)| <= η`. Then
`n⁻¹Σ_{j>=2} 1/(d-λ_j) = n⁻¹Σ_{j>=2} p(λ_j) + O(η) = n⁻¹tr p(A_n) - p(d)/n + O(η)`, and
`n⁻¹tr p(A_n) → ∫p dμ_KM = G_d(d) + O(η)` by I2; `p(d)/n → 0`. Let `η ↓ 0` along a countable set.
∎

*Consequence and honest limit:* T3 is a statement about the **average over a uniform vertex**
(or over the ensemble of `T`), not about a prescribed `T`. For `Δ = 1` there is no randomness in `T`
at all, so T3 does **not** imply T1's hypothesis; and averaging `T` over a uniform `Δ`-subset does
not help either, because the fluctuation of `Γ_n` is dominated by the fluctuation of the matrix
entries themselves (the zero-row-sum structure of `L_n⁺` kills the pure-offset component, but not
the common spectral fluctuation). Any attempt to derive T1 from T3 would be
"expectation for probability" in exactly the sense the batch forbids.

## 10. C1: correction of the batch's target [proved]

The batch's candidate law is `λ = ΔG_d(λ)`, and the candidate threshold `Δ > 2(d-2)` and "the
limiting top two eigenvalues". Consequences of L6 + T1:

1. **The threshold is right and is now explained.** `Δ > 2(d-2)` is exactly the condition for the
   limit function to have an exterior root; at `Δ = 2(d-2)` the root sits on the bulk edge
   `2√(d-1)`, which is a branch point of `G_d`, so root stability degenerates (L6.4).
2. **The top eigenvalue is not a root of the fixed-point law unless `Δ > Δ_x = d²(d-2)/(d-1)`.**
   For `Δ < Δ_x` the top eigenvalue converges to `d`, the host's Perron eigenvalue, and its distance
   from `d` is exactly `Δ²/(n(d-ΔG_d(d)))` (T1). The fixed-point root `λ*(Δ)` is then the limit of
   the **second** eigenvalue. For `Δ = Δ_x` the two collide at `d` and the scaling changes
   (the balance in (★) becomes `t² ≈ n·Δ²` **provided** `d - Γ_n(d) = Θ(1/n)` for that `Δ`, giving
   the heuristic `λ₁ - d ≍ n^{-1/2}`; if instead `d - Γ_n(d) = o(1/n)` the top eigenvalue can sit at
   scale `n^{-1}` still. This is a reading of (★), not a proved limit, and no numerical test was run
   at `Δ = Δ_x`).
3. So "the proposed limiting top two eigenvalues" must be stated as the **unordered** pair
   `{d, λ*(Δ)}`, with `λ₁ → d, λ₂ → λ*` for `Δ<Δ_x` and `λ₁ → λ*, λ₂ → d` for `Δ>Δ_x`. Any
   statement that `λ₁ → λ*` for all admissible `Δ` is false.

## 11. Exact remaining gaps (ranked)

**G1 (the one real gap for `λ₁`).** Prove, for a fixed vertex set `T_n` and fixed `d>=3`,
`Γ_n(d) = 1_T^T L_n⁺ 1_T → Δ G_d(d)` in probability. Equivalently: single-vertex,
real-energy, Perron-orthogonal Green function convergence at the *one* energy `d`, at distance
`(√(d-1)-1)²` above the bulk edge. This is *not* implied by the empirical spectral measure limit
(T3) and *not* a corollary of a bulk local law with `Im z → 0` at the edge. Natural attack:
`L_n⁺ = Σ_k d^{-k-1}(A_n^k - n^{-1}d^k 11^T)` is **not** absolutely convergent termwise, but the
root-level expansion of `(L_n⁺)_{uu}` against the tree recursion does converge because the tree's
closed-walk count grows like `k^{-3/2}d^k`; the needed estimate is a second-moment
(eigenvector-mass) statement at every energy, i.e. a fixed-vertex isotropic local law at real
exterior energy.
**G2 (for the gap eigenvalue and the whole "finite-root law").** `H_ext`: fixed-energy real
convergence of `1_T^T(A_n-λI)⁻¹1_T` for `λ` in compact subintervals of `(2√(d-1),d)` (or of
`(d,∞)` for `Δ > Δ_x`). Note `H_ext` at a single energy is *weaker* than the batch's uniform-in-`λ`
formulation, and single-energy versions are all that T2 uses; uniformity is needed only for the
root-count/absence statements, which L6 supplies for the limit function.
**G3 (citations).** I1, I2 need exact theorem numbers and hypothesis checks (fixed `d`, simple
graph, `T` vs `E`). Not done here.
**G4.** Nothing in this note says anything about eigenvalues inside the bulk, and nothing here
proves or disproves delocalization.

## 12. Numerical evidence (corroboration only, never a proof)

Sampler: **configuration model with rejection of loops/multi-edges**, which is *exactly* uniform on
simple `d`-regular graphs (every simple graph arises from the same number `(d!)^n` of pairings), so
the sampler is certified, unlike `networkx.random_regular_graph`. Seeds are recorded per row;
graphs that came out disconnected were detected by `λ₁` having multiplicity ≥ 2 in `L_n⁺`
(one d=4 instance) and excluded.

(a) `raw/secular_v1.txt` (`scripts/check_secular.py`), θ = `n(λ₁(M_n) - d)` vs the limit
`Δ²/(d-ΔG_d(d))`:

| d | Δ | n=1000 | n=2000 | n=4000 | limit |
|---|---|---|---|---|---|
| 3 | 1 | 0.427890, 0.427221 | 0.427805, 0.428722 | 0.427986, 0.428051 | 3/7 = 0.428571 |
| 3 | 2 | 2.370814, 2.392703 | 2.372728, 2.390698 | 2.386327, 2.383250 | 12/5 = 2.4 |
| 3 | 3 | 8.292091, 8.416496 | 8.555402, 8.945919 | 8.791916, 9.513297 | 9 |
| 4 | 1 | 0.275622, 0.275624 | 0.275795, 0.275728 | — | 8/29 = 0.275862 |

Also in the same file, per instance: the exact secular root reproduces `λ₁(M_n)` and `λ₂(M_n)` from
the direct eigendecomposition to 10 digits (e.g. 3.0004278898 vs 3.0004278898), the exact
prediction `Δ²/(d-Γ_n(d))` tracks `θ` to ~3-4 digits, and `λ₂(M_n)` moves toward the values
predicted by L6 (Δ=1,2: toward the edge 2√2 = 2.8284; Δ=3: straddling `λ*(3) = 2.862892`).

(b) `raw/supercritical_v1.txt` (`scripts/check_supercritical.py`), d=3, Δ=6 > Δ_x = 4.5:
`λ₁` = 3.2222, 3.2061 (n=10³), 3.2154, 3.1920 (n=2·10³), 3.2088, 3.1908 (n=4·10³) toward
`λ*(6) = 3.180699`; `λ₂` = 2.9727, 2.9698, 2.9858, 2.9830, 2.9927, 2.9918 toward `d = 3` from
below; `n(d-λ₂)` = 27.3, 30.2, 28.5, 34.0, 29.1, 33.0 versus the leading prediction
`Δ²/(ΔG_d(d)-d) = 36` — the O(1) shortfall is the expected `(t/n)|Γ_n'|` correction, `|Γ_n'| ~ Δ/c²`
is large (`c ≈ 0.17`), so only the order of magnitude is informative at these `n`.

(c) `raw/entry_fluctuation_v1.txt` (`scripts/entry_fluctuation.py`), d=3, Δ=1, the scalar itself,
8 graphs per size, `(L_n⁺)_{00}` computed by CG on `(dI-A_n)` restricted to `1^⊥`
(`(L⁺)_{uu} = ⟨e_u - 1/n, y⟩`, `(dI-A)y = e_u - 1/n`):

| n | mean of fixed vertex 0 | sd | mean of 16-vertex average |
|---|---|---|---|
| 1000 | 0.660289 | 5.5e-3 | 0.663107 |
| 4000 | 0.663955 | 3.8e-4 | 0.666187 |
| 16000 | 0.666078 | 2.8e-4 | 0.666623 |
| 64000 | 0.666458 | 4.0e-5 | 0.666589 |

`G_d(d) = 2/3 = 0.666667`. The single fixed-vertex entry concentrates with a small residual bias
(`≈ -13/n`), so the sample supports G1 but of course cannot prove it. `sd` estimates rest on 8
samples and are only indicative.

(d) `raw/star_equation.txt` (`scripts/check_star_equation.py`): the positive root of the **exact**
equation (★), computed by bisection, versus `n(λ₁(M_n) - d)` from a direct eigendecomposition,
five instances (d=3, Δ=1,2,3; d=4, Δ=2; d=5, Δ=1): absolute agreement 2e-12 … 6e-12 in every
case. This is the end-to-end check of L3; an earlier version of this script disagreed by a factor
exactly 2 because it subtracted `Δ²` twice (the Perron term `(Δ²/n)/(t/n) = Δ²/t` is already part
of the resolvent form), which is precisely the bookkeeping error (★) is meant to make impossible.
Note `raw/` versions of this log may show a meaningless `Gamma_at_d` column (evaluating `Γ` at the
pole `λ = d`); the corrected column is `Gamma_perp_at_d`.

Files: `notes/secular-theorem.md` (this document), `scripts/check_secular.py`,
`scripts/check_supercritical.py`, `scripts/entry_fluctuation.py`, `scripts/check_identities.py`,
`raw/*.txt` (raw outputs, seeds inline).
