"""Exact maximum second-eigenvalue multiplicity over all connected
d-regular graphs on n vertices, enumerated with nauty-geng."""
import subprocess, sys, json
import numpy as np
import networkx as nx

def decode_g6(s):
    data=bytes(s.strip(),'ascii')
    n=data[0]-63
    bits=[]
    for ch in data[1:]:
        b=ch-63
        for k in range(5,-1,-1): bits.append((b>>k)&1)
    A=np.zeros((n,n),dtype=np.int8); idx=0
    for j in range(1,n):
        for i in range(j):
            if bits[idx]: A[i,j]=A[j,i]=1
            idx+=1
    return A

def record(d,n):
    out=subprocess.run(["nauty-geng","-c","-q","-d"+str(d),"-D"+str(d),str(n)],
                       capture_output=True,text=True)
    lines=[l for l in out.stdout.split("\n") if l.strip()]
    best=-1; bestmul=0; holders=[]; count=0
    for s in lines:
        A=decode_g6(s); count+=1
        ev=np.linalg.eigvalsh(A.astype(float))
        # second largest distinct value
        top=ev[-1]; thr=top-1e-8
        k=len(ev)-int(np.sum(ev>thr))
        if k==0: continue
        lam2=ev[n-len(ev)+k-1] if False else ev[:len(ev)-int(np.sum(ev>thr))][-1]
        mult=0
        for x in ev:
            if abs(x-lam2)<1e-8: mult+=1
        if mult>bestmul:
            bestmul=mult; holders=[s]; best=lam2
        elif mult==bestmul:
            holders.append(s)
    return dict(d=d,n=n,count=count,max_mult=bestmul,lam2=round(float(best),8),
                ratio=round(bestmul/count if count else 0,0),n_holders=len(holders),
                holders=holders[:6])

res=[]
for n in [4,6,8,10,12,14,16,18]:
    r=record(3,n); r["ratio"]=round(r["max_mult"]/n,4); res.append(r); print(r, flush=True)
json.dump(res,open("out/extremal_cubic.json","w"),indent=1)
