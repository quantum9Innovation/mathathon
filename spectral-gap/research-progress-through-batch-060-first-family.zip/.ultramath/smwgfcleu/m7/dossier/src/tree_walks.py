"""Exact closed-walk counts in the d-regular tree, by explicit truncation."""
import numpy as np
import builtins
def pp(*a, **k):
    k.setdefault('flush', True)
    builtins.print(*a, **k)


def tree_counts(d, L):
    """Number of closed walks of length l from the root in the d-regular tree, l <= L."""
    depth = L // 2 + 1
    # explicit nodes: paths of 'turns'; node = tuple of child indices, root = ()
    nodes = {(): 0}
    order = [()]
    i = 0
    while i < len(order):
        node = order[i]
        i += 1
        if len(node) >= depth:
            continue
        for c in range(d if len(node) == 0 else d - 1):
            child = node + (c,)
            if child not in nodes:
                nodes[child] = len(nodes)
                order.append(child)
    N = len(order)
    A = np.zeros((N, N))
    for node, idx in nodes.items():
        if len(node) >= depth:
            continue
        for c in range(d if len(node) == 0 else d - 1):
            j = nodes[node + (c,)]
            A[idx, j] = 1
            A[j, idx] = 1
    M = np.eye(N)
    out = []
    for l in range(L + 1):
        out.append(int(round(M[0, 0])))
        M = M @ A
    return out


if __name__ == '__main__':
    for d in (3, 4):
        pp("d=%d tree closed walks from root, lengths 0..10:" % d)
        pp("   ", tree_counts(d, 10))
