# m1 dossier: band-edge sampling for abelian covers of periodic graphs

Start with `DOSSIER.md` (the research document) and `PROOF-band-edge-law.md`
(the complete proofs). `run_all.sh` reruns every computation into `out/`.
`lit/` holds the downloaded literature and its extracted text.
