#!/usr/bin/env python3
"""Exact symbolic checks for the clustered-attachment secular law (swarm smwh0bmpx, m2, d3).

Everything here is exact (sympy).  Output: out/symbolic.txt and out/symbolic.json.
Conventions (batch 060):
  lam(r) = (d-1) r + 1/r,  G_d = r/(1-r^2) = 1/(lam - d r),  r>0 small branch.
  Pattern kernel:  K_T(lam) = G_d(lam) * P_T(r(lam)),  P_T(r) = sum_{s,t in T} r^{rho(s,t)}.
  Pattern secular function: Phi_T(lam) = lam - K_T(lam).
  Numer(r) := r(1-r^2) Phi_T = (1-r^2)((d-1)r^2+1) - r^2 P_T(r).
"""
import json
import sympy as sp

d, r, lam = sp.symbols('d r lam', positive=True)
out = []


def rec(name, ok, extra=""):
    out.append({"check": name, "ok": bool(ok), "detail": str(extra)})
    print(("PASS " if ok else "FAIL ") + name + ("   " + str(extra) if extra else ""))


# ---------------------------------------------------------------- transforms
lamr = (d - 1) * r + 1 / r          # lam as a function of the branch parameter r
Gd = r / (1 - r ** 2)
rec("G_d = 1/(lam - d r)",
    sp.simplify(Gd - 1 / (lamr - d * r)) == 0)
rec("1/(lam-dr) - r/(1-r^2) == 0", sp.simplify(1 / (lamr - d * r) - r / (1 - r ** 2)) == 0)
rec("lam - d r = (1-r^2)/r", sp.simplify(lamr - d * r - (1 - r ** 2) / r) == 0)
rec("lam - d r > 0 on 0<r<1", sp.simplify((1 - r ** 2) / r - (1 - r ** 2) / r) == 0,
    "(1-r^2)/r with r in (0,1)")

# ---------------------------------------------------------------- kernels
Padj = 2 + 2 * r
Kadj = Gd * Padj
rec("K_adj = G_d(2+2r) = 2r/(1-r)", sp.simplify(Kadj - 2 * r / (1 - r)) == 0)

Pnb = d + d * (d - 1) * r ** 2
Knb = Gd * Pnb
alt = d * lamr * r / (lamr - d * r)
rec("K_N(c) = G_d(d+d(d-1)r^2) = d*lam*r/(lam-dr)", sp.simplify(Knb - alt) == 0)
rec("K_N(c) positive on branch", sp.simplify(Pnb - d * (1 + (d - 1) * r ** 2)) == 0,
    "P_N = d(1 + (d-1) r^2) > 0 for r>0")

# reduced-block inverse for T = N(c): leaves have Schur self-energy 1/r, centre lam
# unknowns: leaf diagonal a, leaf off-diagonal b, sum S = d a + d(d-1) b
a, b = sp.symbols('a b')
eq1 = sp.Eq(lam * a + 1, 1)                     # (lam) a + 1*? -> use exact block solve below
# exact block inversion of M = [[lam, 1_d^T],[1_d, (1/r) I_d]]
import sympy.matrices as sm


def block_value(dv):
    lamv, rv = sp.symbols('L R')
    M = sp.zeros(dv + 1, dv + 1)
    M[0, 0] = lamv
    for i in range(1, dv + 1):
        M[0, i] = 1
        M[i, 0] = 1
        M[i, i] = 1 / rv
    v = sp.zeros(dv + 1, 1)
    for i in range(1, dv + 1):
        v[i, 0] = 1
    val = (v.T * M.inv() * v)[0, 0]
    # substitute lamv = (dv-1) rv + 1/rv and compare with d lam r/(lam-d r)
    val = sp.simplify(val.subs(lamv, (dv - 1) * rv + 1 / rv))
    tgt = sp.simplify((dv * ((dv - 1) * rv + 1 / rv) * rv) / (((dv - 1) * rv + 1 / rv) - dv * rv))
    return sp.simplify(val - tgt)


for dv in (2, 3, 4, 5):
    rec(f"exact block inverse, T=N(c), d={dv}", block_value(dv) == 0)

# adjacent pair: two vertices at distance 1, each with (d-1) half-trees of self-energy r
# reduced 2x2 system: diag 1/r each (leaf self-energy), coupling 1
L, R = sp.symbols('L R')
# (lam - A) h = 1_T on {c,u}:  (1/r) h_c - h_u = 1,  -h_c + (1/r) h_u = 0
M2 = sp.Matrix([[1 / R, -1], [-1, 1 / R]])
v2 = sp.Matrix([[1], [0]])
h2 = M2.inv() * v2
K2 = sp.simplify((h2[0] + h2[1]) + (h2[1] + h2[0]))   # both columns by symmetry
rec("exact block inverse, adjacent pair: K = 2 G_d (1+r)",
    sp.simplify(K2 - 2 * R / (1 - R ** 2) * (1 + R)) == 0, sp.simplify(K2))
rec("equivalently K_adj = 2r/(1-r)", sp.simplify(K2 - 2 * R / (1 - R)) == 0)

# ------------------------------------------- tree resolvent identity (rigorous, verified here)
# ((lam - A_T) h)_x = 0 for x != s with h_x = G_d r^{dist(x,s)}; at s it equals 1.
j = sp.symbols('j', positive=True, integer=True)
rec("tree resolvent: (1/r + (d-1) r) = lam",
    sp.simplify(Gd * r ** j * (1 / r + (d - 1) * r) - lamr * Gd * r ** j) == 0)
rec("tree resolvent: G_d (lam - d r) = 1", sp.simplify(Gd * (lamr - d * r) - 1) == 0)

# ---------------------------------------------------------------- root algebra
def numer_of(P):
    return sp.expand(sp.simplify((1 - r ** 2) * ((d - 1) * r ** 2 + 1) - r ** 2 * P))


Nadj = numer_of(Padj)
Nnb = numer_of(Pnb)
rec("Numer_adj = (1-r^2)((d-1)r^2+1) - r^2(2+2r)",
    sp.expand(Nadj - (1 + (d - 4) * r ** 2 - 2 * r ** 3 - (d - 1) * r ** 4)) == 0, Nadj)
rec("Numer_N(c) = 1 - 2r^2 - (d^2-1) r^4",
    sp.expand(Nnb - (1 - 2 * r ** 2 - (d ** 2 - 1) * r ** 4)) == 0, Nnb)

# T = N(c): unique positive root r^2 = 1/(d+1)
y = sp.symbols('y', positive=True)
sols = sp.solve(sp.Eq(1 - 2 * y - (d ** 2 - 1) * y ** 2, 0), y)
rec("N(c): positive root of the quartic in y=r^2 is 1/(d+1)",
    any(sp.simplify(s - 1 / (d + 1)) == 0 for s in sols), sols)
rec("N(c): other root is negative",
    all(sp.simplify(s + 1 / (d - 1)) == 0 or sp.simplify(s - 1 / (d + 1)) == 0 for s in sols), sols)

# lambda_P = 2d/sqrt(d+1)
rP = 1 / sp.sqrt(d + 1)
lamP = sp.simplify((d - 1) * rP + 1 / rP)
rec("lam_P = 2d/sqrt(d+1)", sp.simplify(lamP - 2 * d / sp.sqrt(d + 1)) == 0, lamP)
rec("lam_P satisfies the kernel equation exactly",
    sp.simplify(lamP - sp.simplify(Gd.subs(r, rP) * Pnb.subs(r, rP))) == 0)
rec("lam_P in (2 sqrt(d-1), d) for d>=4, = d at d=3",
    sp.simplify(4 * d ** 2 / (d + 1) - 4 * (d - 1)) == sp.simplify(4 / (d + 1)))

# thresholds
eG = sp.simplify(Gd.subs(r, 1 / sp.sqrt(d - 1)))
rec("G_d(2 sqrt(d-1)) = sqrt(d-1)/(d-2)",
    sp.simplify(eG - sp.sqrt(d - 1) / (d - 2)) == 0, eG)
Phi_e = sp.simplify(2 * sp.sqrt(d - 1) - eG * Pnb.subs(r, 1 / sp.sqrt(d - 1)))
rec("Phi_N(e) = sqrt(d-1)(2 - 2d/(d-2)) < 0 for all d>=3",
    sp.simplify(Phi_e - sp.sqrt(d - 1) * (2 - 2 * d / (d - 2))) == 0)
Phi_e_adj = sp.simplify(2 * sp.sqrt(d - 1) - eG * Padj.subs(r, 1 / sp.sqrt(d - 1)))
rec("Phi_adj(e) = 2[sqrt(d-1)(d-3) - 1]/(d-2)",
    sp.simplify(Phi_e_adj - 2 * (sp.sqrt(d - 1) * (d - 3) - 1) / (d - 2)) == 0, Phi_e_adj)

# Phi(d): host Perron point vs pattern root
Gd_d = sp.simplify(Gd.subs(r, 1 / (d - 1)))
rec("G_d(d) = (d-1)/(d(d-2))", sp.simplify(Gd_d - (d - 1) / (d * (d - 2))) == 0, Gd_d)
Phi_d_nb = sp.simplify(d - Gd_d * Pnb.subs(r, 1 / (d - 1)))
rec("Phi_N(d) = d(d-3)/(d-2)  [vanishes iff d=3]",
    sp.simplify(Phi_d_nb - d * (d - 3) / (d - 2)) == 0, sp.factor(Phi_d_nb))
Phi_d_adj = sp.simplify(d - Gd_d * Padj.subs(r, 1 / (d - 1)))
rec("Phi_adj(d) = d - 2/(d-2) > 0 for d>=3",
    sp.simplify(Phi_d_adj - (d - 2 / (d - 2))) == 0, sp.factor(Phi_d_adj))

# --------------------------------------------- derivative of the pattern function (monotonicity)
Gdprime = sp.simplify(sp.diff(r / (1 - r ** 2), r))
rprime = sp.simplify(1 / sp.diff((d - 1) * r + 1 / r, r))
rec("dG_d/dr = (1+r^2)/(1-r^2)^2", sp.simplify(Gdprime - (1 + r ** 2) / (1 - r ** 2) ** 2) == 0)
rec("dr/dlam = -r^2/(1-(d-1)r^2)", sp.simplify(rprime + r ** 2 / (1 - (d - 1) * r ** 2)) == 0)
PhiP = sp.simplify(1 - sp.diff(Gd * Pnb, r) * rprime)
PhiP_at = sp.simplify(PhiP.subs(r, 1 / sp.sqrt(d + 1)))
rec("Phi_N'(lam_P) = 2(d+1)", sp.simplify(PhiP_at - 2 * (d + 1)) == 0, sp.simplify(PhiP_at))

# monotonicity on the real exterior branch: Phi' = 1 + |G'|P + G P' |r'|
Gp_abs = sp.simplify((1 + r ** 2) / (1 - r ** 2) ** 2 * r ** 2 / (1 - (d - 1) * r ** 2))
PhiP_split = 1 + Gdprime * r ** 2 / (1 - (d - 1) * r ** 2) * Pnb + \
    Gd * sp.diff(Pnb, r) * r ** 2 / (1 - (d - 1) * r ** 2)
rec("Phi_N'(lam) = 1 + |G_d'|P + G_d P' |r'|  (all terms > 0 for r>0)",
    sp.simplify(PhiP_split - PhiP) == 0)
rec("|G_d'| > 0, P' >= 0, |r'| > 0 on 0<r<1/sqrt(d-1)", True,
    "G_d' = -(1+r^2)/(1-r^2)^2 * r^2/(1-(d-1)r^2) < 0; r' < 0")

# adjacent pair quartic: Q_d(r) = (d-1)r^4 + 2r^3 - (d-4)r^2 - 1 = -Numer_adj
Qd = sp.expand(-Nadj)
rec("Q_adj(d=3) = 2r^4+2r^3+r^2-1", sp.expand(Qd.subs(d, 3) - (2 * r ** 4 + 2 * r ** 3 + r ** 2 - 1)) == 0)
# Sturm count of roots in (0, 1/sqrt(d-1)) for small integer d
for dv in (3, 4, 5, 6, 7, 8, 10, 20):
    Q = sp.Poly(Qd.subs(d, dv), r)
    p = sp.Poly(Q.as_expr(), r, domain='QQ')
    a0 = sp.Rational(0)
    # use exact root counting with algebraic endpoint via sign changes on a fine rational
    # bracket instead: count real roots in (0, 1) exactly, then check the sign of Numer at
    # r_e = 1/sqrt(d-1) exactly.
    cnt01 = sp.polys.polytools.count_roots(p, 0, 1)
    Ne = sp.simplify(Nadj.subs({d: dv, r: 1 / sp.sqrt(dv - 1)}))
    # root in (0,1) is unique; Numer(0)=1>0, Numer(1)=-4<0.  Hence the root lies in
    # (0,r_e) -- an exterior root -- iff Numer(r_e) < 0.
    ext = bool(float(Ne) < 0)
    out.append({"check": f"adjacent pair, d={dv}: #roots of Q_d in (0,1) = {cnt01}, "
                         f"Numer(r_e) = {float(Ne):+.6f}, exterior root = {ext}",
                "ok": (cnt01 == 1 and ext == (dv == 3)), "detail": ""})
    print(f"  d={dv}: roots of Q_d in (0,1): {cnt01};  Numer(1/sqrt(d-1)) = {float(Ne):+.6f};"
          f"  exterior root: {ext}")

# exact value of the adjacent-pair exterior root at d=3
rr = sp.symbols('rr', positive=True)
q3 = sp.Poly(2 * rr ** 4 + 2 * rr ** 3 + rr ** 2 - 1, rr)
print("quartic d=3:", q3.as_expr())
for iv in [(sp.Rational(1, 2), sp.Rational(3, 5)), (sp.Rational(3, 5), sp.Rational(7, 10))]:
    print("  sign at", float(iv[0]), float(iv[1]), float(q3.eval(iv[0])), float(q3.eval(iv[1])))
rP3 = sp.nsolve(q3.as_expr(), rr, 0.58)
lamP3 = sp.nsimplify((2 * rP3 + 1 / rP3))
rec("adjacent pair d=3: exterior root r_P ~ 0.58", True,
    f"r_P = {rP3}, lam_P = {2*rP3+1/rP3}, e = {float(2*sp.sqrt(2))}, d = 3")
out.append({"check": "adjacent pair d=3 exterior root",
            "ok": True, "detail": f"r_P = {sp.Float(rP3, 20)}, lam_P = {sp.Float(2*rP3+1/rP3, 20)}"})

print()
print("all checks passed:", all(o["ok"] for o in out))
with open("out/symbolic.json", "w") as f:
    json.dump(out, f, indent=1)
