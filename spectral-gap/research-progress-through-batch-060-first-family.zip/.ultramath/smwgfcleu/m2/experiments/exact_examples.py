"""
Exact and high-precision checks for direction d6 (one-sided spectra).

(A) Paley digraphs PD(p), p = 3 mod 4: normality AA^T=A^T A (exact integers),
    Schur/moment identity sum|lambda_j|^2 = n*d (exact), nontrivial moduli = sqrt((p+1)/4).
(B) Complete k-regular m-periodic digraph K_{k,m}: spectrum {k*zeta_m^j} u {0^{(k-1)m}}.
(C) De Bruijn digraph DB(k,s): rho = 0, singular values, non-normality.
(D) Line digraph DL(G) of a d-regular graph G: Ihara-Bass formula
    Spec(DL(G)) = {(lam +- sqrt(lam^2-4(d-1)))/2 : lam in Spec G} u {+-1};
    for Ramanujan G all nontrivial eigenvalues of DL(G) have modulus exactly sqrt(d-1).
"""
import json
import numpy as np
import sympy as sp

out = {}


def paley_matrix(p):
    S = set((x * x) % p for x in range(1, p))          # quadratic residues
    A = np.zeros((p, p), dtype=np.int64)
    for a in range(p):
        for b in range(p):
            if (b - a) % p in S:
                A[a, b] = 1
    return A


print("=== (A) Paley digraphs PD(p), p = 3 mod 4 ===")
rows = []
for p in [3, 7, 11, 19, 23, 31, 43, 47, 59, 67, 71, 79, 83]:
    if p % 4 != 3:
        continue
    A = paley_matrix(p)
    k = (p - 1) // 2
    assert A.sum(axis=1).min() == A.sum(axis=1).max() == k
    assert A.sum(axis=0).min() == A.sum(axis=0).max() == k
    # exact normality and exact moment identity
    normal = bool(np.array_equal(A @ A.T, A.T @ A))
    fro2 = int((A * A).sum())
    w = np.linalg.eigvals(A.astype(float))
    mods = np.sort(np.abs(w))[::-1]
    moment_num = float((np.abs(w) ** 2).sum())
    nontriv = mods[1:]
    target = np.sqrt((p + 1) / 4.0)
    rows.append(dict(p=p, k=k, normal=normal, fro2=fro2, moment=moment_num,
                     max_nontriv=float(nontriv.max()), target=float(target),
                     min_nontriv=float(nontriv.min()),
                     spread=float(nontriv.max() - nontriv.min())))
    print(f"p={p:3d} k={k:3d} normal={normal} ||A||_F^2={fro2} sum|lam|^2={moment_num:.6f} "
          f"max|lam_2|={nontriv.max():.9f} sqrt((p+1)/4)={target:.9f} "
          f"min|nontriv|={nontriv.min():.9f}")
out["paley"] = rows

print()
print("=== (B) complete k-regular m-periodic digraph K_{k,m} ===")
def complete_km(k, m):
    n = k * m
    A = np.zeros((n, n), dtype=np.int64)
    for x in range(m):
        for y in range(k):
            for z in range(k):
                A[x * k + y, ((x + 1) % m) * k + z] = 1
    return A

rows = []
for (k, m) in [(2, 2), (2, 3), (3, 2), (3, 3), (3, 4), (4, 3)]:
    A = complete_km(k, m)
    n = A.shape[0]
    w = np.linalg.eigvals(A.astype(float))
    mods = np.sort(np.abs(w))[::-1]
    roots = [abs(k * np.exp(2j * np.pi * j / m)) for j in range(m)]
    rows.append(dict(k=k, m=m, n=n,
                     top_mods=[float(x) for x in mods[:m + 2]],
                     trivial_modulus=float(abs(k)),
                     count_modulus_k=int(np.sum(np.abs(mods - k) < 1e-8)),
                     next_modulus=float(mods[m]),
                     zero_mult=int(np.sum(np.abs(w) < 1e-8))))
    print(f"K_{{{k},{m}}} n={n}: top |lambda| = {np.round(mods[:m+2],8)}, "
          f"#(modulus k) = {rows[-1]['count_modulus_k']} (=m), next = {mods[m]:.2e}, "
          f"zero multiplicity = {rows[-1]['zero_mult']}")
out["complete_km"] = rows

print()
print("=== (C) De Bruijn digraph DB(k,s) ===")
def de_bruijn(k, s):
    n = k ** s
    def idx(word):
        v = 0
        for d in word:
            v = v * k + d
        return v
    A = np.zeros((n, n), dtype=np.int64)
    for w in range(n):
        digits = [(w // k ** (s - 1 - i)) % k for i in range(s)]
        for t in range(k):
            A[w, idx(tuple(digits[1:] + [t]))] += 1
    return A

rows = []
for (k, s) in [(2, 2), (2, 3), (2, 4), (2, 5), (2, 6), (3, 2), (3, 3), (3, 4)]:
    A = de_bruijn(k, s)
    n = A.shape[0]
    w = np.linalg.eigvals(A.astype(float))
    mods = np.sort(np.abs(w))[::-1]
    sv = np.linalg.svd(A.astype(float), compute_uv=False)
    nonnorm = float(np.linalg.norm(A @ A.T - A.T @ A))
    rows.append(dict(k=k, s=s, n=n, max_mod=float(mods[0]), second_mod=float(mods[1]),
                     sigma1=float(sv[0]), sigma2=float(sv[1]),
                     kappa=float(sv[1] / max(mods[1], 1e-12)),
                     nonnorm_defect=nonnorm))
    print(f"DB({k},{s}) n={n}: rho={mods[0]:.6f} (2nd modulus {mods[1]:.3e}) "
          f"sigma_1={sv[0]:.6f} sigma_2={sv[1]:.6f} kappa={rows[-1]['kappa']:.4f} "
          f"||AA^T-A^TA||_F={nonnorm:.4e}")
out["debruijn"] = rows

print()
print("=== (D) line digraphs DL(G), Ihara-Bass check ===")
def cycle(n):
    return [(i, (i + 1) % n) for i in range(n)]

def complete(n):
    return [(i, j) for i in range(n) for j in range(i + 1, n)]

def petersen():
    outer = [(i, (i + 1) % 5) for i in range(5)]
    inner = [(5 + i, 5 + (i + 2) % 5) for i in range(5)]
    spokes = [(i, 5 + i) for i in range(5)]
    return outer + inner + spokes

def k33():
    return [(i, 3 + j) for i in range(3) for j in range(3)]

def heawood():
    # 3-regular bipartite, 14 vertices
    E = []
    for i in range(7):
        E.append((i, 7 + i)); E.append((i, 7 + (i + 1) % 7)); E.append((i, 7 + (i + 3) % 7))
    return E

def hashimoto(G):
    arcs = []
    nb = {}
    for (u, v) in G:
        arcs.append((u, v)); arcs.append((v, u))
        nb.setdefault(u, set()).add(v); nb.setdefault(v, set()).add(u)
    idx = {a: i for i, a in enumerate(arcs)}
    B = np.zeros((len(arcs), len(arcs)))
    for (u, v) in arcs:
        for w in nb[v]:
            if w != u:
                B[idx[(u, v)], idx[(v, w)]] += 1
    return B, idx

def adj(G, n):
    A = np.zeros((n, n))
    for (a, b) in G:
        A[a, b] = 1; A[b, a] = 1
    return A

rows = []
for name, G, n, d in [("C_6", cycle(6), 6, 2), ("C_7", cycle(7), 7, 2), ("K_4", complete(4), 4, 3),
                      ("K_{3,3}", k33(), 6, 3), ("Petersen", petersen(), 10, 3),
                      ("Heawood", heawood(), 14, 3)]:
    k = d - 1
    B, idx = hashimoto(G)
    A = adj(G, n)
    wG = np.linalg.eigvals(A)
    wB = np.linalg.eigvals(B)
    # predicted spectrum of DL(G) from the Ihara-Bass formula
    pred = []
    for lam in wG:
        disc = lam * lam - 4 * k
        pred.append((lam + np.sqrt(disc + 0j)) / 2)
        pred.append((lam - np.sqrt(disc + 0j)) / 2)
    pred += [1.0] * (len(G) - n) + [-1.0] * (len(G) - n)
    pred = np.array(pred, dtype=complex)
    # match sorted-by-modulus multisets
    a = np.sort_complex(np.round(pred, 6))
    b = np.sort_complex(np.round(wB, 6))
    ok = bool(np.allclose(np.sort(np.round(pred, 6)), np.sort(np.round(wB, 6)), atol=1e-6))
    # consistent convention (Section 4.4): exclude peripheral eigenvalues |lam| = d = k+1 first
    nonperiph = [x for x in np.sort(np.abs(wG))[::-1] if abs(x - d) > 1e-7]
    lam2G = float(nonperiph[0]) if nonperiph else 0.0
    ramanujan = bool(lam2G <= 2 * np.sqrt(k) + 1e-9)
    nontriv = [abs(z) for z in wB if abs(abs(z) - k) > 1e-8]
    sv = np.linalg.svd(B, compute_uv=False)
    count_sv_k = int(np.sum(np.abs(sv - k) < 1e-8))
    rows.append(dict(graph=name, n=n, d=d, k=k, ib_ok=ok,
                     max_nontriv_mod=float(max(nontriv)) if nontriv else None,
                     sqrt_k=float(np.sqrt(k)), lam2_G=float(lam2G),
                     ramanujan_G=ramanujan, count_singular_k=count_sv_k,
                     rho=float(max(abs(z) for z in wB))))
    print(f"{name:9s} d={d} k={k}: Ihara-Bass match={ok}; rho_all(DL)={max(abs(z) for z in wB):.6f} "
          f"sqrt(k)={np.sqrt(k):.6f}; non-peripheral max|lam(G)|={lam2G:.6f} Ramanujan={ramanujan}; "
          f"#(singular value k)={count_sv_k} vs |V_G|={n}")
out["line_digraph"] = rows

with open("raw/exact_examples.json", "w") as f:
    json.dump(out, f, indent=1)
print("\nwritten raw/exact_examples.json")
