# Batch 060 / m1 (direction 4): independent verification, counterexamples, singular-case audit

**Status.** This is the adversarial-verification deliverable, not a re-derivation of the
secular laws. Everything below is either (a) an exact symbolic identity I re-derived and
checked myself, (b) an exact closed form I solved myself, (c) a fixed-seed numerical
comparison with the raw output retained, or (d) an explicit erratum. Two of the findings
change a *conclusion* (not just a constant) in the batch-060 target document, and one
corrects a displayed formula that is present both in the target and in the frozen
batch-050 `THEOREM.md`. No frozen file was modified.

Scripts: `scripts/verify_symbolic.py`, `scripts/separated_limit.py`, `scripts/numerics.py`
(`scripts/numerics_v1_buggy.py` is retained deliberately: it documents three bugs of mine
— wrong sign in the secular function, unordered-pair kernel sum, and `T=N(c)` accidentally
including `c` — all found by the checks themselves; its third "bug" produced the
third-family confirmation in §7.3).

Raw output: `out/verify_symbolic.txt`, `out/separated_limit.txt`, `out/numerics_all.txt`,
`out/numerics_raw.json`.

---

## 0. Conventions used and checked

For `d >= 3`, `lambda > 2 sqrt(d-1)`, `r = r(lambda)` the small root of
`(d-1) r + 1/r = lambda` (so `0 < r < 1/sqrt(d-1) < 1`),

```
G_d(lambda) = r/(1-r^2) = 1/(lambda - d r) ,      (lambda - d r) = (1-r^2)/r > 0
(lambda - A_{T_d})^{-1}_{x y} = G_d(lambda) r^{dist(x,y)}
Sigma_n(lambda) = lambda - 1_T^T (lambda I - A)^{-1} 1_T          (zeros = new eigenvalues)
Phi_T(lambda)   = lambda - G_d(lambda) * sum_{s,t in T} r(lambda)^{rho(s,t)}
```

All three are verified exactly in `out/verify_symbolic.txt` §A–B: the branch identities,
the resolvent residual identity at distance 0 and at every distance `k >= 1`, and the
one-sided recursion. The finite-`n` secular identity `p_{G'}(lambda) = p_G(lambda)
Sigma_n(lambda)` with this **sign** convention is verified in exact rational arithmetic on
three explicit host graphs (§H) — this pins the sign that matters for the Perron term.

---

## 1. Adjacent pair `T={c,u}`, `rho(c,u)=1`: complete law

Kernel (exact, §C):

```
K_adj = G_d (2+2r) = 2r/(1-r) ,    K_adj(b) = 2/(sqrt(d-1)-1) ,  b = 2 sqrt(d-1)
Phi_adj(b) = b - K_adj(b) = 2 (s^2-s-1)/(s-1) ,   s = sqrt(d-1)
```

`K_adj` is increasing in `r` and `lambda` is decreasing in `r`, so `Phi_adj' > 1` on
`(b,inf)`: **strictly increasing, at most one root, always simple, no repeated root
exists in the claimed range.** Root existence is exactly the sign of `Phi_adj(b)`:

```
root exists  <=>  s^2 - s - 1 < 0  <=>  sqrt(d-1) < (1+sqrt5)/2  <=>  d < (5+sqrt5)/2 .
```

Exact check for every integer `d >= 3`: `s^2-s-1 = (d-2) - sqrt(d-1)`, and
`(d-2)^2-(d-1) = d^2-5d+5 > 0` for `d >= 4`, while for `d = 3` it is `1-sqrt2 < 0`.
**Hence the adjacent pair has an exterior secular root if and only if `d = 3`**, and

```
d = 3:  2 r^3 + r - 1 = 0 ,  r* = 0.5897545123... ,
        lambda*_adj = 2r*/(1-r*) = 2.8751297941627788260... ,
        minimal polynomial  lambda^3 - lambda^2 - 4 lambda - 4 = 0 ,
        Phi_adj'(lambda*) = 14.57906602...  > 0   (simple).
```

Limiting eigenvalue assignment (with the interlacing/zero-counting of 050 §4):
`lambda*_adj = 2.8751298 < d = 3`, so

```
d = 3 :  lambda_2(G'_n) -> 2.8751297942 ,   lambda_1(G'_n) -> 3 = d
d >= 4:  no exterior root;  lambda_2(G'_n) -> b = 2 sqrt(d-1) ,  lambda_1(G'_n) -> d
```

**Trap that is real, and that I reproduces exactly (§D).** Eliminating `r` between
`lambda = 2r/(1-r)` and the quadratic gives `lambda^3-(d-2)lambda^2-4lambda-4 = 0`, which
has a positive root for *every* `d >= 3` (`d=4`: `3.4798157`; `d=5`: `4.1844`; ...). For
`d >= 4` those roots are **not** secular roots: they sit on the non-physical branch
`r = lambda/(lambda+2)` (`d=4`: `0.63502` vs the physical `0.52491`, with
`1/sqrt(d-1) = 0.57735`), and there `Phi_adj = +1.270`, not `0`. A root of an algebraic
elimination is not a spectral zero unless the branch is checked.

**Host Perron point.** `Phi_adj(d) = (d^2-2d-2)/(d-2) = 0` iff `d = 1+sqrt3`, irrational:
for integer `d` the host Perron point is never a root of the adjacent-pair law. It is a
pole of the *finite-`n`* secular function with residue `-|T|^2/n = -4/n`, and
`d notin sigma(G'_n)` because `1_T^T 1 = 2 != 0`.

---

## 2. Full neighbourhood `T = N(c)`, all pairs at distance 2: complete law

Kernel (exact, all three forms identical as rational functions of `r`, §E):

```
K_N = G_d [ d + d(d-1) r^2 ] = d lambda r/(lambda - d r) = d r + d^2 r^2/(lambda - d r)
```

**Pole audit.** `lambda - d r = (1-r^2)/r > 0` on the whole physical branch, so the
alternative form has **no pole in the closure of `(2 sqrt(d-1), inf)`**; its formal pole
would need `lambda = d r` together with the quadratic, i.e. `r^2 = 1`, `lambda = +-d`,
which is the *other* branch (`|r| = 1 > 1/sqrt(d-1)`). Likewise `2r/(1-r)` has its only
pole at `r = 1`, i.e. `lambda = d` on the other branch. These are poles of algebraic
representations, not spectral poles. At the physical point `lambda = d` one has
`r = 1/(d-1)` and `K_N(d) = d/(d-2)`, `G_d(d) = (d-1)/(d(d-2))`: finite.

`Phi_N = lambda - K_N` is strictly increasing on `(b,inf)` (`K_N` increasing in `r`,
`lambda` decreasing in `r`). The numerator `r(1-r^2) Phi_N = 1 - 2r^2 - (d^2-1) r^4`
gives the exact root:

```
r* = 1/sqrt(d+1) ,   lambda*_N = 2d/sqrt(d+1) ,   Phi_N'(lambda*_N) = 2(d+1) > 0
lambda*_N^2 - b^2 = 4/(d+1) > 0      (always above the bulk edge)
d^2 - lambda*_N^2 = d^2 (d-3)/(d+1)  (=> lambda*_N <= d, equality exactly at d = 3)
Phi_N(b) = -4 sqrt(d-1)/(d-2) < 0     (root exists for every d >= 3, incl. d = 4)
```

Limiting eigenvalue assignment: since `lambda*_N <= d` for every integer `d >= 3`,

```
d = 3 :  lambda*_N = 3 = d  exactly  (critical, see §3)
d >= 4:  lambda_2(G'_n) -> 2d/sqrt(d+1) < d ,   lambda_1(G'_n) -> d
```

**Host Perron point vs pattern root.** `Phi_N(d) = d(d-3)/(d-2)`, so `d` is a root of the
pattern law **exactly at `d = 3`**. This is the integer realisation of the case that the
frozen separated model excluded by nonintegrality (`d^2(d-2)/(d-1) notin Z`): the
exclusion does not carry over, and here it is attained by an explicit integer pattern.
The Perron point remains a pole of `Sigma_n` and is still **not** an eigenvalue of `G'`
(`1_T^T 1 = d != 0`); the two zeros of `Sigma_n` squeeze against the pole from both sides.

---

## 3. The critical case `(d,T) = (3, N(c))`: correct scaling is `n^{-1/2}`, not `n^{-1}`

With `Sigma_n(lambda) = Phi(lambda) - |T|^2/(n(lambda-d)) + o(1)`:

* non-critical (`Phi(d) != 0`): writing `lambda = d - s/n` forces `s = |T|^2/(-Phi(d)) =
  O(1)`, i.e. the 050 `n^{-1}` law;
* critical (`Phi(d) = 0`, `Phi'(d) != 0`): writing `lambda = d - sigma n^{-1/2}` gives
  `Sigma_n = -Phi'(d) sigma n^{-1/2} + |T|^2/(sigma n^{1/2}) + o(n^{-1/2})`, hence

```
sigma = |T| / sqrt(Phi'(d))   and    n^{1/2} (d - lambda_2),  n^{1/2} (lambda_1 - d)
                                 ->  |T| / sqrt(Phi'(d))
```

For `T = N(c)`, `d = 3`: `|T| = 3`, `Phi_N'(3) = 8`, so the constant is `3/sqrt8 =
1.060660...`, and both eigenvalues satisfy `lambda_{1,2} = 3 +- 1.0607 n^{-1/2}`. The
`n^{-1}` law of 050 §2.5 would be wrong here by a factor `sqrt(n)`.

Numerical confirmation (§7.2): `sqrt(n)(3-lambda_2) = 1.0820, 1.0833, 1.1419, 0.9948`
and `sqrt(n)(lambda_1-3) = 1.0269, 1.0345, 0.9969, 1.1134` at `n = 1e3, 2e3, 4e3, 8e3`,
against the predicted `1.06066`. The spread is `O(n^{-1/6})`, the size expected from the
`n^{-2/3}` edge fluctuation, so this is agreement, not tuning.

**Remainder condition for this scaling (honest caveat).** The passage uses the
pattern-resolvent limit with an error that is `o(n^{-1/2})` at the rescaled energy
`lambda = d - sigma n^{-1/2}`. For the 050 walk-expansion proof the error is
`O(rho^{L_n}) + O(L_n/n)` with `L_n = c log_{d-1} n`, and at `lambda = d(1+O(n^{-1/2}))`
the factor `(d/lambda)^k` is `1+O(k n^{-1/2})`, still `O(\log n/n)`. So the same proof
gives it, but **the critical law is only as good as that remainder estimate at rescaled
energies; it should be stated explicitly in the family theorem.** This is the one place
where I would not accept the critical case from the limit statement alone.

---

## 4. General pattern threshold, instantiated

Exactly (`out/separated_limit.txt` §6): with `sigma(lambda) = sum_{s,t} r^{rho(s,t)}`,

```
K_T(b) = G_d(b) sigma(b) = sqrt(d-1)/(d-2) * sigma(b) ,
K_T(b) > b = 2 sqrt(d-1)   <=>   sigma(b) = sum_{s,t} (d-1)^{-rho(s,t)/2} > 2(d-2)
```

and at the boundary `sigma(b) = 2(d-2)` the contact is of **order 1/2**: `r(b+eps) =
1/s - sqrt(eps)/s^{3/2} + O(eps)`, so `Phi_T(b+t^2)` has a nonzero linear term in `t`
(one-sided square-root contact at the branch point), not a double interior root. For
neither family does this boundary case occur for integer `d`: the adjacent pair needs
`s^2-s-1 = 0` (no integer solution) and `N(c)` needs `2d = 2(d-2)` (impossible). So the
answer to "repeated root or `lambda_f = d`" for these two families is: **no repeated
exterior root at all; `lambda_f = d` exactly at `(d,T) = (3,N(c))` and nowhere else.**

---

## 5. Independent restoration of the separated-distance limit (frozen 050 untouched)

`out/separated_limit.txt` §2–4, re-derived from scratch, no appeal to the frozen proof
beyond the statement to be checked:

```
lambda = Delta G_d  <=>  (d-1) r^4 + (Delta+2-d) r^2 - 1 = 0
                    <=>  u^2 - (d^2-(d-2)Delta) u - (d-1)Delta^2 = 0 ,  u = lambda^2
```

i.e. exactly `lambda_f^2 = [d^2-(d-2)Delta + sqrt((d^2-(d-2)Delta)^2+4(d-1)Delta^2)]/2`
(the resultant check passes up to the harmless factor `-(d-1)`), and

```
Phi_sep(b) = s (2 s^2 - 2 - Delta)/(s^2-1)  =>  root iff Delta > 2(d-2)
lambda_f - b = (sqrt(d-1)/(4 d^2)) (Delta-2(d-2))^2 + O(eps^3)      [050 item 4 verified]
```

The clustered laws degenerate to this one exactly in the `rho -> infinity` limit
(`sigma -> |T|`); they do **not** degenerate as `lambda -> infinity` for fixed pattern
(`sigma_adj = 2+2r -> 2` only because `r -> 0`, at the same time). Contact at
`Delta = 2(d-2)` is again order `1/2`, so `(d,Delta) = (3,2)` is the separated model's own
critical integer case — a legitimate old-case branch that the clustered adjacent pair
avoids (`lambda*_adj = 2.8751 > b = 2.8284`).

---

## 6. Errata (separate files, frozen documents untouched)

1. `ERRATUM-060-target-Kadj-edge-value.md` — the target's `K_adj(b) = 2/(1-1/sqrt(d-1))`
   is wrong by the factor `sqrt(d-1)`; the correct value is `2/(sqrt(d-1)-1)`, and the
   conclusion "distinguishes d=3,4" becomes "only d=3". (Independently found by m4/d1;
   both derivations agree.)
2. `ERRATUM-block-inverse-diagonal.md` — the `T=N(c)` block-inverse **diagonal** printed in
   the target ("diagonal `G_d + r^2/(lambda-dr)`") and in the frozen batch-050
   `THEOREM.md` §4.1(b) is wrong. Exact: diagonal `= r + r^2/(lambda-Delta r)`, which for
   `Delta = d` equals `G_d` **exactly** (transitivity of the `d`-regular tree). The
   off-diagonal entry `r^2/(lambda-dr)` and the closed form `d lambda r/(lambda-dr)` are
   correct; the printed diagonal is inconsistent with the same document's closed form
   (`d = 3, lambda = 3.2`: printed diagonal gives sum `2.4094`, closed form `2.12637`).

**Source-applicability note (not an erratum; no mathematics is wrong).** In the
no-exterior-root case (`lambda* = b`) the assignment `lambda_2(G') -> 2 sqrt(d-1)` uses,
besides interlacing, the *lower* edge `lambda_2(A_n) >= b - o(1)` w.h.p. Interlacing alone
gives only `lambda_2(G') >= lambda_2(A_n)`, which is the wrong direction for an upper
limit. The needed input is the **global** Kesten–McKay law (fixed interval `[b-eps,b]` has
positive limit mass, hence `Theta(n)` eigenvalues there) — strictly weaker than Friedman's
bound, but a separate named input; 050's sentence "using host interlacing for the lower
bound" should name it. My numerics confirm that this is not a technicality: in the
no-root case the measured gap `lambda_2(G') - lambda_2(A_n)` decays `4.97e-3, 1.67e-3,
3.1e-4` at `n = 1e3, 2e3, 4e3`, i.e. the two eigenvalues are asymptotic to each other.

---

## 7. Fixed-seed numerics (corroboration only)

Sampler: pairing model with rejection on loops/multi-edges — exactly uniform on simple
`d`-regular graphs after acceptance (each simple graph has `(d!)^n` realisations).
Seeds are printed per row; `c = 0` fixed; `adj: T = {0, min N(0)}`; `N: T = N(0)`;
`C: T = {0} u N(0)` (third family, mixed distances, added by me).
`Sigma_n(lambda_i(G'))` is the exact finite-`n` secular function evaluated at the
eigensolver's eigenvalue, so `~1e-13` is a genuine identity check, not a fit.

### 7.1 Secular identity and resolvent values (pattern vs separated)

`|Sigma_n(lambda_i)| <= 4e-11` in all 30 (row, eigenvalue) checks; the bracketed interior
secular zero agrees with the direct eigensolver `lambda_2` to `<= 1.5e-14`
(agreement is `1e-15` whenever the zero is not within `5e-3` of `d`).

Resolvent `1_T^T (lambda I - A)^{-1} 1_T`, `d = 3`, `n = 8000` (seed 20250609):

| `lambda` | `T` | measured | pattern `G_d sigma_T` | separated `|T| G_d` |
|---|---|---|---|---|
| 3.2 | adj | 1.484664 | 1.483315 | 1.040314 |
| 3.2 | N(c) | 2.130621 | 2.126406 | 1.560470 |
| 3.2 | C | 3.982827 | 3.975566 | 2.080627 |
| 4.5 | adj | 0.666669 | 0.666667 | 0.533333 |
| 4.5 | N(c) | 0.900014 | 0.900000 | 0.800000 |
| 4.5 | C | 1.566687 | 1.566667 | 1.066667 |

`d = 4`, `n = 4000` (seed 20250612): `lam=4.5` adj 0.745386 vs 0.744563 (sep 0.585677);
`N` 1.432304 vs 1.429975 (sep 1.171353); `C` 2.361836 vs 2.358358 (sep 1.464191);
`lam=6.0` adj 0.449516 vs 0.449490; `N` 0.836379 vs 0.836326; `C` 1.305071 vs 1.304999.
The separated value is wrong by 26–43% in the same rows; the pattern value is right to
`3e-4`–`4e-3`. The residual is largest nearest the bulk edge, as the `rho^{L_n}` error
bound predicts.

### 7.2 Eigenvalue limits

```
d=3, T=adj (lambda*=2.8751297942):
  n= 1000 lam2=2.87497463 lam1=3.00386986
  n= 2000 lam2=2.87321186 lam1=3.00196055
  n= 4000 lam2=2.87259181 lam1=3.00098554
  n= 8000 lam2=2.87734959 lam1=3.00049936        (b = 2.8284271, d = 3)
d=3, T=N(c) (lambda*=3 exactly, critical):
  n= 1000 lam2=2.96578455 lam1=3.03247253  sqrt(n)(3-lam2)=1.08199 sqrt(n)(lam1-3)=1.02687
  n= 2000 lam2=2.97577575 lam1=3.02313151  sqrt(n)(3-lam2)=1.08334 sqrt(n)(lam1-3)=1.03447
  n= 4000 lam2=2.98194584 lam1=3.01576262  sqrt(n)(3-lam2)=1.14185 sqrt(n)(lam1-3)=0.99692
  n= 8000 lam2=2.98887748 lam1=3.01244801  sqrt(n)(3-lam2)=0.99483 sqrt(n)(lam1-3)=1.11338
        predicted constant 3/sqrt8 = 1.06066
d=4, T=adj (no exterior root; lambda_2 -> b = 3.4641016):
  n= 1000 lam2=3.45124442 lam1=4.00132900 ; lambda_2(A)=3.44627442
  n= 2000 lam2=3.45386217 lam1=4.00066507 ; lambda_2(A)=3.45219093
  n= 4000 lam2=3.46690029 lam1=4.00033307 ; lambda_2(A)=3.46658726
d=4, T=N(c) (lambda*=8/sqrt5=3.5777087640):
  n= 1000 lam2=3.58201630 lam1=4.00792517
  n= 2000 lam2=3.56709590 lam1=4.00393200
  n= 4000 lam2=3.57224795 lam1=4.00198294
```

### 7.3 The `lambda* > d` branch, confirmed empirically (`T = {c} u N(c)`)

This family was not in the target brief; it exercises the branch that neither primary
family reaches. Kernel `sigma_C = (d+1) + 2d r + d(d-1) r^2` (pairs at distance 1 and 2).

```
d=3: lambda*_C = 3.3423292192 > d ;  lam1 = 3.34437127, 3.34337448, 3.34249305, 3.34286953
     (n=1e3..8e3), lam2 = 2.99402805, 2.99700392, 2.99848722, 2.99925666 -> 3 = d
d=4: lambda*_C = 3.8660605560 > d ;  lam1 = 4.03303902, 4.01708441, 4.00917568,
     lam2 = 3.84073548, 3.84159128, 3.85332173 (still approaching 3.866 from below)
```

So the assignment `lambda_1 -> max(d,lambda*)`, `lambda_2 -> min(d,lambda*)` is observed
in all three regimes: `lambda* < d` (adj, d=3), `lambda* = d` (N, d=3), `lambda* > d`
(C, d=3 and d=4).

---

## 8. Independent review of the other members' findings (as of this writing)

Reproduced or cross-checked exactly by me:

* m4/d1 and m3/d2 both state `K_adj(b) = 2/(sqrt(d-1)-1)` and "only d=3": **agrees with
  my independent computation**, and my `Phi_adj(b) = 2(d-2-s)/(s-1)` is identical to
  m4's `2(d-sqrt(d-1)-2)/(sqrt(d-1)-1)`; m4's `Phi_adj' = 1 + 2r^2/((1-r)^2(1-(d-1)r^2))`
  reproduces my `14.57906602` at `d=3,r=r*`. Their spurious-branch warning
  (`d=4: 3.4798157` spurious, `Phi = +1.270`) is exactly my §1.
* m2/d3's `Phi_adj(e) = 2[s(d-3)-1]/(d-2)` is algebraically equal to mine
  (`2(s^3-2s-1)/(d-2)`); their `d=3` equation `2r^4+2r^3+r^2-1 = 0` is
  `(1+r)(2r^3+r-1)`, so it carries the harmless spurious factor `r = -1` (non-physical
  branch); the stated root `0.5897545, 2.8751298` agrees with mine.
* m3/d2 and m2/d3 both give `lambda*_N = 2d/sqrt(d+1)`, `Phi_N'(lambda*) = 2(d+1)`,
  `Phi_N(d) = d(d-3)/(d-2)`, `d=3` critical, and the `n^{-1/2}` scaling `3/sqrt(8n)`:
  **all four members agree**, and my `out/numerics_all.txt` confirms the constant
  numerically.
* m3's `K_N(d) = d/(d-2)` and its pole audit (`lambda - dr = (1-r^2)/r`, pole only at
  `r^2 = 1`, `lambda = +-d`) agree with mine.

Not covered by anyone else and supplied here: the block-inverse diagonal erratum, the
general threshold criterion with its order-`1/2` edge contact, the verification that 050's
`n^{-1}` finite-size constant is `|T|^2/(-Phi(d))` in the non-critical case, the `n^{-1/2}`
critical constant `|T|/sqrt(Phi'(d))`, the `lambda* > d` numerical confirmation, and the
lower-edge source note of §6.

---

## 9. What is still missing, stated precisely

1. **Not proved by me (and not provable by verification):** the pattern resolvent limit
   `sup_{lambda in K} |Sigma_n(lambda) - Phi_T(lambda)| -> 0` itself. I verified its
   kernels, its finite-`n` sign convention and its numerical predictions; the limit is
   m2/m3/m4's. A family theorem must therefore cite that limit and the two probabilistic
   inputs (Friedman/Bordenave; global Kesten–McKay for the lower edge).
2. **Remainder at rescaled energies:** the critical `n^{-1/2}` law needs the resolvent
   remainder to be `o(n^{-1/2})` uniformly on `[d - delta, d + delta]`. That is plausible
   from the same walk expansion but must be stated as a hypothesis if not re-proved.
3. **Multiplicity:** for `T_adj` and `T=N(c)` the limiting kernel has `Phi' > 1`
   everywhere on the exterior domain, so no repeated exterior root exists; host eigenvalue
   multiplicity does not enter the *limits* (`lambda_2(G')` is the unique zero of
   `Sigma_n` in the gap for every `n`), but it does enter the pseudoinverse criterion at
   an exact coincidence with `lambda_2(A_n)`, which none of my runs exhibits.
4. **Bulk and edge window:** nothing here says anything about `lambda <= b` or the `n^{-2/3}`
   edge scale; the `d=3` adjacent-pair prediction (`lambda_2 -> 2.8751`) is a constant
   distance `0.047` above `b`, which is why it is numerically resolvable while anything
   within `n^{-2/3}` of `b` is not.

---

## 10. Pattern-level finite-size law at the Perron pole (derived and verified here)

This is the item the target calls "any differing displacement near $d$, rather than
replacing only $\Delta$ in the old constant without derivation". Derivation is one line
from the balance already used in §3, so I state it as a claim with its exact constants;
`scripts/finite_size_law.py`, `out/finite_size_law.txt`.

**Claim.** Let $\Sigma_n(\lambda)=\Phi_T(\lambda)-|T|^2/(n(\lambda-d))+o(1)$ uniformly for
$|\lambda-d|\le\delta$, with $\Phi_T$ $C^1$ and $\Phi_T(d)\neq0$. Then on the side of $d$
on which the new eigenvalue lies between $d$ and the pattern-law root,

$$n\,|\lambda_i(G_n')-d|\;\longrightarrow\;\frac{|T|^2}{|\Phi_T(d)|}
=\frac{|T|^2\,d(d-2)}{\big|d^2(d-2)-(d-1)\sigma_T(d)\big|},\qquad
\sigma_T(d)=\sum_{s,t}(d-1)^{-\rho(s,t)} .$$

*Derivation.* Put $\lambda=d+t/n$: $\Sigma_n=\Phi_T(d)+\Phi_T'(d)t/n-|T|^2/t+O(\log n/n)$.
A finite zero $t$ requires $t\xi=\Phi_T(d)t-|T|^2=0$ up to $O(1/n)$, so
$t\to|T|^2/\Phi_T(d)$ and the correction is $O(1/n)$. (If $\Phi_T(d)=0$ the quadratic term
in $t$ is absent, the balance is $\Phi_T'(d)t/n=|T|^2/t$, and $t=\Theta(\sqrt n)$: §3.)

**The separated case is the special case $\sigma_T=|T|=\Delta$**, where
$\Phi_{\rm sep}(d)=d-\Delta G_d(d)=-\big(\Delta(d-1)-d^2(d-2)\big)/(d(d-2))$ and the
constant becomes $\Delta^2/|\Delta G_d(d)-d|=\Delta^2d(d-2)/|\Delta(d-1)-d^2(d-2)|$,
i.e. exactly the 050 §2.5 constant — recovered, not replaced.

**Exact constants and the measured rows** (same seeds as §7; `n|λ_i-d|` in the last
column):

| $d$ | $T$ | $\Phi_T(d)$ | predicted | measured $n|\lambda_i-d|$ |
|---|---|---|---|---|
| 3 | adj | $1$ | 4 | 3.8699, 3.9211, 3.9422, 3.9949 |
| 3 | N(c) | $0$ | critical $3/\sqrt8=1.06066$ | $\sqrt n$ version: 1.082, 1.083, 1.142, 0.995 / 1.027, 1.034, 0.997, 1.113 |
| 3 | C | $-8/3$ | 6 | 5.9719, 5.9922, 6.0511, 5.9467 |
| 4 | adj | $3$ | $4/3$ | 1.3290, 1.3301, 1.3323 |
| 4 | N(c) | $2$ | 8 | 7.9252, 7.8640, 7.9318 |
| 4 | C | $5/8$ | 40 | 33.04, 34.17, 36.70 (still increasing) |

Six independent non-trivial constants (including the irrational-free $4/3$ and $8$) match
to the accuracy the $O(1/n)$ and $n^{-2/3}$ corrections allow. The $T=C$, $d=4$ row is the
slowest because $n|\lambda_1-4|$ converges only after the edge fluctuation has decayed;
it is monotone towards 40, and I would not call it confirmed.

**What this fixes in the batch's requirements.** The pattern enters the near-$d$
displacement only through $|T|^2$ and $\Phi_T(d)$; substituting a "pattern effective
degree" into 050's $\Delta$-constant would be correct only when $\sigma_T(d)=|T|$ (the
separated case). For the two primary families: adjacent pair, $d=3$: $n(\lambda_1-3)\to4$;
adjacent pair, $d\ge4$: $n(\lambda_1-d)\to|T|^2/\Phi_{\rm adj}(d)$; $N(c)$, $d\ge4$:
$n(\lambda_1-d)\to d(d-2)/(d-3)$ (equals 8 at $d=4$); $N(c)$, $d=3$: the critical
$n^{-1/2}$ law of §3.

---

## 11. Independent confirmation of the rank-one resolvent-identity erratum (m4/d1)

m4's erratum on the frozen identity is **correct, and I reproduced it exactly**
(Petersen graph, `d=3`, `n=10`, `T` an edge, `lambda=5/2`, exact rational arithmetic):

```
true      1_T^T (A-lambda I)^{-1} 1_T          = -4/27 = -0.148148148148
frozen    D^2/(n(d-lambda)) - sum_k 1^T A'^k 1/lambda^{k+1}  = -0.308148148148
repaired  ... + D^2/(n lambda)                 = -0.148148148148   (residual 0)
```

Cause, verified as an operator identity: `(A'-lambda I)^{-1} = -P/lambda + Q(A'-lambda I)^{-1}Q`,
hence `(A-lambda I)^{-1} = P/(d-lambda) + P/lambda + (A'-lambda I)^{-1}` — the frozen
formula omits `+P/lambda`. In quadratic form the omission is exactly `+|T|^2/(n lambda)`,
so the corrected decomposition is

```
1_T^T(A-lam)^{-1}1_T = |T|^2/(n(d-lam)) + |T|^2/(n lam) - sum_k 1_T^T A'^k 1_T / lam^{k+1}
```

and the error list of the frozen Theorem A should carry `(|T|^2/(n lambda)) sum_{k=0}^{L}(d/lambda)^k`,
not `sum_{k=1}^{L}`.

**Impact on this report: none.** (i) The limit statements are unchanged since the term is
`O(1/n)` at fixed `lambda`. (ii) The finite-size constants of §10 are unchanged: with
`lambda = d + t/n` the extra term is `|T|^2/(nd) + O(1/n^2)`, so writing `t = t_0 + delta`
gives `delta = -t_0^2(Phi_T'(d) t_0 + |T|^2/d)/n = O(1/n)` and `t_0 = |T|^2/Phi_T(d)` is
untouched; for the critical case the term is again lower order than `n^{-1/2}`.
(iii) My numerical checks never used the frozen identity: they evaluate
`Sigma_n` by direct sparse solves and compare with the eigensolver, so the agreement in
§7 is independent evidence for the *corrected* decomposition.

This is the one frozen-input defect I have confirmed; it is recorded in m4's
`ERRATUM-050-rank-one-resolvent-identity.md` and needs no second file from me.
