"""
bound_state_check.py -- certificate that the radial part of the spherically
homogeneous tree with root children 3 and children counts 2,1,2,1,... has the
eigenvalue sqrt(6), strictly above the top of its Floquet bands sqrt(2)+1.

Radial eigenvalue equation, k >= 1:   b_{k-1} u_{k-1} + b_k u_{k+1} = lam u_k
boundary condition at k = 0:          b_0 u_1 = lam u_0
with b = (sqrt3, sqrt2, 1, sqrt2, 1, ...)  (b_k = sqrt(n_k)).

Solution: u_0 = 1, u_1 = sqrt2, u_2 = sqrt(3/2), u_3 = 1, u_4 = sqrt3/2,
then u_{k+2} = u_k / sqrt2 for all k >= 3.  Decays like 2^(-k/4).
"""
import numpy as np
import sympy as sp


def b_of(k):
    if k == 0:
        return np.sqrt(3.0)
    return np.sqrt(2.0) if k % 2 == 1 else 1.0


def u_solution(K):
    u = [1.0, np.sqrt(2.0), np.sqrt(1.5), 1.0, np.sqrt(3.0)/2.0]
    for k in range(5, K + 1):
        u.append(u[k-2] / np.sqrt(2.0))
    return np.array(u[:K+1])


def main():
    import os
    os.makedirs("outputs", exist_ok=True)
    out = open("outputs/bound_state_check.txt", "w")
    lam = np.sqrt(6.0)
    K = 80
    u = u_solution(K)
    out.write("BOUND STATE CERTIFICATE\n")
    out.write("tree: root has 3 children, children counts 2,1,2,1,...\n")
    out.write(f"lambda = sqrt(6) = {lam:.17f}\n")
    out.write(f"Floquet band top sqrt(2)+1 = {np.sqrt(2)+1:.17f}, excess = {lam-(np.sqrt(2)+1):.6f}\n\n")
    out.write(f"boundary at the root: b_0 u_1 - lambda u_0 = {b_of(0)*u[1] - lam*u[0]:.3e}\n")
    res = np.array([b_of(k-1)*u[k-1] + b_of(k)*u[k+1] - lam*u[k] for k in range(1, K)])
    out.write(f"max |recursion residual| for 1<=k<={K-1}: {np.max(np.abs(res)):.3e}\n")
    out.write(f"max |recursion residual| for 1<=k<=12:  {np.max(np.abs(res[:12])):.3e}\n\n")
    out.write("ratio pattern u_{k+2}/u_k (should be 1/sqrt2 = %.12f for k>=3):\n" % (1/np.sqrt(2)))
    for k in range(0, 10):
        out.write(f"   k={k}: {u[k+2]/u[k]:.12f}\n")
    out.write("\nfirst 12 values:\n  " + ", ".join(f"{x:.8f}" for x in u[:12]) + "\n")
    out.write(f"\nsum_k u_k^2 (k<=200) = {np.sum(u_solution(200)**2):.12f}, so u is in l2\n")
    out.write(f"u_40 = {u_solution(40)[40]:.4e}, u_80 = {u_solution(80)[80]:.4e} (geometric decay 2^(-k/4))\n")

    # exact symbolic residuals for k = 1..6
    lam_s = sp.sqrt(6)
    us = [sp.Integer(1), sp.sqrt(2), sp.sqrt(sp.Rational(3, 2)), sp.Integer(1), sp.sqrt(3)/2,
          sp.sqrt(2)/2, sp.sqrt(3)/(2*sp.sqrt(2)), sp.Rational(1, 2)]
    bs = [sp.sqrt(3), sp.sqrt(2), 1, sp.sqrt(2), 1, sp.sqrt(2), 1, sp.sqrt(2)]
    out.write("\nexact symbolic residuals (must be exactly 0):\n")
    for k in range(1, 7):
        r = sp.simplify(bs[k-1]*us[k-1] + bs[k]*us[k+1] - lam_s*us[k])
        out.write(f"   k={k}: {r}\n")

    # independent check: spectra of Jacobi truncations
    out.write("\nJacobi truncations with off-diagonals sqrt(counts), zero diagonal:\n")
    for N in (100, 200, 400):
        b = np.array([np.sqrt(3.0)] + [np.sqrt(2.0) if k % 2 == 1 else 1.0 for k in range(1, N+1)])
        J = np.diag(b[:N], 1) + np.diag(b[:N], -1)
        ev = np.linalg.eigvalsh(J)
        above = ev[ev > np.sqrt(2)+1]
        out.write(f"   N={N}: #eigenvalues above sqrt2+1 = {len(above)}, top = {ev[-1]:.14f}, "
                  f"sqrt6 = {lam:.14f}, next below band top: {ev[-2]:.10f}\n")
    out.close()
    print(open("outputs/bound_state_check.txt").read())


if __name__ == "__main__":
    main()
